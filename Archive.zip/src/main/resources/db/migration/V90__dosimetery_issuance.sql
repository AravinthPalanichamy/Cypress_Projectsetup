create table dosimetry_issuance (
  id integer not null auto_increment,
  group_id varchar(25) not null,
  dosimetry_issuance_frequency_id integer not null,
  dosimetry_issuance_location_id integer not null,
  primary key(id),
  key FK_DosimetryIssuance_Frequency (dosimetry_issuance_frequency_id),
  key FK_DosimetryIssuance_Location (dosimetry_issuance_location_id),
  constraint FK_DosimetryIssuance_Frequency foreign key (dosimetry_issuance_frequency_id) references frequency (frequency_id),
  constraint FK_DosimetryIssuance_Location foreign key (dosimetry_issuance_location_id) references location (id)
);

alter table person
  add column dosimetry_issuance_id int default null,
  add constraint FK_Person_DosimetryIssuance foreign key (dosimetry_issuance_id) references dosimetry_issuance (id);

insert into frequency (frequency_name, time_in_days) values ('Weekly', 7);

alter table frequency add column display_order int not null;
update frequency set display_order = 1 where frequency_id = 5;
update frequency set display_order = 2 where frequency_id = 4;
update frequency set display_order = 3 where frequency_id = 1;
update frequency set display_order = 4 where frequency_id = 2;
update frequency set display_order = 5 where frequency_id = 3;
