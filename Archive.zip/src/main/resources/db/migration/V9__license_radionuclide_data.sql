SET @SYSTEM_USER_ID = 1;
SET @RP_UCT_PERSON_ID = 2;
SET @RSO_UCT_PERSON_ID = 3;
SET @RSCM_UCT_PERSON_ID = 4;
SET @AU_UCT_PERSON_ID_1 = 6;

SET @UCT_UA_ID_7 = 7;
SET @UCT_UA_BUNDLE_ID_7 = 7;

SET @UCT_CORE_BUNDLE_ID_7 = 7;
SET @UCT_CORE_BUNDLE_PERSON_ID_5 = 5;
SET @UCT_CORE_BUNDLE_LOCATION_ID_7 = 7;
SET @UCT_LOCATION_ID_1 = 1;
SET @UCT_LICENSE_ID = 11;

SET @UCT_CORE_BUNDLE_PERSON_ID_6 = 6;
SET @UCT_UA_BUNDLE_PERSON_ID_6 = 6;
SET @AU_UCT_PERSON_ID_3 = 8;
SET @UCT_CORE_BUNDLE_ID_2 = 2;
SET @UCT_UA_BUNDLE_ID_2 = 2;

SET @DE_UCT_PERSON_ID_1 = 19;
SET @UCT_CODE = '99';

-- For Data Backfill
-- Data Entry Analyst test
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `campus_code`) VALUES (@DE_UCT_PERSON_ID_1, 'testuser16@uctest.edu', 'user16@uctest.edu', 'Test16', 'User16', 'tst-16', @UCT_CODE);

-- Add Data_Entry Role test
INSERT INTO `person_role` (`person_role_id`, `role_type`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `person_id`) VALUES ('14', 'DATA_ENTRY_ANALYST', '2015-10-25 00:00:00', '2015-10-25 00:00:00', '1', '1', @DE_UCT_PERSON_ID_1);

-- fix for breaking ua-overview test every time CS is flushed
INSERT INTO `core_bundle`(`id`, `cs_id`,`name`,`pi_person_id`) VALUES (@UCT_CORE_BUNDLE_ID_7, 'r2d2', 'Dinosaurs Laser Lab', @RP_UCT_PERSON_ID);
INSERT INTO `core_bundle_person`(`id`, `core_bundle_id`,`person_id`) VALUES (@UCT_CORE_BUNDLE_PERSON_ID_5, @UCT_CORE_BUNDLE_ID_7, @AU_UCT_PERSON_ID_1);
INSERT INTO `core_bundle_location`(`id`, `core_bundle_id`,`location_id`) VALUES (@UCT_CORE_BUNDLE_LOCATION_ID_7, @UCT_CORE_BUNDLE_ID_7, @UCT_LOCATION_ID_1);

-- Sync with UI
ALTER TABLE `ua_bundle_location` MODIFY COLUMN `sub_location` VARCHAR(1000);

-- Add Authorized User flag to ua_bundle_person
ALTER TABLE `ua_bundle_person` ADD `is_authorized_to_work` BOOLEAN DEFAULT FALSE NOT NULL;


-- test data
INSERT INTO `ua` (`id`, `number`,`pi_person_id`, `status_type`, `type`, `expiry_date`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `is_active`) VALUES (@UCT_UA_ID_7, 7, @RSCM_UCT_PERSON_ID, 'APPROVED', 'RUA', '2015-10-30 00:00:00', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @RSCM_UCT_PERSON_ID, @RSCM_UCT_PERSON_ID, true);
INSERT INTO `ua_planned_work` (`ua_pw_id`, `chemical_form`, `description_of_use`, `potential_hazards`, `protection_precautions`, `waste_methods`, `experiment_possession_limit_mci`, `is_sealed_source`, `requested_possession_limit_mci`, `single_source_limit_mci`, `vial_possession_limit_mci`, `radionuclide_id`, `ua_id`, `license_line_number_id`, `purpose_type`, `research_type`, `physical_form_id`) VALUES (5, 'Danger1', 'Carefully.', 'It is radiation.', 'All required precautions.', 'Per guidelines.', 2.0, 1, 20.5, 0.5, 0.5, 108, 7, 1, 'CLINICAL', 'HUMAN', 1);
INSERT INTO `ua_bundle` (`id`, `ua_id`, `name`, `cs_id`) VALUES (@UCT_UA_BUNDLE_ID_7, @UCT_UA_ID_7, 'Test Lab 6', '6');
INSERT INTO `ua_bundle_location` (`location_id`,`ua_bundle_id`, `sub_location`) VALUES (@UCT_LOCATION_ID_1, @UCT_UA_BUNDLE_ID_7, 'Under The Hood');
INSERT INTO `soe` (`status_type`,`last_step_completed`, `ua_id`, `person_id`, `is_active`) VALUES ('SUBMITTED', 4, @UCT_UA_ID_7, @RSCM_UCT_PERSON_ID, true);

-- fixing radionuclide table
ALTER TABLE `radionuclide` ADD COLUMN `activity_mci_per_gram` DECIMAL(19,12);

UPDATE `radionuclide` SET `is_source_material`=TRUE WHERE `radionuclide_id`=304;

UPDATE `radionuclide` SET `activity_mci_per_gram`=0.00220 WHERE `radionuclide_id`=91;
UPDATE `radionuclide` SET `activity_mci_per_gram`=9.70000 WHERE `radionuclide_id`=89;
UPDATE `radionuclide` SET `activity_mci_per_gram`=230.00000 WHERE `radionuclide_id`=66;
UPDATE `radionuclide` SET `activity_mci_per_gram`=62.00000 WHERE `radionuclide_id`=65;
UPDATE `radionuclide` SET `activity_mci_per_gram`=62.00000 WHERE `radionuclide_id`=64;
UPDATE `radionuclide` SET `activity_mci_per_gram`=17000.00000 WHERE `radionuclide_id`=63;
UPDATE `radionuclide` SET `activity_mci_per_gram`=530000.00000 WHERE `radionuclide_id`=62;

UPDATE `radionuclide` SET `activity_mci_per_gram`=820000.00000 WHERE `radionuclide_id`=81;
UPDATE `radionuclide` SET `activity_mci_per_gram`=210.00000 WHERE `radionuclide_id`=82;
UPDATE `radionuclide` SET `activity_mci_per_gram`=21.00000 WHERE `radionuclide_id`=83;
UPDATE `radionuclide` SET `activity_mci_per_gram`=0.00011 WHERE `radionuclide_id`=84;
UPDATE `radionuclide` SET `activity_mci_per_gram`=0.00011 WHERE `radionuclide_id`=304;
UPDATE `radionuclide` SET `activity_mci_per_gram`=0.00071 WHERE `radionuclide_id`=87;
UPDATE `radionuclide` SET `activity_mci_per_gram`=6.20000 WHERE `radionuclide_id`=90;
UPDATE `radionuclide` SET `activity_mci_per_gram`=0.06500 WHERE `radionuclide_id`=92;
UPDATE `radionuclide` SET `activity_mci_per_gram`=0.00034 WHERE `radionuclide_id`=93;
UPDATE `radionuclide` SET `activity_mci_per_gram`=0.00022 WHERE `radionuclide_id`=95;
UPDATE `radionuclide` SET `activity_mci_per_gram`=0.00050 WHERE `radionuclide_id`=100;

-- Correcting UCMerced data typo
UPDATE `license_line_number` SET `name`='Cs-137' where `license_line_number_id`=15;

-- Adding missing data to test campus
UPDATE `license` SET `licensee`='University of California, Test Campus' where `license_id`=11;

--for line number mapping
UPDATE `line_number_item` SET `is_solid`=TRUE, `is_liquid`=TRUE, `is_gas`=TRUE, `is_powder`=TRUE WHERE `is_sealed_source`=TRUE;

--Creating new Radioactivity Units
INSERT INTO `radioactivity_unit` (`unit_id`, `unit_name`) VALUES ('8', 'kg');
INSERT INTO `radioactivity_unit` (`unit_id`, `unit_name`) VALUES ('7', 'μl');

UPDATE `radioactivity_unit` SET `unit_name`='μCi' where `unit_id`=2;
UPDATE `radioactivity_unit` SET `unit_name`='g' where `unit_id`=4;
UPDATE `radioactivity_unit` SET `unit_name`='lb' where `unit_id`=5;
UPDATE `radioactivity_unit` SET `unit_name`='mg' where `unit_id`=6;

INSERT INTO core_bundle_person (`id`, `core_bundle_id`,`person_id`) VALUES (@UCT_CORE_BUNDLE_PERSON_ID_6, @UCT_CORE_BUNDLE_ID_2, @AU_UCT_PERSON_ID_3);
INSERT INTO ua_bundle_person (`id`, `person_id`,`ua_bundle_id`, `is_authorized_to_work`) VALUES (@UCT_UA_BUNDLE_PERSON_ID_6, @AU_UCT_PERSON_ID_3, @UCT_UA_BUNDLE_ID_2, TRUE);
