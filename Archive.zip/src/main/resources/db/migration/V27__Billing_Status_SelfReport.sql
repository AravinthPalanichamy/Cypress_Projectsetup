-- Material order scripts for distinction with self reporting
ALTER TABLE material_order ADD is_self_reported_material BOOLEAN DEFAULT FALSE;

-- Removing unused columns
ALTER TABLE material_order DROP FOREIGN KEY FK_MO_Person_ReceivedByLab;
ALTER TABLE material_order DROP COLUMN received_by_lab_person_id;
ALTER TABLE material_order DROP COLUMN received_date_lab;

-- Renaming columns columns
ALTER TABLE material_order DROP FOREIGN KEY FK_MO_Person_ReceivedByEhs;
ALTER TABLE material_order CHANGE received_date_ehs received_date DATETIME;
ALTER TABLE material_order CHANGE received_by_ehs_person_id received_by_person_id INTEGER;

ALTER TABLE material_order
ADD CONSTRAINT FK_MO_Person_ReceivedBy
FOREIGN KEY (received_by_person_id)
REFERENCES person (id);

-- Billing scripts
ALTER TABLE ua_bundle_person  ADD COLUMN dosimetry_account_id INTEGER;
ALTER TABLE ua_bundle         ADD COLUMN pi_dosimetry_account_id INTEGER;

ALTER TABLE ua_bundle_person
ADD CONSTRAINT FK_UBP_Account
FOREIGN KEY (dosimetry_account_id)
REFERENCES account (account_id);

ALTER TABLE ua_bundle
ADD CONSTRAINT FK_UB_Account
FOREIGN KEY (pi_dosimetry_account_id)
REFERENCES account (account_id);

-- UI Status fix
update person set status = 'STAFF' where status = 'EMPLOYEE';