INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('1', 'General Purpose');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('2', 'SS&D CA598D103U');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('3', 'SS&D NR0880D8022');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('4', 'SS&D NC646D130S');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('5', 'Sub-critical Assembly');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('6', 'SS&D CA0208D104S');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('7', 'TRIGA reactor');

DELETE from line_number_item where line_number_item_id = 10000;
DELETE from license_line_number where license_line_number_id=101;

UPDATE license_line_number SET line_number='6.A.1', name='Any nuclide with atomic number 1-83', description='Not to exceed 925 GBq (25 Ci)', use_purpose_id=1 WHERE license_line_number_id=102;
UPDATE license_line_number SET line_number='6.A.2', name='Any nuclide with atomic number 84-105, except: a) SpecialNuclear Material b) Source Material', description='Total not to exceed 3.7 GBq (100 mCi)', use_purpose_id=1 WHERE license_line_number_id=103;
UPDATE license_line_number SET line_number='6.A.3', name='Source Material', description='Not to exceed 6,000 kilograms (13,200 lbs.) (74.6 GBq (2017 mCi))', use_purpose_id=1 WHERE license_line_number_id=104;
UPDATE license_line_number SET line_number='6.A.4', name='Special Nuclear Material (SNM)', description='Not to exceed 600 grams (1.4 TBq (37.3 Ci)) and not to exceed 225 grams of total contained Uranium-233, Uranium-235 and Plutonium', use_purpose_id=1 WHERE license_line_number_id=105;
UPDATE license_line_number SET line_number='6.B.1', name='Any nuclide with atomic number 1-83 (Sealed Source)', description='Total not to exceed 7.4 TBq (200 Ci)', use_purpose_id=1 WHERE license_line_number_id=106;
UPDATE license_line_number SET line_number='6.B.2', name='Any nuclide with atomic number 84-105, except: a) SpecialNuclear Material b) Source Material (Sealed Source)', description='Total not to exceed 370 GBq (10 Ci)', use_purpose_id=1 WHERE license_line_number_id=107;
UPDATE license_line_number SET line_number='6.B.3', name='Special Nuclear Material (SNM) (Sealed Source)', description='Not to exceed 100 grams (229.4 GBq (6.2 Ci))', use_purpose_id=1 WHERE license_line_number_id=108;
UPDATE license_line_number SET line_number='6.B.4', name='Cesium-137 (Sealed Source)', description='Two sources not to exceed total of 14.8 TBq (400 Ci)', use_purpose_id=2 WHERE license_line_number_id=109;
UPDATE license_line_number SET line_number='6.B.5', name='Cesium-137 (Sealed Source)', description='One source not to exceed 7.4 TBq (200 Ci)', use_purpose_id=3 WHERE license_line_number_id=110;
UPDATE license_line_number SET line_number='6.B.6', name='Cesium-137/Americium-241 with or without Beryllium (Sealed Source)', description='Not to exceed 3.7 GBq (100 mCi) for any source, total not to exceed 237 GBq (1 Ci)', use_purpose_id=4 WHERE license_line_number_id=111;
UPDATE license_line_number SET line_number='6.B.7', name='Plutonium-239/Beryllium (Sealed Source)', description='Not to exceed 37 GBq (1 Ci)', use_purpose_id=5 WHERE license_line_number_id=112;
UPDATE license_line_number SET line_number='6.B.8', name='Americium-241/Beryllium (Sealed Source)', description='Not to 1.9 GBq (50 mCi) for any source, total not to exceed 3.7 GBq (100 mCi)', use_purpose_id=6 WHERE license_line_number_id=113;
UPDATE license_line_number SET line_number='6.C.1', name='Americium-241/Beryllium (Sealed Source)', description='Not to exceed 185 GBq (5 Ci)', use_purpose_id=7 WHERE license_line_number_id=114;

INSERT INTO license_line_number (license_line_number_id, line_number, license_id, is_specific, name, description, line_number_radionuclide_form_id, campus_limit, campus_limit_unit_id, use_purpose_id) VALUES ('115', '6.B.9', '1', '1', 'Cesium-137/Americium-241:Beryllium', 'One source pair not to exceed 370 MBA (10 mCi) Cesium-137 and 1.9 GBq (50 mCi) Americium-241/Be', '301', '60', '1', '6');
INSERT INTO line_number_item (line_number_item_id, radionuclide_id, license_line_number_id, is_solid, is_liquid, is_gas, is_powder, is_sealed_source, is_special_nuclear_material, is_source_material, elemental_limit, elemental_limit_unit_id) VALUES ('10637', '97', '115', '1', '1', '1', '1', '1', '0', '0', '10', '1');
INSERT INTO line_number_item (line_number_item_id, radionuclide_id, license_line_number_id, is_solid, is_liquid, is_gas, is_powder, is_sealed_source, is_special_nuclear_material, is_source_material, elemental_limit, elemental_limit_unit_id) VALUES ('10638', '10', '115', '1', '1', '1', '1', '1', '0', '0', '50', '1');

UPDATE line_number_radionuclide_form SET line_number_radionuclide_form='Sealed sources manufactured and distributed in accordance with a license issued by the United States Nuclear Regulatory Commisiion, an Agreement State or Licensing State' WHERE line_number_radionuclide_form_id=301;


-- Container Table

CREATE TABLE container (
  container_id               INTEGER       AUTO_INCREMENT,
  container_name                   VARCHAR(1000) NOT NULL,
  container_amount_mci             DECIMAL(12,5) NOT NULL,
  container_volume_ul              DECIMAL(12,5) NOT NULL,
  container_elemental_mass         DECIMAL(12,5) NOT NULL,
  container_sample_net_mass        DECIMAL(12,5) NOT NULL,
  created_date                     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_modified_date               TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by                       INTEGER       NOT NULL,
  last_modified_by                 INTEGER       NOT NULL,
  active boolean NOT NULL DEFAULT '0',
  PRIMARY KEY (container_id)
);

CREATE TABLE `ua_container` (
  `ua_id` int(11) NOT NULL,
  `container_id` int(11) NOT NULL,
  PRIMARY KEY (`ua_id`,`container_id`),
  KEY `FK_UaContainer_Container` (`container_id`),
  CONSTRAINT `FK_UaContainer_Container` FOREIGN KEY (`container_id`) REFERENCES `container` (`container_id`),
  KEY `FK_UaContainer_Ua` (`ua_id`),
  CONSTRAINT `FK_UaContainer_Ua` FOREIGN KEY (`ua_id`) REFERENCES `ua` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


ALTER TABLE rpm DROP COLUMN on_license,
 ADD COLUMN on_license BIT DEFAULT 0;

ALTER TABLE rpm MODIFY `dph_number` varchar(100) DEFAULT NULL;
ALTER TABLE rpm MODIFY `type` varchar(100) DEFAULT NULL;
ALTER TABLE rpm MODIFY `manufacturer` varchar(100) DEFAULT NULL;
ALTER TABLE rpm MODIFY `number_of_tubes` TINYINT DEFAULT NULL;
ALTER TABLE rpm MODIFY `model` varchar(100) DEFAULT NULL;
ALTER TABLE rpm MODIFY `maximum_current` varchar(100) DEFAULT NULL;
ALTER TABLE rpm MODIFY `maximum_voltage` varchar(100) DEFAULT NULL;
ALTER TABLE rpm MODIFY `max_time` varchar(100) DEFAULT NULL;
ALTER TABLE rpm MODIFY  `normal_current` varchar(100) DEFAULT NULL;
ALTER TABLE rpm MODIFY `normal_voltage` varchar(100) DEFAULT NULL;
ALTER TABLE rpm MODIFY `normal_time` varchar(100) DEFAULT NULL;



alter table radionuclide add column `display_name` varchar(50);
update radionuclide n set display_name = n.name;
update radionuclide set display_name = replace(display_name, '-', '') where display_name like '%-%' ;


-- Update New Radionuclide

insert into radionuclide (radionuclide_id, name, half_life, half_life_unit, radiotoxicity, z_value, is_alpha_emitter, is_beta_emitter, is_gamma_emitter, is_neutron_emitter, is_source_material, is_special_nuclear_material, activity_mci_per_gram, is_sewer_disposal, schedule_c, egroup, ali_mci, is_status_active, display_name )
VALUES (370, 'Tb-161', 6.89, 4, 1, 65, 0, 1, 1, 0, 0, 0, null, 0, 100, 1, 2, 1, 'Tb161' );

insert into radionuclide (radionuclide_id, name, half_life, half_life_unit, radiotoxicity, z_value, is_alpha_emitter, is_beta_emitter, is_gamma_emitter, is_neutron_emitter, is_source_material, is_special_nuclear_material, activity_mci_per_gram, is_sewer_disposal, schedule_c, egroup, ali_mci, is_status_active, display_name )
VALUES (371, 'Rb-83', 86.2, 4,1, 37, 0, 0, 1, 0, 0, 0, null, 0, 100,5, 0.6, 1, 'Rb83' );

insert into radionuclide (radionuclide_id, name, half_life, half_life_unit, radiotoxicity, z_value, is_alpha_emitter, is_beta_emitter, is_gamma_emitter, is_neutron_emitter,
 is_source_material, is_special_nuclear_material, activity_mci_per_gram, is_sewer_disposal, schedule_c, egroup, ali_mci, is_status_active, display_name )
VALUES (372,'Pb-202', 19162500, 4, 0, 82, 0, 0, 1, 0, 0, 0, 0 , 0, 10, 0.1, 0.05, 1, 'Pb202');

insert into radionuclide (radionuclide_id, name, half_life, half_life_unit, radiotoxicity, z_value, is_alpha_emitter, is_beta_emitter, is_gamma_emitter, is_neutron_emitter, is_source_material, is_special_nuclear_material, activity_mci_per_gram, is_sewer_disposal, schedule_c, egroup, ali_mci, is_status_active, display_name )
VALUES (373, 'Y-86', 0.614, 4, 0, 39, 0, 1, 0, 0, 0, 0, 0 ,0 , 100, 25,  1, 1, 'Y86');

insert into radionuclide (radionuclide_id, name, half_life, half_life_unit, radiotoxicity, z_value, is_alpha_emitter, is_beta_emitter, is_gamma_emitter, is_neutron_emitter, is_source_material, is_special_nuclear_material, activity_mci_per_gram, is_sewer_disposal, schedule_c, egroup, ali_mci, is_status_active, display_name )
VALUES (374, 'Sr-82', 25.36, 4, 0, 38, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0.2, 1, 'Sr82' );

insert into radionuclide (radionuclide_id, name, half_life, half_life_unit, radiotoxicity, z_value, is_alpha_emitter, is_beta_emitter, is_gamma_emitter, is_neutron_emitter, is_source_material, is_special_nuclear_material, activity_mci_per_gram, is_sewer_disposal, schedule_c, egroup, ali_mci, is_status_active, display_name )
VALUES (375, 'Mo99-Tc99m', 2.75, 4,0, 42, 0, 1, 1, 0,0, 0, 0, 0, 0, 1, 80, 1, 'Mo99-Tc99m' );


-- Berkeley Radionuclide Table

DROP TABLE IF EXISTS `berkeley_radionuclide`;

CREATE TABLE `berkeley_radionuclide` (
  `radionuclide_id` int(11) DEFAULT NULL,
  `name` text,
  `half_life` DOUBLE,
  `egroup` DOUBLE DEFAULT NULL,
  `ali_mci` DOUBLE DEFAULT 0,
  `z_value` INTEGER(11) DEFAULT 0,
  `radiotoxicity` DOUBLE DEFAULT 0,
  `schedule_c` DOUBLE DEFAULT 0,
  `activity_mci_per_gram` DECIMAL(19,12) DEFAULT 0,
  `is_sewer_disposal` Boolean DEFAULT false,
  `is_source_material` Boolean DEFAULT false,
  `is_special_nuclear_material` Boolean DEFAULT false,
  `is_alpha_emitter` Boolean DEFAULT false,
  `is_beta_emitter` Boolean DEFAULT false,
  `is_gamma_emitter` Boolean DEFAULT false,
  `is_neutron_emitter` Boolean DEFAULT false,
  `is_status_active` Boolean DEFAULT false
);

INSERT INTO `berkeley_radionuclide` (`radionuclide_id`, `name`, `half_life`, `egroup`, `ali_mci`, `z_value`, `radiotoxicity`, `schedule_c`, `activity_mci_per_gram`, `is_sewer_disposal`, `is_source_material`, `is_special_nuclear_material`, `is_alpha_emitter`, `is_beta_emitter`, `is_gamma_emitter`, `is_neutron_emitter`, `is_status_active`) VALUES
('1', 'H3', '4508.000000', '0.1', '80', '1', '0.1', '1000.00000', '0', '1', '0', '0', '0', '1', '0', '0', '1'),
('2', 'P32', '14.290000', '1', '0.6', '15', '1.0', '10.00000', '0', '1', '0', '0', '0', '1', '0', '0', '1'),
('3', 'P33', '24.900000', '0.1', '3', '15', '1.0', '100.00000', '0', '1', '0', '0', '0', '1', '0', '0', '1'),
('4', 'S35', '87.440000', '0.1', '2', '16', '1.0', '100.00000', '0', '1', '0', '0', '0', '1', '0', '0', '1'),
('5', 'I125', '60.140000', '5', '0.04', '53', '10.0', '1.00000', '0', '1', '0', '0', '0', '0', '1', '0', '1'),
('6', 'Ac227', '7893.000000', '1', '4.0E-7', '89', '100.0', '0.00100', '0', '0', '0', '0', '1', '1', '1', '0', '1'),
('7', 'Ag110m', '249.900000', '25', '0.09', '47', '10.0', '10.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('8', 'Ag105', '41.290000', '5', '1', '47', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('9', 'Am241', '157680.000000', '5', '6.0E-6', '95', '100.0', '0.00100', '0', '0', '0', '0', '1', '0', '1', '0', '1'),
('10', 'Am241Be', '157680.000000', '25', '6.0E-6', '95', '100.0', '0.00100', '0', '0', '0', '0', '1', '0', '1', '1', '1'),
('11', 'Am243', '2693700.000000', '1', '1.0E-5', '95', '100.0', '0.00100', '0', '0', '0', '0', '1', '0', '1', '0', '1'),
('12', 'Ar39', '97455.000000', '0.1', '0', '18', '0.1', '1000.00000', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('13', 'Ba133', '3833.000000', '5', '0.7', '56', '1.0', '100.00000', '0', '1', '0', '0', '0', '0', '1', '0', '1'),
('14', 'Bi207', '11704.000000', '25', '0.4', '83', '10.0', '10.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('15', 'Bi210', '5.013000', '1', '0.03', '83', '10.0', '1.00000', '0', '0', '0', '0', '1', '1', '1', '0', '1'),
('16', 'Bi214', '0.013820', '10', '9.000000000000001E-5', '83', '10.0', '0.00100', '0', '0', '0', '0', '1', '1', '1', '0', '1'),
('17', 'Bk247', '511000.000000', '1', '4.0E-6', '97', '100.0', '2.00000', '0', '0', '0', '0', '1', '0', '1', '0', '1'),
('18', 'Ca45', '163.000000', '1', '0.08', '20', '10.0', '100.00000', '0', '1', '0', '0', '0', '1', '0', '0', '1'),
('19', 'Cd109', '462.000000', '5', '0.04', '48', '1.0', '1.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('20', 'Ce139', '140.000000', '5', '3.0E-10', '58', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('21', 'Ce144', '284.300000', '1', '6.0E-12', '58', '10.0', '1.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('22', 'Cf249', '131400.000000', '5', '4.0E-6', '98', '100.0', '0.00100', '0', '0', '0', '0', '1', '1', '1', '0', '1'),
('23', 'Cf252', '982.945000', '1', '3.0E-5', '98', '100.0', '0.00100', '0', '0', '0', '0', '1', '0', '1', '1', '1'),
('24', 'Cl36', '109865000.000000', '0.1', '0.2', '17', '10.0', '10.00000', '0', '1', '0', '0', '0', '1', '0', '0', '1'),
('25', 'Cm242', '163.500000', '1', '0.0003', '96', '100.0', '0.01000', '0', '0', '0', '0', '1', '0', '1', '0', '1'),
('26', 'Cm244', '6610.000000', '1', '2.0E-5', '96', '100.0', '0.00100', '0', '0', '0', '0', '1', '0', '1', '0', '1'),
('27', 'Cm246', '1726450.000000', '1', '6.0E-6', '96', '100.0', '0.00100', '0', '0', '0', '0', '1', '0', '1', '0', '1'),
('28', 'Cm248', '124100000.000000', '10', '2.0E-6', '96', '100.0', '0.00100', '0', '0', '0', '0', '1', '0', '1', '1', '1'),
('29', 'Co56', '78.760000', '25', '0.2', '27', '10.0', '10.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('30', 'Co57', '270.900000', '5', '0.7', '27', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('31', 'Co60', '1924.000000', '25', '0.03', '27', '10.0', '1.00000', '0', '1', '0', '0', '0', '1', '1', '0', '1'),
('32', 'Cr51', '27.704000', '1', '20', '24', '1.0', '1000.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('33', 'Cs134', '753.000000', '10', '0.07000000000000001', '55', '10.0', '10.00000', '0', '1', '0', '0', '0', '1', '1', '0', '1'),
('34', 'Cu64', '0.530000', '5', '10', '29', '1.0', '1000.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('35', 'Eu152', '4865.000000', '10', '0.02', '63', '1.0', '1.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('36', 'Eu154', '3212.000000', '10', '0.02', '63', '10.0', '1.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('37', 'Fe55', '985.500000', '0.1', '2', '26', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('38', 'Fe59', '44.529000', '10', '0.3', '26', '1.0', '10.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('39', 'Gd153', '239.000000', '5', '0.1', '64', '1.0', '10.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('40', 'Hg203', '46.600000', '5', '0.5', '80', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('41', 'I129', '5730500000.000000', '5', '0.005', '53', '0.1', '1.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('42', 'I131', '8.040000', '5', '0.03', '53', '10.0', '1.00000', '0', '1', '0', '0', '0', '1', '1', '0', '1'),
('43', 'K40', '466105000000.000000', '1', '0.3', '19', '10.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('44', 'Kr85', '3913.000000', '1', '1', '36', '0.1', '1000.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('45', 'Lu172', '6.700000', '25', '1', '71', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('46', 'Mn54', '312.500000', '10', '0.08', '25', '10.0', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('47', 'Mo99', '2.750000', '5', '1', '42', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('48', 'Na22', '950.000000', '25', '0.4', '11', '10.0', '10.00000', '0', '1', '0', '0', '0', '0', '1', '0', '1'),
('49', 'Nd144', '99999999999999999.999999', '0', '4.0E-7', '60', '100.0', '0.01000', '0', '0', '0', '0', '1', '0', '0', '0', '1'),
('50', 'Ni59', '27375000.000000', '1', '0.2', '28', '0.1', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('51', 'Ni63', '35040.000000', '0.1', '0.8', '28', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('52', 'Np237', '781100000.000000', '5', '4.0E-6', '93', '100.0', '0.00100', '0', '0', '0', '0', '1', '1', '1', '0', '1'),
('53', 'Pa234', '0.279000', '10', '2', '91', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('54', 'Pb205', '5475000000.000000', '0.1', '1', '82', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('55', 'Pb210', '8140.000000', '1', '0.0002', '82', '100.0', '0.01000', '0', '0', '0', '0', '1', '1', '1', '0', '1'),
('56', 'Pm143', '265.000000', '5', '0.6', '61', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('57', 'Pm144', '363.000000', '10', '0.1', '61', '1.0', '10.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('58', 'Pm147', '958.000000', '0.1', '0.1', '61', '1.0', '10.00000', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('59', 'Po209', '37595.000000', '1', '4.0E-7', '84', '0.1', '0.00100', '0', '0', '0', '0', '1', '0', '1', '0', '1'),
('60', 'Po210', '138.380000', '0', '0.003', '84', '100.0', '0.10000', '0', '0', '0', '0', '1', '0', '0', '0', '1'),
('61', 'Pr144', '0.012000', '1', '30', '59', '0.1', '1000.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('62', 'Pu236', '1043.170000', '1', '2.0E-5', '94', '100.0', '0.00100', '530000.000000000000', '0', '0', '1', '1', '0', '1', '0', '1'),
('63', 'Pu238', '32025.100000', '1', '7.0E-6', '94', '100.0', '0.00100', '17000.000000000000', '0', '0', '1', '1', '0', '1', '0', '1'),
('64', 'Pu239', '8783725.000000', '1', '2.0E-5', '94', '100.0', '0.00100', '62.000000000000', '0', '0', '1', '1', '0', '1', '0', '1'),
('65', 'Pu239Be', '8783725.000000', '25', '2.0E-5', '94', '100.0', '0.00100', '62.000000000000', '0', '0', '1', '1', '0', '1', '1', '1'),
('66', 'Pu240', '2401700.000000', '1', '6.0E-6', '94', '100.0', '0.00100', '230.000000000000', '0', '0', '1', '1', '0', '1', '0', '1'),
('67', 'Ra226', '584000.000000', '1', '0.0005999999999999999', '88', '100.0', '0.10000', '0', '0', '0', '0', '1', '1', '1', '0', '1'),
('68', 'Ra226Be', '584000.000000', '25', '0.0005999999999999999', '88', '100.0', '0.10000', '0', '0', '0', '0', '1', '1', '1', '1', '1'),
('69', 'Ra228', '2099.000000', '0.1', '0.001', '88', '100.0', '0.10000', '0', '0', '0', '0', '1', '1', '1', '0', '1'),
('70', 'Rb86', '18.660000', '1', '0.5', '37', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('71', 'Rb88', '0.012360', '5', '20', '37', '0.1', '1000.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('72', 'Ru106', '368.200000', '0.1', '0.01', '44', '10.0', '1.00000', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('73', 'Sb125', '1011.000000', '5', '0.5', '51', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('74', 'Sc46', '83.830000', '10', '0.2', '21', '10.0', '10.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('75', 'Se75', '119.779000', '5', '0.6', '34', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('76', 'Sm145', '340.000000', '1', '0.5', '62', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('77', 'Sm151', '32850.000000', '1', '0.1', '62', '1.0', '10.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('78', 'Sn113', '120.500000', '5', '0.5', '50', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('79', 'Sr90', '10629.000000', '0.1', '0.02', '38', '10.0', '0.10000', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('80', 'Tc99', '77745000.000000', '0.1', '0.7', '43', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('81', 'Th228', '698.000000', '1', '1.0E-5', '90', '100.0', '0.00100', '820000.000000000000', '0', '1', '0', '1', '0', '1', '0', '1'),
('82', 'Th229', '2679100.000000', '10', '9.0E-7', '90', '100.0', '0.00100', '210.000000000000', '0', '1', '0', '1', '1', '1', '0', '1'),
('83', 'Th230', '28105000.000000', '1', '6.0E-6', '90', '100.0', '0.00100', '21.000000000000', '0', '1', '0', '1', '1', '1', '0', '1'),
('84', 'Th232', '5128250000000.000000', '1', '1.0E-6', '90', '0.1', '100.00000', '0.000110000000', '0', '1', '0', '1', '1', '1', '0', '1'),
('85', 'Tl204', '1386.000000', '1', '2', '81', '10.0', '100.00000', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('86', 'Tm170', '130.000000', '1', '0.2', '69', '10.0', '10.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('87', 'Unat', '1630000000000.000000', '1', '5.0E-5', '92', '0.1', '100.00000', '0.000710000000', '0', '1', '0', '1', '1', '1', '0', '1'),
('88', 'U232', '26280.000000', '0', '8.0E-6', '92', '100.0', '0.00100', '22000.000000000000', '0', '0', '0', '1', '0', '1', '0', '1'),
('89', 'U233', '57852500.000000', '1', '4.0E-5', '92', '100.0', '0.00100', '9.700000000000', '0', '0', '1', '1', '1', '1', '0', '1'),
('90', 'U234', '89242500.000000', '1', '4.0E-5', '92', '100.0', '0.00100', '6.200000000000', '0', '1', '0', '1', '1', '1', '0', '1'),
('91', 'U235', '257000000000.000000', '5', '4.0E-5', '92', '100.0', '0.00100', '0.002200000000', '0', '0', '1', '1', '1', '1', '0', '1'),
('92', 'U236', '8546475000.000000', '1', '4.0E-5', '92', '10.0', '0.00100', '0.065000000000', '0', '1', '0', '1', '1', '1', '0', '1'),
('93', 'U238', '1630000000000.000000', '1', '4.0E-5', '92', '0.1', '100.00000', '0.000340000000', '1', '1', '0', '1', '1', '1', '0', '1'),
('94', 'Zn65', '243.900000', '5', '0.3', '30', '1.0', '10.00000', '0', '1', '0', '0', '0', '0', '1', '0', '1'),
('95', 'Ag108m', '152570.000000', '0', '0.02', '47', '1.0', '1.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('96', 'Cs137', '10976.000000', '5', '0.1', '55', '10.0', '10.00000', '0', '1', '0', '0', '0', '1', '1', '0', '1'),
('97', 'Y88', '107.000000', '25', '0.2', '39', '1.0', '10.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('98', 'Sr85', '64.840000', '10', '2', '38', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('99', 'C14', '2091450.000000', '0.1', '2', '6', '1.0', '100.00000', '0', '1', '0', '0', '0', '1', '0', '0', '1'),
('100', 'Cs137Ba', '10950.000000', '5', '0.1', '55', '10.0', '10.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('101', 'Ag110', '0.000280', '1', '0.0002', '47', '1.0', '0.01000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('102', 'Ag108', '0.001700', '1', '0.2', '47', '1.0', '0.01000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('103', 'As74', '17.900000', '5', '0.8', '33', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('104', 'W187', '0.990000', '5', '2', '74', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('105', 'Eu155', '1737.400000', '1', '0.09', '63', '1.0', '10.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('106', 'Cm244C', '6610.000000', '1', '2.0E-5', '96', '100.0', '0.00100', '0', '0', '0', '0', '1', '0', '1', '1', '1'),
('107', 'Mo93', '1277500.000000', '5', '0.2', '42', '1.0', '10.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('108', 'Nb93m', '5876.500000', '1', '0.2', '41', '1.0', '10.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('109', 'Co58', '70.800000', '10', '0.7', '27', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('110', 'Nb95', '35.060000', '5', '1', '41', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('111', 'Ge68', '288.000000', '1', '0.1', '32', '0.1', '10.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('112', 'Xe133', '5.300000', '5', '1', '54', '0.1', '1000.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('113', 'Nb94', '7300000.000000', '10', '0.02', '41', '1.0', '1.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('114', 'Zr88', '83.400000', '5', '0.2', '40', '1.0', '10.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('115', 'Ga68', '0.047100', '10', '20', '31', '1.0', '1000.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('116', 'Ta182', '114.430000', '10', '0.1', '73', '1.0', '10.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('117', 'Na24', '0.625000', '25', '4', '11', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '0', '0', '1'),
('118', 'La140', '1.678000', '25', '0.6', '57', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '0', '0', '1'),
('119', 'Tm167', '9.250000', '1', '2', '69', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '0', '0', '1'),
('120', 'Tm168', '93.100000', '10', '0.0002', '69', '1.0', '0.01000', '0', '0', '0', '0', '0', '0', '0', '0', '1'),
('121', 'In115m', '0.187000', '5', '10', '49', '10.0', '1000.00000', '0', '0', '0', '0', '0', '0', '0', '0', '1'),
('122', 'Au197m', '2.700000', '1', '0.2', '79', '1.0', '0.01000', '0', '0', '0', '0', '0', '0', '0', '0', '1'),
('123', 'W188', '69.780000', '1', '0.4', '74', '1.0', '10.00000', '100.000000000000', '0', '0', '0', '0', '0', '0', '0', '1'),
('124', 'Re188', '0.707500', '1', '2', '75', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '0', '0', '1'),
('125', 'Ar41', '0.007000', '10', '1', '18', '0.1', '1000.00000', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('126', 'Ar37', '35.040000', '1', '1', '18', '0.1', '1000.00000', '0', '0', '0', '0', '0', '0', '0', '0', '1'),
('127', 'Zr89', '2.975000', '10', '2', '40', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('128', 'Y90', '2.669000', '1', '0.4', '39', '1.0', '10.00000', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('129', 'Ni57', '1.483000', '10', '2', '28', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('130', 'Hf181', '42.390000', '5', '0.2', '72', '10.0', '10.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('131', 'Zr95', '64.032000', '5', '0.1', '40', '10.0', '10.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('132', 'Ca47', '4.540000', '1', '0.8', '20', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('133', 'Cu67', '0.530000', '1', '5', '29', '1.0', '1000.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('134', 'Rh105', '1.470000', '1', '4', '45', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('135', 'Pm149', '53.000000', '1', '1', '61', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('136', 'Sm153', '1.930000', '5', '2', '62', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('137', 'Gd159', '0.770000', '1', '3', '64', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('138', 'Tb161', '6.890000', '1', '2', '65', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('139', 'Ho166', '1.120000', '1', '0.9', '67', '1.0', '0.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('140', 'Yb175', '4.180000', '1', '3', '70', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('141', 'Lu177', '6.650000', '1', '2', '71', '1.0', '100.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('142', 'K42', '0.513375', '5', '5', '42', '1.0', '1000.00000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('143', 'Rb83', '86.200000', '5', '0.6', '37', '1.0', '100.00000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('144', 'Ac225', '10.000000', '1', '0.0003', '89', '100.0', '0.00100', '0', '0', '0', '0', '1', '0', '1', '0', '1'),
('145', 'Ba137m', '0.001772', '1', '0.2', '56', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('146', 'Pd103', '16.991', '5', '4', '46', '0', '100', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('147', 'Pb202', '19162500', '0.1', '0.05', '82', '0', '10', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('148', 'Y86', '0.614', '25', '1', '39', '0', '100', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('149', 'C11', '0.0142', '10', '400', '6', '1000', '1000', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('150', 'Ga67', '3.261', '5', '10', '31', '0', '1000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('151', 'I123', '0.55', '5', '3', '53', '0', '100', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('152', 'In111', '2.83', '10', '4', '59', '0', '100', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('153', 'Ir192', '74.02', '10', '0.2', '77', '0', '1', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('154', 'Ra223', '11.43', '5', '0.0007', '88', '0', '0.1', '0', '0', '0', '0', '1', '1', '1', '0', '1'),
('155', 'Sr82', '25.36', '1', '0.2', '38', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('156', 'Sr89', '50.5', '5', '0.1', '38', '0', '10', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('157', 'Tc99m', '0.2508', '1', '80', '43', '0', '1000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('158', 'Ru103', '39.28', '5', '0.6', '44', '0', '100', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('159', 'I124', '4.18', '10', '0.05', '53', '0', '10', '0', '0', '0', '0', '0', '1', '1', '0', '1'),
('160', 'N13', '0.006923611', '10', '1', '7', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('161', 'Ce141', '32.501', '1', '0.6', '58', '0', '100', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('162', 'O15', '0.001415', '10', '1', '8', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('163', 'F18', '0.7621', '10', '50', '9', '0', '1000', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('164', 'Tl201', '3.0442', '5', '20', '81', '0', '1000', '0', '0', '0', '0', '0', '0', '1', '0', '1'),
('165', 'Rb87', '129000000', '0.1', '1', '37', '0', '100', '0', '0', '0', '0', '0', '1', '0', '0', '1'),
('166', 'Mo99-Tc99m', '2.75', '1', '80', '42', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '1');



UPDATE radionuclide nn INNER JOIN berkeley_radionuclide b
    ON nn.display_name = b.name
SET nn.half_life = b.half_life,
    nn.half_life_unit = 4,
    nn.z_value = b.z_value,
    nn.is_alpha_emitter = b.is_alpha_emitter,
    nn.is_beta_emitter = b.is_beta_emitter,
    nn.is_gamma_emitter = b.is_gamma_emitter,
    nn.is_neutron_emitter = b.is_neutron_emitter,
    nn.is_source_material = b.is_source_material,
    nn.is_special_nuclear_material = b.is_special_nuclear_material,
    nn.activity_mci_per_gram = b.activity_mci_per_gram,
    nn.is_sewer_disposal = b.is_sewer_disposal,
    nn.schedule_c = b.schedule_c,
    nn.egroup = b.egroup,
    nn.ali_mci = b.ali_mci,
    nn.is_status_active = 1;
