-- Update use_factor
UPDATE `use_factor` SET `type_of_operation` = 'Simple wet operations (e.g., dilution, transfers, closed systems with appropriate traps used in hoods), and sealed source handling.' WHERE (`type_of_operation` = 'Simple wet operations, source handling (e.g., dilution, transfers, closed systems with appropriate traps used in hoods)' AND `use_factor_id` <> 0);

--UaBundlePerson--
ALTER TABLE `ua_bundle_person` ADD COLUMN `added_as_exceptional` tinyint(1) DEFAULT 0;

-- Person
ALTER TABLE Person DROP COLUMN exceptionalRua;


--Training
UPDATE `training` SET `activity_code` ='BEEHS 401.1_Objective_UCLOL0021' WHERE (`activity_name` = 'EHS 401.1 Radiation Safety Training for Radioactive Materials Users'  AND `id` <> 0);
UPDATE `training` SET `activity_code` ='BEEHS 401.3_Objective_UCLOL0022' WHERE (`activity_name` = 'EHS 401.2 Radiation Safety Retraining: Radiation Producing Machines'  AND `id` <> 0);
UPDATE `training` SET `activity_code` ='BEEHS 401.2_Objective_UCLOL0020' WHERE (`activity_name` = 'EHS 401.3 Radiation Safety Retraining: Radioactive Materials & Radiation Producing Machines' AND `id` <> 0);

DELETE from `training` WHERE (`activity_code` = 'BEEHS EHS 402.1 Retraining for Radioactive Materials (RAM) Users 8-29-16' AND `id` <> 0);
DELETE from `training` WHERE (`activity_code` = 'BEEHS EHS 402.2 Retraining for Radiation Producing Machine Users 8-29-16' AND `id` <> 0);
DELETE from `training` WHERE (`activity_code` = 'BEEHS EHS 402.3 Retraining for Radioactive Materials (RAM) & Radiation Producing Machine (RPM) Users 8-29-16' AND `id` <> 0);

UPDATE `training` SET `activity_code` ='DACS-RAD-Q-SAFSVC' WHERE (`activity_name` = 'Radiation Quiz' AND `id` <> 0);

INSERT INTO training (id, campus_code, classification_name, source_system_id, source_system_name, activity_code, activity_name, active, created_date, last_modified_date, created_by, last_modified_by, training_catagory, training_type)
VALUES (39,'03','Radiation',2,'LMS','DACS-RADILT-SAFSVC','UC Davis Radiation Safety',1,null,null,1,1,'RAM,RPM','I');

INSERT INTO training (id, campus_code, classification_name, source_system_id, source_system_name, activity_code, activity_name, active, created_date, last_modified_date, created_by, last_modified_by, training_catagory, training_type)
VALUES (40,'03','Radiation',2,'LMS','DAC-UCLOL0031-ECO','Radiation Safety Refresher for Users of Radioactive Material',1,null,null,1,1,'RAM','R');

INSERT INTO training (id, campus_code, classification_name, source_system_id, source_system_name, activity_code, activity_name, active, created_date, last_modified_date, created_by, last_modified_by, training_catagory, training_type)
VALUES (41,'03','Radiation',2,'LMS','DAC-UCLOL0032-ECO','Radiation Safety Refresher for Users of Radiation Producing Machine',1,null,null,1,1,'RPM','R');

CREATE TABLE `changelog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity` varchar(50) NOT NULL,
  `entity_id` int(11)  NOT NULL,
  `property_name` varchar(255) NOT NULL,
  `type` VARCHAR (1) NOT NULL COMMENT 'I,U,D',
  `last_modified_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL,
  `old_value` mediumtext,
  `new_value` mediumtext,
  PRIMARY KEY (`id`),
  KEY `idx_changelog_entity_id` (`entity_id`),
  KEY `idx_changelog_last_modified_date` (`last_modified_date`),
  KEY `idx_changelog_entity` (`entity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
