ALTER TABLE `line_number_item` ADD COLUMN active tinyint(1) default 1;
UPDATE `line_number_item` set active = 0 where line_number_item_id in (21899, 30617, 30624, 40559, 70003, 17151, 910);

