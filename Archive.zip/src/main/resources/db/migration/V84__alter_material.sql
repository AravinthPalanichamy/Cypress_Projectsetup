alter table radionuclide_material add column current_non_decayed_amount DECIMAL (19,11);

update radionuclide_material set current_non_decayed_amount = request_amount where id > 0;
