
ALTER TABLE `ua` DROP COLUMN `is_backfill`;

ALTER TABLE `ua_limit` MODIFY COLUMN `chemical_form` varchar(250);

ALTER TABLE `ua_planned_work` MODIFY COLUMN `chemical_form` varchar(250);

ALTER TABLE `material` MODIFY COLUMN `chemical_form` varchar(250);