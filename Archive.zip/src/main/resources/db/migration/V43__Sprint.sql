--
-- Table structure for table `other`
--

CREATE TABLE `other` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `other`(`code`, `description`)
VALUES('ICL', 'IC Location');

INSERT INTO `other`(`code`, `description`)
VALUES('EDEG', 'E/D exception granted');

INSERT INTO `other`(`code`, `description`)
VALUES('DDA', 'Drain Disposal Allowed');

--
-- Table structure for table `ua_other`
--

CREATE TABLE `ua_other` (
  `ua_id` int(11) NOT NULL,
  `other_id` int(11) NOT NULL,
  KEY `FK_UaOther_Ua` (`ua_id`),
  KEY `FK_UaOther_Other` (`other_id`),
  PRIMARY KEY (ua_id, other_id),
  CONSTRAINT `FK_UaOther_Ua` FOREIGN KEY (`ua_id`) REFERENCES `ua` (`id`),
  CONSTRAINT `FK_UaOther_Other` FOREIGN KEY (`other_id`) REFERENCES `other` (`id`),
  CONSTRAINT `UK_UAId_OtherId` UNIQUE (`ua_id`, `other_id`)
);

CREATE TABLE `REVINFO` (
  `REV` int(11) NOT NULL AUTO_INCREMENT,
  `REVTSTMP` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `Z_ua_other_CHANGE_LOG` (
  `ua_id` int(11) NOT NULL,
  `other_id` int(11) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`ua_id`,`other_id`,`REV`),
  KEY `FK_UA_Other_REV` (`REV`),
  CONSTRAINT `FK_UA_Other_REV` FOREIGN KEY (`REV`) REFERENCES `REVINFO` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `Z_ua_CHANGE_LOG` (
  `id` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `number_MOD` tinyint(1) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `type_MOD` tinyint(1) DEFAULT NULL,
  `status_type` varchar(25) DEFAULT NULL,
  `statusType_MOD` tinyint(1) DEFAULT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK_UA_REV` (`REV`),
  CONSTRAINT `FK_UA_REV` FOREIGN KEY (`REV`) REFERENCES `REVINFO` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- WastE tag table --

CREATE TABLE `container_waste_tag` (
  `waste_tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `container_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `lab_location` varchar(200) DEFAULT NULL,
  `tracking_number` varchar(50) DEFAULT NULL,
  `cocktail` varchar(50) DEFAULT NULL,
  `request_pick_up_date` datetime DEFAULT NULL,
  `ph` double DEFAULT NULL,
  `dose_rate` double DEFAULT NULL,
  `physical_state` varchar(50) DEFAULT NULL,
  `waste_tag_type` varchar(50) DEFAULT NULL,
  `waste_material_type` varchar(50) DEFAULT NULL,
  `waste_size` decimal(12,5) DEFAULT NULL,
  `comments` text,
  `waste_tag_identifier` varchar(50) NOT NULL DEFAULT '',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `last_modified_by` int(11) NOT NULL,
  PRIMARY KEY (`waste_tag_id`),
  KEY `FK_Container_WasteTag` (`container_id`),
  KEY `FK_WasteTag_Location` (`location_id`),
  CONSTRAINT `FK_Container_WasteTag` FOREIGN KEY (`container_id`) REFERENCES `container` (`container_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_WasteTag_Location` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `waste_tag_chemicals` (
  `waste_tag_chem_id`        int(11) NOT NULL AUTO_INCREMENT,
  `waste_tag_id`             int(11) DEFAULT NULL,
  `chemical_name`              		 varchar(100) DEFAULT NULL,
  `percent`                  double DEFAULT NULL,
  PRIMARY KEY (`waste_tag_chem_id`),
  KEY `FK_WasteTag_Chemical` (`waste_tag_id`),
  CONSTRAINT `FK_WasteTag_Chemical` FOREIGN KEY (`waste_tag_id`) REFERENCES `container_waste_tag` (`waste_tag_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


CREATE TABLE `waste_tag_hazard` (
  `waste_tag_hazard_id`        int(11) NOT NULL AUTO_INCREMENT,
  `waste_tag_id`             int(11) DEFAULT NULL,
  `hazard_name`             varchar(100) DEFAULT NULL,
  PRIMARY KEY (`waste_tag_hazard_id`),
  KEY `FK_WasteTag_Hazard` (`waste_tag_id`),
  CONSTRAINT `FK_WasteTag_Hazard` FOREIGN KEY (`waste_tag_id`) REFERENCES `container_waste_tag` (`waste_tag_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- material use
ALTER TABLE material_use ADD COLUMN  use_date datetime;

ALTER TABLE material_use ADD COLUMN material_use_status_type VARCHAR (25);