SET @SYSTEM_USER_ID = 1;
SET @RP_UCT_PERSON_ID = 2;
SET @RSO_UCT_PERSON_ID = 3;
SET @AU_UCT_PERSON_ID_1 = 6;
SET @UCT_LOCATION_ID_1 = 1;
SET @AU_UCT_PERSON_ID_3 = 8;
SET @INVENTORY_PACKAGE_ID = 1;

-- Correction for radionuclide half life unit data
UPDATE `radionuclide` SET `half_life_unit`='4' WHERE `radionuclide_id`='306';

-- New tables for package transfers
-- Package vendor
CREATE TABLE package_vendor (
  package_vendor_id                       INTEGER       AUTO_INCREMENT,
  package_vendor_name                     VARCHAR(50)   NOT NULL,
  campus_code                             VARCHAR(2)    NOT NULL,
  PRIMARY KEY (package_vendor_id)
);

ALTER TABLE package_vendor
ADD CONSTRAINT FK_PackageVendor_Campus
FOREIGN KEY (campus_code)
REFERENCES campus (code);

INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('1', 'new V', '99');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('2', 'old V', '99');

-- Package type
CREATE TABLE package_type (
  package_type_id                 INTEGER       AUTO_INCREMENT,
  package_type_name               VARCHAR(50)   NOT NULL,
  campus_code                     VARCHAR(2)    NOT NULL,
  PRIMARY KEY (package_type_id)
);

ALTER TABLE package_type
ADD CONSTRAINT FK_PackageType_Campus
FOREIGN KEY (campus_code)
REFERENCES campus (code);

INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('1', 'DOT 1', '99');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('2', 'DOT 2', '99');

-- Inventory package
CREATE TABLE inventory_package (
  inventory_package_id            INTEGER       AUTO_INCREMENT,
  inventory_package_number        INTEGER       NOT NULL,
  package_type_id                 INTEGER       NOT NULL,
  transport_index                 DECIMAL(12,5) NOT NULL,
  package_vendor_id               INTEGER       NOT NULL,
  comments                        VARCHAR(1000),
  contact_reading                 DECIMAL(12,5) NOT NULL,
  one_meter_reading               DECIMAL(12,5) NOT NULL,
  received_date                   DATETIME      NOT NULL,
  ex_swipe_con_free               BOOLEAN       NOT NULL,
  ex_cpm                          DECIMAL(12,5),
  pr_swipe_con_free               BOOLEAN       NOT NULL,
  pr_cpm                          DECIMAL(12,5),
  checked_by_person_id            INTEGER       NOT NULL,
  checked_by_date                 DATETIME      NOT NULL,
  ua_id                           INTEGER       NOT NULL,
  accepted_by_person_id           INTEGER,
  accepted_by_date                DATETIME,
  created_date                    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_modified_date              TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by                      INTEGER       NOT NULL,
  last_modified_by                INTEGER       NOT NULL,
  PRIMARY KEY (inventory_package_id)
);

ALTER TABLE inventory_package
ADD CONSTRAINT FK_InventoryPackage_PackageType
FOREIGN KEY (package_type_id)
REFERENCES package_type (package_type_id);

ALTER TABLE inventory_package
ADD CONSTRAINT FK_InventoryPackage_PackageVendor
FOREIGN KEY (package_vendor_id)
REFERENCES package_vendor (package_vendor_id);

ALTER TABLE inventory_package
ADD CONSTRAINT FK_IP_Person_CheckedBy
FOREIGN KEY (checked_by_person_id)
REFERENCES person (id);

ALTER TABLE inventory_package
ADD CONSTRAINT FK_InventoryPackage_Ua
FOREIGN KEY (ua_id)
REFERENCES ua (id);

ALTER TABLE inventory_package
ADD CONSTRAINT FK_IP_Person_AcceptedBy
FOREIGN KEY (accepted_by_person_id)
REFERENCES person (id);


-- New tables for material requests
-- Test type - for leak testing sealed sources
CREATE TABLE test_type (
  test_type_id             INTEGER       AUTO_INCREMENT,
  test_name                VARCHAR(50)   NOT NULL,
  PRIMARY KEY (test_type_id)
);

INSERT INTO `test_type` (`test_type_id`, `test_name`) VALUES ('1', 'None');
INSERT INTO `test_type` (`test_type_id`, `test_name`) VALUES ('2', 'Leak Test');
INSERT INTO `test_type` (`test_type_id`, `test_name`) VALUES ('3', 'Contamination Test');

-- Material request status
CREATE TABLE request_status (
  request_status_id             INTEGER       AUTO_INCREMENT,
  request_status_description    VARCHAR(50)   NOT NULL,
  PRIMARY KEY (request_status_id)
);

INSERT INTO `request_status` (`request_status_id`, `request_status_description`) VALUES ('1', 'Requested');
INSERT INTO `request_status` (`request_status_id`, `request_status_description`) VALUES ('2', 'Received');
INSERT INTO `request_status` (`request_status_id`, `request_status_description`) VALUES ('3', 'Transferred');
INSERT INTO `request_status` (`request_status_id`, `request_status_description`) VALUES ('4', 'Declined');

-- Material order
CREATE TABLE material_order (
  material_order_id                INTEGER       AUTO_INCREMENT,
  material_request_number          INTEGER       NOT NULL,
  ua_pw_id                         INTEGER       NOT NULL,
  physical_form_id                 INTEGER       NOT NULL,
  chemical_form                    VARCHAR(50)   NOT NULL,
  user_comment                     VARCHAR(1000),
  request_status_id                INTEGER       NOT NULL,
  reference_date                 DATETIME,
  requested_date                   DATETIME      NOT NULL,
  requested_by_person_id           INTEGER       NOT NULL,
  received_date_ehs                DATETIME,
  received_by_ehs_person_id        INTEGER,
  received_date_lab                DATETIME,
  received_by_lab_person_id        INTEGER,
  stored_at_location_id            INTEGER       NOT NULL,
  stored_sub_location              VARCHAR(1000),
  test_type_id                     INTEGER,
  elemental_mass_grams             DECIMAL(12,5),
  sample_net_mass_grams            DECIMAL(12,5),
  requested_amount_mci             DECIMAL(12,5),
  requested_volume_ul              DECIMAL(12,5),
  inventory_package_id             INTEGER,
  created_date                     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_modified_date               TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by                       INTEGER       NOT NULL,
  last_modified_by                 INTEGER       NOT NULL,
  is_active                        BOOLEAN       NOT NULL,
  PRIMARY KEY (material_order_id)
);

ALTER TABLE material_order
ADD CONSTRAINT FK_MaterialOrder_UAPW
FOREIGN KEY (ua_pw_id)
REFERENCES ua_planned_work (ua_pw_id);

ALTER TABLE material_order
ADD CONSTRAINT FK_MaterialOrder_PhysicalForm
FOREIGN KEY (physical_form_id)
REFERENCES physical_form (physical_form_id);

ALTER TABLE material_order
ADD CONSTRAINT FK_MaterialOrder_TestType
FOREIGN KEY (test_type_id)
REFERENCES test_type (test_type_id);

ALTER TABLE material_order
ADD CONSTRAINT FK_MaterialOrder_RequestStatus
FOREIGN KEY (request_status_id)
REFERENCES request_status (request_status_id);

ALTER TABLE material_order
ADD CONSTRAINT FK_MO_Person_RequestedBy
FOREIGN KEY (requested_by_person_id)
REFERENCES person (id);

ALTER TABLE material_order
ADD CONSTRAINT FK_MO_Person_ReceivedByEhs
FOREIGN KEY (received_by_ehs_person_id)
REFERENCES person (id);

ALTER TABLE material_order
ADD CONSTRAINT FK_MO_Person_ReceivedByLab
FOREIGN KEY (received_by_lab_person_id)
REFERENCES person (id);

ALTER TABLE material_order
ADD CONSTRAINT FK_MaterialOrder_Location
FOREIGN KEY (stored_at_location_id)
REFERENCES location (id);

ALTER TABLE material_order
ADD CONSTRAINT FK_MaterialOrder_InventoryPackage
FOREIGN KEY (inventory_package_id)
REFERENCES inventory_package (inventory_package_id);


-- test data for material requests
-- Pu-240
INSERT INTO `license_line_number` (`license_line_number_id`, `line_number`, `license_id`, `is_specific`, `name`, `description`, `line_number_radionuclide_form_id`, `campus_limit`, `campus_limit_unit_id`) VALUES ('30', '6.X.3', @UCT_LICENSE_ID, FALSE, 'Pu-240', 'Plutonium-240', 1, 100, 1);
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('2', '66', '30', '0', '1', '0', '0', '0', '1', '0');
INSERT INTO `ua_planned_work` (`ua_pw_id`, `chemical_form`, `description_of_use`, `potential_hazards`, `protection_precautions`, `waste_methods`, `experiment_possession_limit_mci`, `is_sealed_source`, `requested_possession_limit_mci`, `single_source_limit_mci`, `vial_possession_limit_mci`, `radionuclide_id`, `ua_id`, `license_line_number_id`, `purpose_type`, `research_type`, `physical_form_id`, `unit`) VALUES ('4', 'Special One', 'Carefully.', 'It is radiation.', 'All required precautions.', 'Per guidelines.', 5.0, 0, 20.5, 0, 1, 66, 2, 30, 'CLINICAL', 'HUMAN', 2, 4);

-- Th-232
INSERT INTO `license_line_number` (`license_line_number_id`, `line_number`, `license_id`, `is_specific`, `name`, `description`, `line_number_radionuclide_form_id`, `campus_limit`, `campus_limit_unit_id`) VALUES ('31', '6.X.4', @UCT_LICENSE_ID, FALSE, 'Th-232', 'Thorium-232', 1, 100, 1);
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('3', '84', '31', '0', '1', '0', '0', '0', '1', '1');
INSERT INTO `ua_planned_work` (`ua_pw_id`, `chemical_form`, `description_of_use`, `potential_hazards`, `protection_precautions`, `waste_methods`, `experiment_possession_limit_mci`, `is_sealed_source`, `requested_possession_limit_mci`, `single_source_limit_mci`, `vial_possession_limit_mci`, `radionuclide_id`, `ua_id`, `license_line_number_id`, `purpose_type`, `research_type`, `physical_form_id`, `unit`) VALUES ('6', 'Source One', 'Play with it.', 'It is radiation.', 'All required precautions.', 'Per guidelines.', 5.0, 0, 20.5, 0, 1, 84, 2, 31, 'CLINICAL', 'HUMAN', 2, 4);

-- C-14 - for testing inventory amendment
INSERT INTO `license_line_number` (`license_line_number_id`, `line_number`, `license_id`, `is_specific`, `name`, `description`, `line_number_radionuclide_form_id`, `campus_limit`, `campus_limit_unit_id`) VALUES ('32', '6.B.2', @UCT_LICENSE_ID, FALSE, 'C-14', 'C-14', 1, 100, 1);
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('4', '125', '32', '0', '1', '0', '0', '0', '0', '0');
INSERT INTO `ua_planned_work` (`ua_pw_id`, `chemical_form`, `description_of_use`, `potential_hazards`, `protection_precautions`, `waste_methods`, `experiment_possession_limit_mci`, `is_sealed_source`, `requested_possession_limit_mci`, `single_source_limit_mci`, `vial_possession_limit_mci`, `radionuclide_id`, `ua_id`, `license_line_number_id`, `purpose_type`, `research_type`, `physical_form_id`, `unit`) VALUES ('7', 'Liquid', 'Play with it.', 'It is radiation.', 'All required precautions.', 'Per guidelines.', 5.0, 0, 20.0, 0, 1, 125, 2, 32, 'CLINICAL', 'HUMAN', 3, 1);

-- line number item for As-74
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('5', '306', '1', '0', '0', '0', '1', '0', '0', '0');

-- line number item for Bi-207
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('6', '14', '2', '0', '1', '0', '0', '0', '0', '0');

-- Co-60 - for validating waste containers with 7 radionuclides
INSERT INTO `ua_planned_work` (`ua_pw_id`, `chemical_form`, `description_of_use`, `potential_hazards`, `protection_precautions`, `waste_methods`, `experiment_possession_limit_mci`, `is_sealed_source`, `requested_possession_limit_mci`, `single_source_limit_mci`, `vial_possession_limit_mci`, `radionuclide_id`, `ua_id`, `license_line_number_id`, `purpose_type`, `research_type`, `physical_form_id`, `unit`) VALUES ('8', 'Liquid', 'Play with it.', 'It is radiation.', 'All required precautions.', 'Per guidelines.', 5.0, 0, 20.0, 0, 1, 31, 2, 4, 'CLINICAL', 'HUMAN', 3, 4);

-- Am-241 for validating waste containers with 7 radionuclides
INSERT INTO `ua_planned_work` (`ua_pw_id`, `chemical_form`, `description_of_use`, `potential_hazards`, `protection_precautions`, `waste_methods`, `experiment_possession_limit_mci`, `is_sealed_source`, `requested_possession_limit_mci`, `single_source_limit_mci`, `vial_possession_limit_mci`, `radionuclide_id`, `ua_id`, `license_line_number_id`, `purpose_type`, `research_type`, `physical_form_id`, `unit`) VALUES ('9', 'Liquid', 'Play with it.', 'It is radiation.', 'All required precautions.', 'Per guidelines.', 5.0, 0, 20.0, 0, 1, 9, 2, 4, 'CLINICAL', 'HUMAN', 3, 4);

-- Bi-210 for validating waste containers with 7 radionuclides
INSERT INTO `ua_planned_work` (`ua_pw_id`, `chemical_form`, `description_of_use`, `potential_hazards`, `protection_precautions`, `waste_methods`, `experiment_possession_limit_mci`, `is_sealed_source`, `requested_possession_limit_mci`, `single_source_limit_mci`, `vial_possession_limit_mci`, `radionuclide_id`, `ua_id`, `license_line_number_id`, `purpose_type`, `research_type`, `physical_form_id`, `unit`) VALUES ('10', 'Liquid', 'Play with it.', 'It is radiation.', 'All required precautions.', 'Per guidelines.', 5.0, 0, 20.0, 0, 1, 15, 2, 4, 'CLINICAL', 'HUMAN', 3, 4);

-- Test data for inventory package
INSERT INTO `inventory_package` (`inventory_package_id`, `inventory_package_number`, `package_type_id`, `transport_index`, `package_vendor_id`, `comments`, `contact_reading`, `one_meter_reading`, `received_date`, `ex_swipe_con_free`, `pr_swipe_con_free`, `checked_by_person_id`, `checked_by_date`, `ua_id`, `accepted_by_person_id`, `accepted_by_date`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES (@INVENTORY_PACKAGE_ID, '1', '1', '1', '1', 'Test Comments', '1', '1', '2015-04-26 00:00:00', '1', '1', '3', '2015-04-26 00:00:00', '2', '3', '2015-04-26 00:00:00', '2015-04-26 00:00:00', '2015-04-26 00:00:00', @RSO_UCT_PERSON_ID, @RSO_UCT_PERSON_ID);


-- test data for material orders
INSERT INTO `material_order` (`material_order_id`, `material_request_number`, `ua_pw_id`, `physical_form_id`, `stored_at_location_id`, `chemical_form`, `requested_amount_mci`, `requested_volume_ul`, `request_status_id`, `requested_date`, `requested_by_person_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `test_type_id`, `reference_date`, `received_date_ehs`, `received_by_ehs_person_id`, `inventory_package_id`, `is_active`) VALUES (1, 1, 1, 2, @UCT_LOCATION_ID_1, 'something awesome', '2.8', '5.6', 2, '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, '2015-04-26 00:00:00', '2015-05-20 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID, 1, '2016-02-27 00:00:00', '2016-01-20 00:00:00', @RSO_UCT_PERSON_ID, @INVENTORY_PACKAGE_ID, TRUE);
INSERT INTO `material_order` (`material_order_id`, `material_request_number`, `ua_pw_id`, `physical_form_id`, `stored_at_location_id`, `chemical_form`, `requested_amount_mci`, `requested_volume_ul`, `request_status_id`, `requested_date`, `requested_by_person_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `user_comment`, `stored_sub_location`, `is_active`) VALUES (2, 2, 1, 2, @UCT_LOCATION_ID_1, 'something new', '3', '6', 1, '2015-04-26 00:00:00', @AU_UCT_PERSON_ID_3, '2015-04-26 00:00:00', '2015-04-26 00:00:00', @AU_UCT_PERSON_ID_3, @AU_UCT_PERSON_ID_3, 'Please make sure the chemical form is accurate. Also I want inventory with no residue left. So if there is residue left, then please return the inventory and order new.', 'Above the central shelf', TRUE);
INSERT INTO `material_order` (`material_order_id`, `material_request_number`, `ua_pw_id`, `physical_form_id`, `stored_at_location_id`, `chemical_form`, `requested_amount_mci`, `requested_volume_ul`, `request_status_id`, `requested_date`, `requested_by_person_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `user_comment`, `stored_sub_location`, `is_active`) VALUES (3, 3, 1, 2, @UCT_LOCATION_ID_1, 'something different', '1.2', '2.00', 1, '2015-04-23 00:00:00', @RP_UCT_PERSON_ID, '2015-04-23 00:00:00', '2015-04-23 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, 'Please make sure the chemical form is accurate. Also I want inventory with no residue left. So if there is residue left, then please return the inventory and order new.', 'In the central shelf', TRUE);
INSERT INTO `material_order` (`material_order_id`, `material_request_number`, `ua_pw_id`, `physical_form_id`, `stored_at_location_id`, `chemical_form`, `requested_amount_mci`, `requested_volume_ul`, `request_status_id`, `requested_date`, `requested_by_person_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `test_type_id`, `reference_date`, `received_date_ehs`, `received_by_ehs_person_id`, `inventory_package_id`, `is_active`) VALUES (4, 4, 1, 2, @UCT_LOCATION_ID_1, 'something different2', '1.5', '3.00', 2, '2015-04-23 00:00:00', @RP_UCT_PERSON_ID, '2015-04-23 00:00:00', '2015-05-20 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, 1, '2015-04-30 00:00:00', '2015-05-20 00:00:00', @RSO_UCT_PERSON_ID, @INVENTORY_PACKAGE_ID, TRUE);
INSERT INTO `material_order` (`material_order_id`, `material_request_number`, `ua_pw_id`, `physical_form_id`, `stored_at_location_id`, `chemical_form`, `requested_amount_mci`, `requested_volume_ul`, `request_status_id`, `requested_date`, `requested_by_person_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `test_type_id`, `reference_date`, `received_date_ehs`, `received_by_ehs_person_id`, `inventory_package_id`, `is_active`) VALUES (5, 5, 1, 2, @UCT_LOCATION_ID_1, 'something new2', '2.00', '4.00', 2, '2015-04-26 00:00:00', @AU_UCT_PERSON_ID_3, '2015-04-26 00:00:00', '2015-05-20 00:00:00', @AU_UCT_PERSON_ID_3, @AU_UCT_PERSON_ID_3, 1, '2015-04-30 00:00:00', '2015-05-20 00:00:00', @RSO_UCT_PERSON_ID, @INVENTORY_PACKAGE_ID, TRUE);
INSERT INTO `material_order` (`material_order_id`, `material_request_number`, `ua_pw_id`, `physical_form_id`, `stored_at_location_id`, `chemical_form`, `requested_amount_mci`, `requested_volume_ul`, `request_status_id`, `requested_date`, `requested_by_person_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `test_type_id`, `reference_date`, `received_date_ehs`, `received_by_ehs_person_id`, `user_comment`, `stored_sub_location`, `is_active`) VALUES (6, 6, 5, 2, @UCT_LOCATION_ID_1, 'something new2', '2.00', '4.00', 1, '2015-04-26 00:00:00', @AU_UCT_PERSON_ID_3, '2015-04-26 00:00:00', '2015-05-20 00:00:00', @AU_UCT_PERSON_ID_3, @AU_UCT_PERSON_ID_3, 1, '2015-04-30 00:00:00', '2015-05-20 00:00:00', @RSO_UCT_PERSON_ID, 'Please make sure the chemical form is accurate. Also I want inventory with no residue left. So if there is residue left, then please return the inventory and order new.', 'Above the fridge', TRUE);
INSERT INTO `material_order` (`material_order_id`, `material_request_number`, `ua_pw_id`, `physical_form_id`, `stored_at_location_id`, `chemical_form`, `elemental_mass_grams`, `sample_net_mass_grams`, `request_status_id`, `requested_date`, `requested_by_person_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `test_type_id`, `reference_date`, `received_date_ehs`, `received_by_ehs_person_id`, `inventory_package_id`, `is_active`) VALUES (7, 7, 4, 2, @UCT_LOCATION_ID_1, 'special nuclear', '0.00300', '0.00300', 2, '2015-04-26 00:00:00', @AU_UCT_PERSON_ID_3, '2015-04-26 00:00:00', '2015-05-20 00:00:00', @AU_UCT_PERSON_ID_3, @AU_UCT_PERSON_ID_3, 1, '2015-04-30 00:00:00', '2015-05-20 00:00:00', @RSO_UCT_PERSON_ID, @INVENTORY_PACKAGE_ID, TRUE);
INSERT INTO `material_order` (`material_order_id`, `material_request_number`, `ua_pw_id`, `physical_form_id`, `stored_at_location_id`, `chemical_form`, `elemental_mass_grams`, `sample_net_mass_grams`, `request_status_id`, `requested_date`, `requested_by_person_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `test_type_id`, `reference_date`, `received_date_ehs`, `received_by_ehs_person_id`, `inventory_package_id`, `is_active`) VALUES (8, 8, 6, 2, @UCT_LOCATION_ID_1, 'source material', '0.00300', '0.00300', 2, '2015-04-26 00:00:00', @AU_UCT_PERSON_ID_3, '2015-04-26 00:00:00', '2015-05-20 00:00:00', @AU_UCT_PERSON_ID_3, @AU_UCT_PERSON_ID_3, 1, '2015-04-30 00:00:00', '2015-05-20 00:00:00', @RSO_UCT_PERSON_ID, @INVENTORY_PACKAGE_ID, TRUE);

-- C-14 for testing amendment of inventory
INSERT INTO `material_order` (`material_order_id`, `material_request_number`, `ua_pw_id`, `physical_form_id`, `stored_at_location_id`, `chemical_form`, `requested_amount_mci`, `requested_volume_ul`, `request_status_id`, `requested_date`, `requested_by_person_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `test_type_id`, `reference_date`, `received_date_ehs`, `received_by_ehs_person_id`, `inventory_package_id`, `is_active`) VALUES (9, 9, 7, 2, @UCT_LOCATION_ID_1, 'something new 3', '5.0', '20.0', 2, '2015-04-26 00:00:00', @AU_UCT_PERSON_ID_3, '2015-04-26 00:00:00', '2015-05-20 00:00:00', @AU_UCT_PERSON_ID_3, @AU_UCT_PERSON_ID_3, 1, '2015-04-30 00:00:00', '2015-05-20 00:00:00', @RSO_UCT_PERSON_ID, @INVENTORY_PACKAGE_ID, TRUE);

-- Co-60 for validating waste containers with 7 radionuclides
INSERT INTO `material_order` (`material_order_id`, `material_request_number`, `ua_pw_id`, `physical_form_id`, `stored_at_location_id`, `chemical_form`, `requested_amount_mci`, `requested_volume_ul`, `request_status_id`, `requested_date`, `requested_by_person_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `test_type_id`, `reference_date`, `received_date_ehs`, `received_by_ehs_person_id`, `inventory_package_id`, `is_active`) VALUES (10, 10, 8, 2, @UCT_LOCATION_ID_1, 'something new 3', '5.0', '20.0', 2, '2015-04-26 00:00:00', @AU_UCT_PERSON_ID_3, '2015-04-26 00:00:00', '2015-05-20 00:00:00', @AU_UCT_PERSON_ID_3, @AU_UCT_PERSON_ID_3, 1, '2015-04-30 00:00:00', '2015-05-20 00:00:00', @RSO_UCT_PERSON_ID, @INVENTORY_PACKAGE_ID, TRUE);

-- Am-241 for validating waste containers with 7 radionuclides
INSERT INTO `material_order` (`material_order_id`, `material_request_number`, `ua_pw_id`, `physical_form_id`, `stored_at_location_id`, `chemical_form`, `requested_amount_mci`, `requested_volume_ul`, `request_status_id`, `requested_date`, `requested_by_person_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `test_type_id`, `reference_date`, `received_date_ehs`, `received_by_ehs_person_id`, `inventory_package_id`, `is_active`) VALUES (11, 11, 9, 2, @UCT_LOCATION_ID_1, 'something new 3', '5.0', '20.0', 2, '2015-04-26 00:00:00', @AU_UCT_PERSON_ID_3, '2015-04-26 00:00:00', '2015-05-20 00:00:00', @AU_UCT_PERSON_ID_3, @AU_UCT_PERSON_ID_3, 1, '2015-04-30 00:00:00', '2015-05-20 00:00:00', @RSO_UCT_PERSON_ID, @INVENTORY_PACKAGE_ID, TRUE);

-- Bi-210 for validating waste containers with 7 radionuclides
INSERT INTO `material_order` (`material_order_id`, `material_request_number`, `ua_pw_id`, `physical_form_id`, `stored_at_location_id`, `chemical_form`, `requested_amount_mci`, `requested_volume_ul`, `request_status_id`, `requested_date`, `requested_by_person_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `test_type_id`, `reference_date`, `received_date_ehs`, `received_by_ehs_person_id`, `inventory_package_id`, `is_active`) VALUES (12, 12, 10, 2, @UCT_LOCATION_ID_1, 'something new 3', '5.0', '20.0', 2, '2015-04-26 00:00:00', @AU_UCT_PERSON_ID_3, '2015-04-26 00:00:00', '2015-05-20 00:00:00', @AU_UCT_PERSON_ID_3, @AU_UCT_PERSON_ID_3, 1, '2015-04-30 00:00:00', '2015-05-20 00:00:00', @RSO_UCT_PERSON_ID, @INVENTORY_PACKAGE_ID, TRUE);


-- Inventory Use Log Status
CREATE TABLE inventory_use_log_status (
  inventory_use_log_status_id INTEGER AUTO_INCREMENT,
  description VARCHAR(50) NOT NULL,
  PRIMARY KEY (inventory_use_log_status_id)
);

-- Inventory Use Log status insert statements.
INSERT INTO `inventory_use_log_status` (`inventory_use_log_status_id`, `description`) VALUES ('1', 'Calibration');
INSERT INTO `inventory_use_log_status` (`inventory_use_log_status_id`, `description`) VALUES ('2', 'In Process');
INSERT INTO `inventory_use_log_status` (`inventory_use_log_status_id`, `description`) VALUES ('3', 'In Disposal');
INSERT INTO `inventory_use_log_status` (`inventory_use_log_status_id`, `description`) VALUES ('4', 'Decayed');

-- Inventory options create table
CREATE TABLE inventory_status (
  inventory_status_id INTEGER AUTO_INCREMENT,
  description VARCHAR(50) NOT NULL,
  PRIMARY KEY (inventory_status_id)
);

-- Inventory status insert statements.
INSERT INTO `inventory_status` (`inventory_status_id`, `description`) VALUES ('1', 'In Inventory');
INSERT INTO `inventory_status` (`inventory_status_id`, `description`) VALUES ('2', 'Used Completely');

-- Inventory  create table
CREATE TABLE inventory (
  inventory_id              INTEGER AUTO_INCREMENT,
  current_amount_mci        DECIMAL(12,5),
  current_volume_ul         DECIMAL(12,5),
  current_elemental_mass    DECIMAL(12,5),
  current_sample_net_mass   DECIMAL(12,5),
  inventory_type            VARCHAR(50) NOT NULL,
  inventory_status_id       INTEGER    NOT NULL,
  material_order_id         INTEGER    NOT NULL,
  created_date              TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_modified_date        TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by                INTEGER    NOT NULL,
  last_modified_by          INTEGER    NOT NULL,
  is_active                 BOOLEAN    NOT NULL,
  PRIMARY KEY (inventory_id)
);


ALTER TABLE inventory
ADD CONSTRAINT FK_Inventory_InventoryStatus
FOREIGN KEY (inventory_status_id)
REFERENCES inventory_status (inventory_status_id);

ALTER TABLE inventory
ADD CONSTRAINT FK_Inventory_MaterialOrder
FOREIGN KEY (material_order_id)
REFERENCES material_order (material_order_id);


-- adding test data for use log purpose
INSERT INTO `inventory` (`inventory_id`, `current_amount_mci`, `current_volume_ul`, `material_order_id`,`created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `inventory_status_id`, `inventory_type`, `is_active`) VALUES ('1', '2.8', '5.6', '1','2015-04-26 00:00:00', '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, 1, 'RAM', TRUE);
INSERT INTO `inventory` (`inventory_id`, `current_elemental_mass`, `current_sample_net_mass`, `material_order_id`,`created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `inventory_status_id`, `inventory_type`, `is_active`) VALUES ('2', '0.00200', '0.00200', '7','2015-04-26 00:00:00', '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, 1, 'RAM', TRUE);
INSERT INTO `inventory` (`inventory_id`, `current_elemental_mass`, `current_sample_net_mass`, `material_order_id`,`created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `inventory_status_id`, `inventory_type`, `is_active`) VALUES ('3', '0.00200', '0.00200', '8','2015-04-26 00:00:00', '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, 1, 'RAM', TRUE);

-- C-14 for validating waste containers with 7 radionuclides
INSERT INTO `inventory` (`inventory_id`, `current_amount_mci`, `current_volume_ul`, `material_order_id`,`created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `inventory_status_id`, `inventory_type`, `is_active`) VALUES ('4', '5.0', '20.0', '9','2015-04-26 00:00:00', '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, 1, 'RAM', TRUE);

-- Co-60 for validating waste containers with 7 radionuclides
INSERT INTO `inventory` (`inventory_id`, `current_amount_mci`, `current_volume_ul`, `material_order_id`,`created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `inventory_status_id`, `inventory_type`, `is_active`) VALUES ('5', '5.0', '20.0', '10','2015-04-26 00:00:00', '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, 1, 'RAM', TRUE);

-- Am-241 for validating waste containers with 7 radionuclides
INSERT INTO `inventory` (`inventory_id`, `current_amount_mci`, `current_volume_ul`, `material_order_id`,`created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `inventory_status_id`, `inventory_type`, `is_active`) VALUES ('6', '5.0', '20.0', '11','2015-04-26 00:00:00', '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, 1, 'RAM', TRUE);

-- Bi-210 for validating waste containers with 7 radionuclides
INSERT INTO `inventory` (`inventory_id`, `current_amount_mci`, `current_volume_ul`, `material_order_id`,`created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `inventory_status_id`, `inventory_type`, `is_active`) VALUES ('7', '5.0', '20.0', '12','2015-04-26 00:00:00', '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, 1, 'RAM', TRUE);


-- Waste Type
CREATE TABLE waste_type (
  waste_type_id             INTEGER       AUTO_INCREMENT,
  waste_type_description    VARCHAR(1000) NOT NULL,
  waste_type_label          VARCHAR(100)  NOT NULL,
  campus_code               VARCHAR(2)    NOT NULL,
  physical_form_id          INTEGER       NOT NULL,
  PRIMARY KEY (waste_type_id)
);


ALTER TABLE waste_type
ADD CONSTRAINT FK_WasteType_Campus
FOREIGN KEY (campus_code)
REFERENCES campus (code);

ALTER TABLE waste_type
ADD CONSTRAINT FK_WasteType_PhysicalForm
FOREIGN KEY (physical_form_id)
REFERENCES physical_form (physical_form_id);

-- Inserting waste types
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('1', 'Dry Solid', 'DRY_SOLID', '2','99');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('2', 'Liquid', 'LIQUID', '3', '99');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('3', 'Exempt Scintillation Vials', 'EXEMPT_VIALS', '2', '99');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('4', 'Regulated Scintillation Vials', 'REGULATED_VIALS', '2', '99');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('5', 'Source Vials', 'SOURCE_VIALS', '2', '99');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('6', 'Bactec Plates', 'BACTEC_PLATES','2', '99');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('7', 'Beta Plates', 'BETA_PLATES', '2', '99');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('8', 'Other', 'OTHER', '2', '99');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('9', 'Sharps', 'SHARPS', '2', '99');


-- Waste Container Type
CREATE TABLE waste_container_type (
  waste_container_type_id             INTEGER       AUTO_INCREMENT,
  waste_container_type_description    VARCHAR(1000)  NOT NULL,
  waste_container_type_label          VARCHAR(45)   NOT NULL,
  campus_code                         VARCHAR(2)    NOT NULL,
  PRIMARY KEY (waste_container_type_id)
);

ALTER TABLE waste_container_type
ADD CONSTRAINT FK_WasteContainerType_Campus
FOREIGN KEY (campus_code)
REFERENCES campus (code);

-- Inserting waste container types
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('1', 'Aerosol', 'AEROSOL', '99');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('2', 'Bag', 'BAG', '99');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('3', 'Bottle, Glass', 'BOTTLE_GLASS', '99');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('4', 'Bottle, Plastic', 'BOTTLE_PLASTIC', '99');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('5', 'Box, Cardboard', 'BOX_CARDBOARD', '99');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('6', 'Box, 2 Cubic Feet', 'BOX_2_CUBIC_FEET', '99');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('7', 'Box, Cubic Yard', 'BOX_CUBIC_YARD', '99');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('8', 'Carboy', 'CARBOY', '99');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('9', 'Cylinder', 'CYLINDER', '99');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('10', 'Drum, Metal', 'DRUM_METAL', '99');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('11', 'Drum, Poly', 'DRUM_POLY', '99');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('12', 'Metal Can', 'METAL_CAN', '99');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('13', 'Pail', 'PAIL', '99');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('14', 'Sharps Container', 'SHARPS_CONTAINER', '99');


-- Waste Container creation
CREATE TABLE waste_container (
  waste_container_id               INTEGER       AUTO_INCREMENT,
  container_name                   VARCHAR(1000) NOT NULL,
  waste_type_id                    INTEGER       NOT NULL,
  waste_container_type_id          INTEGER       NOT NULL,
  location_id                      INTEGER       NOT NULL,
  container_amount_mci             DECIMAL(12,5) NOT NULL,
  container_volume_ul              DECIMAL(12,5) NOT NULL,
  container_elemental_mass         DECIMAL(12,5) NOT NULL,
  container_sample_net_mass        DECIMAL(12,5) NOT NULL,
  container_size                   DECIMAL(12,5),
  created_from                     INTEGER,
  is_active                        BOOLEAN       NOT NULL,
  tracking_number                  VARCHAR(50),
  request_pick_up_date             DATETIME,
  created_date                     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_modified_date               TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by                       INTEGER       NOT NULL,
  last_modified_by                 INTEGER       NOT NULL,
  PRIMARY KEY (waste_container_id)
);

ALTER TABLE waste_container
ADD CONSTRAINT FK_WasteContainer_WasteType
FOREIGN KEY (waste_type_id)
REFERENCES waste_type (waste_type_id);


ALTER TABLE waste_container
ADD CONSTRAINT FK_WasteContainer_WasteContainerType
FOREIGN KEY (waste_container_type_id)
REFERENCES waste_container_type (waste_container_type_id);


ALTER TABLE waste_container
ADD CONSTRAINT FK_WasteContainer_Location
FOREIGN KEY (location_id)
REFERENCES location(id);

-- Insert Waste container
INSERT INTO `waste_container` (`waste_container_id`, `container_name`, `waste_type_id`, `waste_container_type_id`, `location_id`, `container_amount_mci`, `container_volume_ul`, `container_elemental_mass`, `container_sample_net_mass`, `is_active`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES ('1', 'Dry Waste', '1', '1', '1', '0.1', '1', '0', '0', '1', '2015-04-30 00:00:00', '2015-04-30 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID);
INSERT INTO `waste_container` (`waste_container_id`, `container_name`, `waste_type_id`, `waste_container_type_id`, `location_id`, `container_amount_mci`, `container_volume_ul`, `container_elemental_mass`, `container_sample_net_mass`, `is_active`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES ('2', 'Liquid Waste', '2', '1', '1', '0', '0', '0', '0', '1', '2015-04-30 00:00:00', '2015-04-30 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID);


-- Inventory use log table
CREATE TABLE inventory_use_log (
  inventory_use_log_id             INTEGER       AUTO_INCREMENT,
  use_log_number                   INTEGER       NOT NULL,
  inventory_id                     INTEGER       NOT NULL,
  in_use_amount_mci                DECIMAL(12,5),
  in_use_volume_ul                 DECIMAL(12,5),
  initial_amount_mci               DECIMAL(12,5),
  initial_volume_ul                DECIMAL(12,5),
  in_use_elemental_mass            DECIMAL(12,5),
  in_use_sample_net_mass           DECIMAL(12,5),
  initial_elemental_mass           DECIMAL(12,5),
  initial_sample_net_mass          DECIMAL(12,5),
  process_name                     VARCHAR(1000) NOT NULL,
  waste_container_id               INTEGER,
  inventory_use_log_status_id      INTEGER,
  created_from_use_log_id          INTEGER,
  logged_date                      DATETIME      NOT NULL,
  logged_by_person_id              INTEGER       NOT NULL,
  is_active                        BOOLEAN       NOT NULL,
  created_date                     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_modified_date               TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by                       INTEGER       NOT NULL,
  last_modified_by                 INTEGER       NOT NULL,
  PRIMARY KEY (inventory_use_log_id)
);

ALTER TABLE inventory_use_log
ADD CONSTRAINT FK_InventoryUseLog_Inventory
FOREIGN KEY (inventory_id)
REFERENCES inventory (inventory_id);

ALTER TABLE inventory_use_log
ADD CONSTRAINT FK_InventoryUseLog_WasteContainer
FOREIGN KEY (waste_container_id)
REFERENCES waste_container (waste_container_id);

ALTER TABLE inventory_use_log
ADD CONSTRAINT FK_InventoryUseLog_InventoryUseLogStatus
FOREIGN KEY (inventory_use_log_status_id)
REFERENCES inventory_use_log_status (inventory_use_log_status_id);

ALTER TABLE inventory_use_log
ADD CONSTRAINT FK_InventoryUseLog_Person_LoggedBy
FOREIGN KEY (logged_by_person_id)
REFERENCES person (id);

-- Insert Test use log
INSERT INTO `inventory_use_log` (`inventory_use_log_id`, `use_log_number`, `inventory_id`, `in_use_amount_mci`, `in_use_volume_ul`, `initial_amount_mci`, `initial_volume_ul`, `process_name`, `waste_container_id`, `inventory_use_log_status_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `logged_date`, `logged_by_person_id`, `is_active`) VALUES ('1', '-1', '1', '0.1', '0.2', '0.1', '0.2', 'Disposed', '1', '3', '2015-04-26 00:00:00', '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, TRUE);
INSERT INTO `inventory_use_log` (`inventory_use_log_id`, `use_log_number`, `inventory_id`, `in_use_amount_mci`, `in_use_volume_ul`, `initial_amount_mci`, `initial_volume_ul`, `process_name`, `inventory_use_log_status_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `logged_date`, `logged_by_person_id`, `is_active`) VALUES ('2', '1', '1', '0.1', '0.2', '0.1', '0.2', 'Experiment 1', '2', '2015-04-26 00:00:00', '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, TRUE);
INSERT INTO `inventory_use_log` (`inventory_use_log_id`, `use_log_number`, `inventory_id`, `in_use_elemental_mass`, `in_use_sample_net_mass`, `initial_elemental_mass`, `initial_sample_net_mass`, `process_name`, `waste_container_id`, `inventory_use_log_status_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `logged_date`, `logged_by_person_id`, `is_active`) VALUES ('3', '-1', '2', '0.001', '0.001', '0.001', '0.001', 'Disposed', '1', '3', '2015-04-26 00:00:00', '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, '2016-02-01 00:00:00', @RP_UCT_PERSON_ID, TRUE);
INSERT INTO `inventory_use_log` (`inventory_use_log_id`, `use_log_number`, `inventory_id`, `in_use_elemental_mass`, `in_use_sample_net_mass`, `initial_elemental_mass`, `initial_sample_net_mass`, `process_name`, `inventory_use_log_status_id`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `logged_date`, `logged_by_person_id`, `is_active`) VALUES ('4', '2', '3', '0.001', '0.001', '0.001', '0.001', 'Experiment 1', '2', '2015-04-26 00:00:00', '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, '2015-04-26 00:00:00', @RP_UCT_PERSON_ID, TRUE);

-- Test data changes for decay
UPDATE `ua_planned_work` SET `radionuclide_id` = 306 where `ua_pw_id` = 1;
UPDATE `license_line_number` SET `name` = 'As-74 and At-217' where `license_line_number_id` = 1;
UPDATE `license_line_number` SET `description` = 'As-74 and At-217' where `license_line_number_id` = 1;

-- Updating campus unit for the special and source material
UPDATE `license_line_number` SET `campus_limit_unit_id` = 4 where `license_line_number_id` = 30;
UPDATE `license_line_number` SET `campus_limit_unit_id` = 4 where `license_line_number_id` = 31;
UPDATE `license_line_number` SET `include_special_nuclear_material` = true where `license_line_number_id` = 30;
UPDATE `license_line_number` SET `include_source_material` = true where `license_line_number_id` = 31;


-- updating column names on UA PlannedWork to accommodate SNM and NON-SNM
ALTER TABLE `ua_planned_work` CHANGE `experiment_possession_limit_mci` `experiment_possession_limit` DOUBLE  NOT NULL;
ALTER TABLE `ua_planned_work` CHANGE `requested_possession_limit_mci` `requested_possession_limit` DOUBLE  NOT NULL;
ALTER TABLE `ua_planned_work` CHANGE `vial_possession_limit_mci` `vial_possession_limit` DOUBLE;
ALTER TABLE `ua_planned_work` CHANGE `single_source_limit_mci` `single_source_limit` DOUBLE;
