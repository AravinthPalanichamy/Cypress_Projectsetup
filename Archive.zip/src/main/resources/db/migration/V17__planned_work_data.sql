-- Updating Karen smith's ua information from UCM
UPDATE `ua_planned_work` SET `vial_possession_limit_mci`=0.005 WHERE `ua_pw_id` = 103;
UPDATE `ua_planned_work` SET `vial_possession_limit_mci`=0.005 WHERE `ua_pw_id` = 105;
UPDATE `ua_planned_work` SET `single_source_limit_mci`=15 WHERE `ua_pw_id` = 101;

UPDATE `ua_planned_work` SET `vial_possession_limit_mci`=0.005 WHERE `ua_pw_id` = 104;
UPDATE `ua_planned_work` SET `vial_possession_limit_mci`=0.005 WHERE `ua_pw_id` = 106;
UPDATE `ua_planned_work` SET `single_source_limit_mci`=15 WHERE `ua_pw_id` = 102;

-- Correct Radionuclide table
UPDATE `radionuclide` SET `half_life` = 17.77 where `radionuclide_id` = 306;

-- Add a field to UA Planned Work for Amendment
ALTER TABLE `ua_planned_work` ADD COLUMN `created_from` INTEGER;