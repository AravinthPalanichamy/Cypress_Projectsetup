--NOTE: PersonId starts with 2
SET @RP_UCT_PERSON_ID = 2;
SET @RSO_UCT_PERSON_ID = 3;
SET @RSCM_UCT_PERSON_ID = 4;
SET @RSS_UCT_PERSON_ID = 5;
SET @AU_UCT_PERSON_ID_1 = 6;
SET @AU_UCT_PERSON_ID_2 = 7;
SET @AU_UCT_PERSON_ID_3 = 8;
SET @AU_UCT_PERSON_ID_4 = 9;


SET @UCT_CODE = '99';

SET @UCT_LOCATION_ID_1 = 1;
SET @UCT_LOCATION_ID_2 = 2;
SET @UCT_LOCATION_ID_3 = 3;
SET @UCT_LOCATION_ID_4 = 4;

SET @UCT_UA_ID_1 = 1;
SET @UCT_UA_ID_2 = 2;
SET @UCT_UA_ID_3 = 3;
SET @UCT_UA_ID_4 = 4;
SET @UCT_UA_ID_5 = 5;
SET @UCT_UA_ID_6 = 6;
SET @UCT_UA_ID_7 = 7;
SET @UCT_UA_ID_8 = 8;

SET @AMEND_ID_1 = 1;
SET @AMEND_NUMBER_1 = 1;

SET @UCT_CORE_BUNDLE_ID_1 = 1;
SET @UCT_CORE_BUNDLE_ID_2 = 2;
SET @UCT_CORE_BUNDLE_ID_3 = 3;
SET @UCT_CORE_BUNDLE_ID_4 = 4;
SET @UCT_CORE_BUNDLE_ID_5 = 5;
SET @UCT_CORE_BUNDLE_ID_6 = 6;

SET @UCT_UA_BUNDLE_ID_1 = 1;
SET @UCT_UA_BUNDLE_ID_2 = 2;
SET @UCT_UA_BUNDLE_ID_3 = 3;
SET @UCT_UA_BUNDLE_ID_4 = 4;
SET @UCT_UA_BUNDLE_ID_5 = 5;


SET @UCT_LICENSE_NUMBER = '11';
SET @UCT_LICENSE_ID = 11;

INSERT INTO `campus` (`code`, `name`, `name_abbr`) VALUES (@UCT_CODE, 'University Of California - Test', 'UCT');

--LICENSE TEST DATA
INSERT INTO `license` (`license_id`, `license_number`, `license_name`, `campus_code`, `license_type_id`, `license_rule_type_id`, `person_id`, `expiration_date`, `inspection_agency`) VALUES (@UCT_LICENSE_ID, @UCT_LICENSE_NUMBER, 'Broad scope test', @UCT_CODE, 1, 1, 1, '2014-02-23 0:00:00', 'Radiological Health Branch North');

--LICENSE LINE NUMBER INFO TEST DATA
INSERT INTO `license_line_number_info` (`license_line_number_info_id`, `name`, `description`, `line_number_radionuclide_form_id`, `possession_limit`, `possession_limit_unit_id`) VALUES ('1', 'At-217', 'At-217', '1', '3000', '1');
INSERT INTO `license_line_number_info` (`license_line_number_info_id`, `name`, `description`, `line_number_radionuclide_form_id`, `possession_limit`, `possession_limit_unit_id`) VALUES ('2', 'Bi-207', 'Bismuth-207', '1', '100', '1');
INSERT INTO `license_line_number_info` (`license_line_number_info_id`, `name`, `description`, `line_number_radionuclide_form_id`, `possession_limit`, `possession_limit_unit_id`) VALUES ('3', 'H-3', 'Hydrogen-3', '4', '100', '1');

--LICENSE LINE NUMBER
INSERT INTO `license_line_number` (`license_line_number_id`, `line_number`, `license_id`, `is_specific`, `license_line_number_info_id`) VALUES (1, '6.A.1', @UCT_LICENSE_ID, FALSE, 1);
INSERT INTO `license_line_number` (`license_line_number_id`, `line_number`, `license_id`, `is_specific`, `license_line_number_info_id`) VALUES (2, '6.B.1', @UCT_LICENSE_ID, FALSE, 2);
INSERT INTO `license_line_number` (`license_line_number_id`, `line_number`, `license_id`, `is_specific`, `license_line_number_info_id`) VALUES (3, '6.C.1', @UCT_LICENSE_ID, FALSE, 3);

--PERSON TEST DATA
--RP
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `campus_code`, `status`, `gender`, `dob`) VALUES (@RP_UCT_PERSON_ID, 'testuser1@uctest.edu', 'user1@uctest.edu', 'Test1', 'User1', 'tst-1', @UCT_CODE, 'EMPLOYEE', 'MALE', '1980-10-10');
--RSO
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `campus_code`, `status`, `gender`, `dob`) VALUES (@RSO_UCT_PERSON_ID,  'testuser2@augueut.edu', 'user2@uctest.edu', 'Test2', 'User2', 'tst-2', @UCT_CODE, 'EMPLOYEE', 'MALE', '1980-10-10');
--RSCM
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `campus_code`) VALUES (@RSCM_UCT_PERSON_ID, 'testuser3@uctest.edu', 'user3@uctest.edu', 'Test3', 'User3', 'tst-3', @UCT_CODE);
--AU_1
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `campus_code`) VALUES (@AU_UCT_PERSON_ID_1, 'testuser4@uctest.edu', 'user4@uctest.edu', 'Test4', 'User4', 'tst-4', @UCT_CODE);
--RSS
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `campus_code`) VALUES (@RSS_UCT_PERSON_ID, 'testuser5@uctest.edu', 'user5@uctest.edu', 'Test5', 'User5', 'tst-5', @UCT_CODE);
--AU_3
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `campus_code`) VALUES (@AU_UCT_PERSON_ID_3, 'testuser6@uctest.edu', 'user6@uctest.edu', 'Test6', 'User6', 'tst-6', @UCT_CODE);
--AU_4
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `campus_code`) VALUES (@AU_UCT_PERSON_ID_4, 'testuser15@uctest.edu', 'user15@uctest.edu', 'Test15', 'User15', 'tst-15', @UCT_CODE);


-- LINE NUMBER RADIONUCLIDE FORM TEST DATA
INSERT INTO `line_number_radionuclide_form` (`line_number_radionuclide_form_id`, `line_number_radionuclide_form`) VALUES (9, 'Liquid-test');

--PERSON ROLE TEST DATA
INSERT INTO `person_role`(`person_id`,`role_type`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES (@RSO_UCT_PERSON_ID, 'RADIATION_SAFETY_OFFICER', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID);
INSERT INTO `person_role`(`person_id`,`role_type`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES (@RSCM_UCT_PERSON_ID, 'RADIATION_SAFETY_COMMITTEE_MEMBER', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID);
INSERT INTO `person_role`(`person_id`,`role_type`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES (@RSS_UCT_PERSON_ID, 'RADIATION_SAFETY_SPECIALIST', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID);

--LOCATION TEST DATA
INSERT INTO `location`(`id`, `building_display_name`,`building_key`,`building_primary_name`, `campus_code`, `floor_key`, `floor_name`, `room_key`, `room_number`) VALUES (@UCT_LOCATION_ID_1, 'TB1', 'T-B-1', 'Test Building 1', @UCT_CODE, 'T-F-1', 'Test Floor 1','T-R-1', '1');
INSERT INTO `location`(`id`, `building_display_name`,`building_key`,`building_primary_name`, `campus_code`, `floor_key`, `floor_name`, `room_key`, `room_number`) VALUES (@UCT_LOCATION_ID_2, 'TB1', 'T-B-1', 'Test Building 1', @UCT_CODE, 'T-F-1', 'Test Floor 1','T-R-2', '2');
INSERT INTO `location`(`id`, `building_display_name`,`building_key`,`building_primary_name`, `campus_code`, `floor_key`, `floor_name`, `room_key`, `room_number`) VALUES (@UCT_LOCATION_ID_3, 'TB1', 'T-B-1', 'Test Building 1', @UCT_CODE, 'T-F-1', 'Test Floor 1','T-R-3', '3');
INSERT INTO `location`(`id`, `building_display_name`,`building_key`,`building_primary_name`, `campus_code`, `floor_key`, `floor_name`, `room_key`, `room_number`) VALUES (@UCT_LOCATION_ID_4, 'TB1', 'T-B-1', 'Test Building 1', @UCT_CODE, 'T-F-1', 'Test Floor 1','T-R-4', '4');

--PERSON EXPERIENCE TEST DATA FOR RP
INSERT INTO `person_experience`(`address1`,`address2`,`city`, `end_date`, `institution_name`, `start_date`, `state`, `type_of_work`, `zip`, `person_id`, `is_active`) VALUES ('2000 Test St.', '#444', 'Davis', '2015-04-30 00:00:00', 'Test Institution', '2014-04-30 00:00:00','CA', 'That is what we do', '98754', @RP_UCT_PERSON_ID, true);
INSERT INTO `person_experience`(`address1`,`address2`,`city`, `end_date`, `institution_name`, `start_date`, `state`, `type_of_work`, `zip`, `person_id`, `is_active`) VALUES ('3000 Test St.', '#555', 'Davis', '2015-04-30 00:00:00', 'AuTest Institution', '2014-04-30 00:00:00','CA', 'That is what we do', '98754', @AU_UCT_PERSON_ID_1, true);

--PERSON DOSIMETRY TEST DATA FOR RP
INSERT INTO `person_dosimetry`(`address1`,`address2`,`city`, `end_date`, `institution_name`, `start_date`, `state`, `zip`, `person_id`, `is_active`) VALUES ('2000 Test St.', '#444', 'Davis', '2015-04-30 00:00:00', 'Test Institution', '2014-04-30 00:00:00','CA', '98754', @RP_UCT_PERSON_ID, true);
INSERT INTO `person_dosimetry`(`address1`,`address2`,`city`, `end_date`, `institution_name`, `start_date`, `state`, `zip`, `person_id`, `is_active`) VALUES ('3000 Test St.', '#555', 'Davis', '2015-04-30 00:00:00', 'AuTest Institution', '2014-04-30 00:00:00','CA', '98754', @AU_UCT_PERSON_ID_1, true);

--PERSON TRAINING TEST DATA FOR RP
INSERT INTO `person_training`(`completed_date`, `duration`, `institution_name`, `topic`, `person_id`, `is_active`, `expiry_date`) VALUES ('2014-04-30 00:00:00', 3, 'Test Institution', 'Test Topic', @RP_UCT_PERSON_ID, true, NULL );
INSERT INTO `person_training`(`completed_date`, `duration`, `institution_name`, `topic`, `person_id`, `is_active`, `expiry_date`) VALUES ('2014-04-30 00:00:00', 3, 'AuTest Institution', 'Test Topic', @AU_UCT_PERSON_ID_1, true, NULL);

--UA TEST DATA
INSERT INTO `ua`(`id`, `number`,`pi_person_id`, `status_type`, `type`, `expiry_date`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `is_active`) VALUES (@UCT_UA_ID_1, 1, @RP_UCT_PERSON_ID, 'DRAFT', 'RUA', '2020-04-30 00:00:00', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, true);
INSERT INTO `ua`(`id`, `number`,`pi_person_id`, `status_type`, `type`, `expiry_date`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `is_active`) VALUES (@UCT_UA_ID_2, 2, @RP_UCT_PERSON_ID, 'APPROVED', 'RUA', '2015-10-30 00:00:00', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, true);
INSERT INTO `ua`(`id`, `number`,`pi_person_id`, `status_type`, `type`, `expiry_date`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `is_active`) VALUES (@UCT_UA_ID_3, 3, @RP_UCT_PERSON_ID, 'PENDING_REVIEW', 'RUA', '2020-04-30 00:00:00', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, true);
INSERT INTO `ua`(`id`, `number`,`pi_person_id`, `status_type`, `type`, `expiry_date`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `is_active`) VALUES (@UCT_UA_ID_4, 4, @RSO_UCT_PERSON_ID, 'PENDING_REVIEW', 'RUA', '2020-04-30 00:00:00', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @RSO_UCT_PERSON_ID, @RSO_UCT_PERSON_ID, true);
INSERT INTO `ua`(`id`, `number`,`pi_person_id`, `status_type`, `type`, `expiry_date`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `is_active`) VALUES (@UCT_UA_ID_5, 5, @RSO_UCT_PERSON_ID, 'DRAFT', 'RUA', '2020-04-30 00:00:00', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @RSO_UCT_PERSON_ID, @RSO_UCT_PERSON_ID, true);
INSERT INTO `ua`(`id`, `number`,`pi_person_id`, `status_type`, `type`, `expiry_date`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `is_active`) VALUES (@UCT_UA_ID_6, 6, @SYSTEM_USER_ID, 'DRAFT', 'RUA', '2020-04-30 00:00:00', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID, true);

--UA PLANNEDWORK TEST DATA
INSERT INTO `ua_planned_work` (`chemical_form`, `description_of_use`, `potential_hazards`, `protection_precautions`, `waste_methods`, `experiment_possession_limit_mci`, `is_sealed_source`, `requested_possession_limit_mci`, `single_source_limit_mci`, `vial_possession_limit_mci`, `radionuclide_id`, `ua_id`, `license_line_number_id`, `purpose_type`, `research_type`, `physical_form_id`) VALUES ('Danger1', 'Carefully.', 'It is radiation.', 'All required precautions.', 'Per guidelines.', 2.0, 1, 20.5, 0.5, 0.5, 108, 2, 1, 'CLINICAL', 'HUMAN', 1);
INSERT INTO `ua_planned_work` (`chemical_form`, `description_of_use`, `potential_hazards`, `protection_precautions`, `waste_methods`, `experiment_possession_limit_mci`, `is_sealed_source`, `requested_possession_limit_mci`, `single_source_limit_mci`, `vial_possession_limit_mci`, `radionuclide_id`, `ua_id`, `license_line_number_id`, `purpose_type`, `research_type`, `physical_form_id`) VALUES ('Danger2', 'Carefully.', 'It is radiation.', 'All required precautions.', 'Per guidelines.', 2.0, 0,20.5, 0.5, 0.5, 108, 3, 3, 'CLINICAL', 'HUMAN', 1);
INSERT INTO `ua_planned_work` (`chemical_form`, `description_of_use`, `potential_hazards`, `protection_precautions`, `waste_methods`, `experiment_possession_limit_mci`, `is_sealed_source`, `requested_possession_limit_mci`, `single_source_limit_mci`, `vial_possession_limit_mci`, `radionuclide_id`, `ua_id`, `purpose_type`, `research_type`, `physical_form_id`) VALUES ('Danger3', 'Carefully.', 'It is radiation.', 'All required precautions.', 'Per guidelines.', 2.0, 0,20.5, 0.5, 0.5, 108, 4, 'CLINICAL', 'HUMAN', 1);

--CORE BUNDLE TEST DATA
INSERT INTO `core_bundle`(`id`, `cs_id`,`name`,`pi_person_id`) VALUES (@UCT_CORE_BUNDLE_ID_1, '1', 'Test Lab', @RP_UCT_PERSON_ID);
INSERT INTO `core_bundle`(`id`, `cs_id`,`name`,`pi_person_id`) VALUES (@UCT_CORE_BUNDLE_ID_2, '2', 'Test Lab 2', @RP_UCT_PERSON_ID);
INSERT INTO `core_bundle`(`id`, `cs_id`,`name`,`pi_person_id`) VALUES (@UCT_CORE_BUNDLE_ID_3, '3', 'Test Lab 3', @RP_UCT_PERSON_ID);
INSERT INTO `core_bundle`(`id`, `cs_id`,`name`,`pi_person_id`) VALUES (@UCT_CORE_BUNDLE_ID_4, '4', 'Test Lab 4', @RSCM_UCT_PERSON_ID);
INSERT INTO `core_bundle`(`id`, `cs_id`,`name`,`pi_person_id`) VALUES (@UCT_CORE_BUNDLE_ID_5, '5', 'Test Lab 5', @RSS_UCT_PERSON_ID);
INSERT INTO `core_bundle`(`id`, `cs_id`,`name`,`pi_person_id`) VALUES (@UCT_CORE_BUNDLE_ID_6, '6', 'Test Lab 6', @RSCM_UCT_PERSON_ID);

--CORE BUNDLE PERSON TEST DATA
INSERT INTO `core_bundle_person`(`core_bundle_id`,`person_id`) VALUES (@UCT_CORE_BUNDLE_ID_1, @AU_UCT_PERSON_ID_1);
INSERT INTO `core_bundle_person`(`core_bundle_id`,`person_id`) VALUES (@UCT_CORE_BUNDLE_ID_2, @AU_UCT_PERSON_ID_1);
INSERT INTO `core_bundle_person`(`core_bundle_id`,`person_id`) VALUES (@UCT_CORE_BUNDLE_ID_3, @AU_UCT_PERSON_ID_1);
INSERT INTO `core_bundle_person`(`core_bundle_id`,`person_id`) VALUES (@UCT_CORE_BUNDLE_ID_3, @AU_UCT_PERSON_ID_1);

--CORE BUNDLE LOCATION TEST DATA
INSERT INTO `core_bundle_location`(`core_bundle_id`,`location_id`) VALUES (@UCT_CORE_BUNDLE_ID_1, @UCT_LOCATION_ID_1);
INSERT INTO `core_bundle_location`(`core_bundle_id`,`location_id`) VALUES (@UCT_CORE_BUNDLE_ID_2, @UCT_LOCATION_ID_1);
INSERT INTO `core_bundle_location`(`core_bundle_id`,`location_id`) VALUES (@UCT_CORE_BUNDLE_ID_3, @UCT_LOCATION_ID_1);
INSERT INTO `core_bundle_location`(`core_bundle_id`,`location_id`) VALUES (@UCT_CORE_BUNDLE_ID_4, @UCT_LOCATION_ID_1);
INSERT INTO `core_bundle_location`(`core_bundle_id`,`location_id`) VALUES (@UCT_CORE_BUNDLE_ID_5, @UCT_LOCATION_ID_1);
INSERT INTO `core_bundle_location`(`core_bundle_id`,`location_id`) VALUES (@UCT_CORE_BUNDLE_ID_6, @UCT_LOCATION_ID_1);

--UA BUNDLE TEST DATA
INSERT INTO `ua_bundle`(`id`, `ua_id`, `name`, `cs_id`) VALUES (@UCT_UA_BUNDLE_ID_1, @UCT_UA_ID_1, 'Test Lab', '1');
INSERT INTO `ua_bundle`(`id`, `ua_id`, `name`, `cs_id`) VALUES (@UCT_UA_BUNDLE_ID_2, @UCT_UA_ID_2, 'Test Lab 2', '2');
INSERT INTO `ua_bundle`(`id`, `ua_id`, `name`, `cs_id`) VALUES (@UCT_UA_BUNDLE_ID_3, @UCT_UA_ID_3, 'Test Lab 3', '3');
INSERT INTO `ua_bundle`(`id`, `ua_id`, `name`, `cs_id`) VALUES (@UCT_UA_BUNDLE_ID_4, @UCT_UA_ID_4, 'Test Lab 4', '4');
INSERT INTO `ua_bundle`(`id`, `ua_id`, `name`, `cs_id`) VALUES (@UCT_UA_BUNDLE_ID_5, @UCT_UA_ID_5, 'Test Lab 5', '5');

--UA BUNDLE PERSON TEST DATA
INSERT INTO `ua_bundle_person`(`person_id`,`ua_bundle_id`) VALUES (@AU_UCT_PERSON_ID_1, @UCT_UA_BUNDLE_ID_1);
INSERT INTO `ua_bundle_person`(`person_id`,`ua_bundle_id`) VALUES (@AU_UCT_PERSON_ID_1, @UCT_UA_BUNDLE_ID_2);
INSERT INTO `ua_bundle_person`(`person_id`,`ua_bundle_id`) VALUES (@AU_UCT_PERSON_ID_1, @UCT_UA_BUNDLE_ID_3);
INSERT INTO `ua_bundle_person`(`person_id`,`ua_bundle_id`) VALUES (@RP_UCT_PERSON_ID, @UCT_UA_BUNDLE_ID_4);
INSERT INTO `ua_bundle_person`(`person_id`,`ua_bundle_id`) VALUES (@RP_UCT_PERSON_ID, @UCT_UA_BUNDLE_ID_5);

--SOE TEST DATA
INSERT INTO `soe`(`status_type`,`last_step_completed`, `ua_id`, `person_id`, `is_active`) VALUES ('PENDING', 0, @UCT_UA_ID_1, @RP_UCT_PERSON_ID, true);
INSERT INTO `soe`(`status_type`,`last_step_completed`, `ua_id`, `person_id`, `is_active`) VALUES ('SUBMITTED', 4, @UCT_UA_ID_2, @RSCM_UCT_PERSON_ID, true);
INSERT INTO `soe`(`status_type`,`last_step_completed`, `ua_id`, `person_id`, `is_active`) VALUES ('SUBMITTED', 4, @UCT_UA_ID_3, @RP_UCT_PERSON_ID, true);
INSERT INTO `soe`(`status_type`,`last_step_completed`, `ua_id`, `person_id`, `is_active`) VALUES ('SUBMITTED', 4, @UCT_UA_ID_4, @RSO_UCT_PERSON_ID, true);
INSERT INTO `soe`(`status_type`,`last_step_completed`, `ua_id`, `person_id`, `is_active`) VALUES ('PENDING', 0, @UCT_UA_ID_5, @RSO_UCT_PERSON_ID, true);

INSERT INTO `soe`(`status_type`,`last_step_completed`, `ua_id`, `person_id`, `is_active`) VALUES ('PENDING', 0, @UCT_UA_ID_1, @RP_UCT_PERSON_ID, true);
INSERT INTO `soe`(`status_type`,`last_step_completed`, `ua_id`, `person_id`, `is_active`) VALUES ('PENDING', 0, @UCT_UA_ID_1, @AU_UCT_PERSON_ID_1, true);
INSERT INTO `soe`(`status_type`,`last_step_completed`, `ua_id`, `person_id`, `is_active`) VALUES ('PENDING', 0, @UCT_UA_ID_2, @AU_UCT_PERSON_ID_1, true);
INSERT INTO `soe`(`status_type`,`last_step_completed`, `ua_id`, `person_id`, `is_active`) VALUES ('PENDING', 0, @UCT_UA_ID_3, @AU_UCT_PERSON_ID_1, true);
INSERT INTO `soe`(`status_type`,`last_step_completed`, `ua_id`, `person_id`, `is_active`) VALUES ('PENDING', 0, @UCT_UA_ID_4, @RP_UCT_PERSON_ID, true);
INSERT INTO `soe`(`status_type`,`last_step_completed`, `ua_id`, `person_id`, `is_active`) VALUES ('PENDING', 0, @UCT_UA_ID_5, @RP_UCT_PERSON_ID, true);

--UA BUNDLE LOCATION TEST DATA
INSERT INTO `ua_bundle_location`(`location_id`,`ua_bundle_id`, `sub_location`) VALUES (@UCT_LOCATION_ID_1, @UCT_UA_BUNDLE_ID_1, 'Under The Hood');
INSERT INTO `ua_bundle_location`(`location_id`,`ua_bundle_id`, `sub_location`) VALUES (@UCT_LOCATION_ID_1, @UCT_UA_BUNDLE_ID_2, 'Under The Hood');
INSERT INTO `ua_bundle_location`(`location_id`,`ua_bundle_id`, `sub_location`) VALUES (@UCT_LOCATION_ID_1, @UCT_UA_BUNDLE_ID_3, 'Under The Hood');
INSERT INTO `ua_bundle_location`(`location_id`,`ua_bundle_id`, `sub_location`) VALUES (@UCT_LOCATION_ID_1, @UCT_UA_BUNDLE_ID_4, 'Under The Hood');
INSERT INTO `ua_bundle_location`(`location_id`,`ua_bundle_id`, `sub_location`) VALUES (@UCT_LOCATION_ID_1, @UCT_UA_BUNDLE_ID_5, 'Under The Hood');

--AGREEMENT TEST DATA
INSERT INTO `agreement` (`created_date`, `last_modified_date`, `agreement_text`, `agreement_type`, `created_by`, `last_modified_by`, `campus_code`) VALUES ('2014-04-30 00:00:00', '2014-04-30 00:00:00', 'I certify that I have read the Radiation Safety Manual issued by the Radiation Safety Committee governing the use of radiation sources and radioactive material, and agree to comply with all applicable regulations', 'RUA' , @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, @UCT_CODE);
INSERT INTO `agreement` (`created_date`, `last_modified_date`, `agreement_text`, `agreement_type`, `created_by`, `last_modified_by`, `campus_code`) VALUES ('2014-04-30 00:00:00', '2014-04-30 00:00:00', 'I certify that I have read the Radiation Safety Manual issued by the Radiation Safety Committee governing the use of radiation sources and radioactive material, and agree to comply with all applicable regulations', 'SOE' , @RP_UCT_PERSON_ID, @RP_UCT_PERSON_ID, @UCT_CODE);



