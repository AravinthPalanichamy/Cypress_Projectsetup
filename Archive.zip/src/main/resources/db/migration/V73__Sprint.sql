
ALTER TABLE material DROP COLUMN is_sealed_source;

ALTER TABLE material_package modify column transport_index DECIMAL (5,3);
ALTER TABLE material_package modify column exterior_dpm DECIMAL (8,3);
ALTER TABLE material_package modify column primary_dpm DECIMAL (8,3);
ALTER TABLE material_package modify column other_dpm DECIMAL (8,3);
ALTER TABLE material_package modify column contact_mrem DECIMAL (5,3);

ALTER TABLE material_use modify column use_amount DECIMAL (19,11);
ALTER TABLE material_use modify column use_volume DECIMAL (19,11);
ALTER TABLE material_use modify column use_elemental_mass DECIMAL (19,11);
ALTER TABLE material_use modify column use_net_mass DECIMAL (19,11);

ALTER TABLE radionuclide modify column activity_mci_per_gram DECIMAL (17,11);

ALTER TABLE radionuclide_material modify column request_elemental_mass DECIMAL (19,11);
ALTER TABLE radionuclide_material modify column request_net_mass DECIMAL (19,11);
ALTER TABLE radionuclide_material modify column request_amount DECIMAL (19,11);
ALTER TABLE radionuclide_material modify column request_volume DECIMAL (19,11);
ALTER TABLE radionuclide_material modify column initial_elemental_mass DECIMAL (19,11);
ALTER TABLE radionuclide_material modify column initial_net_mass DECIMAL (19,11);
ALTER TABLE radionuclide_material modify column initial_amount DECIMAL (19,11);
ALTER TABLE radionuclide_material modify column initial_volume DECIMAL (19,11);
ALTER TABLE radionuclide_material modify column current_volume DECIMAL (19,11);
ALTER TABLE radionuclide_material modify column current_elemental_mass DECIMAL (19,11);
ALTER TABLE radionuclide_material modify column current_net_mass DECIMAL (19,11);

ALTER TABLE container_waste_tag modify column waste_size DECIMAL (19,11);
