CREATE TABLE settings (
  id int(11) NOT NULL AUTO_INCREMENT,
  campus_code varchar(10) NOT NULL,
  backfill_inventory TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
)
