------ua ---
ALTER TABLE ua DROP COLUMN org_dept;

DELETE FROM line_number_item WHERE line_number_item_id='10315';
DELETE FROM line_number_item WHERE line_number_item_id='10623';

CREATE TABLE `cpu_location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `building_display_name` varchar(255) DEFAULT NULL,
  `building_key` varchar(255) DEFAULT NULL,
  `building_primary_name` varchar(255) DEFAULT NULL,
  `campus_code` varchar(255) DEFAULT NULL,
  `room_key` varchar(255) DEFAULT NULL,
  `room_number` varchar(255) DEFAULT NULL,
  `room_id` varchar(1000) NOT NULL DEFAULT 'ROOMID',
  `building_id` varchar(200) NOT NULL DEFAULT 'BUILDING_ID',
  `is_cpu` bool default 1,
  PRIMARY KEY (`id`)
);


INSERT INTO `cpu_location`
(
	`building_display_name`,
	`room_number`,
	`campus_code`)
VALUES
('Koshland/Barker',
	'0034',
	'01');


    INSERT INTO `cpu_location`
(
	`building_display_name`,
	`room_number`,
	`campus_code`)
VALUES
('Life Sciences Addition',
	'155',
	'01');

     INSERT INTO `cpu_location`
(
	`building_display_name`,
	`room_number`,
	`campus_code`)
VALUES
('Stanley Hall',
	'161',
	'01');

         INSERT INTO `cpu_location`
(
	`building_display_name`,
	`room_number`,
	`campus_code`)
VALUES
('Morgan Hall',
	'30',
	'01');


         INSERT INTO `cpu_location`
(
	`building_display_name`,
	`room_number`,
	`campus_code`)
VALUES
('Li Ka Shing',
	'177',
	'01');


ALTER TABLE container_waste_tag
ADD COLUMN `cpu_location_id` int(11) DEFAULT NULL,
ADD CONSTRAINT `FK_WasteTag_CpuLocation` FOREIGN KEY (`cpu_location_id`)
REFERENCES `cpu_location` (`id`);