-- Hazard rating changes
ALTER TABLE `ua` ADD COLUMN `hazard_rating` VARCHAR(50);

-- Dosimetry Changes
ALTER TABLE `ua` ADD COLUMN `is_monitoring_required` BOOLEAN;

UPDATE `ua` SET `is_monitoring_required`=FALSE;

ALTER TABLE `ua` MODIFY COLUMN `is_monitoring_required` BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE monitor_type (
  id                  INTEGER AUTO_INCREMENT,
  type                VARCHAR(100) NOT NULL,
  name                VARCHAR(100) NOT NULL,
  description         VARCHAR(200),
  PRIMARY KEY (id)
);

INSERT INTO `monitor_type`(`id`, `type`,`name`) VALUES (1, 'Dosimetry', 'Finger ring - Left');
INSERT INTO `monitor_type`(`id`, `type`,`name`) VALUES (2, 'Dosimetry', 'Finger ring - Right');
INSERT INTO `monitor_type`(`id`, `type`,`name`) VALUES (3, 'Dosimetry', 'Wrist badge - Left');
INSERT INTO `monitor_type`(`id`, `type`,`name`) VALUES (4, 'Dosimetry', 'Wrist badge - Right');
INSERT INTO `monitor_type`(`id`, `type`,`name`) VALUES (5, 'Dosimetry', 'Body badge - Collar');

INSERT INTO `monitor_type`(`id`, `type`,`name`) VALUES (6, 'Bioassay', 'Thyroid scan');
INSERT INTO `monitor_type`(`id`, `type`,`name`) VALUES (7, 'Bioassay', 'Urinalysis');

INSERT INTO `monitor_type`(`id`, `type`,`name`) VALUES (8, 'Dosimetry', 'Body badge - Waist');
INSERT INTO `monitor_type`(`id`, `type`,`name`) VALUES (9, 'Dosimetry', 'Body badge - Chest');
INSERT INTO `monitor_type`(`id`, `type`,`name`) VALUES (10, 'Dosimetry', 'Fetal badge');
INSERT INTO `monitor_type`(`id`, `type`,`name`) VALUES (11, 'Dosimetry', 'Neutron badge');

CREATE TABLE monitor_person (
  id                            INTEGER AUTO_INCREMENT,
  person_id                     INTEGER   NOT NULL,
  ua_id                         INTEGER   NOT NULL,
  monitor_type_id               INTEGER   NOT NULL,
  effective_from_date           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  effective_to_date             DATETIME  NOT NULL,
  effective_from_assigned_by    INTEGER   NOT NULL,
  effective_to_assigned_by      INTEGER   NOT NULL,
  PRIMARY KEY (id)
);

ALTER TABLE monitor_person
ADD CONSTRAINT FK_MonitorPerson_Person
FOREIGN KEY (person_id)
REFERENCES person (id);

ALTER TABLE monitor_person
ADD CONSTRAINT FK_MonitorPerson_Ua
FOREIGN KEY (ua_id)
REFERENCES ua (id);

ALTER TABLE monitor_person
ADD CONSTRAINT FK_MonitorPerson_MonitorType
FOREIGN KEY (monitor_type_id)
REFERENCES monitor_type (id);

ALTER TABLE monitor_person
ADD CONSTRAINT FK_MonitorPerson_EF_Person
FOREIGN KEY (effective_from_assigned_by)
REFERENCES person (id);

ALTER TABLE monitor_person
ADD CONSTRAINT FK_MonitorPerson_ET_Person
FOREIGN KEY (effective_to_assigned_by)
REFERENCES person (id);

-- lot number changes
ALTER TABLE `material_order` ADD COLUMN `lot_number` VARCHAR(20);
ALTER TABLE `material_order` ADD COLUMN `lot_description` VARCHAR(150);

-- STOCK VIAL SCRIPTS START
-- Adding is_stock_vial to inventory table for stock vial creation
ALTER TABLE `inventory` ADD COLUMN `is_stock_vial` BOOLEAN not null DEFAULT FALSE;
ALTER TABLE `inventory` ADD COLUMN `created_from` INTEGER;
ALTER TABLE `inventory_use_log` MODIFY COLUMN `process_name` VARCHAR(1000) null;

CREATE TABLE waste_tag_type (
  waste_tag_type_id                INTEGER       AUTO_INCREMENT,
  waste_tag_type_description       VARCHAR(20)   NOT NULL,
  PRIMARY KEY (waste_tag_type_id)
);

-- Inserting tag types, these tag types are in accordance with waste application
INSERT INTO `waste_tag_type` (`waste_tag_type_id`, `waste_tag_type_description`) VALUES ('1', 'chem');
INSERT INTO `waste_tag_type` (`waste_tag_type_id`, `waste_tag_type_description`) VALUES ('2', 'mix');
INSERT INTO `waste_tag_type` (`waste_tag_type_id`, `waste_tag_type_description`) VALUES ('3', 'rad');
INSERT INTO `waste_tag_type` (`waste_tag_type_id`, `waste_tag_type_description`) VALUES ('4', 'univ');
INSERT INTO `waste_tag_type` (`waste_tag_type_id`, `waste_tag_type_description`) VALUES ('5', 'bio');


-- Inserting Hazard Class. these are in accordance with waste application
CREATE TABLE waste_hazard_class (
  waste_hazard_class_id                INTEGER       AUTO_INCREMENT,
  waste_hazard_class_description       VARCHAR(50)   NOT NULL,
  PRIMARY KEY (waste_hazard_class_id)
);

-- Inserting waste hazard class, these hazard classes are in accordance with waste application
INSERT INTO `waste_hazard_class` (`waste_hazard_class_id`, `waste_hazard_class_description`) VALUES ('1', 'Flammable');
INSERT INTO `waste_hazard_class` (`waste_hazard_class_id`, `waste_hazard_class_description`) VALUES ('2', 'Corrosive Acid (pH ≤ 2)');
INSERT INTO `waste_hazard_class` (`waste_hazard_class_id`, `waste_hazard_class_description`) VALUES ('3', 'Corrosive Base (pH ≥ 12.5)');
INSERT INTO `waste_hazard_class` (`waste_hazard_class_id`, `waste_hazard_class_description`) VALUES ('4', 'Toxic');
INSERT INTO `waste_hazard_class` (`waste_hazard_class_id`, `waste_hazard_class_description`) VALUES ('5', 'Reactive');
INSERT INTO `waste_hazard_class` (`waste_hazard_class_id`, `waste_hazard_class_description`) VALUES ('6', 'Oxidizer');
INSERT INTO `waste_hazard_class` (`waste_hazard_class_id`, `waste_hazard_class_description`) VALUES ('7', 'Extremely Hazardous');


--Inventory stock vial chemical table
CREATE TABLE inventory_stock_vial_chemical (
  inventory_stock_vial_chemical_id     INTEGER       AUTO_INCREMENT,
  inventory_id                         INTEGER       NOT NULL,
  chemical_name                        VARCHAR(250)  NOT NULL,
  chemical_amount                      DECIMAL(12,5) NOT NULL,
  unit                                 INTEGER       NOT NULL,
  PRIMARY KEY (inventory_stock_vial_chemical_id)
);

ALTER TABLE inventory_stock_vial_chemical
ADD CONSTRAINT FK_InventoryStockVialChemical_Inventory
FOREIGN KEY (inventory_id)
REFERENCES inventory (inventory_id);

ALTER TABLE inventory_stock_vial_chemical
ADD CONSTRAINT FK_InventoryStockVialChemical_RadioActivityUnit
FOREIGN KEY (unit)
REFERENCES radioactivity_unit (unit_id);

-- Adding join table for waste hazard classes
CREATE TABLE waste_container_hazard_class (
  waste_container_id         INTEGER NOT NULL,
  waste_hazard_class_id      INTEGER NOT NULL,
  PRIMARY KEY (waste_hazard_class_id, waste_container_id)
);

-- Adding pH and dose rate to waste container (This is for mixed waste tag generation)
ALTER TABLE `waste_container` ADD COLUMN `ph` DOUBLE;
ALTER TABLE `waste_container` ADD COLUMN `dose_rate` DOUBLE;


-- Billing changes and working solution changes
CREATE TABLE account (
  account_id            INTEGER AUTO_INCREMENT,
  account_number        VARCHAR(100)   NOT NULL,
  sub_account_number    VARCHAR(100),
  chart_number          VARCHAR(100),
  billing_id            VARCHAR(100),
  is_active             BOOLEAN NOT NULL DEFAULT 1,
  PRIMARY KEY (account_id)
);

CREATE TABLE person_account (
  account_id            INTEGER NOT NULL,
  person_id             INTEGER NOT NULL,
  PRIMARY KEY (account_id, person_id)
);

ALTER TABLE account
ADD CONSTRAINT UK_Account UNIQUE (account_number, sub_account_number, chart_number);

ALTER TABLE person_account
ADD CONSTRAINT FK_Person_Account_Account
FOREIGN KEY (account_id)
REFERENCES account (account_id);

ALTER TABLE person_account
ADD CONSTRAINT FK_Person_Account_Person
FOREIGN KEY (person_id)
REFERENCES person (id);

ALTER TABLE ua ADD COLUMN account_id INTEGER;

ALTER TABLE ua
ADD CONSTRAINT FK_Ua_Account
FOREIGN KEY (account_id)
REFERENCES account (account_id);

ALTER TABLE campus ADD COLUMN has_billing BOOLEAN NOT NULL DEFAULT 0;

ALTER TABLE inventory ADD COLUMN working_solution_id INTEGER;

-- TEST DATA
-- test data for dosimetry
UPDATE `ua` SET `is_monitoring_required`=TRUE WHERE id=3;

INSERT INTO `ua` (`id`, `number`,`pi_person_id`, `status_type`, `type`, `expiry_date`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `is_active`) VALUES (8, 8, 2, 'TERMINATED', 'RUA', '2015-10-30 00:00:00', '2014-04-30 00:00:00', '2015-04-30 00:00:00', 2, 2, true);
INSERT INTO `ua_planned_work` (`ua_pw_id`, `chemical_form`, `description_of_use`, `potential_hazards`, `protection_precautions`, `waste_methods`, `experiment_possession_limit`, `is_sealed_source`, `requested_possession_limit`, `single_source_limit`, `vial_possession_limit`, `radionuclide_id`, `ua_id`, `license_line_number_id`, `purpose_type`, `research_type`, `physical_form_id`, `unit`) VALUES (11, 'Danger1', 'Carefully.', 'It is radiation.', 'All required precautions.', 'Per guidelines.', 2.0, 1, 20.5, 0.5, 0.5, 108, 8, 1, 'CLINICAL', 'HUMAN', 1, 1);
INSERT INTO `ua_bundle` (`id`, `ua_id`, `name`, `cs_id`) VALUES (8, 8, 'Test Lab 6', '6');
INSERT INTO `ua_bundle_location` (`location_id`,`ua_bundle_id`, `sub_location`) VALUES (1, 8, 'Do not care');
INSERT INTO `soe` (`status_type`,`last_step_completed`, `ua_id`, `person_id`, `is_active`) VALUES ('SUBMITTED', 4, 8, 2, true);

INSERT INTO `monitor_person`(`id`, `person_id`,`ua_id`, `monitor_type_id`, `effective_from_date`, `effective_to_date`, `effective_from_assigned_by`, `effective_to_assigned_by`) VALUES (1, 2, 3, 1, '2016-01-01 00:00:00', '9999-12-31 23:59:00', 2, 2);
INSERT INTO `monitor_person`(`id`, `person_id`,`ua_id`, `monitor_type_id`, `effective_from_date`, `effective_to_date`, `effective_from_assigned_by`, `effective_to_assigned_by`) VALUES (2, 2, 3, 6, '2016-01-01 00:00:00', '9999-12-31 23:59:00', 2, 2);
INSERT INTO `monitor_person`(`id`, `person_id`,`ua_id`, `monitor_type_id`, `effective_from_date`, `effective_to_date`, `effective_from_assigned_by`, `effective_to_assigned_by`) VALUES (3, 6, 4, 2, '2016-01-01 00:00:00', '2016-02-02 00:00:00', 2, 2);

