UPDATE detector_type SET active = 1 WHERE name = 'gamma_counter' AND id > 0;
UPDATE detector_type SET active = 1, name = 'liquid_scintillation_counter' WHERE name = 'liquid_scintillation_counter)' AND id > 0;
