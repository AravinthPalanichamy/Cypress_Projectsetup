ALTER TABLE ua

ADD COLUMN `org_dept` varchar(250)  DEFAULT NULL,

ADD COLUMN `is_animals_used` tinyint(1) DEFAULT '0',

ADD COLUMN `animal_protocol_number` varchar(100),

ADD COLUMN `amendment_number` int(11) DEFAULT NULL,
ADD COLUMN `billing` varchar(250)  DEFAULT NULL,
ADD COLUMN `contact_info` varchar(250) DEFAULT NULL,

ADD COLUMN `terminated_date` datetime DEFAULT NULL ,

ADD COLUMN `signature_rua_holder` varchar(50) DEFAULT 'signed' ,
ADD COLUMN `signature_rso` varchar(50)  DEFAULT NULL,

ADD COLUMN `signature_department_chair` varchar(50) DEFAULT NULL,

ADD COLUMN `signature_rsc` varchar(50) DEFAULT NULL,

ADD COLUMN `additional_location_info`   TEXT CHARACTER SET latin1 COLLATE latin1_general_cs,

ADD COLUMN `description` TEXT CHARACTER SET latin1 COLLATE latin1_general_cs,
ADD COLUMN `precautions` TEXT CHARACTER SET latin1 COLLATE latin1_general_cs,
ADD COLUMN `comments` TEXT CHARACTER SET latin1 COLLATE latin1_general_cs
;


ALTER TABLE `location`
ADD COLUMN `location_address` VARCHAR(255) NULL AFTER `room_id`;

 -- ADD detector_type for instrumentation required table

CREATE TABLE `detector_type`(
	`id` int(11)NOT NULL AUTO_INCREMENT,
	`name` varchar(100)NOT NULL,
	`active` tinyint(1)NOT NULL DEFAULT '0',
	`display_name` varchar(200)DEFAULT NULL,
	PRIMARY KEY(`id`))ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8;

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('pancakegm',
	1,
	'Pancake GM (PGM)');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('endwindow_gm',
	1,
	'End-Window GM (EWGM)');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('energy_compaseted_gm',
	1,
	'Energy Compensated GM');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('nai_scintillator',
	1,
	'NaI Scintillator');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('plastic_scintillator',
	1,
	'Plastic Scintillator');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('alpha',
	1,
	'Alpha');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('neutron',
	1,
	'Neutron');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('ion_chamber',
	1,
	'Ion Chamber');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('lanthanum_bromide',
	1,
	'Lanthanum Bromide');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('other',
	1,
	'Other');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('solid_state_semiconductor',
	0,
	'Solid State Semiconductor');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('phoswich_scintillator',
	0,
	'Phoswich scintillator');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('high_purity_germanium',
	0,
	'High Purity Germanium (HPGe)');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('liquid_scintillation_counter)',
	0,
	'Liquid Scintillation Counter (LSC)');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('gamma_counter',
	0,
	'Gamma Counter');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('multichannel_analyzer',
	0,
	'Multichannel Analyzer (MCA)');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('electronic_personal_dosimeter',
	0,
	'Electronic Personal Dosimeter (EPD)');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('gas_flow_proportional',
	0,
	'Gas flow proportional');

INSERT INTO `detector_type`
(
	`name`,
	`active`,
	`display_name`)
VALUES
('lanthanum_bromide',
	0,
	'Lanthanum Bromide (LaBr3)');


	-- Mapping Table UA


CREATE TABLE `ua_dosimetry` (
	`ua_dosimetry_id` int(11) NOT NULL AUTO_INCREMENT,
	`ua_id` int(11) NOT NULL,
	`dosimetry_id` int(11) NOT NULL,

  PRIMARY KEY (`ua_dosimetry_id`),
  KEY `FK_UaDosimetry_Ua` (`ua_id`),
  KEY `FK_UaDosimetry_Dosimetry` (`dosimetry_id`),
  CONSTRAINT `FK_UaDosimetry_Ua` FOREIGN KEY (`ua_id`) REFERENCES `ua` (`id`),
  CONSTRAINT `FK_UaDosimetry_Dosimetry` FOREIGN KEY (`dosimetry_id`) REFERENCES `monitor_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


CREATE TABLE `ua_detector` (
	`ua_detector_id` int(11) NOT NULL AUTO_INCREMENT,
	`ua_id` int(11) NOT NULL,
	`detector_id` int(11) NOT NULL,

  PRIMARY KEY (`ua_detector_id`),
  KEY `FK_UaDetector_Ua` (`ua_id`),
  KEY `FK_UaDetector_Detector` (`detector_id`),
  CONSTRAINT `FK_UaDetector_Ua` FOREIGN KEY (`ua_id`) REFERENCES `ua` (`id`),
  CONSTRAINT `FK_UaDetector_Detector` FOREIGN KEY (`detector_id`) REFERENCES `detector_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;