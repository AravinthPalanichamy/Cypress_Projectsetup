ALTER TABLE `attachment` ADD COLUMN `created_date` TIMESTAMP NOT NULL DEFAULT '2016-01-01 00:00:00';
ALTER TABLE `attachment` ADD COLUMN `last_modified_date` TIMESTAMP NOT NULL DEFAULT '2016-01-01 00:00:00';
ALTER TABLE `attachment` ADD COLUMN `created_by` INTEGER NOT NULL DEFAULT 1;
ALTER TABLE `attachment` ADD COLUMN `last_modified_by` INTEGER NOT NULL DEFAULT 1;

ALTER TABLE attachment
ADD CONSTRAINT FK_CB_Attachment_Person
FOREIGN KEY (created_by)
REFERENCES person (id);

ALTER TABLE attachment
ADD CONSTRAINT FK_LM_Attachment_Person
FOREIGN KEY (last_modified_by)
REFERENCES person (id);