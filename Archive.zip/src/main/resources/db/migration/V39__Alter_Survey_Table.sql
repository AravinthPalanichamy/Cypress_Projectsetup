ALTER TABLE survey ADD COLUMN `inspection_id` varchar(25) DEFAULT NULL;

--Add RPM Table

CREATE TABLE `rpm` (
  `id` 				INTEGER 	  NOT NULL AUTO_INCREMENT,
  `machine_id` 		VARCHAR(100)  NOT NULL,
  `ua_id` 			INTEGER 	  NOT NULL,
  `location_id` 	INTEGER   NOT NULL,
  `dph_number` 		VARCHAR(45)   NULL,
  `type` 			VARCHAR(45)   NULL,
  `number_of_tubes` VARCHAR(45)   NULL,
  `manufacturer` 	VARCHAR(45)   NULL,
  `model` 			VARCHAR(45)   NULL,
  `maximum_current` VARCHAR(45)   NULL,
  `maximum_voltage` VARCHAR(45)   NULL,
  `max_time` 		VARCHAR(45)   NULL,
  `normal_current` 	VARCHAR(45)   NULL,
  `normal_voltage` 	VARCHAR(45)   NULL,
  `normal_time` 	VARCHAR(45)   NULL,
  `use_code` 		VARCHAR(45)   NULL,
  `hazard_class` 	VARCHAR(45)   NULL,
  `on_license` 		VARCHAR(45)   NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_UA_ID` FOREIGN KEY (`ua_id`) REFERENCES `ua` (`id`),
  CONSTRAINT `FK_LOCATION_ID` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE survey ADD COLUMN `active` tinyint(1) DEFAULT 1;

-- Add UA Limit Table

 CREATE TABLE `use_factor` (
  `use_factor_id` int(11) NOT NULL AUTO_INCREMENT,
  `use_factor_value` double NOT NULL,
  `display_value` varchar(100) NOT NULL,
  `type_of_operation` varchar(255) NOT NULL,
  PRIMARY KEY (`use_factor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `engineering_control` (
  `eng_control_id` int(11) NOT NULL AUTO_INCREMENT,
  `eng_control_name` varchar(100) NOT NULL,
  `eng_control_internal` double NOT NULL,
  `eng_control_external` double NOT NULL,
  `displayValue` varchar(100) NOT NULL,
  PRIMARY KEY (`eng_control_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

 CREATE TABLE `form_factor` (
  `form_factor_id` int(11) NOT NULL AUTO_INCREMENT,
  `form_factor_value` double NOT NULL,
  `display_value` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`form_factor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


CREATE TABLE `ua_limit` (
  `ua_limit_id` int(11) NOT NULL AUTO_INCREMENT,
  `chemical_form` varchar(50) NOT NULL,
  `experiment_possession_limit` double NOT NULL,
  `is_sealed_source` tinyint(1) NOT NULL,
  `purpose_type` varchar(255) DEFAULT NULL,
  `requested_possession_limit` double NOT NULL,
  `research_type` varchar(255) DEFAULT NULL,
  `single_source_limit` double DEFAULT NULL,
  `vial_possession_limit` double DEFAULT NULL,
  `license_line_number_id` int(11) DEFAULT NULL,
  `radionuclide_id` int(11) NOT NULL,
  `ua_id` int(11) NOT NULL,
  `physical_form_id` int(11) NOT NULL,
  `use_factor_id` int(11) DEFAULT NULL,
  `eng_control_id` int(11) DEFAULT NULL,
  `form_factor_id` int(11) DEFAULT NULL,
  `created_from` int(11) DEFAULT NULL,
  `unit` int(11) NOT NULL,
  `is_self_receivable` tinyint(1) NOT NULL DEFAULT '0',
  `date_added` datetime DEFAULT NULL,
  `date_removed` datetime DEFAULT NULL,
  `entered_date` datetime DEFAULT NULL,
  `enrichment_percent` double DEFAULT NULL,
  `entered_by_person_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ua_limit_id`),
  KEY `FK_UaLimit_LLN` (`license_line_number_id`),
  KEY `FK_UaLimit_Radionuclide` (`radionuclide_id`),
  KEY `FK_UaLimit_Ua` (`ua_id`),
  KEY `FK_UaLimit_PhysicalForm` (`physical_form_id`),
  KEY `FK_UaLimit_RadioActivityUnit` (`unit`),
  KEY `FK_UaLimit_EnteredBy` (`entered_by_person_id`),
  KEY `FK_UaLimit_UseFactor` (`use_factor_id`),
  KEY `FK_UaLimit_EngControl` (`eng_control_id`),
  KEY `FK_UaLimit_FormFactor` (`form_factor_id`),
  CONSTRAINT `FK_UaLimit_LLN` FOREIGN KEY (`license_line_number_id`) REFERENCES `license_line_number` (`license_line_number_id`),
  CONSTRAINT `FK_UaLimit_RadioActivityUnit` FOREIGN KEY (`unit`) REFERENCES `radioactivity_unit` (`unit_id`),
  CONSTRAINT `FK_UaLimit_EngControl` FOREIGN KEY (`eng_control_id`) REFERENCES `engineering_control` (`eng_control_id`),
  CONSTRAINT `FK_UaLimit_EnteredBy` FOREIGN KEY (`entered_by_person_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK_UaLimit_FormFactor` FOREIGN KEY (`form_factor_id`) REFERENCES `form_factor` (`form_factor_id`),
  CONSTRAINT `FK_UaLimit_PhysicalForm` FOREIGN KEY (`physical_form_id`) REFERENCES `physical_form` (`physical_form_id`),
  CONSTRAINT `FK_UaLimit_Radionuclide` FOREIGN KEY (`radionuclide_id`) REFERENCES `radionuclide` (`radionuclide_id`),
  CONSTRAINT `FK_UaLimit_Ua` FOREIGN KEY (`ua_id`) REFERENCES `ua` (`id`),
  CONSTRAINT `FK_UaLimit_UseFactor` FOREIGN KEY (`use_factor_id`) REFERENCES `use_factor` (`use_factor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


INSERT INTO `engineering_control`
(`eng_control_id`,
`eng_control_name`,
`eng_control_internal`,
`eng_control_external`,
 `displayValue`)
VALUES
(1,
'Glove box',
0.01,
1.0,
'0.01/1.0');

INSERT INTO `engineering_control`
(`eng_control_id`,
`eng_control_name`,
`eng_control_internal`,
`eng_control_external`,
`displayValue`)
VALUES
(2,
'Hot Cell',
0.01,
0.01,
'0.01/0.01');

INSERT INTO `engineering_control`
(`eng_control_id`,
`eng_control_name`,
`eng_control_internal`,
`eng_control_external`,
`displayValue`)
VALUES
(3,
'Fume Hood',
0.1,
1.0,
'0.1/1.0');

INSERT INTO `engineering_control`
(`eng_control_id`,
`eng_control_name`,
`eng_control_internal`,
`eng_control_external`,
`displayValue`)
VALUES
(4,
'Open Bench-top',
1.0,
1.0,
'1.0/1.0');

INSERT INTO `use_factor`
(`use_factor_id`,
`use_factor_value`,
`display_value`,
`type_of_operation`)
VALUES
(1,
0.1,
'0.1',
'Simple wet operations, source handling (e.g., dilution, transfers, closed systems with appropriate traps used in hoods)');

INSERT INTO `use_factor`
(`use_factor_id`,
`use_factor_value`,
`display_value`,
`type_of_operation`)
VALUES
(2,
1.0,
'1.0',
'Normal chemical operations (e.g., chromatography, filtration, centrifugation, animal injections)' );

INSERT INTO `use_factor`
(`use_factor_id`,
`use_factor_value`,
`display_value`,
`type_of_operation`)
VALUES
(3,
10.0,
'10.0',
'Simple dry operations, transfer and manipulation of dispersible material, complex wet operations, or DNA precursors');

INSERT INTO `use_factor`
(`use_factor_id`,
`use_factor_value`,
`display_value`,
`type_of_operation`)
VALUES
(4,
 100.0,
'100.0',
'Production and use of volatile material; complex dry operations (e.g., crushing, mixing)');



INSERT INTO `form_factor`
(`form_factor_id`,
`form_factor_value`,
`display_value`,
`description`)
VALUES
(1,
0.001,
'0.001',
'Sealed sources');

INSERT INTO `form_factor`
(`form_factor_id`,
`form_factor_value`,
`display_value`,
`description`)
VALUES
(2,
0.1,
'0.1',
'Thin window sealed sources, solid sources');

INSERT INTO `form_factor`
(`form_factor_id`,
`form_factor_value`,
`display_value`,
`description`)
VALUES
(3,
1.0,
'1.0',
'Liquid');

INSERT INTO `form_factor`
(`form_factor_id`,
`form_factor_value`,
`display_value`,
`description`)
VALUES
(4,
10.0,
'10.0',
'Powders, gases, volatile compounds');



--Add Attachment Table

ALTER TABLE attachment ADD COLUMN `reference_date` DATETIME DEFAULT NULL;
ALTER TABLE attachment ADD COLUMN `title` varchar(250) DEFAULT NULL;
ALTER TABLE attachment ADD COLUMN `description` varchar(1000) DEFAULT NULL;
ALTER TABLE attachment ADD COLUMN `active` bit NOT NULL DEFAULT 1;

CREATE TABLE ua_attachment (
  ua_id       INTEGER NOT NULL,
  attachment_id      INTEGER NOT NULL,
  PRIMARY KEY (ua_id, attachment_id)
);


ALTER TABLE ua_attachment
ADD CONSTRAINT UK_AttachmentId_UAId UNIQUE (attachment_id);

ALTER TABLE ua_attachment
ADD CONSTRAINT FK_ua_attachment_attachmentId FOREIGN KEY (attachment_id)
REFERENCES attachment (attachment_id);

ALTER TABLE ua_attachment
ADD CONSTRAINT FK_ua_attachment_uaId FOREIGN KEY (ua_id)
REFERENCES ua (id);


--Alter Instrument Table

ALTER TABLE `instrument`DROP FOREIGN KEY `FK_Instrument_Person_Assigned`;
ALTER TABLE `instrument`DROP FOREIGN KEY `FK_Instrument_MeterScale`;
ALTER TABLE `instrument` DROP COLUMN `assigned_to`;
ALTER TABLE `instrument` DROP COLUMN `meter_scale_id`;
ALTER TABLE `instrument` DROP COLUMN  `detector_type`;
ALTER TABLE `instrument` DROP COLUMN  `calibration_due_date`;

ALTER TABLE `instrument` ADD COLUMN `probe1_model`  varchar(25) DEFAULT NULL;
ALTER TABLE `instrument` ADD COLUMN `probe1_serial`  varchar(25) DEFAULT NULL;
ALTER TABLE `instrument` ADD COLUMN `probe2_model`  varchar(25) DEFAULT NULL;
ALTER TABLE `instrument` ADD COLUMN `probe2_serial`  varchar(25) DEFAULT NULL;
ALTER TABLE `instrument` ADD COLUMN `comment` LONGTEXT DEFAULT NULL;
ALTER TABLE `instrument` ADD COLUMN `scale`  varchar(20) DEFAULT NULL;
ALTER TABLE `instrument` ADD COLUMN `calibration_due_status_type` varchar(20) DEFAULT NULL;
ALTER TABLE `instrument` ADD COLUMN `calibration_next_due` DATETIME DEFAULT NULL;



-- Create Material Table


--Alter RUA Limit table

ALTER TABLE ua_limit ADD COLUMN `active` bit NOT NULL DEFAULT 1;


--Alter PErson Table
ALTER TABLE Person

ADD COLUMN `created_by` int(11)  DEFAULT 1,
ADD COLUMN `created_date` datetime DEFAULT CURRENT_TIMESTAMP ,
ADD COLUMN `last_modified_by` int(11)  DEFAULT 1,
ADD COLUMN `last_modified_date` datetime DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN `nrccbc_completed` datetime DEFAULT NULL,
ADD COLUMN `user_form_completed` bool DEFAULT 0;


ALTER TABLE Ua_Bundle_Person

ADD COLUMN `created_by` int(11)  DEFAULT 1,
ADD COLUMN `created_date` datetime DEFAULT CURRENT_TIMESTAMP ,
ADD COLUMN `last_modified_by` int(11)  DEFAULT 1,
ADD COLUMN `last_modified_date` datetime DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN `date_added` datetime DEFAULT CURRENT_TIMESTAMP;


CREATE TABLE `ua_person_dosimetry` (
	`ua_person_dosimetry_id` int(11) NOT NULL AUTO_INCREMENT,
	`person_id` int(11) NOT NULL,
	`ua_id` int(11) NOT NULL,
	`dosimetry_id` int(11) NOT NULL,

  PRIMARY KEY (`ua_person_dosimetry_id`),
  KEY `FK_UaPersonDosimetry_Person` (`person_id`),
  KEY `FK_UaPersonDosimetry_Dosimetry` (`dosimetry_id`),
  CONSTRAINT `FK_UaPersonDosimetry_Person` FOREIGN KEY (`person_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK_UaPersonDosimetry_Dosimetry` FOREIGN KEY (`dosimetry_id`) REFERENCES `monitor_type` (`id`),
  CONSTRAINT `FK_UaPersonDosimetry_Ua` FOREIGN KEY (`ua_id`) REFERENCES `ua` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--Alter Radionuclide

ALTER TABLE radionuclide ADD COLUMN `is_sewer_disposal` BOOLEAN DEFAULT FALSE ;
ALTER TABLE radionuclide ADD COLUMN `schedule_c` DOUBLE DEFAULT 0;
ALTER TABLE radionuclide ADD COLUMN `egroup` DOUBLE DEFAULT 0;
ALTER TABLE radionuclide ADD COLUMN `ali_mci` DOUBLE DEFAULT 0;
ALTER TABLE radionuclide ADD COLUMN `is_status_active` BOOLEAN DEFAULT FALSE;

--Alter Rua RPM

ALTER TABLE rpm ADD COLUMN `active` bit NOT NULL DEFAULT 1;

--Alter People

ALTER TABLE Person

ADD COLUMN `has_statement_experience` bool NOT NULL DEFAULT 0,
ADD COLUMN `comment` TEXT DEFAULT NULL;

ALTER TABLE Person DROP COLUMN user_form_completed;

--Instrument Attachment
CREATE TABLE instrument_attachment (
  instrument_id       INTEGER NOT NULL,
  attachment_id      INTEGER NOT NULL,
  PRIMARY KEY (instrument_id, attachment_id)
);

ALTER TABLE instrument_attachment
ADD CONSTRAINT UK_attachmentId_InstrumentId UNIQUE (attachment_id);

ALTER TABLE instrument_attachment
ADD CONSTRAINT FK_instrument_attachment_attachmentId FOREIGN KEY (attachment_id)
REFERENCES attachment (attachment_id);

ALTER TABLE instrument_attachment
ADD CONSTRAINT FK_instrument_attachment_instrumentId FOREIGN KEY (instrument_id)
REFERENCES instrument (instrument_id);

--Alter UA Limit
ALTER TABLE ua_limit ADD COLUMN `elemental_mass` double DEFAULT NULL;
ALTER TABLE ua_limit ADD COLUMN `net_mass` double DEFAULT NULL;
ALTER TABLE ua_limit ADD COLUMN `contained_mass` double DEFAULT NULL;

--Create Material Table

create table material (
    id integer not null auto_increment,
    created_date datetime not null,
    last_modified_date datetime not null,
    chemical_form varchar(50) not null,
    initial_amount decimal(19,2),
    initial_date datetime,
    initial_elemental_mass decimal(19,2),
    initial_sample_net_mass decimal(19,2),
    initial_volume decimal(19,2),
    request_amount decimal(19,2),
    request_elemental_mass decimal(19,2),
    request_rst_comments varchar(255),
    request_sample_net_mass decimal(19,2),
    request_user_comments varchar(255),
    request_volume decimal(19,2),
    sub_location varchar(255),
    created_by integer not null,
    last_modified_by integer not null,
    material_package_id integer,
    storage_location_id integer not null,
    ua_id integer not null,
    ua_limit_id integer,
    primary key (id)
);

create table material_package (
    id integer not null auto_increment,
    created_date datetime not null,
    last_modified_date datetime not null,
    comments varchar(255),
    contact_mrem decimal(19,2),
    date_received datetime not null,
    exterior_dpm decimal(19,2),
    has_exterior_survey bit,
    has_other_survey bit,
    has_primary_survey bit,
    is_dry_ice_ok bit,
    is_exterior_swipe_contamination_free bit,
    is_other_swipe_contamination_free bit,
    is_primary_swipe_contamination_free bit,
    other_dpm decimal(19,2),
    other_name varchar(255),
    package_number integer not null,
    primary_dpm decimal(19,2),
    problems varchar(255),
    transport_index decimal(19,2),
    created_by integer not null,
    last_modified_by integer not null,
    checked_by_id integer not null,
    package_type_id integer not null,
    package_vendor_id integer not null,
    ua_id integer not null,
    primary key (id)
);

alter table material
    add constraint FK_6ljg5j4kou521m3xqdml81gnh
    foreign key (created_by)
    references person (id);

alter table material
    add constraint FK_hyanma9uf9d0tn4nff0ivvtln
    foreign key (last_modified_by)
    references person (id);

alter table material
    add constraint FK_Material_MaterialPackage
    foreign key (material_package_id)
    references material_package (id);

alter table material
    add constraint FK_3nhx5igwxqtrb4iattpvf6so3
    foreign key (storage_location_id)
    references location (id);

alter table material
    add constraint FK_na45kqn9rx3r8a5lhl8y1f56c
    foreign key (ua_id)
    references ua (id);

alter table material
    add constraint FK_98wy1vikupenqneb95ugoankq
    foreign key (ua_limit_id)
    references ua_limit (ua_limit_id);

alter table material_package
    add constraint FK_l2uuwmxknojq7trksa6d0fuvc
    foreign key (created_by)
    references person (id);

alter table material_package
    add constraint FK_paiisloa2n6up71a693vwmrog
    foreign key (last_modified_by)
    references person (id);

alter table material_package
    add constraint FK_Package_Person
    foreign key (checked_by_id)
    references person (id);

alter table material_package
    add constraint FK_Package_PackageType
    foreign key (package_type_id)
    references package_type (package_type_id);

alter table material_package
    add constraint FK_Package_PackageVendor
    foreign key (package_vendor_id)
    references package_vendor (package_vendor_id);

alter table material_package
    add constraint FK_Package_Ua
    foreign key (ua_id)
    references ua (id);