--Create table line_number_item
CREATE TABLE line_number_item (
line_number_item_id         INTEGER AUTO_INCREMENT,
radionuclide_id             INTEGER   NOT NULL,
license_line_number_id      INTEGER   NOT NULL,
is_solid                    BOOLEAN   NOT NULL,
is_liquid                   BOOLEAN   NOT NULL,
is_gas                      BOOLEAN   NOT NULL,
is_powder                   BOOLEAN   NOT NULL,
is_sealed_source            BOOLEAN   NOT NULL,
is_special_nuclear_material BOOLEAN   NOT NULL,
is_source_material        BOOLEAN   NOT NULL,
elemental_limit             DOUBLE,
elemental_limit_unit_id     INTEGER,
PRIMARY KEY (line_number_item_id)
);

--Create use_purpose table
CREATE TABLE use_purpose (
  use_purpose_id              INTEGER AUTO_INCREMENT,
  use_purpose_name            VARCHAR(100)   NOT NULL,
  PRIMARY KEY (use_purpose_id)
);

--Remove table license_rule_type and its references
ALTER TABLE `license` DROP FOREIGN KEY `FK_License_LicenseRuleType`;
ALTER TABLE `license` DROP COLUMN `license_rule_type_id`;


ALTER TABLE line_number_item
ADD CONSTRAINT FK_LineNumberItem_Radionuclide
FOREIGN KEY (radionuclide_id)
REFERENCES radionuclide (radionuclide_id);

ALTER TABLE line_number_item
ADD CONSTRAINT FK_LineNumberItem_LicenseLineNumber
FOREIGN KEY (license_line_number_id)
REFERENCES license_line_number (license_line_number_id);

ALTER TABLE line_number_item
ADD CONSTRAINT FK_LineNumberItem_RadioActivityUnit
FOREIGN KEY (elemental_limit_unit_id)
REFERENCES radioactivity_unit (unit_id);


--Merge licenseLineNumberInfo and licenseLineNumber
ALTER TABLE `license_line_number` DROP FOREIGN KEY `FK_LicenseLineNumber_LLNInfo`;
ALTER TABLE `license_line_number` DROP COLUMN `license_line_number_info_id`;

ALTER TABLE `license_line_number` ADD COLUMN `name` VARCHAR(100);
ALTER TABLE `license_line_number` ADD COLUMN `description` VARCHAR(100);

ALTER TABLE `license_line_number` ADD COLUMN `line_number_radionuclide_form_id` INTEGER;
ALTER TABLE `license_line_number` ADD COLUMN `campus_limit` DOUBLE;
ALTER TABLE `license_line_number` ADD COLUMN `campus_limit_unit_id` INTEGER;

ALTER TABLE `license_line_number` ADD COLUMN `z_value_min` INTEGER;
ALTER TABLE `license_line_number` ADD COLUMN `z_value_max` INTEGER;
ALTER TABLE `license_line_number` ADD COLUMN `include_special_nuclear_material` BOOLEAN;
ALTER TABLE `license_line_number` ADD COLUMN `include_source_material` BOOLEAN;
ALTER TABLE `license_line_number` ADD COLUMN `elemental_limit` DOUBLE;
ALTER TABLE `license_line_number` ADD COLUMN `max_items` INTEGER;
ALTER TABLE `license_line_number` ADD COLUMN `limit_contained` DOUBLE;
ALTER TABLE `license_line_number` ADD COLUMN `limit_contained_unit_id` INTEGER;
ALTER TABLE `license_line_number` ADD COLUMN `elemental_limit_unit_id` INTEGER;
ALTER TABLE `license_line_number` ADD COLUMN `use_purpose_id` INTEGER;

ALTER TABLE license_line_number
ADD CONSTRAINT FK_LicenseLineNumber_RadioActivityUnit
FOREIGN KEY (limit_contained_unit_id)
REFERENCES radioactivity_unit (unit_id);

ALTER TABLE license_line_number
ADD CONSTRAINT FK_LicenseLineNumber_ElementalRadioActivityUnit
FOREIGN KEY (elemental_limit_unit_id)
REFERENCES radioactivity_unit (unit_id);

ALTER TABLE license_line_number
ADD CONSTRAINT FK_LicenseLineNumber_UsePurpose
FOREIGN KEY (use_purpose_id)
REFERENCES use_purpose (use_purpose_id);

--Load UCMerced line number data
UPDATE `license_line_number` SET `name`='H-3', `description`='Hydrogen-3', `line_number_radionuclide_form_id`=1, `campus_limit`=100, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=25;
UPDATE `license_line_number` SET `name`='C-14', `description`='Carbon-14', `line_number_radionuclide_form_id`=1, `campus_limit`=100, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=4;
UPDATE `license_line_number` SET `name`='P-32', `description`='Phosphorous-32', `line_number_radionuclide_form_id`=1, `campus_limit`=30, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=5;
UPDATE `license_line_number` SET `name`='S-35', `description`='Sulphur-35', `line_number_radionuclide_form_id`=1, `campus_limit`=10, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=6;
UPDATE `license_line_number` SET `name`='Ca-45', `description`='Calcium-45', `line_number_radionuclide_form_id`=1, `campus_limit`=20, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=7;
UPDATE `license_line_number` SET `name`='I-125', `description`='Iodine-125', `line_number_radionuclide_form_id`=2, `campus_limit`=100, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=8;
UPDATE `license_line_number` SET `name`='H-3', `description`='Hydrogen-3', `line_number_radionuclide_form_id`=3, `campus_limit`=5, `campus_limit_unit_id`=2 WHERE `license_line_number_id`=9;
UPDATE `license_line_number` SET `name`='C-14', `description`='Carbon-14', `line_number_radionuclide_form_id`=3, `campus_limit`=5, `campus_limit_unit_id`=2 WHERE `license_line_number_id`=10;
UPDATE `license_line_number` SET `name`='Po-210', `description`='Polonium-210', `line_number_radionuclide_form_id`=4, `campus_limit`=1.2, `campus_limit_unit_id`=2 WHERE `license_line_number_id`=11;
UPDATE `license_line_number` SET `name`='Sr-90', `description`='Strontium-90', `line_number_radionuclide_form_id`=4, `campus_limit`=1.2, `campus_limit_unit_id`=2 WHERE `license_line_number_id`=12;
UPDATE `license_line_number` SET `name`='Tl-204', `description`='Thallium-204', `line_number_radionuclide_form_id`=4, `campus_limit`=12, `campus_limit_unit_id`=2 WHERE `license_line_number_id`=13;
UPDATE `license_line_number` SET `name`='Co-60', `description`='Cobalt-60', `line_number_radionuclide_form_id`=4, `campus_limit`=20, `campus_limit_unit_id`=2 WHERE `license_line_number_id`=14;
UPDATE `license_line_number` SET `name`='Ce-137', `description`='Cesium-137', `line_number_radionuclide_form_id`=4, `campus_limit`=60, `campus_limit_unit_id`=2 WHERE `license_line_number_id`=15;
UPDATE `license_line_number` SET `name`='Cs-137Ba', `description`='Cesium-137/Barium 137m', `line_number_radionuclide_form_id`=5, `campus_limit`=60, `campus_limit_unit_id`=2 WHERE `license_line_number_id`=16;
UPDATE `license_line_number` SET `name`='Fl-18', `description`='Fluorine-18', `line_number_radionuclide_form_id`=1, `campus_limit`=10, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=17;
UPDATE `license_line_number` SET `name`='Cu-64', `description`='Copper-64', `line_number_radionuclide_form_id`=1, `campus_limit`=10, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=18;
UPDATE `license_line_number` SET `name`='Y-90', `description`='Yttrium-90', `line_number_radionuclide_form_id`=1, `campus_limit`=10, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=19;
UPDATE `license_line_number` SET `name`='Na-22', `description`='Sodium-22', `line_number_radionuclide_form_id`=4, `campus_limit`=0.1, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=20;
UPDATE `license_line_number` SET `name`='Ge-68', `description`='Germanium-68', `line_number_radionuclide_form_id`=4, `campus_limit`=0.1, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=21;
UPDATE `license_line_number` SET `name`='Ni-63', `description`='Nickel-63', `line_number_radionuclide_form_id`=6, `campus_limit`=45, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=22;
UPDATE `license_line_number` SET `name`='Cs-137', `description`='Cesium-137', `line_number_radionuclide_form_id`=7, `campus_limit`=4000, `campus_limit_unit_id`=3 WHERE `license_line_number_id`=23;
UPDATE `license_line_number` SET `name`='Ni-63', `description`='Nickel-63', `line_number_radionuclide_form_id`=8, `campus_limit`=10, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=24;

--Load UC Test line number data
UPDATE `license_line_number` SET `name`='At-217', `description`='At-217', `line_number_radionuclide_form_id`=1, `campus_limit`=3000, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=1;
UPDATE `license_line_number` SET `name`='Bi-207', `description`='Bismuth-207', `line_number_radionuclide_form_id`=1, `campus_limit`=100, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=2;
UPDATE `license_line_number` SET `name`='H-3', `description`='Hydrogen-3', `line_number_radionuclide_form_id`=4, `campus_limit`=100, `campus_limit_unit_id`=1 WHERE `license_line_number_id`=3;

--update uaplanned work
UPDATE `ua_planned_work` SET `license_line_number_id`='2' WHERE `ua_pw_id`='3';


ALTER TABLE license_line_number
ADD CONSTRAINT FK_LicenseLineNumber_Form
FOREIGN KEY (line_number_radionuclide_form_id)
REFERENCES line_number_radionuclide_form (line_number_radionuclide_form_id);

ALTER TABLE license_line_number
ADD CONSTRAINT FK_LicenseLineNumber_CampusRadioactivityUnit
FOREIGN KEY (campus_limit_unit_id)
REFERENCES radioactivity_unit (unit_id);

DROP TABLE `license_line_number_info`;
DROP TABLE `license_rule_type`;

--inserting merced license information
--6.A.2 : C-14 Liquid
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('101', '125', '4', '0', '1', '0', '0', '0', '0', '0');
--6.A.3 : P-32 Liquid
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('102', '2', '5', '0', '1', '0', '0', '0', '0', '0');
--6.A.4 S-35 Liquid
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('103', '4', '6', '0', '1', '0', '0', '0', '0', '0');
--6.A.5 Ca-45 Liquid
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('104', '18', '7',  '0', '1', '0', '0', '0', '0', '0');
--6.A.6 I-125 Liquid Non-volatile
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('105', '5', '8', '0', '1', '0', '0', '0', '0', '0');
--6.A.7 h-3 Sealed liquid vial
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('106', '1', '9', '0', '1', '0', '0', '0', '0', '0');
--6.A.8 C-14 Sealed Liquid vials
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('107', '125', '10', '0', '1', '0', '0', '0', '0', '0');
--6.A.9 Po-210 SS
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('108', '60', '11',  '0', '0', '0', '0', '1', '0', '0');
--6.A.10 Sr-90 SS
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('109', '79', '12',  '0', '0', '0', '0', '1', '0', '0');
--6.A.11 Tl-204 SS
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('110', '85', '13',  '0', '0', '0', '0', '1', '0', '0');
--6.A.12 Co-60 SS
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('111', '31', '14',  '0', '0', '0', '0', '1', '0', '0');
--6.A.13 Cs-137 SS
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('112', '97', '15',  '0', '0', '0', '0', '1', '0', '0');
--6.A.14 Cs-137/Ba-137m anything
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('113', '303', '16', '1', '1', '1', '1', '0', '0', '0');
--6.B.1 Fl-18 Liquid
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('114', '143', '17', '0', '1', '0', '0', '0', '0', '0');
--6.B.2 Cu-64 Liquid
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('115', '34', '18',  '0', '1', '0', '0', '0', '0', '0');
--6.B.3 Y-90 Liquid
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('116', '282', '19','0', '1', '0', '0', '0', '0', '0');
--6.B.4 Na-22 SS
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('117', '48', '20',  '0', '0', '0', '0', '1', '0', '0');
--6.B.5 Ge-68 SS
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('118', '294', '21', '0', '0', '0', '0', '1', '0', '0');
--6.C Ni-63 SS
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('119', '51', '22',  '0', '0', '0', '0', '1', '0', '0');
--6.D Cs-137 SS
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('120', '97', '23',  '0', '0', '0', '0', '1', '0', '0');
--6.E Ni-63 SS
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('121', '51', '24',  '0', '0', '0', '0', '1', '0', '0');
--6.A.1 H-3 Liquid
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('122', '1', '25',   '0', '1', '0', '0', '0', '0', '0');

--Inserting test data
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`) VALUES ('1', '1', '3', '1', '0', '0', '0', '1', '0', '0');

INSERT INTO `license_line_number` (`line_number`, `license_id`, `is_specific`, `name`, `description`, `line_number_radionuclide_form_id`, `campus_limit`, `campus_limit_unit_id`) VALUES ('6.D.1', @UCT_LICENSE_ID, FALSE, 'H-3', 'Hydrogen-3', 1, 100, 1);
INSERT INTO `license_line_number` (`line_number`, `license_id`, `is_specific`, `name`, `description`, `line_number_radionuclide_form_id`, `campus_limit`, `campus_limit_unit_id`) VALUES ('6.E.1', @UCT_LICENSE_ID, FALSE, 'H-3', 'Hydrogen-3', 1, 100, 1);
UPDATE `ua_planned_work` SET `is_sealed_source` = 0 WHERE `ua_pw_id` = 1;
UPDATE `ua_planned_work` SET `radionuclide_id` = 1 WHERE `ua_pw_id` = 2;
UPDATE `ua_planned_work` SET `license_line_number_id` = 1 WHERE `ua_pw_id` = 3;