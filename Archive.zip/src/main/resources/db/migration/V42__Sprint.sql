CREATE TABLE probe (
  id          INTEGER     NOT NULL AUTO_INCREMENT,
  model       VARCHAR(50) NOT NULL,
  serial      VARCHAR(50) NOT NULL,
  campus_code VARCHAR(3)  NOT NULL,
  active   BOOLEAN  NOT NULL DEFAULT TRUE,
  PRIMARY KEY (id)
);

CREATE TABLE calibration (
  id                      INTEGER NOT NULL AUTO_INCREMENT,
  probe_id                INTEGER NOT NULL,
  instrument_id           INTEGER NOT NULL,
  comment                 LONGTEXT         DEFAULT NULL,
  calibration_date        DATETIME         DEFAULT NULL,
  entry_date              DATETIME         DEFAULT NULL,
  calibrated_by           INTEGER          DEFAULT NULL,
  vendor_name             VARCHAR(100) DEFAULT NULL,
  voltage                 DECIMAL(10, 3)   DEFAULT NULL,
  background              DECIMAL(10, 3)   DEFAULT NULL,
  battery_ok           VARCHAR(3)  DEFAULT NULL,
  audio_ok             VARCHAR(3)  DEFAULT NULL,
  cable_ok             VARCHAR(3)  DEFAULT NULL,
  general_condition_ok VARCHAR(3)  DEFAULT NULL,
  calibration_type        VARCHAR(50) DEFAULT NULL,
  calibration_source_id      INTEGER DEFAULT NULL,
  meter_scale            VARCHAR(10)      DEFAULT NULL,
  created_by                INTEGER           NOT NULL,
  created_date              TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_modified_by          INTEGER           NOT NULL,
  last_modified_date        TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);

CREATE TABLE meter_range (
  id    INTEGER     NOT NULL AUTO_INCREMENT,
  label VARCHAR(25) NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE calibration_source (
  id    INTEGER     NOT NULL AUTO_INCREMENT,
  name  VARCHAR(50) NOT NULL,
  calibration_type        VARCHAR(50),
  campus_code VARCHAR(3)  NOT NULL,
  active   BOOLEAN  NOT NULL DEFAULT TRUE,
  PRIMARY KEY (id)
);

CREATE TABLE probe_response_check_source (
  id    INTEGER     NOT NULL AUTO_INCREMENT,
  name  VARCHAR(50) NOT NULL,
  campus_code VARCHAR(3)  NOT NULL,
  active   BOOLEAN  NOT NULL DEFAULT TRUE,
  PRIMARY KEY (id)
);

CREATE TABLE calibration_matrix (
  id                     INTEGER NOT NULL AUTO_INCREMENT,
  calibration_id         INTEGER NOT NULL,
  meter_range_id         INTEGER NOT NULL,
  pulse_or_exposure_rate  DECIMAL(10, 3)   DEFAULT NULL,
  reading_found           DECIMAL(10, 3)   DEFAULT NULL,
  percentage_error        DECIMAL(5, 2)   DEFAULT NULL,
  reading_adjusted       DECIMAL(10, 3)   DEFAULT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE probe_response_check (
  id                     INTEGER NOT NULL AUTO_INCREMENT,
  calibration_id         INTEGER NOT NULL,
  cpm_reading          DECIMAL(10, 3)   DEFAULT NULL,
  dpm_of_source  DECIMAL(10, 3)   DEFAULT NULL,
  percentage_efficiency        DECIMAL(5, 2)   DEFAULT NULL,
  probe_response_check_source_id INTEGER not NULL,
  PRIMARY KEY (id)
);

ALTER TABLE probe
ADD CONSTRAINT FK_Probe_Campus
FOREIGN KEY (campus_code)
REFERENCES campus (code);

ALTER TABLE calibration_source
ADD CONSTRAINT FK_Calibration_Source_Campus
FOREIGN KEY (campus_code)
REFERENCES campus (code);

ALTER TABLE probe_response_check_source
ADD CONSTRAINT FK_Probe_response_Source_Campus
FOREIGN KEY (campus_code)
REFERENCES campus (code);

ALTER TABLE calibration
ADD CONSTRAINT FK_Calibration_Instrument
FOREIGN KEY (instrument_id)
REFERENCES instrument (instrument_id);

ALTER TABLE calibration
ADD CONSTRAINT FK_Calibration_Person
FOREIGN KEY (calibrated_by)
REFERENCES person (id);

ALTER TABLE calibration
ADD CONSTRAINT FK_Calibration_Probe
FOREIGN KEY (probe_id)
REFERENCES probe (id);

ALTER TABLE calibration
ADD CONSTRAINT FK_Calibration_Calibration_Source
FOREIGN KEY (calibration_source_id)
REFERENCES calibration_source (id);

ALTER TABLE calibration
ADD CONSTRAINT FK_Calibration_Person_LM
FOREIGN KEY (last_modified_by)
REFERENCES person (id);

ALTER TABLE calibration
ADD CONSTRAINT FK_Calibration_Person_Created
FOREIGN KEY (created_by)
REFERENCES person (id);

ALTER TABLE calibration_matrix
ADD CONSTRAINT FK_Calibration_Matrix_Meter_Range
FOREIGN KEY (meter_range_id)
REFERENCES meter_range (id);

ALTER TABLE calibration_matrix
ADD CONSTRAINT FK_Calibration_Matrix_Calibration_Id
FOREIGN KEY (calibration_id)
REFERENCES calibration (id);

ALTER TABLE probe_response_check
ADD CONSTRAINT FK_Probe_Response_Check_Calibration_Id
FOREIGN KEY (calibration_id)
REFERENCES calibration (id);

ALTER TABLE probe_response_check
ADD CONSTRAINT FK_Probe_Response_Check_Probe_Source_Id
FOREIGN KEY (probe_response_check_source_id)
REFERENCES probe_response_check_source (id);

INSERT INTO `meter_range` (`id`, `label`) VALUES ('1', 'X0.01');
INSERT INTO `meter_range` (`id`, `label`) VALUES ('2', 'X0.01');
INSERT INTO `meter_range` (`id`, `label`) VALUES ('3', 'X0.1');
INSERT INTO `meter_range` (`id`, `label`) VALUES ('4', 'X0.1');
INSERT INTO `meter_range` (`id`, `label`) VALUES ('5', 'X1.0');
INSERT INTO `meter_range` (`id`, `label`) VALUES ('6', 'X1.0');
INSERT INTO `meter_range` (`id`, `label`) VALUES ('7', 'X10.0');
INSERT INTO `meter_range` (`id`, `label`) VALUES ('8', 'X10.0');
INSERT INTO `meter_range` (`id`, `label`) VALUES ('9', 'X100');
INSERT INTO `meter_range` (`id`, `label`) VALUES ('10', 'X100');
INSERT INTO `meter_range` (`id`, `label`) VALUES ('11', 'X1000');
INSERT INTO `meter_range` (`id`, `label`) VALUES ('12', 'X1000');

ALTER TABLE material
ADD COLUMN test_frequency_id INT(11) NULL,
ADD COLUMN next_due_date DATETIME NULL,
ADD COLUMN id_number VARCHAR (25) NULL,
ADD COLUMN ssd VARCHAR (25) NULL,
ADD COLUMN description VARCHAR(255) NULL;

ALTER TABLE material
ADD CONSTRAINT FK_TEST_FREQUENCY
  FOREIGN KEY (test_frequency_id)
  REFERENCES frequency (frequency_id)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE material_test
  ADD COLUMN due_date TIMESTAMP NULL;

RENAME TABLE material_test TO leak_test;

--Survey Attachment
CREATE TABLE survey_attachment (
  survey_id       INTEGER NOT NULL,
  attachment_id      INTEGER NOT NULL,
  PRIMARY KEY (survey_id, attachment_id)
);

ALTER TABLE survey_attachment
ADD CONSTRAINT UK_AttachmentId_SurveyId UNIQUE (attachment_id);

ALTER TABLE survey_attachment
ADD CONSTRAINT FK_survey_attachment_attachmentId FOREIGN KEY (attachment_id)
REFERENCES attachment (attachment_id);

ALTER TABLE survey_attachment
ADD CONSTRAINT FK_survey_attachment_surveyId FOREIGN KEY (survey_id)
REFERENCES survey (id);

ALTER TABLE material DROP FOREIGN KEY FK_98wy1vikupenqneb95ugoankq;
ALTER TABLE material DROP COLUMN current_elemental_mass;
ALTER TABLE material DROP COLUMN current_sample_net_mass;
ALTER TABLE material DROP COLUMN current_volume;
ALTER TABLE material DROP COLUMN current_amount;
ALTER TABLE material DROP COLUMN request_elemental_mass;
ALTER TABLE material DROP COLUMN request_sample_net_mass;
ALTER TABLE material DROP COLUMN request_volume;
ALTER TABLE material DROP COLUMN request_amount;
ALTER TABLE material DROP COLUMN request_user_comments;
ALTER TABLE material DROP COLUMN request_rst_comments;
ALTER TABLE material DROP COLUMN initial_elemental_mass;
ALTER TABLE material DROP COLUMN initial_sample_net_mass;
ALTER TABLE material DROP COLUMN initial_volume;
ALTER TABLE material DROP COLUMN initial_amount;
ALTER TABLE material DROP COLUMN ua_limit_id;

ALTER TABLE material ADD COLUMN is_sealed_source tinyint(1) NOT NULL DEFAULT '0';

CREATE TABLE radionuclide_material (
  id INT(11) NOT NULL AUTO_INCREMENT,
  material_id INT(11) DEFAULT NULL,
  ua_limit_id INT(11) DEFAULT NULL,
  request_elemental_mass DECIMAL (19,5),
  request_net_mass DECIMAL (19, 5),
  request_amount DECIMAL (19, 5),
  request_volume DECIMAL (19, 5),
  request_rst_comments VARCHAR (250),
  request_user_comments VARCHAR (250),
  initial_elemental_mass DECIMAL (19, 5),
  initial_net_mass DECIMAL (19, 5),
  initial_amount DECIMAL (19, 5),
  initial_volume DECIMAL (19, 5),
  PRIMARY KEY (id),
  KEY FK_RadionuclideMaterial_Material (material_id),
  KEY FK_RadionuclideMaterial_UaLimit (ua_limit_id),
  CONSTRAINT FK_RadionuclideMaterial_Material FOREIGN KEY (material_id) REFERENCES material (id),
  CONSTRAINT FK_RadionuclideMaterial_UaLimit FOREIGN KEY (ua_limit_id) REFERENCES ua_limit (ua_limit_id)
);

--LeakTest Attachment
CREATE TABLE leaktest_attachment (
  material_id       INTEGER NOT NULL,
  attachment_id      INTEGER NOT NULL,
  PRIMARY KEY (material_id, attachment_id)
);

ALTER TABLE leaktest_attachment
ADD CONSTRAINT UK_AttachmentId_MaterialId UNIQUE (attachment_id);

ALTER TABLE leaktest_attachment
ADD CONSTRAINT FK_leaktest_attachment_attachmentId FOREIGN KEY (attachment_id)
REFERENCES attachment (attachment_id);

ALTER TABLE leaktest_attachment
ADD CONSTRAINT FK_leaktest_attachment_materialId FOREIGN KEY (material_id)
REFERENCES material (id);
