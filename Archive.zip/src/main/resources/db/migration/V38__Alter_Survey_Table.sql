ALTER TABLE survey ADD COLUMN `date_emailed` DATETIME DEFAULT NULL;

ALTER TABLE ua_bundle ADD COLUMN `campus_code` varchar(255) DEFAULT NULL;
