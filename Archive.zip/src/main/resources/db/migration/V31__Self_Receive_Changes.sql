-- self-receive
ALTER TABLE ua ADD COLUMN is_self_receivable BOOLEAN DEFAULT FALSE NOT NULL;

ALTER TABLE ua_planned_work ADD COLUMN is_self_receivable BOOLEAN DEFAULT FALSE NOT NULL;

ALTER TABLE material_order DROP COLUMN is_self_reported_material;