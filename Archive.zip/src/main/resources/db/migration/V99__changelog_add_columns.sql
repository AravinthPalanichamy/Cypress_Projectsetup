ALTER TABLE `changelog`
ADD COLUMN `parent_entity` VARCHAR(50) NULL AFTER `entity_id`;

ALTER TABLE `changelog`
ADD COLUMN `parent_entity_id` INT(11) NULL AFTER `parent_entity`;
