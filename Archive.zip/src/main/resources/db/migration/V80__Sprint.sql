-- RPM --

ALTER TABLE rpm ADD COLUMN `rpm_uses_type` VARCHAR(20);

--rua_assessment_factor--
 ALTER TABLE `ua` ADD `no_charge` TINYINT(1) DEFAULT 0 AFTER `billing`;
 ALTER TABLE `ua` ADD `other` TINYINT(1) DEFAULT 0 AFTER `no_charge`;

ALTER TABLE `calibration_source` CHANGE COLUMN `name` `name` VARCHAR(250) NOT NULL ;

ALTER TABLE `calibration` DROP FOREIGN KEY `FK_Calibration_Probe`;
ALTER TABLE `calibration` CHANGE COLUMN `probe_id` `probe_id` INT(11) NULL DEFAULT NULL ;
ALTER TABLE `calibration` ADD CONSTRAINT `FK_Calibration_Probe` FOREIGN KEY (`probe_id`) REFERENCES `probe` (`id`);
