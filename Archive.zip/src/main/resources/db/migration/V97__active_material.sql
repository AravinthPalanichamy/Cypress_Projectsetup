alter table material add column is_active tinyint(1) not null default 1;
