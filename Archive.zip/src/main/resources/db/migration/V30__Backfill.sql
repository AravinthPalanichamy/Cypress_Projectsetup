-- Campus setting for back-fill
ALTER TABLE campus ADD COLUMN using_back_fill BOOLEAN DEFAULT TRUE NOT NULL;

-- Material Order back-fill flag
ALTER TABLE material_order ADD is_back_filled BOOLEAN DEFAULT FALSE NOT NULL;