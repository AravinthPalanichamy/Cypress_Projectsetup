alter table material
  add column container_id int(11) default null,
  add column waste_tag_id int(11) default null,
  add column process_name varchar(250) default null;

alter table material add constraint FK_Material_Container foreign key (container_id) references container (container_id);
alter table material add constraint FK_Material_WasteTag foreign key (waste_tag_id) references container_waste_tag (waste_tag_id);

alter table material_use drop foreign key FK_MaterialUse_Container;
alter table material_use drop foreign key FK_MaterialUse_WasteTag;
alter table material_use
  drop column material_use_status_type,
  drop column process_name,
  drop column container_id,
  drop column waste_tag_id,
  drop column return_value_to_material_use_id,
  drop column use_date,
  drop column radionuclide_material_id;

alter table material_use
  add column material_use_type varchar(25),
  add column reference_material_id int(11);

alter table material_use add constraint FK_MaterialUse_ReferenceMaterial foreign key (reference_material_id) references material (id);

