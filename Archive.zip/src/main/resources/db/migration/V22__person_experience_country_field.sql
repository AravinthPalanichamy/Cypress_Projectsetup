-- Added country column for Intl Addr form under SOE and Dosimetry 
ALTER TABLE person_experience ADD country VARCHAR (100) NOT NULL DEFAULT 'United States' after `state`;

ALTER TABLE person_experience MODIFY COLUMN state VARCHAR (100);

ALTER TABLE person_experience MODIFY COLUMN zip VARCHAR (50);

ALTER TABLE person_dosimetry ADD country VARCHAR (100) NOT NULL DEFAULT 'United States' after `state`;

ALTER TABLE person_dosimetry MODIFY COLUMN state VARCHAR (100);

ALTER TABLE person_dosimetry MODIFY COLUMN zip VARCHAR (50);