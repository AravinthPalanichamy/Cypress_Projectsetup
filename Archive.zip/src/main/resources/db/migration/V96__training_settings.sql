--Update setting--
ALTER TABLE `settings`ADD trainings tinyint(1) default 1;

-- Disable Cs-137 mapping to 6.Y--
UPDATE  `line_number_item` SET active = false where line_number_item_id = 31122;

--Mapping Am-247 to 6.Y--
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`, `active`) VALUES ('32260', '9', '326', '1', '1', '1', '1', '1', '0', '0', '100', '1', '1');
