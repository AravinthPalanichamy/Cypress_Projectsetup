-- Waste-Rad Workflow Changes
-- Add usingWaste flag to campus
ALTER TABLE campus            ADD COLUMN using_waste BOOLEAN DEFAULT TRUE NOT NULL;
ALTER TABLE waste_container   ADD COLUMN dispose_using_waste BOOLEAN;
ALTER TABLE waste_container   ADD COLUMN container_identifier varchar(50) DEFAULT '' NOT NULL;

-- Updating test data
UPDATE waste_container SET container_identifier='eca05450-4df7-11e6-bdf4-0800200c9a66' WHERE waste_container_id='1';
UPDATE waste_container SET container_identifier='f723d3c0-4df7-11e6-bdf4-0800200c9a66' WHERE waste_container_id='2';

DELETE FROM person_role WHERE role_type='DATA_ENTRY_ANALYST';