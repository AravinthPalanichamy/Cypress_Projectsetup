-- Training --

ALTER TABLE training ADD COLUMN `training_catagory` VARCHAR(50);
ALTER TABLE training ADD COLUMN `training_type` VARCHAR(50);

--- Campus Code - 01 - Berkeley  Trainings--
UPDATE  training  SET  activity_code = 'BEEHS 401.1_Radiation Safety Training for Users of Radioactive Materials_UCLOL0021_3/28/16', training_catagory ='RAM', training_type = 'I' where id = 1 ;

UPDATE  training  SET  activity_code = 'BEEHS 401.2 Radiation Safety Training for Users of Radiation Producing Machines (RPM)_UCLOL0020_3/28', training_catagory ='RAM', training_type = 'I' where id = 2 ;

UPDATE  training  SET  activity_code = 'BEEHS 401.3_Radiation Safety Training for Users of Radioactive Materials and Radiation Producing Machines (RPM)_UCLOL0022_3/24/16', training_catagory ='RAM,RPM', training_type = 'I' where id = 3 ;

UPDATE  training  SET  activity_code = 'BEEHS EHS 402.1 Retraining for Radioactive Materials (RAM) Users 8-29-16', training_catagory ='RAM', training_type = 'R' where id = 4 ;

UPDATE  training  SET  activity_code = 'BEEHS EHS 402.2 Retraining for Radiation Producing Machine Users 8-29-16', training_catagory ='RPM', training_type = 'R' where id = 5 ;

UPDATE  training  SET  activity_code = 'BEEHS EHS 402.3 Retraining for Radioactive Materials (RAM) & Radiation Producing Machine (RPM) Users 8-29-16', training_catagory ='RAM,RPM', training_type = 'R' where id = 6 ;

UPDATE  training  SET training_catagory ='OTHER', training_type = 'NA' where id = 32 ;

UPDATE  training  SET training_catagory ='OTHER', training_type = 'NA' where id = 33 ;
---  Berkeley Trainings End --


--- Campus Code - 05 - Riverside   Trainings--
UPDATE  training  SET training_catagory ='RAM,RPM', training_type = 'I' where id = 14;
UPDATE  training  SET training_catagory ='RAM,RPM', training_type = 'R' where id = 15;
INSERT INTO training (id, campus_code, classification_name, source_system_id, source_system_name, activity_code, activity_name, active, created_date, last_modified_date, created_by, last_modified_by, training_catagory, training_type)
VALUES (34,'05','Radiation',2,'LMS','RI-ESTOP0101','Radiation Safety',1,null,null,1,1,'RAM,RPM','I,R');
---  Riverside Trainings End --


--- Campus Code - 07 - Santa cruz  Trainings--
UPDATE  training  SET training_catagory ='RAM,RPM', training_type = 'I' where id = 16;
UPDATE  training  SET training_catagory ='RAM,RPM', training_type = 'R' where id = 17;
UPDATE  training  SET training_catagory ='RAM,RPM', training_type = 'I,R' where id = 18;
---  Santa cruz Trainings End --


--- Campus Code - 10 - Merced   Trainings--
UPDATE  training  SET training_catagory ='RPM', training_type = 'I,R' where id = 19;
UPDATE  training  SET training_catagory ='RAM', training_type = 'I,R' where id = 20;
UPDATE  training  SET training_catagory ='RAM', training_type = 'I,R' where id = 21;
UPDATE  training  SET training_catagory ='RAM', training_type = 'I,R' where id = 22;
UPDATE  training  SET training_catagory ='RAM,RPM', training_type = 'I,R' where id = 23;
---  Merced Trainings End --

--- Campus Code - 03 - Davis   Trainings--
UPDATE  training  SET training_catagory ='RAM', training_type = 'R' where id = 28;
UPDATE  training  SET training_catagory ='RPM', training_type = 'I' where id = 29;
UPDATE  training  SET training_catagory ='RAM', training_type = 'I' where id = 30;
UPDATE  training  SET training_catagory ='RAM,RPM', training_type = 'I' where id = 31;

INSERT INTO training (id, campus_code, classification_name, source_system_id, source_system_name, activity_code, activity_name, active, created_date, last_modified_date, created_by, last_modified_by, training_catagory, training_type)
VALUES (35,'03','Radiation',2,'LMS','DAC-XRAY-Q-SAFSVC','Analytical X-Ray Quiz',1,null,null,1,1,'RPM','R');

INSERT INTO training (id, campus_code, classification_name, source_system_id, source_system_name, activity_code, activity_name, active, created_date, last_modified_date, created_by, last_modified_by, training_catagory, training_type)
VALUES (36,'03','Radiation',2,'LMS','DAC-DIAG-XRAY-Q-SAFSVC','Diagnostic X-Ray Quiz',1,null,null,1,1,'RPM','I,R');

INSERT INTO training (id, campus_code, classification_name, source_system_id, source_system_name, activity_code, activity_name, active, created_date, last_modified_date, created_by, last_modified_by, training_catagory, training_type)
VALUES (37,'03','Radiation',2,'LMS','DAC-HYDRO-Q-SAFSVC','Hydroprobe Quiz',1,null,null,1,1,'OTHER','NA');

INSERT INTO training (id, campus_code, classification_name, source_system_id, source_system_name, activity_code, activity_name, active, created_date, last_modified_date, created_by, last_modified_by, training_catagory, training_type)
VALUES (38,'03','Radiation',2,'LMS','DACS-HYDROPROBE-SAFSVC','Hydroprobe Safety',1,null,null,1,1,'OTHER','NA');
---  Davis Trainings End --

--- Material Use ---
ALTER TABLE radionuclide_material ADD COLUMN `current_elemental_mass` DECIMAL(19,11);
update radionuclide_material m set m.current_elemental_mass = m.initial_elemental_mass where initial_elemental_mass is not null and material_id is not null;

ALTER TABLE radionuclide_material ADD COLUMN `current_net_mass` DECIMAL(19,11);
update radionuclide_material m set m.current_net_mass = m.initial_net_mass where initial_net_mass is not null and material_id is not null;


ALTER TABLE radionuclide_material modify column request_elemental_mass DECIMAL (19,11);
ALTER TABLE radionuclide_material modify column request_net_mass DECIMAL (19, 11);
ALTER TABLE radionuclide_material modify column request_amount DECIMAL (19, 11);
ALTER TABLE radionuclide_material modify column request_volume DECIMAL (19, 11);
ALTER TABLE radionuclide_material modify column initial_elemental_mass DECIMAL (19, 11);
ALTER TABLE radionuclide_material modify column initial_net_mass DECIMAL (19, 11);
ALTER TABLE radionuclide_material modify column initial_amount DECIMAL (19, 11);
ALTER TABLE radionuclide_material modify column initial_volume DECIMAL (19, 11);
ALTER TABLE radionuclide_material modify column current_elemental_mass DECIMAL (19, 11);
ALTER TABLE radionuclide_material modify column current_net_mass DECIMAL (19, 11);
ALTER TABLE radionuclide_material modify column current_volume DECIMAL (19, 11);



ALTER TABLE material_use modify column use_amount DECIMAL (19, 12);
ALTER TABLE material_use modify column use_volume DECIMAL (19, 12);
ALTER TABLE material_use modify column use_net_mass DECIMAL (19, 12);
ALTER TABLE material_use modify column use_elemental_mass DECIMAL (19, 12);
---
