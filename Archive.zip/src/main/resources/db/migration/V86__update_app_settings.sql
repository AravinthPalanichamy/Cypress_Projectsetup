alter table settings add column request_materials TINYINT(1) NOT NULL DEFAULT 0;
