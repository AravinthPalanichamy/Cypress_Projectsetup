-- The following are included:
-- Package vendors for the campuses: UCR, UCB, UCSB, UCD, UCM, UCI
-- Package types for all campuses
-- Waste types for all campuses
-- Waste Container types for all campuses

-- Package vendors for UCR
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('3', 'Affinity Labeling Tech', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('4', 'American Radiolabeled CHM', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('5', 'Agilent Technologies', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('6', 'Beckman Coulter Inc.', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('7', 'Cardinal Health', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('8', 'FMC Agricultural Products', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('9', 'First Point Scientific, Inc.', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('10', 'Fisher Scientific', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('11', 'GIBCO (Invitrogen)', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('12', 'GE Healthcare', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('13', 'Homemade by lab', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('14', 'ICN', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('15', 'Isotope Products Lab', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('16', 'iThemba Labs', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('17', 'Moravek Bio Chem', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('18', 'MP Biomedicals', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('19', 'Mettler-Toledo, Inc.', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('20', 'NEC', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('21', 'NRD, LLC', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('22', 'Nucleus', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('23', 'PerkinElmer', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('24', 'Peninsula Laboratories', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('25', 'PASCO', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('26', 'Sigma-Aldrich', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('27', 'Siemens', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('28', 'Spectrum Techniques, Inc.', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('29', 'Thermo Quest Instruments', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('30', 'Troxler Electronics', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('31', 'TSI', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('32', 'Valco Instrument', '05');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('33', 'VWR International, LLC', '05');

-- Package vendors for UCB
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('34', 'Eckert and Ziegler', '01');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('35', 'ARC', '01');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('36', 'MP Biomedical', '01');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('37', 'Sigma Aldrich', '01');

-- Package vendors for UCSB
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('38', 'Perkin Elmer', '08');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('39', 'Moravek Bio Chem', '08');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('40', 'MP Biomedicals', '08');

-- Package vendors for UCD
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('41', 'ALPCO', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('42', 'Amersham', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('43', 'Beckman Coulter', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('44', 'Bracco', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('45', 'Cardinal Health', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('46', 'DiaSorin', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('47', 'Eckert and Ziegler', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('48', 'GE Healthcare', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('49', 'Genentech', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('50', 'George Washington University', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('51', 'ICN', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('52', 'Immunodiagnostic Systems', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('53', 'Isotope Products', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('54', 'MDS Nordin', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('55', 'Merck Millipore', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('56', 'TERA-MIR', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('57', 'Morovek Biochemicals', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('58', 'MP Biomedical', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('59', 'Oregon State University', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('60', 'PerkinElmer', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('61', 'PETNET Solutions', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('62', 'Phoenix Pharmaceuticals', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('63', 'Siemens', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('64', 'Sigma Aldrich', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('65', 'Sirtex', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('66', 'University of Notre Dame', '03');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('67', 'Washington University', '03');

-- Package vendors for UCM
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('68', 'Alpco', '10');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('69', 'Siemens Diagnostics', '10');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('70', 'Perkin Elmer', '10');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('71', 'MP Biomedicals', '10');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('72', 'Millipore', '10');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('73', 'Phoenix Pharmaceuticals', '10');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('74', 'SLAC', '10');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('75', 'EMD', '10');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('76', 'DiaSorin', '10');

-- Package vendors for UCI
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('77', 'Eckert & Ziegler', '09');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('78', 'NRD, LLC', '09');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('79', 'ARC', '09');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('80', 'Moravek Biochemicals', '09');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('81', 'Sanders Medical', '09');
INSERT INTO `package_vendor` (`package_vendor_id`, `package_vendor_name`, `campus_code`) VALUES ('82', 'EMD Millipore', '09');



-------------------------------------- PACKAGE TYPES FOR ALL CAMPUSES START ---------------------------------------------------------


-- Package types for UCB
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('3', 'DOT I', '01');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('4', 'DOT II', '01');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('5', 'DOT III', '01');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('6', 'Exempt', '01');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('7', 'LQ', '01');

-- Package types for UCSF
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('8', 'DOT I', '02');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('9', 'DOT II', '02');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('10', 'DOT III', '02');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('11', 'Exempt', '02');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('12', 'LQ', '02');

-- Package types for UCD
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('13', 'DOT I', '03');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('14', 'DOT II', '03');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('15', 'DOT III', '03');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('16', 'Exempt', '03');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('17', 'LQ', '03');

-- Package types for UCLA
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('18', 'DOT I', '04');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('19', 'DOT II', '04');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('20', 'DOT III', '04');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('21', 'Exempt', '04');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('22', 'LQ', '04');

-- Package types for UCR
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('23', 'DOT I', '05');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('24', 'DOT II', '05');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('25', 'DOT III', '05');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('26', 'Exempt', '05');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('27', 'LQ', '05');

-- Package types for UCSD
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('28', 'DOT I', '06');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('29', 'DOT II', '06');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('30', 'DOT III', '06');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('31', 'Exempt', '06');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('32', 'LQ', '06');

-- Package types for UCSC
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('33', 'DOT I', '07');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('34', 'DOT II', '07');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('35', 'DOT III', '07');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('36', 'Exempt', '07');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('37', 'LQ', '07');

-- Package types for UCSB
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('38', 'DOT I', '08');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('39', 'DOT II', '08');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('40', 'DOT III', '08');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('41', 'Exempt', '08');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('42', 'LQ', '08');

-- Package types for UCI
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('43', 'DOT I', '09');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('44', 'DOT II', '09');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('45', 'DOT III', '09');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('46', 'Exempt', '09');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('47', 'LQ', '09');

-- Package types for UCM
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('48', 'DOT I', '10');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('49', 'DOT II', '10');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('50', 'DOT III', '10');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('51', 'Exempt', '10');
INSERT INTO `package_type` (`package_type_id`, `package_type_name`, `campus_code`) VALUES ('52', 'LQ', '10');

-------------------------------------- PACKAGE TYPES FOR ALL CAMPUSES END ---------------------------------------------------------


-------------------------------------- WASTE TYPES FOR ALL CAMPUSES  START ---------------------------------------------------------

-- Inserting waste types UCB
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('101', 'Dry Solid', 'DRY_SOLID', '2','01');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('102', 'Liquid', 'LIQUID', '3', '01');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('103', 'Exempt Scintillation Vials', 'EXEMPT_VIALS', '2', '01');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('104', 'Regulated Scintillation Vials', 'REGULATED_VIALS', '2', '01');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('105', 'Source Vials', 'SOURCE_VIALS', '2', '01');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('106', 'Bactec Plates', 'BACTEC_PLATES','2', '01');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('107', 'Beta Plates', 'BETA_PLATES', '2', '01');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('108', 'Other', 'OTHER', '2', '01');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('109', 'Sharps', 'SHARPS', '2', '01');


-- Inserting waste types UCSF
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('110', 'Dry Solid', 'DRY_SOLID', '2','02');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('111', 'Liquid', 'LIQUID', '3', '02');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('112', 'Exempt Scintillation Vials', 'EXEMPT_VIALS', '2', '02');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('113', 'Regulated Scintillation Vials', 'REGULATED_VIALS', '2', '02');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('114', 'Source Vials', 'SOURCE_VIALS', '2', '02');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('115', 'Bactec Plates', 'BACTEC_PLATES','2', '02');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('116', 'Beta Plates', 'BETA_PLATES', '2', '02');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('117', 'Other', 'OTHER', '2', '02');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('118', 'Sharps', 'SHARPS', '2', '02');


-- Inserting waste types UCD
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('119', 'Dry Solid', 'DRY_SOLID', '2','03');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('120', 'Liquid', 'LIQUID', '3', '03');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('121', 'Exempt Scintillation Vials', 'EXEMPT_VIALS', '2', '03');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('122', 'Regulated Scintillation Vials', 'REGULATED_VIALS', '2', '03');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('123', 'Source Vials', 'SOURCE_VIALS', '2', '03');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('124', 'Bactec Plates', 'BACTEC_PLATES','2', '03');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('125', 'Beta Plates', 'BETA_PLATES', '2', '03');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('126', 'Other', 'OTHER', '2', '03');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('127', 'Sharps', 'SHARPS', '2', '03');


-- Inserting waste types UCLA
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('128', 'Dry Solid', 'DRY_SOLID', '2','04');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('129', 'Liquid', 'LIQUID', '3', '04');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('130', 'Exempt Scintillation Vials', 'EXEMPT_VIALS', '2', '04');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('131', 'Regulated Scintillation Vials', 'REGULATED_VIALS', '2', '04');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('132', 'Source Vials', 'SOURCE_VIALS', '2', '04');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('133', 'Bactec Plates', 'BACTEC_PLATES','2', '04');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('134', 'Beta Plates', 'BETA_PLATES', '2', '04');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('135', 'Other', 'OTHER', '2', '04');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('136', 'Sharps', 'SHARPS', '2', '04');


-- Inserting waste types UCR
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('137', 'Dry Solid', 'DRY_SOLID', '2','05');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('138', 'Liquid', 'LIQUID', '3', '05');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('139', 'Exempt Scintillation Vials', 'EXEMPT_VIALS', '2', '05');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('140', 'Regulated Scintillation Vials', 'REGULATED_VIALS', '2', '05');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('141', 'Source Vials', 'SOURCE_VIALS', '2', '05');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('142', 'Bactec Plates', 'BACTEC_PLATES','2', '05');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('143', 'Beta Plates', 'BETA_PLATES', '2', '05');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('144', 'Other', 'OTHER', '2', '05');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('145', 'Sharps', 'SHARPS', '2', '05');


-- Inserting waste types UCSD
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('146', 'Dry Solid', 'DRY_SOLID', '2','06');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('147', 'Liquid', 'LIQUID', '3', '06');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('148', 'Exempt Scintillation Vials', 'EXEMPT_VIALS', '2', '06');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('149', 'Regulated Scintillation Vials', 'REGULATED_VIALS', '2', '06');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('150', 'Source Vials', 'SOURCE_VIALS', '2', '06');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('151', 'Bactec Plates', 'BACTEC_PLATES','2', '06');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('152', 'Beta Plates', 'BETA_PLATES', '2', '06');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('153', 'Other', 'OTHER', '2', '06');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('154', 'Sharps', 'SHARPS', '2', '06');


-- Inserting waste types UCSC
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('155', 'Dry Solid', 'DRY_SOLID', '2','07');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('156', 'Liquid', 'LIQUID', '3', '07');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('157', 'Exempt Scintillation Vials', 'EXEMPT_VIALS', '2', '07');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('158', 'Regulated Scintillation Vials', 'REGULATED_VIALS', '2', '07');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('159', 'Source Vials', 'SOURCE_VIALS', '2', '07');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('160', 'Bactec Plates', 'BACTEC_PLATES','2', '07');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('161', 'Beta Plates', 'BETA_PLATES', '2', '07');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('162', 'Other', 'OTHER', '2', '07');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('163', 'Sharps', 'SHARPS', '2', '07');


-- Inserting waste types UCSB
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('164', 'Dry Solid', 'DRY_SOLID', '2','08');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('165', 'Liquid', 'LIQUID', '3', '08');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('166', 'Exempt Scintillation Vials', 'EXEMPT_VIALS', '2', '08');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('167', 'Regulated Scintillation Vials', 'REGULATED_VIALS', '2', '08');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('168', 'Source Vials', 'SOURCE_VIALS', '2', '08');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('169', 'Bactec Plates', 'BACTEC_PLATES','2', '08');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('170', 'Beta Plates', 'BETA_PLATES', '2', '08');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('171', 'Other', 'OTHER', '2', '08');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('172', 'Sharps', 'SHARPS', '2', '08');


-- Inserting waste types UCI
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('173', 'Dry Solid', 'DRY_SOLID', '2','09');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('174', 'Liquid', 'LIQUID', '3', '09');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('175', 'Exempt Scintillation Vials', 'EXEMPT_VIALS', '2', '09');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('176', 'Regulated Scintillation Vials', 'REGULATED_VIALS', '2', '09');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('177', 'Source Vials', 'SOURCE_VIALS', '2', '09');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('178', 'Bactec Plates', 'BACTEC_PLATES','2', '09');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('179', 'Beta Plates', 'BETA_PLATES', '2', '09');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('180', 'Other', 'OTHER', '2', '09');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('181', 'Sharps', 'SHARPS', '2', '09');


-- Inserting waste types UCM
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('182', 'Dry Solid', 'DRY_SOLID', '2','10');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('183', 'Liquid', 'LIQUID', '3', '10');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('184', 'Exempt Scintillation Vials', 'EXEMPT_VIALS', '2', '10');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('185', 'Regulated Scintillation Vials', 'REGULATED_VIALS', '2', '10');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('186', 'Source Vials', 'SOURCE_VIALS', '2', '10');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('187', 'Bactec Plates', 'BACTEC_PLATES','2', '10');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('188', 'Beta Plates', 'BETA_PLATES', '2', '10');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('189', 'Other', 'OTHER', '2', '10');
INSERT INTO `waste_type` (`waste_type_id`, `waste_type_description`, `waste_type_label`, `physical_form_id`, `campus_code`) VALUES ('190', 'Sharps', 'SHARPS', '2', '10');


-------------------------------------- WASTE TYPES FOR ALL CAMPUSES END ---------------------------------------------------------



-------------------------------------- WASTE CONTAINER TYPES FOR ALL CAMPUSES START ---------------------------------------------------------

-- Inserting waste container types UCB
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('101', 'Aerosol', 'AEROSOL', '01');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('102', 'Bag', 'BAG', '01');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('103', 'Bottle, Glass', 'BOTTLE_GLASS', '01');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('104', 'Bottle, Plastic', 'BOTTLE_PLASTIC', '01');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('105', 'Box, Cardboard', 'BOX_CARDBOARD', '01');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('106', 'Box, 2 Cubic Feet', 'BOX_2_CUBIC_FEET', '01');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('107', 'Box, Cubic Yard', 'BOX_CUBIC_YARD', '01');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('108', 'Carboy', 'CARBOY', '01');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('109', 'Cylinder', 'CYLINDER', '01');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('110', 'Drum, Metal', 'DRUM_METAL', '01');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('111', 'Drum, Poly', 'DRUM_POLY', '01');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('112', 'Metal Can', 'METAL_CAN', '01');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('113', 'Pail', 'PAIL', '01');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('114', 'Sharps Container', 'SHARPS_CONTAINER', '01');


-- Inserting waste container types UCSF
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('115', 'Aerosol', 'AEROSOL', '02');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('116', 'Bag', 'BAG', '02');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('117', 'Bottle, Glass', 'BOTTLE_GLASS', '02');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('118', 'Bottle, Plastic', 'BOTTLE_PLASTIC', '02');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('119', 'Box, Cardboard', 'BOX_CARDBOARD', '02');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('120', 'Box, 2 Cubic Feet', 'BOX_2_CUBIC_FEET', '02');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('121', 'Box, Cubic Yard', 'BOX_CUBIC_YARD', '02');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('122', 'Carboy', 'CARBOY', '02');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('123', 'Cylinder', 'CYLINDER', '02');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('124', 'Drum, Metal', 'DRUM_METAL', '02');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('125', 'Drum, Poly', 'DRUM_POLY', '02');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('126', 'Metal Can', 'METAL_CAN', '02');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('127', 'Pail', 'PAIL', '02');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('128', 'Sharps Container', 'SHARPS_CONTAINER', '02');


-- Inserting waste container types UCD
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('129', 'Aerosol', 'AEROSOL', '03');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('130', 'Bag', 'BAG', '03');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('131', 'Bottle, Glass', 'BOTTLE_GLASS', '03');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('132', 'Bottle, Plastic', 'BOTTLE_PLASTIC', '03');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('133', 'Box, Cardboard', 'BOX_CARDBOARD', '03');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('134', 'Box, 2 Cubic Feet', 'BOX_2_CUBIC_FEET', '03');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('135', 'Box, Cubic Yard', 'BOX_CUBIC_YARD', '03');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('136', 'Carboy', 'CARBOY', '03');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('137', 'Cylinder', 'CYLINDER', '03');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('138', 'Drum, Metal', 'DRUM_METAL', '03');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('139', 'Drum, Poly', 'DRUM_POLY', '03');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('140', 'Metal Can', 'METAL_CAN', '03');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('141', 'Pail', 'PAIL', '03');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('142', 'Sharps Container', 'SHARPS_CONTAINER', '03');


-- Inserting waste container types UCLA
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('143', 'Aerosol', 'AEROSOL', '04');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('144', 'Bag', 'BAG', '04');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('145', 'Bottle, Glass', 'BOTTLE_GLASS', '04');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('146', 'Bottle, Plastic', 'BOTTLE_PLASTIC', '04');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('147', 'Box, Cardboard', 'BOX_CARDBOARD', '04');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('148', 'Box, 2 Cubic Feet', 'BOX_2_CUBIC_FEET', '04');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('149', 'Box, Cubic Yard', 'BOX_CUBIC_YARD', '04');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('150', 'Carboy', 'CARBOY', '04');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('151', 'Cylinder', 'CYLINDER', '04');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('152', 'Drum, Metal', 'DRUM_METAL', '04');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('153', 'Drum, Poly', 'DRUM_POLY', '04');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('154', 'Metal Can', 'METAL_CAN', '04');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('155', 'Pail', 'PAIL', '04');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('156', 'Sharps Container', 'SHARPS_CONTAINER', '04');


-- Inserting waste container types UCR
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('157', 'Aerosol', 'AEROSOL', '05');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('158', 'Bag', 'BAG', '05');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('159', 'Bottle, Glass', 'BOTTLE_GLASS', '05');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('160', 'Bottle, Plastic', 'BOTTLE_PLASTIC', '05');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('161', 'Box, Cardboard', 'BOX_CARDBOARD', '05');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('162', 'Box, 2 Cubic Feet', 'BOX_2_CUBIC_FEET', '05');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('163', 'Box, Cubic Yard', 'BOX_CUBIC_YARD', '05');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('164', 'Carboy', 'CARBOY', '05');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('165', 'Cylinder', 'CYLINDER', '05');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('166', 'Drum, Metal', 'DRUM_METAL', '05');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('167', 'Drum, Poly', 'DRUM_POLY', '05');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('168', 'Metal Can', 'METAL_CAN', '05');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('169', 'Pail', 'PAIL', '05');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('170', 'Sharps Container', 'SHARPS_CONTAINER', '05');

-- Inserting waste container types UCSD
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('171', 'Aerosol', 'AEROSOL', '06');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('172', 'Bag', 'BAG', '06');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('173', 'Bottle, Glass', 'BOTTLE_GLASS', '06');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('174', 'Bottle, Plastic', 'BOTTLE_PLASTIC', '06');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('175', 'Box, Cardboard', 'BOX_CARDBOARD', '06');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('176', 'Box, 2 Cubic Feet', 'BOX_2_CUBIC_FEET', '06');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('177', 'Box, Cubic Yard', 'BOX_CUBIC_YARD', '06');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('178', 'Carboy', 'CARBOY', '06');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('179', 'Cylinder', 'CYLINDER', '06');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('180', 'Drum, Metal', 'DRUM_METAL', '06');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('181', 'Drum, Poly', 'DRUM_POLY', '06');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('182', 'Metal Can', 'METAL_CAN', '06');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('183', 'Pail', 'PAIL', '06');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('184', 'Sharps Container', 'SHARPS_CONTAINER', '06');


-- Inserting waste container types UCSC
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('185', 'Aerosol', 'AEROSOL', '07');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('186', 'Bag', 'BAG', '07');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('187', 'Bottle, Glass', 'BOTTLE_GLASS', '07');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('188', 'Bottle, Plastic', 'BOTTLE_PLASTIC', '07');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('189', 'Box, Cardboard', 'BOX_CARDBOARD', '07');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('190', 'Box, 2 Cubic Feet', 'BOX_2_CUBIC_FEET', '07');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('191', 'Box, Cubic Yard', 'BOX_CUBIC_YARD', '07');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('192', 'Carboy', 'CARBOY', '07');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('193', 'Cylinder', 'CYLINDER', '07');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('194', 'Drum, Metal', 'DRUM_METAL', '07');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('195', 'Drum, Poly', 'DRUM_POLY', '07');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('196', 'Metal Can', 'METAL_CAN', '07');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('197', 'Pail', 'PAIL', '07');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('198', 'Sharps Container', 'SHARPS_CONTAINER', '07');


-- Inserting waste container types UCSB
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('199', 'Aerosol', 'AEROSOL', '08');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('200', 'Bag', 'BAG', '08');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('201', 'Bottle, Glass', 'BOTTLE_GLASS', '08');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('202', 'Bottle, Plastic', 'BOTTLE_PLASTIC', '08');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('203', 'Box, Cardboard', 'BOX_CARDBOARD', '08');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('204', 'Box, 2 Cubic Feet', 'BOX_2_CUBIC_FEET', '08');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('205', 'Box, Cubic Yard', 'BOX_CUBIC_YARD', '08');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('206', 'Carboy', 'CARBOY', '08');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('207', 'Cylinder', 'CYLINDER', '08');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('208', 'Drum, Metal', 'DRUM_METAL', '08');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('209', 'Drum, Poly', 'DRUM_POLY', '08');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('210', 'Metal Can', 'METAL_CAN', '08');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('211', 'Pail', 'PAIL', '08');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('212', 'Sharps Container', 'SHARPS_CONTAINER', '08');


-- Inserting waste container types UCI
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('213', 'Aerosol', 'AEROSOL', '09');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('214', 'Bag', 'BAG', '09');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('215', 'Bottle, Glass', 'BOTTLE_GLASS', '09');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('216', 'Bottle, Plastic', 'BOTTLE_PLASTIC', '09');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('217', 'Box, Cardboard', 'BOX_CARDBOARD', '09');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('218', 'Box, 2 Cubic Feet', 'BOX_2_CUBIC_FEET', '09');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('219', 'Box, Cubic Yard', 'BOX_CUBIC_YARD', '09');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('220', 'Carboy', 'CARBOY', '09');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('221', 'Cylinder', 'CYLINDER', '09');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('222', 'Drum, Metal', 'DRUM_METAL', '09');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('223', 'Drum, Poly', 'DRUM_POLY', '09');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('224', 'Metal Can', 'METAL_CAN', '09');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('225', 'Pail', 'PAIL', '09');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('226', 'Sharps Container', 'SHARPS_CONTAINER', '09');


-- Inserting waste container types UCM
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('227', 'Aerosol', 'AEROSOL', '10');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('228', 'Bag', 'BAG', '10');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('229', 'Bottle, Glass', 'BOTTLE_GLASS', '10');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('230', 'Bottle, Plastic', 'BOTTLE_PLASTIC', '10');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('231', 'Box, Cardboard', 'BOX_CARDBOARD', '10');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('232', 'Box, 2 Cubic Feet', 'BOX_2_CUBIC_FEET', '10');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('233', 'Box, Cubic Yard', 'BOX_CUBIC_YARD', '10');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('234', 'Carboy', 'CARBOY', '10');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('235', 'Cylinder', 'CYLINDER', '10');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('236', 'Drum, Metal', 'DRUM_METAL', '10');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('237', 'Drum, Poly', 'DRUM_POLY', '10');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('238', 'Metal Can', 'METAL_CAN', '10');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('239', 'Pail', 'PAIL', '10');
INSERT INTO `waste_container_type` (`waste_container_type_id`, `waste_container_type_description`, `waste_container_type_label`, `campus_code`) VALUES ('240', 'Sharps Container', 'SHARPS_CONTAINER', '10');


-------------------------------------- WASTE CONTAINER TYPES FOR ALL CAMPUSES END ---------------------------------------------------------
