-- Mapped Ru-103 sealed Source to 6.B.1-
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`, `active`)
VALUES ('32252', '227', '329', '1', '1', '1', '1', '1', '0', '0', null, null, '1');

-- Mapped Ru-103, Er-169 and Lu-177 sealed Source to 6.F.1-
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`, `active`)
VALUES ('32253', '227', '301', '1', '1', '1', '1', '1', '0', '0', null, null, '1');
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`, `active`)
VALUES ('32254', '333', '301', '1', '1', '1', '1', '1', '0', '0', null, null, '1');
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`, `active`)
VALUES ('32255', '346', '301', '1', '1', '1', '1', '1', '0', '0', null, null, '1');

-- Mapped Ru-103 sealed Source to 6.I-
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`, `active`)
VALUES ('32256', '227', '305', '1', '1', '1', '1', '1', '0', '0', null, null, '1');


-- Mapped Ru-103 Non sealed Source to 6.H-
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`, `active`)
VALUES ('32257', '227', '204', '1', '1', '1', '1', '0', '0', '0', null, null, '1');


-- Mapped Ru-103 Non sealed Source to 6.S.1-
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`, `active`)
VALUES ('32258', '227', '315', '1', '1', '1', '1', '0', '0', '0', null, null, '1');

-- Mapped Ru-103 Non sealed Source to 6.R-
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`, `active`)
VALUES ('32259', '227', '314', '1', '1', '1', '1', '0', '0', '0', null, null, '1');

--Updating 6.R mapping, from sealed source to non sealed source
UPDATE `line_number_item` SET is_sealed_source = false where line_number_item_id in
(30886,30887,30888,31016,30982,30983,30890,31040,31107,31108,31109,30896,30988,31049,31050,30889,30913,30914,30915,30905,31033,30921,31069,31070,30911,30912,31073,31094,31017,31018,30893,30936,31082,30906,30968,30883,31056,30917,30918,31101,31102,31058,31059,31060,31053,30941,30942,30973,31000,30899,30931,31065,31066,30995,30945,30970,31096,31077,30924,30984,31034,30985,30986,30891,31092,31041,31042,31043,31044,31045,30875,30876,31110,31111,31112,30933,30934,30935,30877,30878,30897,30898,30989,30990,31051,31052,30916,31035,31036,31037,31038,30922,31071,31072,30882,30926,31074,31095,31076,31019,31020,31021,31022,31023,31024,30991,30992,30993,31091,30894,30895,30937,30938,30939,30940,31046,31047,31048,30907,30908,30909,30910,30969,30879,30880,30884,30962,30963,30964,30965,30966,31057,30919,30881,31103,31104,31105,31106,30979,30980,31061,31062,31063,31064,31054,31055,30943,30944,31089,30976,30977,30978,30974,30975,31001,31002,31003,31004,30900,30901,30902,30932,31067,31068,30996,30997,30998,30999,30946,30947,30948,30949,30950,31075,30971,30972,31005,31006,31007,31008,31009,31010,31011,31012,31013,31014,31015,31097,31098,31099,31100,30904,31084,31085,31086,31026,31027,31028,31029,31030,31031,30951,30952,30953,30954,30955,31081,30925,30957,30958,30959,30929,30923,30928,31025,30981,30885,30903,31078,31087,31032,30956,31039,30987,30930,30960,30967,30927,31083,31079,31080,30994,31093,31088,31090,30892,30961,30920,32251,32248);

--Making sr-90 and pb 210 mapping inactive, because they are exception for 6.F.1 mapping-
UPDATE `line_number_item` SET active = false where line_number_item_id in (31194, 31351);

--Adding new Radionuclide Dy-159--
INSERT INTO `radionuclide` (`radionuclide_id`, `name`, `half_life`, `half_life_unit`, `radiotoxicity`, `z_value`, `is_alpha_emitter`, `is_beta_emitter`, `is_gamma_emitter`, `is_neutron_emitter`, `is_source_material`, `is_special_nuclear_material`, `activity_mci_per_gram`, `is_sewer_disposal`, `schedule_c`, `egroup`, `ali_mci`, `is_status_active`, `display_name`)VALUES ('376', 'Dy-159', '144.40000', '4', '1', '66', '0', '0', '0', '0', '0', '0', '0.00000000000', '0', '0', '1', '2', '1', 'Dy159');
