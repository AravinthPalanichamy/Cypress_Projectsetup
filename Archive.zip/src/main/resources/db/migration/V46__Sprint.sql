--- ua limit
ALTER TABLE ua_limit DROP COLUMN elemental_mass;
ALTER TABLE ua_limit DROP COLUMN net_mass;
ALTER TABLE ua_limit DROP COLUMN contained_mass;


ALTER TABLE material ADD COLUMN lot_number VARCHAR (50);
ALTER TABLE material ADD COLUMN lot_description VARCHAR (250);
