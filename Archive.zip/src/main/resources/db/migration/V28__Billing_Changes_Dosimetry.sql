ALTER TABLE machine ADD account_id INTEGER;

ALTER TABLE machine
ADD CONSTRAINT FK_Machine_Account
FOREIGN KEY (account_id)
REFERENCES account (account_id);

-- Delegate Changes
ALTER TABLE `ua_bundle_person` ADD `is_delegate` BOOLEAN DEFAULT FALSE NOT NULL;
ALTER TABLE `core_bundle_person` ADD `is_delegate` BOOLEAN DEFAULT FALSE NOT NULL;