--Note: PeronId starts with 9
SET @SYSTEM_USER_ID = 1;
SET @RSO_UCR_PERSON_ID = 10;
SET @RSCM_UCR_PERSON_ID = 11;

SET @RSO_UCD_PERSON_ID = 12;

SET @RSO_UCDMC_PERSON_ID = 13;
SET @RSCM_UCDMC_PERSON_ID = 14;

SET @RSO_UCI_PERSON_ID = 15;

SET @RSO_UCIMC_PERSON_ID = 16;

SET @RSO_UCB_PERSON_ID = 17;

SET @RSO_UCLA_PERSON_ID = 18;

SET @RSO_UCMERCED_PERSON_ID = 19;

SET @RSO_UCSC_PERSON_ID = 20;

--UC RIVERSIDE
--PERSON DATA
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `campus_code`, `department`) VALUES (@RSO_UCR_PERSON_ID, 'karen.janiga@ucr.edu', 'kjaniga@ucr.edu', 'Karen', 'Janiga', '1287917', '05', 'ENVIRONMENTAL HEALTH &amp; SAFETY');
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `phone`, `campus_code`, `department`) VALUES (@RSCM_UCR_PERSON_ID, 'morris.maduro@ucr.edu', 'mmaduro@ucr.edu', 'Morris', 'Maduro', '160299', '9518277196', '05', 'BIOLOGY');

--PERSON ROLE TEST DATA
INSERT INTO `person_role`(`person_id`,`role_type`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES (@RSO_UCR_PERSON_ID, 'RADIATION_SAFETY_OFFICER', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID);
INSERT INTO `person_role`(`person_id`,`role_type`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES (@RSCM_UCR_PERSON_ID, 'RADIATION_SAFETY_COMMITTEE_MEMBER', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID);

--UC DAVIS
--PERSON DATA
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `campus_code`, `department`) VALUES (@RSO_UCD_PERSON_ID, 'gdwestcot@UCDAVIS.EDU', 'gw5743@ucdavis.edu', 'Gerry', 'Westcott', '49725', '03', 'ENVIRONMENTAL HEALTH &amp; SAFETY');

--PERSON ROLE DATA
INSERT INTO `person_role`(`person_id`,`role_type`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES (@RSO_UCD_PERSON_ID, 'RADIATION_SAFETY_OFFICER', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID);

--UC DAVIS MC
--PERSON DATA
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `phone`, `campus_code`, `department`) VALUES (@RSO_UCDMC_PERSON_ID, 'linda.kroger@ucdmc.ucdavis.edu', 'szkroger@ucdavis.edu', 'Linda', 'Kroger', '44710', '9167347325', '03', 'UCDMC APS APPOINTMENTS');
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `phone`, `campus_code`, `department`) VALUES (@RSCM_UCDMC_PERSON_ID, 'cameron.foster@ucdmc.ucdavis.edu', 'CS1407714334687_676601@ucdavis.edu', 'Cameron', 'Foster', '676601', '9167032133', '03', 'MED: DIAGNOSTIC RADIOLOGY');

--PERSON ROLE TEST DATA
INSERT INTO `person_role`(`person_id`,`role_type`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES (@RSO_UCDMC_PERSON_ID, 'RADIATION_SAFETY_OFFICER', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID);
INSERT INTO `person_role`(`person_id`,`role_type`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES (@RSCM_UCDMC_PERSON_ID, 'RADIATION_SAFETY_COMMITTEE_MEMBER', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID);

--UC IRVINE
--PERSON DATA
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `campus_code`, `department`) VALUES (@RSO_UCI_PERSON_ID, 'ridendo@uci.edu', 'RIDENDO@uci.edu', 'Rocky I.', 'Dendo', '169596', '09', 'ENVIRON HEALTH &amp; SAFETY OFFICE');

--PERSON ROLE DATA
INSERT INTO `person_role`(`person_id`,`role_type`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES (@RSO_UCI_PERSON_ID, 'RADIATION_SAFETY_OFFICER', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID);

--UC IRVINE MC
--PERSON DATA
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `campus_code`, `department`) VALUES (@RSO_UCIMC_PERSON_ID, 'jgratzle@uci.edu', 'CS1438278989786_1014735@uci.edu', 'John', 'Gratzle', '1014735', '09', 'ENVIRONMENTAL HEALTH &amp; SAFETY');

--PERSON ROLE DATA
INSERT INTO `person_role`(`person_id`,`role_type`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES (@RSO_UCIMC_PERSON_ID, 'RADIATION_SAFETY_OFFICER', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID);

--UC BERKELEY
--PERSON DATA
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `phone`, `campus_code`, `department`) VALUES (@RSO_UCB_PERSON_ID, 'cjmackenzie@berkeley.edu', 'cjmackenzie@berkeley.edu', 'Carolyn', 'Mac Kenzie', '454798', '5106437976', '01', 'BAS ENVIRON HEALTH &amp; SAFETY');

--PERSON ROLE DATA
INSERT INTO `person_role`(`person_id`,`role_type`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES (@RSO_UCB_PERSON_ID, 'RADIATION_SAFETY_OFFICER', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID);

--UC LOS ANGELES
--PERSON DATA
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `campus_code`, `department`) VALUES (@RSO_UCLA_PERSON_ID, 'bruiz@ehs.ucla.edu', 'bruiz@ucla.edu', 'Bryan', 'Ruiz', '1165707', '04', 'RADIATION SAFETY');

--PERSON ROLE DATA
INSERT INTO `person_role`(`person_id`,`role_type`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES (@RSO_UCLA_PERSON_ID, 'RADIATION_SAFETY_OFFICER', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID);

--UC SANTA CRUZ
--PERSON DATA
INSERT INTO `person`(`id`, `email`,`eppn`,`first_name`, `last_name`, `net_id`, `campus_code`, `department`) VALUES (@RSO_UCSC_PERSON_ID, 'csherma1@ucsc.edu', 'csherma1@ucsc.edu', 'Conrad', 'Sherman', '1294500', '07', 'ENV HEALTH &amp; SAFETY-A');

--PERSON ROLE DATA
INSERT INTO `person_role`(`person_id`,`role_type`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`) VALUES (@RSO_UCSC_PERSON_ID, 'RADIATION_SAFETY_OFFICER', '2014-04-30 00:00:00', '2015-04-30 00:00:00', @SYSTEM_USER_ID, @SYSTEM_USER_ID);