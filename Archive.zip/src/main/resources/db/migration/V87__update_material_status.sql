ALTER TABLE `material` 
CHANGE COLUMN `inventory_status_type` `inventory_status_type` VARCHAR(50) NOT NULL ;