ALTER TABLE material_order DROP FOREIGN KEY FK_MaterialOrder_SealedSourceInfo;

ALTER TABLE material_order ADD CONSTRAINT `FK_MaterialOrder_SealedSourceInfo` FOREIGN KEY (`ss_info_id`) REFERENCES `sealed_source_info` (`ss_info_id`);
