-- Possession Factor table

CREATE TABLE `possession_factor` (
  `possession_factor_id` int(11) NOT NULL AUTO_INCREMENT,
  `possession_factor_value` int(11) NOT NULL,
  `display_value` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `min` int(11) NOT NULL,
  `max` int(11) NOT NULL,
  PRIMARY KEY (`possession_factor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `ua_limit` ADD COLUMN `possession_factor_id` int(11) DEFAULT NULL AFTER `form_factor_id`;

ALTER TABLE `ua_limit` ADD KEY `FK_UaLimit_PossessionFactor` (`possession_factor_id`);

ALTER TABLE `ua_limit` ADD  CONSTRAINT `FK_UaLimit_PossessionFactor` FOREIGN KEY (`possession_factor_id`) REFERENCES `possession_factor` (`possession_factor_id`);

-- Possession Factor Data

INSERT INTO `possession_factor`
(`possession_factor_value`, `display_value`, `description`, `min`, `max`)
VALUES
(1, '1', '≤ 10 mCi', 0, 10);

INSERT INTO `possession_factor`
(`possession_factor_value`, `display_value`, `description`, `min`, `max`)
VALUES
(2, '2', '10 mCi < Possession ≤ 50 mCi', 10, 50);

INSERT INTO `possession_factor`
(`possession_factor_value`, `display_value`, `description`, `min`, `max`)
VALUES
(5, '5', '50 mCi < Possession ≤ 100 mCi', 50, 100);

INSERT INTO `possession_factor`
(`possession_factor_value`, `display_value`, `description`, `min`, `max`)
VALUES
(10, '10', 'Possession > 100 mCi', 100, 10000000);