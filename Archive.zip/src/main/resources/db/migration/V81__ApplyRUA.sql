
alter table ua add column ua_submitted tinyint(1) default 0;