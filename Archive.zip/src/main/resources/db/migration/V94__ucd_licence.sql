-- (UCD) Changing radionuclide status to active for Be-7, Mn-52, Sc-47, Sc-48, Ce-143--
UPDATE `radionuclide` SET is_status_active = true WHERE radionuclide_id IN (117, 169, 235, 236, 131, 333);

--Mapping 6.B.1, use purpose to clinical --
UPDATE `license_line_number` set use_purpose_id = 29 where license_line_number_id = 329;

--Mapping 6.D.1, use purpose to clinical --
UPDATE `license_line_number` set use_purpose_id = 29 where license_line_number_id = 331;

--updating Description for 6.T--
UPDATE `license_line_number` set description = 'Total 740 TBq (20 Ci) in 2 sources, no single source to exceed 370 GBq (10 Ci),To be used for brachytherapy in animals only(Human use is prohibited.)' where license_line_number_id = 321;

--updating use_purpose_name--
UPDATE `use_purpose` SET use_purpose_name = 'Blood irradiator' where use_purpose_id = 31;

--Licence lineNumber Id for UCD -ranges form 3xxx0-3xxx9 corresponds to license id = 3 --
--Adding Lu-177 to line_number_item with mapping 6.B.1, 6.B, 6.I all sealedSource --
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`) VALUES ('32246', '346', '329', '1', '1', '1', '1', '1', '0', '0', '10', '3');
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`) VALUES ('32247', '346', '305', '1', '1', '1', '1', '1', '0', '0', '10', '3');
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`) VALUES ('32248', '346', '314', '1', '1', '1', '1', '1', '0', '0', '10', '3');


--Adding Er-169 to line_number_item with mapping 6.B.1, 6.B, 6.I all sealedSource --
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`) VALUES ('32249', '333', '329', '1', '1', '1', '1', '1', '0', '0', '10', '3');
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`) VALUES ('32250', '333', '305', '1', '1', '1', '1', '1', '0', '0', '10', '3');
INSERT INTO `line_number_item` (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`) VALUES ('32251', '333', '314', '1', '1', '1', '1', '1', '0', '0', '10', '3');
