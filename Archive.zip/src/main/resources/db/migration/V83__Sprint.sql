--Training
UPDATE training SET activity_code ='BEEHS 401.2_Objective_Recordkeeping_UCLOL0020' WHERE (activity_code = 'BEEHS 401.2_Objective_UCLOL0020' AND id <> 0);
UPDATE training SET activity_code ='BEEHS 401.3_Objective_Recordkeeping_UCLOL0022' WHERE (activity_code = 'BEEHS 401.3_Objective_UCLOL0022' AND id <> 0);

UPDATE person_role set role_type = 'INSPECTOR' where  role_type  = 'RADIATION_SAFETY_SPECIALIST' and person_role_id <> 0;
UPDATE person_role set role_type = 'RADIATION_ADMIN' where  role_type  = 'RADIATION_SAFETY_OFFICER' and person_role_id <> 0;
