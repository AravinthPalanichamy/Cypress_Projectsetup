
alter table ua_bundle_location add column created_from int(11) default null;

alter table ua_bundle_person add column created_from int(11) default null;

alter table ua_bundle add column created_from int(11) default null;

alter table rpm add column created_from int(11) default null;

alter table attachment add column created_from int(11) default null;

alter table calibration add column created_from int(11) default null;

alter table container add column created_from int(11) default null;

alter table instrument add column created_from int(11) default null;

alter table leak_test add column created_from int(11) default null;

alter table material add column created_from int(11) default null;

alter table material_package add column created_from int(11) default null;

alter table person add column created_from int(11) default null;

alter table person_role add column created_from int(11) default null;

alter table training add column created_from int(11) default null;

alter table container_waste_tag add column created_from int(11) default null;
