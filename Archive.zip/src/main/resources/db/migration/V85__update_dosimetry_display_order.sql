alter table monitor_type add column display_order integer;

update monitor_type set display_order = 1 where id = 1;
update monitor_type set display_order = 2 where id = 2;
update monitor_type set display_order = 3 where id = 3;
update monitor_type set display_order = 4 where id = 4;
update monitor_type set display_order = 5 where id = 5;
update monitor_type set display_order = 6 where id = 8;
update monitor_type set display_order = 7 where id = 9;
update monitor_type set display_order = 8 where id = 6;
update monitor_type set display_order = 9 where id = 7;
update monitor_type set display_order = 10 where id = 10;
update monitor_type set display_order = 11 where id = 11;
update monitor_type set display_order = 12 where id = 12;
