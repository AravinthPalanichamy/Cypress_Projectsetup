update material set inventory_status_type = 'REQUESTED' where inventory_status_type = 'PENDING' and id > 0;
update material set inventory_status_type = 'IN_LOCAL_WASTE' where inventory_status_type = 'IN_LOCAL_WASTE_CONTAINER' and id > 0;
update material set inventory_status_type = 'SHIPPED' where inventory_status_type = 'OFF_SITE' and id > 0;
