--Licence Line Number, UCD UPDATE ----

INSERT INTO `use_purpose` VALUES (29, 'Clinical');
INSERT INTO `use_purpose` VALUES (30, 'Marker and calibration sources');
INSERT INTO `use_purpose` VALUES (31, 'Blood  Irradiator');


--Map  Clinical use purpose to  -> 6.A, 6.B, 6.C, 6.D.2, 6.E.1, 6.E.2, 6.E.3 ,6.E.4 ----
UPDATE `license_line_number` set use_purpose_id = 29 where license_line_number_id = 328;
UPDATE `license_line_number` set use_purpose_id = 29 where license_line_number_id = 330;
UPDATE `license_line_number` set use_purpose_id = 29 where license_line_number_id = 332;
UPDATE `license_line_number` set use_purpose_id = 29 where license_line_number_id = 333;
UPDATE `license_line_number` set use_purpose_id = 29 where license_line_number_id = 334;
UPDATE `license_line_number` set use_purpose_id = 29 where license_line_number_id = 335;
UPDATE `license_line_number` set use_purpose_id = 29 where license_line_number_id = 336;

--Map Marker and calibration sources Use purpose to -> 6.F.1 & 6.F.2 ---
UPDATE `license_line_number` set use_purpose_id = 30 where license_line_number_id = 301;
UPDATE `license_line_number` set use_purpose_id = 30 where license_line_number_id = 302;

---6.T -> Research and Development USe Purpose---
UPDATE `license_line_number` set use_purpose_id = 17 where license_line_number_id = 321;

----6.V mapped to -> Blood Irradiator--
UPDATE `license_line_number` set use_purpose_id = 31 where license_line_number_id = 323;

----6.W mapped to -> Research irradiator--
UPDATE `license_line_number` set use_purpose_id = 28 where license_line_number_id = 324;


UPDATE `license_line_number` set description = 'Total 370 GBq (10 Ci), activated cyclotron component' where license_line_number_id = 314;
