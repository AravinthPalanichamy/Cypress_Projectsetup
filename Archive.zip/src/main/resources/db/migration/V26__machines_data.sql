CREATE TABLE machine (
  machine_id            INTEGER AUTO_INCREMENT,
  type                  VARCHAR(100),
  model                 VARCHAR(100),
  manufacturer          VARCHAR(100),
  cdph_use_code         VARCHAR(100),
  cdph_number           VARCHAR(100),
  number_of_tubes       INTEGER,
  serial_number         VARCHAR(100),
  max_ma                VARCHAR(100),
  max_kvp               VARCHAR(100),
  norm_ma               VARCHAR(100),
  norm_kvp              VARCHAR(100),
  PRIMARY KEY (machine_id)
);

CREATE TABLE machine_planned_work (
  machine_pw_id                    INTEGER AUTO_INCREMENT,
  machine_id                       INTEGER   NOT NULL,
  ua_id                            INTEGER   NOT NULL,
  purpose_type                     VARCHAR(100),
  created_from                     INTEGER,
  description_of_use               VARCHAR(3000),
  potential_hazards                VARCHAR(3000),
  protection_precautions           VARCHAR(3000),
  location_id                      INTEGER,
  PRIMARY KEY (machine_pw_id)
);

ALTER TABLE machine_planned_work
ADD CONSTRAINT FK_MacPW_Mac
FOREIGN KEY (machine_id)
REFERENCES machine (machine_id);

ALTER TABLE machine_planned_work
ADD CONSTRAINT FK_MacPW_Ua
FOREIGN KEY (ua_id)
REFERENCES ua (id);

ALTER TABLE machine_planned_work
ADD CONSTRAINT FK_MacPW_Loc
FOREIGN KEY (location_id)
REFERENCES location (id);

CREATE TABLE control_unit (
  control_unit_id          INTEGER AUTO_INCREMENT,
  manufacturer             VARCHAR(100),
  model                    VARCHAR(100),
  serial_number            VARCHAR(100),
  machine_id               INTEGER   NOT NULL,
  inventory_number         VARCHAR(100),
  PRIMARY KEY (control_unit_id)
);

ALTER TABLE control_unit
ADD CONSTRAINT FK_CU_Mac
FOREIGN KEY (machine_id)
REFERENCES machine (machine_id);

