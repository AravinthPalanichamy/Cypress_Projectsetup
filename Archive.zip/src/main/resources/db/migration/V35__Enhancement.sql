ALTER TABLE person ADD COLUMN `user_id` VARCHAR(1000) NOT NULL DEFAULT 'USERID';
ALTER TABLE location ADD COLUMN  `room_id` VARCHAR(1000) NOT NULL DEFAULT 'ROOMID';

ALTER TABLE ua ADD COLUMN `frequency_id` INTEGER NOT NULL DEFAULT 4;

CREATE TABLE `survey` (
  	id 				INTEGER 	AUTO_INCREMENT,
   	ua_id 			INTEGER 	NOT NULL,
   	survey_type 	VARCHAR(25) DEFAULT NULL,
   	assigned_to 	INTEGER 	DEFAULT NULL,
   	performed_by 	INTEGER 	DEFAULT NULL,
   	performed_date      DATETIME   	DEFAULT NULL,
   	due_date      DATETIME   	DEFAULT NULL,
   	status_type      VARCHAR(25)     DEFAULT NULL,
   	text LONGTEXT DEFAULT NULL,
   	comment LONGTEXT DEFAULT NULL,
   PRIMARY KEY (`id`),
   KEY `FK_UA_idx` (`ua_id`),
   KEY `FK_Person_assigned_to` (`assigned_to`),
   KEY `FK_Person_performed_by` (`performed_by`),
   CONSTRAINT `FK_Person_assigned_to` FOREIGN KEY (`assigned_to`) REFERENCES `person` (`id`),
   CONSTRAINT `FK_Person_performed_by` FOREIGN KEY (`performed_by`) REFERENCES `person` (`id`),
   CONSTRAINT `FK_UA` FOREIGN KEY (`ua_id`) REFERENCES `ua` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `frequency` (`frequency_id`, `frequency_name`, `time_in_days`) VALUES (4, 'Monthly', 30);

ALTER TABLE ua
ADD CONSTRAINT FK_Frequency
FOREIGN KEY (frequency_id)
REFERENCES frequency (frequency_id);
