--UC Davis
UPDATE `license_line_number` SET `campus_limit`='1', `campus_limit_unit_id`='6' WHERE `license_line_number_id`='309';

-- UCSB
UPDATE `license_line_number` SET `campus_limit`='250', `campus_limit_unit_id`='5' WHERE `license_line_number_id`='805';
UPDATE `license_line_number` SET `campus_limit`='10', `campus_limit_unit_id`='4' WHERE `license_line_number_id`='806';

--UCI
UPDATE `license_line_number` SET `include_special_nuclear_material`='1' WHERE `license_line_number_id`='907';

--UCLA
UPDATE `license_line_number` SET `campus_limit`='100', `campus_limit_unit_id`='8' WHERE `license_line_number_id`='413';
UPDATE `license_line_number` SET `description`='Total not to exceed 34 mCi(100 kg)' WHERE `license_line_number_id`='413';
UPDATE `license_line_number` SET `description`='Total not to exceed 310 mCi(5 g)', `campus_limit`='5', `campus_limit_unit_id`='4' WHERE `license_line_number_id`='414';

-- UCSC
UPDATE `license_line_number` SET `include_special_nuclear_material`='1' WHERE `license_line_number_id`='705';
UPDATE `license_line_number` SET `include_source_material`='1' WHERE `license_line_number_id`='706';

-- Data Fix for the records that were accidentally created by Wolf lab people when mike gave a demo on March 7, 2016
UPDATE `ua` SET `is_active`=FALSE WHERE `number` = '1563';
UPDATE `ua` SET `is_active`=FALSE WHERE `number` = '1564';

-- Data Fix for the record that Gerry created March 5, 2016 -- ticket no INC0034063
UPDATE `ua` SET `number`='1556' WHERE `number` = '1565';

-- PlannedWork changes

-- Add units for UA Planned Work for BI Team
ALTER TABLE `ua_planned_work` ADD COLUMN `unit` INTEGER;

ALTER TABLE ua_planned_work
ADD CONSTRAINT FK_UPW_RadioActivityUnit
FOREIGN KEY (unit)
REFERENCES radioactivity_unit (unit_id);

-- Updating units on existing plannedwork
-- adding MCI as unit for non-snm and source plannedwork
UPDATE ua_planned_work uap, radionuclide r SET uap.unit = 1 WHERE uap.radionuclide_id = r.radionuclide_id AND r.is_source_material = 0 AND r.is_special_nuclear_material = 0;
UPDATE ua_planned_work uap, radionuclide r SET uap.unit = 4 WHERE uap.radionuclide_id = r.radionuclide_id AND (r.is_source_material = 1 OR r.is_special_nuclear_material = 1);

ALTER TABLE `ua_planned_work` MODIFY COLUMN `unit` INTEGER NOT NULL;







