UPDATE `ua` SET `status_type`='PENDING_REVIEW' WHERE `id`='105';
UPDATE `ua` SET `status_type`='PENDING_REVIEW', `created_from`='2' WHERE `id`='106';
UPDATE `ua` SET `status_type`='PENDING_REVIEW' WHERE `id`='107';