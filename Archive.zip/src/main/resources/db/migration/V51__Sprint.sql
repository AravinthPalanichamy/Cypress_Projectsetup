DELETE FROM person_role WHERE person_role_id='914';

ALTER TABLE `ua`
CHANGE COLUMN `amendment_number` `amendment_number` INT(11) NULL DEFAULT null ;

ALTER TABLE  `ua`
ADD COLUMN `summary_of_changes` VARCHAR(1000) NULL DEFAULT NULL;

ALTER TABLE  `ua`
ADD COLUMN `amendment_submitted` TINYINT(1) NULL DEFAULT 0;
ALTER TABLE ua ADD COLUMN `special_request` VARCHAR (1000) DEFAULT NULL;

ALTER TABLE material_use ADD COLUMN radionuclide_material_id int(11) default null;