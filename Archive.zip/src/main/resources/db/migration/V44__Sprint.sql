Alter table ua_person_dosimetry add COLUMN `otherDosimetry` VARCHAR (50);

ALTER TABLE radionuclide_material ADD COLUMN `current_volume` DECIMAL(12,5);

update radionuclide_material m set m.current_volume = m.initial_volume where initial_volume is not null and material_id is not null;

ALTER TABLE `rpm`
  CHANGE COLUMN `active` `active` TINYINT(1) NOT NULL DEFAULT 1 ,
  CHANGE COLUMN `on_license` `on_license` TINYINT(1) NULL DEFAULT 0 ;

-- RPM Attachment
CREATE TABLE rpm_attachment (
  rpm_id       INTEGER NOT NULL,
  attachment_id      INTEGER NOT NULL,
  PRIMARY KEY (rpm_id, attachment_id)
);

ALTER TABLE rpm_attachment
  ADD CONSTRAINT UK_AttachmentId_RpmId UNIQUE (attachment_id);

ALTER TABLE rpm_attachment
  ADD CONSTRAINT FK_rpm_attachment_attachmentId FOREIGN KEY (attachment_id)
REFERENCES attachment (attachment_id);

ALTER TABLE rpm_attachment
  ADD CONSTRAINT FK_rpm_attachment_rpmId FOREIGN KEY (rpm_id)
REFERENCES rpm (id);

-- Berkeley Radiation Training
INSERT INTO `training`
(`id`, `campus_code`, `classification_name`, `source_system_id`, `source_system_name`, `activity_code`, `activity_name`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `active`)
VALUES
  (32,'01','Radiation',2,'LMS','BEEHS EHS 405 172111.202pm','EHS 405 Radiation Producing Machine Practical Training','2017-12-04 00:00:00','2017-12-04 00:00:00',1,1,1),
  (33,'01','Radiation',2,'LMS','BEEHS EHS 406 172111.217pm','EHS 406 Soil Moisture Density Gauge Training','2017-12-04 00:00:00','2017-12-04 00:00:00',1,1,1);


-- Person Attachment
CREATE TABLE person_attachment (
  person_id       INTEGER NOT NULL,
  attachment_id      INTEGER NOT NULL,
  PRIMARY KEY (person_id, attachment_id)
);

ALTER TABLE person_attachment
  ADD CONSTRAINT UK_AttachmentId_PersonId UNIQUE (attachment_id);

ALTER TABLE person_attachment
  ADD CONSTRAINT FK_person_attachment_attachmentId FOREIGN KEY (attachment_id)
REFERENCES attachment (attachment_id);

ALTER TABLE person_attachment
  ADD CONSTRAINT FK_person_attachment_personId FOREIGN KEY (person_id)
REFERENCES person (id);

 -- for waste container
ALTER TABLE container ADD COLUMN `waste_tagged` tinyint(1) DEFAULT '0';
ALTER TABLE container ADD COLUMN `current_waste_tag_id` INTEGER DEFAULT NULL;
ALTER TABLE container ADD COLUMN `owner_rua_id` INTEGER NOT NULL;

ALTER TABLE radionuclide_material DROP COLUMN request_user_comments;
ALTER TABLE radionuclide_material DROP COLUMN request_rst_comments;
ALTER TABLE material ADD COLUMN user_comments VARCHAR (250);
ALTER TABLE material ADD COLUMN rst_comments VARCHAR (250);

ALTER TABLE material_use
ADD COLUMN waste_tag_id int(11) DEFAULT NULL AFTER container_id,
ADD CONSTRAINT FK_MaterialUse_WasteTag FOREIGN KEY (waste_tag_id)
REFERENCES container_waste_tag (waste_tag_id);

ALTER TABLE container_waste_tag
ADD COLUMN `waste_tag_status`  varchar(50) DEFAULT NULL,
ADD COLUMN `picked_up_date` datetime DEFAULT NULL;

Update `monitor_type` set `type` = 'Other', `name` = 'Other' where id=12;