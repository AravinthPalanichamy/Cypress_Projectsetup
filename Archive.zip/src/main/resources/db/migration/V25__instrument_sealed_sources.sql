-- Adding inner contamination test fields to material order table
-- consider moving to test_result table
ALTER TABLE material_order ADD COLUMN `contamination_result` DECIMAL(12,5);

-- Not adding a NOT NULL constraint here as existing records throw an error
ALTER TABLE material_order ADD COLUMN `contamination_free` BOOLEAN NULL DEFAULT TRUE;

INSERT INTO `test_type` (`test_type_id`, `test_name`) VALUES (4, 'Calibration Test');

ALTER TABLE `inventory_package` MODIFY COLUMN `pr_swipe_con_free` BOOLEAN NULL;

-- Test Frequency
CREATE TABLE frequency (
    frequency_id               INTEGER     AUTO_INCREMENT,
    frequency_name             VARCHAR(20) NOT NULL,
    time_in_days               INTEGER     NOT NULL,
    PRIMARY KEY (frequency_id)
);

INSERT INTO `frequency` (`frequency_id`, `frequency_name`, `time_in_days`) VALUES (1, 'Quarterly', 90);
INSERT INTO `frequency` (`frequency_id`, `frequency_name`, `time_in_days`) VALUES (2, 'Semi-Annually', 180);
INSERT INTO `frequency` (`frequency_id`, `frequency_name`, `time_in_days`) VALUES (3, 'Annually', 365);

-- Meter Scale
CREATE TABLE meter_scale (
    id               INTEGER     AUTO_INCREMENT,
    scale_unit       VARCHAR(20) NOT NULL,
    PRIMARY KEY (id)
);

INSERT INTO `meter_scale` (`id`, `scale_unit`) VALUES (1, 'CPM');
INSERT INTO `meter_scale` (`id`, `scale_unit`) VALUES (2, 'CPS');
INSERT INTO `meter_scale` (`id`, `scale_unit`) VALUES (3, 'Dual');
INSERT INTO `meter_scale` (`id`, `scale_unit`) VALUES (4, 'mR/hr');

-- Add sealed source table
CREATE TABLE sealed_source_info (
    ss_info_id                      INTEGER       AUTO_INCREMENT,
    ss_device_registry              VARCHAR(20),
    ss_serial_number                VARCHAR(50),
    test_frequency_id               INTEGER       NOT NULL,
    test_due_date                   DATETIME      NOT NULL,
    assigned_to                     INTEGER,
    created_date                    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by                      INTEGER       NOT NULL,
    last_modified_date              TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_modified_by                INTEGER       NOT NULL,
    PRIMARY KEY (ss_info_id)
);

ALTER TABLE sealed_source_info
ADD CONSTRAINT FK_SealedSourceInfo_Person_Assigned
FOREIGN KEY (assigned_to)
REFERENCES person (id);

ALTER TABLE sealed_source_info
ADD CONSTRAINT FK_SealedSourceInfo_Person_LM
FOREIGN KEY (last_modified_by)
REFERENCES person (id);

ALTER TABLE sealed_source_info
ADD CONSTRAINT FK_SealedSourceInfo_Person_Created
FOREIGN KEY (created_by)
REFERENCES person (id);

ALTER TABLE sealed_source_info
ADD CONSTRAINT FK_SealedSourceInfo_Frequency
FOREIGN KEY (test_frequency_id)
REFERENCES frequency (frequency_id);

-- Add Sealed source to material order
ALTER TABLE material_order ADD COLUMN `ss_info_id` INTEGER;

ALTER TABLE material_order
ADD CONSTRAINT FK_MaterialOrder_SealedSourceInfo
FOREIGN KEY (ss_info_id)
REFERENCES person (id);

-- Instrument table
CREATE TABLE instrument (
    instrument_id             INTEGER           AUTO_INCREMENT,
    ua_id                     INTEGER           NOT NULL,
    manufacturer              VARCHAR(100)      NOT NULL,
    model                     VARCHAR(50)       NOT NULL,
    serial_number             VARCHAR(50),
    detector_type             VARCHAR(50)       NOT NULL,
    meter_scale_id            INTEGER           NOT NULL,
    calibration_frequency_id  INTEGER           NOT NULL,
    calibration_due_date      DATETIME          NOT NULL,
    assigned_to               INTEGER,
    created_by                INTEGER           NOT NULL,
    created_date              TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_modified_by          INTEGER           NOT NULL,
    last_modified_date        TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (instrument_id)
);

ALTER TABLE instrument
ADD CONSTRAINT FK_Instrument_Ua
FOREIGN KEY (ua_id)
REFERENCES ua (id);

ALTER TABLE instrument
ADD CONSTRAINT FK_Instrument_MeterScale
FOREIGN KEY (meter_scale_id)
REFERENCES meter_scale (id);

ALTER TABLE instrument
ADD CONSTRAINT FK_Instrument_Person_Assigned
FOREIGN KEY (assigned_to)
REFERENCES person (id);

ALTER TABLE instrument
ADD CONSTRAINT FK_Instrument_Person_LM
FOREIGN KEY (last_modified_by)
REFERENCES person (id);

ALTER TABLE instrument
ADD CONSTRAINT FK_Instrument_Person_Created
FOREIGN KEY (created_by)
REFERENCES person (id);

ALTER TABLE instrument
ADD CONSTRAINT FK_Instrument_Frequency
FOREIGN KEY (calibration_frequency_id)
REFERENCES frequency (frequency_id);

-- Test Record
CREATE TABLE test_record (
    test_record_id                  INTEGER       AUTO_INCREMENT,
    test_date                       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    tested_by                       INTEGER       NOT NULL,
    test_type_id                    INTEGER       NOT NULL,
    test_result                     DECIMAL(12,5),
    test_result_unit_id             INTEGER,
    test_comment                    VARCHAR(250),
    is_active                       BOOLEAN       NOT NULL DEFAULT TRUE,
    created_date                    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by                      INTEGER       NOT NULL,
    last_modified_date              TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_modified_by                INTEGER       NOT NULL,
    PRIMARY KEY (test_record_id)
);

ALTER TABLE test_record
ADD CONSTRAINT FK_TestRecord_TestType
FOREIGN KEY (test_type_id)
REFERENCES test_type (test_type_id);

ALTER TABLE test_record
ADD CONSTRAINT FK_TestRecord_Person
FOREIGN KEY (tested_by)
REFERENCES person (id);

ALTER TABLE test_record
ADD CONSTRAINT FK_TestRecord_Person_Created
FOREIGN KEY (created_by)
REFERENCES person (id);

ALTER TABLE test_record
ADD CONSTRAINT FK_TestRecord_Person_LM
FOREIGN KEY (last_modified_by)
REFERENCES person (id);

ALTER TABLE test_record
ADD CONSTRAINT FK_TestRecord_RadioactivityUnit
FOREIGN KEY (test_result_unit_id)
REFERENCES radioactivity_unit (unit_id);

-- join table Instrument to Test record
CREATE TABLE instrument_test_record (
    test_record_id                       INTEGER       NOT NULL,
    instrument_id                        INTEGER       NOT NULL,
    PRIMARY KEY (instrument_id, test_record_id)
);

ALTER TABLE instrument_test_record
ADD CONSTRAINT UK_TestRecordId_ITR UNIQUE (test_record_id);

ALTER TABLE instrument_test_record
ADD CONSTRAINT FK_ITR_Instrument
FOREIGN KEY (instrument_id)
REFERENCES instrument (instrument_id);

ALTER TABLE instrument_test_record
ADD CONSTRAINT FK_ITR_TestRecord
FOREIGN KEY (test_record_id)
REFERENCES test_record (test_record_id);

-- join table Sealed source to Test record
CREATE TABLE ss_test_record (
    test_record_id                    INTEGER       NOT NULL,
    ss_info_id                        INTEGER       NOT NULL,
    PRIMARY KEY (ss_info_id, test_record_id)
);

ALTER TABLE ss_test_record
ADD CONSTRAINT UK_TestRecordId_SSTR UNIQUE (test_record_id);

ALTER TABLE ss_test_record
ADD CONSTRAINT FK_SSTR_SSInfo
FOREIGN KEY (ss_info_id)
REFERENCES sealed_source_info (ss_info_id);

ALTER TABLE ss_test_record
ADD CONSTRAINT FK_SSTR_TestRecord
FOREIGN KEY (test_record_id)
REFERENCES test_record (test_record_id);

CREATE TABLE test_record_attachment (
  test_record_id                         INTEGER NOT NULL,
  attachment_id                          INTEGER NOT NULL,
  PRIMARY KEY (test_record_id, attachment_id)
);

ALTER TABLE test_record_attachment
ADD CONSTRAINT UK_AttachmentId_TestAttachment UNIQUE (attachment_id);

ALTER TABLE test_record_attachment
ADD CONSTRAINT FK_TRA_Attachment
FOREIGN KEY (attachment_id)
REFERENCES attachment (attachment_id);

ALTER TABLE test_record_attachment
ADD CONSTRAINT FK_TRA_TestRecord
FOREIGN KEY (test_record_id)
REFERENCES test_record (test_record_id);

-- License ine No Item for At-217 (Sealed Source)
INSERT INTO line_number_item (`line_number_item_id`, `radionuclide_id`, `license_line_number_id`, `is_solid`, `is_liquid`, `is_gas`, `is_powder`, `is_sealed_source`, `is_special_nuclear_material`, `is_source_material`, `elemental_limit`, `elemental_limit_unit_id`) VALUES ('7', '108', '1', '1', '1', '1', '1', '1', '0', '0', NULL, NULL);

-- updated person department data for machines testing
UPDATE `person` SET `department`='ENVIRONMENTAL HEALTH &amp; SAFETY' WHERE `id`='2';
UPDATE `person` SET `department`='BIOLOGY' WHERE `id`='3';

ALTER TABLE test_record ADD COLUMN `is_exact` BOOLEAN NOT NULL DEFAULT TRUE;