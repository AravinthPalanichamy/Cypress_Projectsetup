alter table ua_limit add column enrichment_percent double default null;

ALTER TABLE `ua` ADD COLUMN `entered_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `type`;
UPDATE `ua` SET `status_type` = 'ACTIVE' where id = 100;
UPDATE `ua` SET `entered_date` = `created_date` where `id` <> 0;
