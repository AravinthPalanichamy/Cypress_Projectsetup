CREATE TABLE material_transfer (
  id int(11) NOT NULL AUTO_INCREMENT,
  from_ua_id int(11) NOT NULL,
  to_ua_id int(11),
  material_id int(11) NOT NULL,
  material_transfer_status_type VARCHAR (25) NOT NULL DEFAULT 'PENDING',
  institution_name VARCHAR (250),
  CONSTRAINT FK_MaterialTransfer_FromUa FOREIGN KEY (from_ua_id) REFERENCES ua (id),
  CONSTRAINT FK_MaterialTransfer_ToUa FOREIGN KEY (to_ua_id) REFERENCES ua (id),
  CONSTRAINT FK_MaterialTransfer_Material FOREIGN KEY (material_id) REFERENCES material (id) ,
  PRIMARY KEY (id)
);

alter table material add column parent_material_id int(11) default null;
alter table material add constraint FK_Material_Material foreign key (parent_material_id) references material (id);
