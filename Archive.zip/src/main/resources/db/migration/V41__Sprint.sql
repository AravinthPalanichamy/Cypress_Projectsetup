

--
-- Table structure for table `training`
--

CREATE TABLE `training` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campus_code` varchar(10) NOT NULL,
  `classification_name` varchar(250) NOT NULL,
  `source_system_id` int(11) NOT NULL,
  `source_system_name` varchar(100) DEFAULT NULL,
  `activity_code` varchar(500) DEFAULT NULL,
  `activity_name` varchar(1000) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `last_modified_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_training_campus` (`campus_code`),
  KEY `FK_training_created_by` (`created_by`),
  KEY `FK_training_last_modified_by` (`last_modified_by`),
  CONSTRAINT `FK_training_campus` FOREIGN KEY (`campus_code`) REFERENCES `campus` (`code`),
  CONSTRAINT `FK_training_created_by` FOREIGN KEY (`created_by`) REFERENCES `person` (`id`),
  CONSTRAINT `FK_training_last_modified_by` FOREIGN KEY (`last_modified_by`) REFERENCES `person` (`id`)
);

--
-- Dumping data for table `training`
--
INSERT INTO `training`
(`id`, `campus_code`, `classification_name`, `source_system_id`, `source_system_name`, `activity_code`, `activity_name`, `created_date`, `last_modified_date`, `created_by`, `last_modified_by`, `active`)
VALUES
(1,'01','Radiation',2,'LMS','242821','EHS 401.1 Radiation Safety Training for Radioactive Materials Users','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(2,'01','Radiation',2,'LMS','242811','EHS 401.2 Radiation Safety Retraining: Radiation Producing Machines','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(3,'01','Radiation',2,'LMS','242698','EHS 401.3 Radiation Safety Retraining: Radioactive Materials & Radiation Producing Machines','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(4,'01','Radiation',2,'LMS','252843','EHS 402.1 Refresher Radiation Safety Training for Radioactive Materials Users','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(5,'01','Radiation',2,'LMS','252070','EHS 402.2 Refresher Radiation Safety Retraining: Radiation Producing Machines','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(6,'01','Radiation',2,'LMS','252844','EHS 402.3 Refresher Radiation Safety Retraining: Radioactive Materials & Radiation Producing Machines','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(7,'02','Radiation',2,'LMS','SFCEHS0031','Radiation Safety Training','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(8,'02','Radiation',2,'LMS','SFCEHS0086','Clinical Radiation Safety Refresher','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(9,'02','Radiation',2,'LMS','SFCEHS0086','Clinical Radiation Safety Refresher (7/5/2012-7/13/2012)','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(10,'02','Radiation',2,'LMS','SFCEHS0086','Session 1','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(11,'02','Radiation',2,'LMS','SFCEHS0125','Irradiator Radiation Safety Training Blood Bank','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(12,'02','Radiation',2,'LMS','SFCEHS0125','Irradiator Radiation Safety Training Blood Bank (9/20/2012-9/28/2012)','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(13,'02','Radiation',2,'LMS','SFCEHS0125','Session 1','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(14,'05','Radiation',2,'LMS','RI-ESILT0011','Radiation Safety: Initial','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(15,'05','Radiation',2,'LMS','RI-ESTOP0048','Radiation Safety Refresher','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(16,'07','Radiation',2,'LMS','SC-EHS-RAD0088-ECO','Radioisotope Laboratory Safety - Initial','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(17,'07','Radiation',2,'LMS','SC-EHS-RAD0212-ECO','Radioisotope Laboratory Safety - Refresher','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(18,'07','Radiation',2,'LMS','SC-EHS-RSL-ILT','Radiation Safety Lecture','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(19,'10','Radiation',2,'LMS','ME-EHS-EC-RADSAFE-02-00-0312','Radiation Producing Machines','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(20,'10','Radiation',2,'LMS','ME-EHS-IL-RADSAFE-01-00-0810','Radiation Safety (Materials)','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(21,'10','Radiation',2,'LMS','ME-EHS-RADI-021510','Radiation Safety Training (Materials)','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(22,'10','Radiation',2,'LMS','ME-EHS-RADSAF-06','Radioactive Materials','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(23,'10','Radiation',2,'LMS','ME-EHS-UCLOL0022-ECO','Radiation Safety For Users of Radioactive Materials and Radiation Producing Machines','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(24,'02','Radiation',2,'LMS','DAC-XRAY-Q-SAFSVC','Analytical X-Ray Quiz','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(25,'02','Radiation',2,'LMS','DAC-DIAG-XRAY-Q-SAFSVC','Diagnostic X-Ray Quiz','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(26,'02','Radiation',2,'LMS','DAC-HYDRO-Q-SAFSVC','Hydroprobe Quiz','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(27,'02','Radiation',2,'LMS','DACS-HYDROPROBE-SAFSVC','Hydroprobe Safety','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(28,'03','Radiation',2,'LMS','DAC-RAD-Q-SAFSVC','Radiation Quiz','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(29,'03','Radiation',2,'LMS','DACS-UCLOL0020-ECO-SAFSVC','Radiation Safety For Users of Radiation Producing Machines','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(30,'03','Radiation',2,'LMS','DACS-UCLOL0021-ECO-SAFSVC','Radiation Safety For Users of Radioactive Materials','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1),
(31,'03','Radiation',2,'LMS','DACS-UCLOL0022-ECO-SAFSVC','Radiation Safety For Users of Radioactive Materials and Radiation Producing Machines','2017-10-26 00:00:00','2017-10-26 00:00:00',1,1,1);


ALTER TABLE material ADD COLUMN `is_material_for_test` tinyint(1) NOT NULL DEFAULT '0';

RENAME TABLE test_record TO material_test;

ALTER TABLE material_test ADD COLUMN material_id INT(11) NULL AFTER test_record_id;

ALTER TABLE material_test ADD CONSTRAINT FK_MATERIAL_ID FOREIGN KEY (material_id) REFERENCES material (id);

ALTER TABLE material_test ADD COLUMN material_comment VARCHAR(250);

ALTER TABLE material ADD COLUMN inventory_status_type VARCHAR (25) NOT NULL;
ALTER TABLE material ADD COLUMN current_amount DECIMAL (19,2);
ALTER TABLE material ADD COLUMN current_volume DECIMAL (19,2);
ALTER TABLE material ADD COLUMN current_elemental_mass DECIMAL(19,2);
ALTER TABLE material ADD COLUMN current_sample_net_mass DECIMAL(19,2);

CREATE TABLE `material_use` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `process_name` VARCHAR (250),
  `use_amount` DECIMAL(19,5),
  `use_volume` DECIMAL(19,5),
  `use_elemental_mass` DECIMAL(19,5),
  `use_net_mass` DECIMAL(19.5),
  `container_id` int(11) DEFAULT NULL,
  `material_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_MaterialUse_Container` (`container_id`),
  KEY `FK_MaterialUse_Material` (`material_id`),
  CONSTRAINT `FK_MaterialUse_Material` FOREIGN KEY (`material_id`) REFERENCES `material` (`id`),
  CONSTRAINT `FK_MaterialUse_Container` FOREIGN KEY (`container_id`) REFERENCES `container` (`container_id`)
);

ALTER TABLE container DROP COLUMN container_amount_mci;
ALTER TABLE container DROP COLUMN container_volume_ul;
ALTER TABLE container DROP COLUMN container_elemental_mass;
ALTER TABLE container DROP COLUMN container_sample_net_mass;

ALTER TABLE container
    ADD COLUMN `location_id` int DEFAULT NULL,
    ADD CONSTRAINT `FK_Container_Location` FOREIGN KEY (`location_id`) REFERENCES Location(`id`)
;

ALTER TABLE location
    ADD COLUMN  `building_id` VARCHAR(200) NOT NULL DEFAULT 'BUILDING_ID';



ALTER TABLE material_test
DROP FOREIGN KEY FK_TestRecord_TestType,
DROP FOREIGN KEY FK_TestRecord_RadioactivityUnit;

ALTER TABLE material_test
CHANGE COLUMN test_type_id test_type_id INT(11) DEFAULT 2 ,
CHANGE COLUMN test_result test_result VARCHAR(25) NULL DEFAULT NULL ,
DROP INDEX FK_TestRecord_RadioactivityUnit ;

ALTER TABLE material_test
ADD CONSTRAINT FK_TestRecord_TestType
  FOREIGN KEY (test_type_id)
  REFERENCES test_type (test_type_id);

ALTER TABLE material ADD COLUMN ss_group_id INT(11) DEFAULT 0 ;


/*Monitor Type*/
INSERT INTO monitor_type (id, type, name, description) VALUES (12, 'Dosimetry', 'other', null);


/*UaBundlePerson*/
ALTER TABLE ua_bundle_person ADD COLUMN `date_removed` datetime DEFAULT NULL;
ALTER TABLE ua_bundle_person ADD COLUMN `added_to_rua` tinyint(1) DEFAULT 0;
ALTER TABLE ua_bundle_person ADD COLUMN `active` tinyint(1) DEFAULT 1;


/*Ua Table*/
UPDATE ua set status_type = 'ACTIVE' where status_type = 'APPROVED';