--rua_assessment_factor--

UPDATE rua_assessment_factor SET assessment_factor = 5 WHERE id = 4;

INSERT INTO rua_assessment_factor(id, laboratory_status, compliance, assessment_factor)
VALUES (5, 'Below Average Laboratory', 'Below Average', 2);


-- Alter People
ALTER TABLE Person DROP COLUMN nrccbc_completed;
