 -- backfill data for wastetags
UPDATE container_waste_tag
SET waste_tag_status = 'STARTED'
WHERE tracking_number IS NOT NULL AND request_pick_up_date IS NULL;

 -- updating comment to be more than 250
ALTER TABLE material MODIFY user_comments TEXT;
ALTER TABLE material MODIFY rst_comments TEXT;

ALTER TABLE use_purpose
ADD COLUMN campus_code INT(11) NULL COMMENT 'Null means applicable to all campuses' AFTER use_purpose_name;

ALTER TABLE use_purpose
ADD INDEX FK_CAMPUS_CODE_idx (campus_code ASC);
ALTER TABLE use_purpose
ADD CONSTRAINT FK_CAMPUS_CODE
  FOREIGN KEY (campus_code)
  REFERENCES campus (id)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO use_purpose (use_purpose_id, use_purpose_name, campus_code) VALUES ('8', 'SS&D CA0208D104S', '01');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name, campus_code) VALUES ('9', 'TRIGA reactor', '01');
UPDATE use_purpose SET use_purpose_name='Sub-critical Assembly', campus_code='01' WHERE use_purpose_id='7';
UPDATE use_purpose SET use_purpose_name='SS&D NC646D130S', campus_code='01' WHERE use_purpose_id='6';
UPDATE use_purpose SET use_purpose_name='SS&D NR0880D8022', campus_code='01' WHERE use_purpose_id='5';
UPDATE use_purpose SET use_purpose_name='SS&D CA598D103U', campus_code='01' WHERE use_purpose_id='4';
UPDATE use_purpose SET use_purpose_name='Veterinary' WHERE use_purpose_id='3';
UPDATE use_purpose SET use_purpose_name='Medical' WHERE use_purpose_id='2';

UPDATE license_line_number SET use_purpose_id='4' WHERE license_line_number_id='109';
UPDATE license_line_number SET use_purpose_id='5' WHERE license_line_number_id='110';
UPDATE license_line_number SET use_purpose_id='6' WHERE license_line_number_id='111';
UPDATE license_line_number SET use_purpose_id='7' WHERE license_line_number_id='112';
UPDATE license_line_number SET use_purpose_id='8' WHERE license_line_number_id='113';
UPDATE license_line_number SET use_purpose_id='8' WHERE license_line_number_id='115';
UPDATE license_line_number SET use_purpose_id='9' WHERE license_line_number_id='114';

ALTER TABLE ua_limit
CHANGE COLUMN purpose_type use_purpose INT(11) NULL DEFAULT NULL;

ALTER TABLE ua_limit
ADD CONSTRAINT FK_UaLimit_UsePurpose
  FOREIGN KEY (use_purpose)
  REFERENCES use_purpose (use_purpose_id)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE material_use ADD COLUMN return_value_to_material_use_id int(11) DEFAULT NULL;


-- core_collection
CREATE TABLE core_collection (
  id       INTEGER NOT NULL AUTO_INCREMENT,
  collection_id      VARCHAR (255) NOT NULL,
  collection_name      VARCHAR (255) NOT NULL,
  PRIMARY KEY (id)
);

ALTER TABLE ua
ADD COLUMN `core_collection_id` int(11)  DEFAULT null;

alter table ua
    add constraint FK_Core_Collection
    foreign key (core_collection_id)
    references core_collection (id);

 -- HGV calculation data points

CREATE TABLE `hgv_range` (
`hgv_range_id` double NOT NULL AUTO_INCREMENT,
`hazard_class` varchar(100) NOT NULL,
`floor_value` double NOT NULL,
`ceiling_value` double NOT NULL,
`campus_code` varchar(3) DEFAULT NULL,
PRIMARY KEY(`hgv_range_id`),
 KEY `FK_HgvRange_campus` (`campus_code`),
 CONSTRAINT `FK_HgvRange_campus` FOREIGN KEY (`campus_code`) REFERENCES `campus` (`code`)
);

CREATE TABLE `rua_assessment_factor` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`laboratory_status` varchar(100) NOT NULL,
`compliance` varchar(100) NOT NULL,
`assessment_factor` double NOT NULL,
PRIMARY KEY (`id`)
);


INSERT INTO `rua_assessment_factor`
(
	`laboratory_status`,
	`compliance`,
	`assessment_factor`)
VALUES
('Outstanding Laboratory',
	'No issues',
	0.1);

INSERT INTO `rua_assessment_factor`
(
	`laboratory_status`,
	`compliance`,
	`assessment_factor`)
VALUES
('Good Laboratory',
	'Minor issues',
	0.5);

INSERT INTO `rua_assessment_factor`
(
	`laboratory_status`,
	`compliance`,
	`assessment_factor`)
VALUES
('Average Laboratory',
	'Average',
	1.0);

    INSERT INTO `rua_assessment_factor`
(
	`laboratory_status`,
	`compliance`,
	`assessment_factor`)
VALUES
('Poor Laboratory',
	'Poor performance',
	1.5);

ALTER TABLE ua
ADD COLUMN `hgv_value` double DEFAULT NULL,
ADD COLUMN `assessment_factor_id` int(11) DEFAULT 3,
ADD CONSTRAINT `FK_Ua_AssessmentFactor` FOREIGN KEY (`assessment_factor_id`)
REFERENCES `rua_assessment_factor` (`id`);

 -- END --- HGV calculation data points

-- person --
ALTER TABLE person ADD  COLUMN `exceptionalRua` TINYINT(1) NOT NULL DEFAULT '0' AFTER `has_statement_experience`;
ALTER TABLE material ADD COLUMN is_backfill TINYINT(1) NOT NULL DEFAULT 0;

UPDATE license_line_number SET limit_contained=null, limit_contained_unit_id=null WHERE license_line_number_id='109';
UPDATE license_line_number SET limit_contained=null, limit_contained_unit_id=null WHERE license_line_number_id='110';
UPDATE license_line_number SET elemental_limit=null, limit_contained=null, limit_contained_unit_id=null, elemental_limit_unit_id=null WHERE license_line_number_id='111';
UPDATE license_line_number SET elemental_limit=null, limit_contained=null, limit_contained_unit_id=null, elemental_limit_unit_id=null WHERE license_line_number_id='113';

ALTER TABLE use_purpose
DROP FOREIGN KEY FK_CAMPUS_CODE;
ALTER TABLE use_purpose
CHANGE COLUMN use_purpose_name use_purpose_name VARCHAR(255) NOT NULL,
DROP COLUMN campus_code,
DROP INDEX FK_CAMPUS_CODE_idx ;

ALTER TABLE ua_limit
DROP COLUMN enrichment_percent,
ADD COLUMN contained_exp_limit DOUBLE NULL DEFAULT NULL AFTER active,
ADD COLUMN contailed_vial_limit DOUBLE NULL DEFAULT NULL AFTER contained_exp_limit,
ADD COLUMN contained_poss_limit DOUBLE NULL DEFAULT NULL AFTER contailed_vial_limit;

SET SQL_SAFE_UPDATES = 0;
update line_number_item set elemental_limit = null, elemental_limit_unit_id = null;


UPDATE
	license l,
  license_line_number lln,
	line_number_item lni
SET
	lni.elemental_limit = lln.limit_contained,
	lni.elemental_limit_unit_id = lln.limit_contained_unit_id
WHERE
  l.license_id = lln.license_id and
	lln.license_line_number_id = lni.license_line_number_id and
	lln.limit_contained is not null;
SET SQL_SAFE_UPDATES = 1;

ALTER TABLE license_line_number
DROP FOREIGN KEY FK_LicenseLineNumber_RadioActivityUnit;
ALTER TABLE license_line_number
DROP COLUMN limit_contained,
DROP COLUMN limit_contained_unit_id,
ADD COLUMN contained_limit DOUBLE NULL DEFAULT NULL AFTER campus_limit_unit_id,
ADD COLUMN contained_limit_unit_id INT(11) NULL DEFAULT NULL AFTER contained_limit;
ALTER TABLE license_line_number
ADD CONSTRAINT FK_ContainedLimitUnit_RadioActivityUnit
  FOREIGN KEY (contained_limit_unit_id)
  REFERENCES radioactivity_unit (unit_id);

UPDATE license_line_number SET contained_limit='225', contained_limit_unit_id='4' WHERE license_line_number_id='105';
UPDATE license_line_number SET campus_limit='1', campus_limit_unit_id='3' WHERE license_line_number_id='111';
UPDATE license_line_number SET campus_limit='100' WHERE license_line_number_id='113';
UPDATE license_line_number SET include_special_nuclear_material='0' WHERE license_line_number_id='112';
UPDATE license_line_number SET include_special_nuclear_material='0', include_source_material='0' WHERE license_line_number_id='115';
ALTER TABLE license_line_number
DROP FOREIGN KEY FK_LicenseLineNumber_ElementalRadioActivityUnit;
ALTER TABLE license_line_number
DROP COLUMN elemental_limit_unit_id,
DROP COLUMN elemental_limit,
DROP INDEX FK_LicenseLineNumber_ElementalRadioActivityUnit ;


UPDATE line_number_item SET elemental_limit='100', elemental_limit_unit_id='1' WHERE line_number_item_id in ('10631', '10632', '10633');
UPDATE line_number_item SET elemental_limit='10', elemental_limit_unit_id='1' WHERE line_number_item_id='10637';
UPDATE line_number_item SET elemental_limit='50', elemental_limit_unit_id='1' WHERE line_number_item_id in ('10635','10638');

delete from line_number_item where line_number_item_id=31123;
delete from license_line_number where license_line_number_id=327;
UPDATE license_line_number  SET NAME = 'Any radioactive material permitted by 10 CFR 35.100, 35.200 and 35.300', DESCRIPTION = 'Combined possession limit not to exceed 1.3 TBQ (36.3 Ci)', CAMPUS_LIMIT = '36.3', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 328;
UPDATE license_line_number  SET NAME = 'Radioactive material permitted by 10 CFR 35.400 as follows: Any radionuclide with atomic numbers 3-83', DESCRIPTION = 'Total 370 GBQ (10 Ci), no single source to exceed 3.7 GBQ (100 mCi)', CAMPUS_LIMIT = '10', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 329;
UPDATE license_line_number  SET NAME = 'Any radioactive material permitted by 10 CFR 35.500', DESCRIPTION = 'Total 555 GBQ (15 Ci), no single source to exceed 37 GBQ (1 Ci)', CAMPUS_LIMIT = '15', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 330;
UPDATE license_line_number  SET NAME = 'Any radioactive material permitted by 10 CFR 35.600 as follows: Iridium-192', DESCRIPTION = 'Total 740 GBq (20 Ci) in 2 sources. No single source to exceed 444 GBq (12 Ci)', CAMPUS_LIMIT = '20', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 331;
UPDATE license_line_number  SET NAME = 'Any radioactive material permitted by 10 CFR 35.600 as follows: Iridium-192', DESCRIPTION = 'Total 740 GBq (20 Ci) in 2 sources. No single source to exceed 444 GBq (12 Ci)', CAMPUS_LIMIT = '20', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 332;
UPDATE license_line_number  SET NAME = 'Any radioactive material permitted by 10 CFR 35.1000 as follows: Yttrium-90', DESCRIPTION = 'Total 22.2 GBq (600 mCi). Each source vial not to exceed 7 GBq (189 mCi)', CAMPUS_LIMIT = '600', CAMPUS_LIMIT_UNIT_ID = '1' WHERE LICENSE_LINE_NUMBER_ID = 333;
UPDATE license_line_number  SET NAME = 'Any radioactive material permitted by 10 CFR 35.1000 as follows: Yttrium-90', DESCRIPTION = 'Total not to exceed 74 GBq (2 Ci). Each vial not to exceed 20 GBq (540 mCi)', CAMPUS_LIMIT = '2', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 334;
UPDATE license_line_number  SET NAME = 'Any radioactive material permitted by 10 CFR 35.1000 as follows: Cobalt-60', DESCRIPTION = 'Total 370 TBq (10,000 Ci), no single source to exceed 1.3 TBq (36 Ci)', CAMPUS_LIMIT = '10000', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 335;
UPDATE license_line_number  SET NAME = 'Any radioactive material permitted by 10 CFR 35.1000 as follows: Iodine-125', DESCRIPTION = 'Total not to exceed 925 MBq (25 mCi), no single source to exceed 11.1 MBq (0.3 mCi)', CAMPUS_LIMIT = '25', CAMPUS_LIMIT_UNIT_ID = '1' WHERE LICENSE_LINE_NUMBER_ID = 336;
UPDATE license_line_number  SET NAME = 'Any radionuclide with atomic number 3-83, inclusive, except: Strontium-90 and Lead-210', DESCRIPTION = 'Total 185 GBq (5 Ci), no single source to exceed 37 GBq (1 Ci)', CAMPUS_LIMIT = '5', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 301;
UPDATE license_line_number  SET NAME = 'Americium-241', DESCRIPTION = 'Total 555 GBq (15 mCi) in one source', CAMPUS_LIMIT = '15', CAMPUS_LIMIT_UNIT_ID = '1' WHERE LICENSE_LINE_NUMBER_ID = 302;
UPDATE license_line_number  SET NAME = 'Hydrogen-3', DESCRIPTION = 'Total 3.7 TBq (100 Ci)', CAMPUS_LIMIT = '100', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 303;
UPDATE license_line_number  SET NAME = 'Any radionuclide with atomic number 3-83', DESCRIPTION = 'Total 3.7 TBq (100 Ci)', CAMPUS_LIMIT = '100', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 304;
UPDATE license_line_number  SET NAME = 'Any radionuclide with atomic number 3-83', DESCRIPTION = 'Total 1.5 TBq (40 Ci)', CAMPUS_LIMIT = '40', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 305;
UPDATE license_line_number  SET NAME = 'Any radionuclide with atomic number 84-105, except special nuclear material and source material', DESCRIPTION = 'Total 55.5 GBq (1.5 Ci)', CAMPUS_LIMIT = '1.5', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 306;
UPDATE license_line_number  SET NAME = 'Any radionuclide with atomic number 84-105, except special nuclear material and source material', DESCRIPTION = 'Total 37 GBq (1 Ci)', CAMPUS_LIMIT = '1', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 307;
UPDATE license_line_number  SET NAME = 'Source material', DESCRIPTION = 'Total 100 pounds [566.1 MBq (15.3 mCi)]', CAMPUS_LIMIT = '100', CAMPUS_LIMIT_UNIT_ID = '5' WHERE LICENSE_LINE_NUMBER_ID = 308;
UPDATE license_line_number  SET NAME = 'Special nuclear material', DESCRIPTION = 'Total 1 milligram [3.7 MBq (0.1  mCi)]', CAMPUS_LIMIT = '1', CAMPUS_LIMIT_UNIT_ID = '6' WHERE LICENSE_LINE_NUMBER_ID = 309;
UPDATE license_line_number  SET NAME = 'Special nuclear material', DESCRIPTION = 'Total 15 grams [34.4 GBq (931 mCi)]', CAMPUS_LIMIT = '15', CAMPUS_LIMIT_UNIT_ID = '4' WHERE LICENSE_LINE_NUMBER_ID = 310;
UPDATE license_line_number  SET NAME = 'Cesium-137', DESCRIPTION = 'Total 4.8 TBq (131 Ci) in 2 sources', CAMPUS_LIMIT = '131', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 311;
UPDATE license_line_number  SET NAME = 'Cesium-137', DESCRIPTION = '370 TBq (10,000 Ci) in 1 source', CAMPUS_LIMIT = '10000', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 312;
UPDATE license_line_number  SET NAME = 'Cesium-137/Actium-227 or Americium-241 with or without Beryllium', DESCRIPTION = 'Total 259 GBq (7 Ci), no single source to exceed 5.6 GBq (150 mCi)', CAMPUS_LIMIT = '7', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 313;
UPDATE license_line_number  SET NAME = 'Any radionuclide with atomic number 3-83', DESCRIPTION = 'Total 370 GBq (10 Ci)', CAMPUS_LIMIT = '10', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 314;
UPDATE license_line_number  SET NAME = 'Any radionuclide with atomic number 3-83', DESCRIPTION = 'Total not to exceed 555 GBq (15 Ci)', CAMPUS_LIMIT = '15', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 315;
UPDATE license_line_number  SET NAME = 'Carbon-11', DESCRIPTION = 'Total not to exceed 148 GBq (4 Ci)', CAMPUS_LIMIT = '4', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 316;
UPDATE license_line_number  SET NAME = 'Nitrogen-13', DESCRIPTION = 'Total not to exceed 11.1 GBq (300 mCi)', CAMPUS_LIMIT = '300', CAMPUS_LIMIT_UNIT_ID = '1' WHERE LICENSE_LINE_NUMBER_ID = 317;
UPDATE license_line_number  SET NAME = 'Oxygen-15', DESCRIPTION = 'Total not to exceed 148 GBq (4 Ci)', CAMPUS_LIMIT = '4', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 318;
UPDATE license_line_number  SET NAME = 'Fluorine-18', DESCRIPTION = 'Total not to exceed 370 GBq (10 Ci)', CAMPUS_LIMIT = '10', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 319;
UPDATE license_line_number  SET NAME = 'Copper-64', DESCRIPTION = 'Total not to exceed 11.1 GBq (300 mCi)', CAMPUS_LIMIT = '300', CAMPUS_LIMIT_UNIT_ID = '1' WHERE LICENSE_LINE_NUMBER_ID = 320;
UPDATE license_line_number  SET NAME = 'Iridium-192', DESCRIPTION = 'Total 40.7 TBq (20 Ci) in 2 sources, no single source to exceed 370 GBq (10 Ci)', CAMPUS_LIMIT = '20', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 321;
UPDATE license_line_number  SET NAME = 'Cesium-137', DESCRIPTION = 'Total 40.7 TBq (1,100 Ci) in 2 sources', CAMPUS_LIMIT = '1100', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 322;
UPDATE license_line_number  SET NAME = 'Cesium-137', DESCRIPTION = 'Total 112.8 TBq (3,048 Ci) in 2 sources', CAMPUS_LIMIT = '3048', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 323;
UPDATE license_line_number  SET NAME = 'Cesium-137', DESCRIPTION = 'Total 48.8 TBq (1320 Ci) in 1 source', CAMPUS_LIMIT = '1320', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 324;
UPDATE license_line_number  SET NAME = 'Cesium-137', DESCRIPTION = 'Total 29.6 TBq (800 Ci) in 1 source', CAMPUS_LIMIT = '800', CAMPUS_LIMIT_UNIT_ID = '3' WHERE LICENSE_LINE_NUMBER_ID = 325;
UPDATE license_line_number  SET NAME = 'Americium-241', DESCRIPTION = 'Total not to exceed 1.9 GBq (50 mCi) in 1 source', CAMPUS_LIMIT = '50', CAMPUS_LIMIT_UNIT_ID = '1' WHERE LICENSE_LINE_NUMBER_ID = 326;
UPDATE line_number_item SET radionuclide_id='97' WHERE line_number_item_id IN ('31118', '31119');

INSERT INTO line_number_radionuclide_form (line_number_radionuclide_form_id, line_number_radionuclide_form) VALUES ('413', 'Sealed Sources (IsoAid Model IAI-125A)');
INSERT INTO license_line_number (license_line_number_id, line_number, license_id, is_specific, name, description, line_number_radionuclide_form_id, campus_limit, campus_limit_unit_id, include_special_nuclear_material, include_source_material) VALUES ('336', '6.E.4', '3', '1', 'Iodine-125', 'Total not to exceed 925 mbq (25 mCi), no single source to exceed 11.1 MBQ (0.3 mCi)', '413', '25', '3', '0', '0');
INSERT INTO line_number_item (line_number_item_id, radionuclide_id, license_line_number_id, is_solid, is_liquid, is_gas, is_powder, is_sealed_source, is_special_nuclear_material, is_source_material, elemental_limit, elemental_limit_unit_id) VALUES ('32245', '5', '336', '1', '1', '1', '1', '1', '0', '0', '0.3', '1');

UPDATE license_line_number SET name='Carbon-14', description='Total not to exceed 100 mCi' WHERE license_line_number_id='4';
UPDATE license_line_number SET name='Phosphorous-32', description='Total not to exceed 30 mCi' WHERE license_line_number_id='5';
UPDATE license_line_number SET name='Sulphur-35', description='Total not to exceed 10 mCi' WHERE license_line_number_id='6';
UPDATE license_line_number SET name='Calcium-45', description='Total not to exceed 20 mCi' WHERE license_line_number_id='7';
UPDATE license_line_number SET name='Iodine-125', description='Total not to exceed 100 mCi' WHERE license_line_number_id='8';
UPDATE license_line_number SET name='Hydrogen-3', description='Total not to exceed 5 μCi' WHERE license_line_number_id='9';
UPDATE license_line_number SET name='Carbon-14', description='Total not to exceed 5 μCi' WHERE license_line_number_id='10';
UPDATE license_line_number SET name='Polonium-210', description='Total not to exceed 1.2 μCi, each source not exceed 0.1 μCi' WHERE license_line_number_id='11';
UPDATE license_line_number SET name='Strontium-90', description='Total not to exceed 1.2 μCi, each source not exceed 0.1 μCi' WHERE license_line_number_id='12';
UPDATE license_line_number SET name='Thallium-204', description='Total not to exceed 12 μCi, each source not exceed 1 μCi' WHERE license_line_number_id='13';
UPDATE license_line_number SET name='Cobalt-60', description='Total not to exceed 20 μCi, each source not exceed 5 μCi' WHERE license_line_number_id='14';
UPDATE license_line_number SET name='Cesium-137', description='Total not to exceed 60 μCi, each source not exceed 5 μCi' WHERE license_line_number_id='15';
UPDATE license_line_number SET name='Cesium-137/Barium 137m', description='Total not to exceed 60 μCi, each kit not to exceed 10 μCi' WHERE license_line_number_id='16';
UPDATE license_line_number SET name='Fluorine-18', description='Total not to exceed 10 mCi' WHERE license_line_number_id='17';
UPDATE license_line_number SET name='Copper-64', description='Total not to exceed 10 mCi' WHERE license_line_number_id='18';
UPDATE license_line_number SET name='Yttrium-90', description='Total not to exceed 10 mCi' WHERE license_line_number_id='19';
UPDATE license_line_number SET name='Sodium-22', description='Total not to exceed 0.1 mCi' WHERE license_line_number_id='20';
UPDATE license_line_number SET name='Germanium-68', description='Total not to exceed 0.1 mCi' WHERE license_line_number_id='21';
UPDATE license_line_number SET name='Nickel-63', description='Total 45 mCi in 3 sources. Each source not to exceed 15 mCi' WHERE license_line_number_id='22';
UPDATE license_line_number SET name='Cesium-137', description='Total not to exceed 4,000 Ci' WHERE license_line_number_id='23';
UPDATE license_line_number SET name='Nickel-63', description='Total 10 mCi' WHERE license_line_number_id='24';
UPDATE license_line_number SET name='Hydrogen-3', description='Total not to exceed 100 mCi' WHERE license_line_number_id='25';

UPDATE line_number_item SET elemental_limit='0.1', elemental_limit_unit_id='2' WHERE line_number_item_id='108';
UPDATE line_number_item SET elemental_limit='0.1', elemental_limit_unit_id='2' WHERE line_number_item_id='109';
UPDATE line_number_item SET elemental_limit='1', elemental_limit_unit_id='2' WHERE line_number_item_id='110';
UPDATE line_number_item SET elemental_limit='5', elemental_limit_unit_id='2' WHERE line_number_item_id='111';
UPDATE line_number_item SET elemental_limit='5', elemental_limit_unit_id='2' WHERE line_number_item_id='112';
UPDATE line_number_item SET elemental_limit='10', elemental_limit_unit_id='2' WHERE line_number_item_id='113';
UPDATE line_number_item SET elemental_limit='15', elemental_limit_unit_id='1' WHERE line_number_item_id='119';

UPDATE license_line_number SET description='Total not to exceed 222 GBq (6 Ci). Not to exceed e4*the quantity listed in 17 CCR, Section 30235, Schedule A, for any 1 radionuclide' WHERE license_line_number_id='501';
UPDATE license_line_number SET description='Total not to exceed 3.7 MBq (100 μCi). Not to exceed e4*the quantity listed in 17 CCR, Section 30235, Schedule A, for any one radionuclide and 0.1 emitting μCi for any other alpha emitting radionuclide' WHERE license_line_number_id='502';
UPDATE license_line_number SET description='Total not to exceed 105 pounds' WHERE license_line_number_id='503';
UPDATE license_line_number SET description='Total not to exceed 925 GBq (25 Ci).' WHERE license_line_number_id='504';
UPDATE license_line_number SET description='Total not to exceed 185 GBq (5 Ci).' WHERE license_line_number_id='505';
UPDATE license_line_number SET description='Total not to exceed 14.8 GBq (400 mCi).' WHERE license_line_number_id='506';
UPDATE license_line_number SET description='Total not to exceed 740 GBq (20 mCi).' WHERE license_line_number_id='507';
UPDATE license_line_number SET description='Total not to exceed 11.1 GBq (300 mCi).' WHERE license_line_number_id='508';
UPDATE license_line_number SET description='Total not to exceed 111 GBq (3 Ci). No single source to exceed 11.1 GBq (300 mCi).' WHERE license_line_number_id='509';
UPDATE license_line_number SET description='Total not to exceed 37 GBq (1 Ci). No Single source to exceed 7.4 GBq (200 mCi).' WHERE license_line_number_id='510';
UPDATE license_line_number SET description='Total not to exceed 74 GBq (2 Ci). No single source to exceed 7.4 GBq (200 mCi).' WHERE license_line_number_id='512';
UPDATE license_line_number SET description='Total 740 MBq (20 mCi) in 5 sources. No single source to exceed 185 MBq (5 mCi).' WHERE license_line_number_id='513';
UPDATE license_line_number SET description='Total 27.8 GBq (750 mCi) in 3 sources. No single source to exceed 9.3 GBq (250 mCi).' WHERE license_line_number_id='514';
UPDATE license_line_number SET description='Total not to exceed 18.5 GBq (500 mCi).' WHERE license_line_number_id='515';
UPDATE license_line_number SET description='Total not to exceed 740 MBq (20 mCi).' WHERE license_line_number_id='516';
UPDATE license_line_number SET description='Total not to exceed 740 MBq (20 mCi).' WHERE license_line_number_id='517';
UPDATE license_line_number SET description='Total not to exceed 740 MBq (20 mCi).' WHERE license_line_number_id='518';
UPDATE license_line_number SET description='Total not to exceed 740 MBq (20 mCi).' WHERE license_line_number_id='519';
UPDATE license_line_number SET description='Total 33.7 TBq (911 Ci) in one source array.' WHERE license_line_number_id='520';
UPDATE license_line_number SET description='Total 40.7 TBq (1,100 Ci) in one source array.' WHERE license_line_number_id='521';
UPDATE license_line_number SET description='Total 74 GBq (2 Ci) in one source.' WHERE license_line_number_id='522';
UPDATE license_line_number SET description='Total not to exceed 222 GBq (6 Ci). No single source to exceed 74 GBq (2 Ci).' WHERE license_line_number_id='523';
UPDATE license_line_number SET description='Total not to exceed 11.1 GBq (300 mCi) in 20 sources. No single source to exceed 555 MBq (15 mCi).' WHERE license_line_number_id='524';
UPDATE license_line_number SET description='Total 18 GBq (500 mCi) in one source.' WHERE license_line_number_id='525';
UPDATE license_line_number SET description='Total not to exceed 5.6 GBq (150 mCi).' WHERE license_line_number_id='526';
UPDATE license_line_number SET description='Total not to exceed 9.3 GBq (250 mCi).' WHERE license_line_number_id='527';

INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('10', 'Labeling, synthesizing, sequencing and identifying proteins');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('11', 'Liquid scintillation counting standards');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('12', 'Instruction programs to demonstrate radiation properties and counting techniques');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('13', 'Minor PET imaging and evaluation studies');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('14', 'Components of gas chromatography units for Varian Model 3600CX and Hewlett Packard Models 6890 and 5890');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('15', 'JL Shepherd & Associates Mark 1 Model 30 irradiator for irradiation of materials');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('16', 'Shimadzu Model ECD-2010 gas chromatograph');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('17', 'Research and development');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('18', 'Components of guages for measurement of moisture and density');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('19', 'Biological field studies');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('20', 'U.S. Nuclear Model GR-12 irradiator');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('21', 'J.L. Shepherd Model Mark 168-A orradiator');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('22', 'J.L. Shepherd and Associates Model 28-6B for irradiation of materials');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('23', 'Components of detector cells incorporated in chromatograph units');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('24', 'Callibration of a gamma ray telescope and instruction programs');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('25', 'Component of a lettuce maturity tester');
INSERT INTO use_purpose (use_purpose_id, use_purpose_name) VALUES ('26', 'Amersham Model 773 calibrator');

UPDATE license_line_number SET use_purpose_id='10' WHERE license_line_number_id='4';
UPDATE license_line_number SET use_purpose_id='10' WHERE license_line_number_id='5';
UPDATE license_line_number SET use_purpose_id='10' WHERE license_line_number_id='6';
UPDATE license_line_number SET use_purpose_id='10' WHERE license_line_number_id='7';
UPDATE license_line_number SET use_purpose_id='10' WHERE license_line_number_id='8';
UPDATE license_line_number SET use_purpose_id='11' WHERE license_line_number_id='9';
UPDATE license_line_number SET use_purpose_id='11' WHERE license_line_number_id='10';
UPDATE license_line_number SET use_purpose_id='12' WHERE license_line_number_id='11';
UPDATE license_line_number SET use_purpose_id='12' WHERE license_line_number_id='12';
UPDATE license_line_number SET use_purpose_id='12' WHERE license_line_number_id='13';
UPDATE license_line_number SET use_purpose_id='12' WHERE license_line_number_id='14';
UPDATE license_line_number SET use_purpose_id='12' WHERE license_line_number_id='15';
UPDATE license_line_number SET use_purpose_id='12' WHERE license_line_number_id='16';
UPDATE license_line_number SET use_purpose_id='13' WHERE license_line_number_id='17';
UPDATE license_line_number SET use_purpose_id='13' WHERE license_line_number_id='18';
UPDATE license_line_number SET use_purpose_id='13' WHERE license_line_number_id='19';
UPDATE license_line_number SET use_purpose_id='13' WHERE license_line_number_id='20';
UPDATE license_line_number SET use_purpose_id='13' WHERE license_line_number_id='21';
UPDATE license_line_number SET use_purpose_id='14' WHERE license_line_number_id='22';
UPDATE license_line_number SET use_purpose_id='15' WHERE license_line_number_id='23';
UPDATE license_line_number SET use_purpose_id='16' WHERE license_line_number_id='24';
UPDATE license_line_number SET use_purpose_id='10' WHERE license_line_number_id='25';
UPDATE license_line_number SET use_purpose_id='17' WHERE license_line_number_id='501';
UPDATE license_line_number SET use_purpose_id='17' WHERE license_line_number_id='502';
UPDATE license_line_number SET use_purpose_id='17' WHERE license_line_number_id='503';
UPDATE license_line_number SET use_purpose_id='17' WHERE license_line_number_id='504';
UPDATE license_line_number SET use_purpose_id='17' WHERE license_line_number_id='505';
UPDATE license_line_number SET use_purpose_id='17' WHERE license_line_number_id='506';
UPDATE license_line_number SET use_purpose_id='17' WHERE license_line_number_id='507';
UPDATE license_line_number SET use_purpose_id='17' WHERE license_line_number_id='508';
UPDATE license_line_number SET use_purpose_id='17' WHERE license_line_number_id='509';
UPDATE license_line_number SET use_purpose_id='17' WHERE license_line_number_id='510';
UPDATE license_line_number SET use_purpose_id='17' WHERE license_line_number_id='511';
UPDATE license_line_number SET use_purpose_id='18' WHERE license_line_number_id='512';
UPDATE license_line_number SET use_purpose_id='18' WHERE license_line_number_id='513';
UPDATE license_line_number SET use_purpose_id='18' WHERE license_line_number_id='514';
UPDATE license_line_number SET use_purpose_id='19' WHERE license_line_number_id='515';
UPDATE license_line_number SET use_purpose_id='19' WHERE license_line_number_id='516';
UPDATE license_line_number SET use_purpose_id='19' WHERE license_line_number_id='517';
UPDATE license_line_number SET use_purpose_id='19' WHERE license_line_number_id='518';
UPDATE license_line_number SET use_purpose_id='19' WHERE license_line_number_id='519';
UPDATE license_line_number SET use_purpose_id='20' WHERE license_line_number_id='520';
UPDATE license_line_number SET use_purpose_id='21' WHERE license_line_number_id='521';
UPDATE license_line_number SET use_purpose_id='22' WHERE license_line_number_id='522';
UPDATE license_line_number SET use_purpose_id='23' WHERE license_line_number_id='523';
UPDATE license_line_number SET use_purpose_id='23' WHERE license_line_number_id='524';
UPDATE license_line_number SET use_purpose_id='24' WHERE license_line_number_id='525';
UPDATE license_line_number SET use_purpose_id='25' WHERE license_line_number_id='526';
UPDATE license_line_number SET use_purpose_id='26' WHERE license_line_number_id='527';

DELETE FROM line_number_item WHERE line_number_item_id='100001';
DELETE FROM line_number_item WHERE line_number_item_id='100002';
DELETE FROM license_line_number WHERE license_line_number_id='1001';
DELETE FROM license_line_number WHERE license_line_number_id='1002';
