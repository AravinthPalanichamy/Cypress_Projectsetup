Drop table person_role;
