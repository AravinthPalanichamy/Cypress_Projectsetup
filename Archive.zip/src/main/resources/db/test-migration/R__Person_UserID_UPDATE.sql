/*
-- Query: select temp.user_id WHERE `eppn` =  prsn.eppn WHERE `eppn` =  prsn.campus_code from person prsn join temp_cs temp on prsn.eppn = temp.eppn
LIMIT 0 WHERE `eppn` =  1000

-- Date: 2017-08-30 16:49
*/
UPDATE `person` SET `user_id` = 'VEVTVHw5OXx1c2VyM0B1Y3Rlc3QuZWR1' WHERE `eppn` = 'user3@uctest.edu' AND `campus_code` = '99';
UPDATE `person` SET `user_id` = 'VEVTVHw5OXx1c2VyMkB1Y3Rlc3QuZWR1' WHERE `eppn` = 'user2@uctest.edu' AND `campus_code` = '99';
UPDATE `person` SET `user_id` = 'VEVTVHw5OXx1c2VyMTVAdWN0ZXN0LmVkdQ' WHERE `eppn` = 'user15@uctest.edu' AND `campus_code` = '99';
UPDATE `person` SET `user_id` = 'VEVTVHw5OXx1c2VyMTZAdWN0ZXN0LmVkdQ' WHERE `eppn` = 'user16@uctest.edu' AND `campus_code` = '99';
UPDATE `person` SET `user_id` = 'VEVTVHw5OXx1c2VyMUB1Y3Rlc3QuZWR1' WHERE `eppn` = 'user1@uctest.edu' AND `campus_code` = '99';
UPDATE `person` SET `user_id` = 'VEVTVHw5OXx1c2VyNEB1Y3Rlc3QuZWR1' WHERE `eppn` = 'user4@uctest.edu' AND `campus_code` = '99';
UPDATE `person` SET `user_id` = 'VEVTVHw5OXx1c2VyNkB1Y3Rlc3QuZWR1' WHERE `eppn` = 'user6@uctest.edu' AND `campus_code` = '99';
UPDATE `person` SET `user_id` = 'VEVTVHw5OXx1c2VyNUB1Y3Rlc3QuZWR1' WHERE `eppn` = 'user5@uctest.edu' AND `campus_code` = '99';
UPDATE `person` SET `user_id` = 'VUN8MDd8Y3NoZXJtYTFAdWNzYy5lZHU' WHERE `eppn` = 'csherma1@ucsc.edu' AND `campus_code` = '07';
UPDATE `person` SET `user_id` = 'VUN8MDF8Y2ptYWNrZW56aWVAYmVya2VsZXkuZWR1' WHERE `eppn` = 'cjmackenzie@berkeley.edu' AND `campus_code` = '01';
UPDATE `person` SET `user_id` = 'VUN8MDh8amNhc3RvQHVjc2IuZWR1' WHERE `eppn` = 'jcasto@ucsb.edu' AND `campus_code` = '08';
UPDATE `person` SET `user_id` = 'VUN8MDJ8NzQzNzEyQHVjc2YuZWR1' WHERE `eppn` = '743712@ucsf.edu' AND `campus_code` = '02';
UPDATE `person` SET `user_id` = 'VUN8MDl8cmlkZW5kb0B1Y2kuZWR1' WHERE `eppn` = 'RIDENDO@uci.edu' AND `campus_code` = '09';
UPDATE `person` SET `user_id` = 'VUN8MDl8YW5nZWxlc3NAdWNpLmVkdQ' WHERE `eppn` = 'angeless@uci.edu' AND `campus_code` = '09';
UPDATE `person` SET `user_id` = 'VUN8MDN8c3prcm9nZXJAdWNkYXZpcy5lZHU' WHERE `eppn` = 'szkroger@ucdavis.edu' AND `campus_code` = '03';
UPDATE `person` SET `user_id` = 'VUN8MDN8dmFuZGV5YWVAdWNkYXZpcy5lZHU' WHERE `eppn` = 'vandeyae@ucdavis.edu' AND `campus_code` = '03';
UPDATE `person` SET `user_id` = 'VUN8MDN8Z3c1NzQzQHVjZGF2aXMuZWR1' WHERE `eppn` = 'gw5743@ucdavis.edu' AND `campus_code` = '03';
UPDATE `person` SET `user_id` = 'VUN8MDN8ZnpidXNoYmVAdWNkYXZpcy5lZHU' WHERE `eppn` = 'fzbushbe@ucdavis.edu' AND `campus_code` = '03';
UPDATE `person` SET `user_id` = 'VUN8MDR8YnJ1aXpAdWNsYS5lZHU' WHERE `eppn` = 'bruiz@ucla.edu' AND `campus_code` = '04';
UPDATE `person` SET `user_id` = 'VUN8MDR8ZGltb2NrY0B1Y2xhLmVkdQ' WHERE `eppn` = 'dimockc@ucla.edu' AND `campus_code` = '04';
UPDATE `person` SET `user_id` = 'VUN8MDV8a2phbmlnYUB1Y3IuZWR1' WHERE `eppn` = 'kjaniga@ucr.edu' AND `campus_code` = '05';
UPDATE `person` SET `user_id` = 'VUN8MDV8bW1hZHVyb0B1Y3IuZWR1' WHERE `eppn` = 'mmaduro@ucr.edu' AND `campus_code` = '05';
UPDATE `person` SET `user_id` = 'VUN8MTB8a25ndXllbjY1QHVjbWVyY2VkLmVkdQ' WHERE `eppn` = 'knguyen65@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8a2hveWVyMkB1Y21lcmNlZC5lZHU' WHERE `eppn` = 'khoyer2@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8a3NtaXRoMjNAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'ksmith23@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8a3ZhbGVudGluZTJAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'kvalentine2@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8aGZvcm1hbkB1Y21lcmNlZC5lZHU' WHERE `eppn` = 'hforman@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8aHRob21wc29uQHVjbWVyY2VkLmVkdQ' WHERE `eppn` = 'hthompson@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8am1hbmlsYXlAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'jmanilay@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8amNob2lAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'jchoi@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8bm92aWVkbzJAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'noviedo2@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8bWJldmlzQHVjbWVyY2VkLmVkdQ' WHERE `eppn` = 'mbevis@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8bWNsZWFyeTRAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'mcleary4@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8bWR1bmxhcEB1Y21lcmNlZC5lZHU' WHERE `eppn` = 'mdunlap@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8bXRpdHVzQHVjbWVyY2VkLmVkdQ' WHERE `eppn` = 'mtitus@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8c2hhcnQ0QHVjbWVyY2VkLmVkdQ' WHERE `eppn` = 'shart4@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8c3N0ZXBwQHVjbWVyY2VkLmVkdQ' WHERE `eppn` = 'sstepp@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8cG9kYXlAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'poday@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8cGJhcmdob3V0aEB1Y21lcmNlZC5lZHU' WHERE `eppn` = 'pbarghouth@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8cm9ydGl6QHVjbWVyY2VkLmVkdQ' WHERE `eppn` = 'rortiz@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8cmhvZ2x1bmRAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'rhoglund@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8cnJvZHJpZ3VlejNAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'rrodriguez3@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8dmxlcHBlcnRAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'vleppert@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8dnZvbmdwaGFraGFtQHVjbWVyY2VkLmVkdQ' WHERE `eppn` = 'vvongphakham@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8eXBlbGxtYW5AdWNtZXJjZWQuZWR1' WHERE `eppn` = 'ypellman@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8eXpoYW8zMkB1Y21lcmNlZC5lZHU' WHERE `eppn` = 'yzhao32@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8VUNORVRJRHw5NzM5NDY' WHERE `eppn` = 'CS1443028609490_973946@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8Y2xpMzJAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'cli32@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8Ym1hcnRpbmV6MjZAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'bmartinez26@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8YnppbWFuQHVjbWVyY2VkLmVkdQ' WHERE `eppn` = 'bziman@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8YXBhcmtlcjdAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'aparker7@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8ZGdyYXZhbm9AdWNtZXJjZWQuZWR1' WHERE `eppn` = 'dgravano@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8ZGJ1cm93QHVjbWVyY2VkLmVkdQ' WHERE `eppn` = 'dburow@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8ZGphcmFtaWxsby1mZWxsaW5AdWNtZXJjZWQuZWR1' WHERE `eppn` = 'djaramillo-fellin@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8ZGRhdmlkaWFuQHVjbWVyY2VkLmVkdQ' WHERE `eppn` = 'ddavidian@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8ZHpodTRAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'dzhu4@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8ZXdlcm5lckB1Y21lcmNlZC5lZHU' WHERE `eppn` = 'ewerner@ucmerced.edu' AND `campus_code` = '10';
UPDATE `person` SET `user_id` = 'VUN8MTB8ZXJlaW5vc28tbWFzZXRAdWNtZXJjZWQuZWR1' WHERE `eppn` = 'ereinoso-maset@ucmerced.edu' AND `campus_code` = '10';
