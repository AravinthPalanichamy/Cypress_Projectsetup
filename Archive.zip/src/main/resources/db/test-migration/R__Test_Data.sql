-- User data for testing the WASTe/RAD integration requires setting up an approved RUA
-- PI in RAD and in WASTe : Allen Van Deynze

-- Person
INSERT IGNORE INTO `person` (`id`; `email`;`eppn`;`first_name`; `last_name`; `net_id`; `campus_code`; `user_id`; `status`; `gender`; `dob`) VALUES (100; 'avandeynze@ucdavis.edu'; 'vandeyae@ucdavis.edu'; 'Allen'; 'Van Deynze'; '671533'; '03'; 'VUN8MDN8dmFuZGV5YWVAdWNkYXZpcy5lZHU'; 'STAFF'; 'MALE'; '1980-10-10');

---------------------------------- UA details ------------------------------------

-- UA
INSERT IGNORE INTO `ua`(`id`; `number`;`pi_person_id`; `status_type`; `type`; `expiry_date`; `created_date`; `last_modified_date`; `created_by`; `last_modified_by`; `is_active`; `is_monitoring_required`) VALUES (100; 8; (SELECT id FROM person WHERE eppn LIKE 'vandeyae@ucdavis.edu'); 'APPROVED'; 'RUA'; '2020-04-30 00:00:00'; '2014-04-30 00:00:00'; '2015-04-30 00:00:00'; 1; 1; true; false);

-- Planned work
INSERT IGNORE INTO `ua_planned_work` (`ua_pw_id`; `chemical_form`; `description_of_use`; `potential_hazards`; `protection_precautions`; `waste_methods`; `experiment_possession_limit`; `is_sealed_source`; `requested_possession_limit`; `single_source_limit`; `vial_possession_limit`; `radionuclide_id`; `ua_id`; `license_line_number_id`; `purpose_type`; `research_type`; `physical_form_id`; `unit`) VALUES (100; 'Danger1'; 'Carefully.'; 'It is radiation.'; 'All required precautions.'; 'Per guidelines.'; 2.0; 0; 20.5; 0.5; 0.5; 108; (SELECT id FROM ua WHERE number = 8 AND pi_person_id in (select id from person where eppn like 'vandeyae@ucdavis.edu')); 328; 'CLINICAL'; 'HUMAN'; 1; 1);

-- SOE
INSERT IGNORE INTO `soe`(`id`; `status_type`;`last_step_completed`; `ua_id`; `person_id`; `is_active`) VALUES (100; 'SUBMITTED'; 4; (SELECT id FROM ua WHERE number = 8 AND pi_person_id in (select id from person where eppn like 'vandeyae@ucdavis.edu')); (SELECT id FROM person WHERE eppn LIKE 'vandeyae@ucdavis.edu'); true);

---------------------------------- Bundle details ------------------------------------

-- Core bundle
INSERT IGNORE INTO `core_bundle`(`id`; `cs_id`;`name`;`pi_person_id`) VALUES (100; 'eab10864-4ede-4795-9f99-f4148015eb4c'; 'Van Deynze Lab'; (SELECT id FROM person WHERE eppn LIKE 'vandeyae@ucdavis.edu'));

-- UA bundle
INSERT IGNORE INTO `ua_bundle`(`id`; `ua_id`; `name`; `cs_id`) VALUES (100; (SELECT id FROM ua WHERE number = 8 AND pi_person_id in (select id from person where eppn like 'vandeyae@ucdavis.edu')); 'Van Deynze Lab'; 'eab10864-4ede-4795-9f99-f4148015eb4c');

-- Location
INSERT IGNORE INTO `location`(`id`; `building_display_name`;`building_key`;`building_primary_name`; `campus_code`; `floor_key`; `floor_name`; `room_key`; `room_number`) VALUES (100; 'Plant Reproductive Biology Facility'; 'DV-01-001533'; 'Plant Reproductive Biology Facility (formerly Gennome Launch Facility)'; '03'; 'DV-01-0001649'; '1st Floor'; 'DV-01-00032553'; '1401');

-- Core bundle location
INSERT IGNORE INTO `core_bundle_location`(`id`; `core_bundle_id`;`location_id`) VALUES (100; (SELECT id FROM core_bundle WHERE cs_id='eab10864-4ede-4795-9f99-f4148015eb4c'); (SELECT id FROM location WHERE building_key LIKE 'DV-01-001533' AND floor_key LIKE 'DV-01-0001649' AND room_key LIKE 'DV-01-00032553' AND campus_code LIKE '03'));

-- UA bundle location
INSERT IGNORE INTO `ua_bundle_location`(`id`; `location_id`;`ua_bundle_id`) VALUES (100; (SELECT id FROM location WHERE building_key LIKE 'DV-01-001533' AND floor_key LIKE 'DV-01-0001649' AND room_key LIKE 'DV-01-00032553' AND campus_code LIKE '03'); (SELECT id FROM ua_bundle WHERE ua_id = (SELECT id FROM ua WHERE number = 8 AND pi_person_id in (select id from person where eppn like 'vandeyae@ucdavis.edu')) AND cs_id LIKE 'eab10864-4ede-4795-9f99-f4148015eb4c'));

--Survey Data
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`; `due_date`; `status_type`; `text`; `comment`) VALUES (1; 'ROUTINE'; 1; 1; '2016-10-31 00:00:00';  '2017-12-25 00:00:00'; null; null; null);
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`; `due_date`; `status_type`; `text`; `comment`) VALUES (2; 'ROUTINE'; 2; 2; '2016-11-26 00:00:00';  '2017-11-24 00:00:00'; null; null; null);
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`; `due_date`; `status_type`; `text`; `comment`) VALUES (3; 'ROUTINE'; 3; 3; '2016-09-22 00:00:00';  '2017-10-23 00:00:00'; null; null; null);
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`;  `due_date`; `status_type`; `text`; `comment`) VALUES (4; 'ROUTINE'; 4; 4; '2016-07-19 00:00:00';  '2017-09-20 00:00:00'; null; null; null);
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`;  `due_date`; `status_type`; `text`; `comment`) VALUES (5; 'ROUTINE'; 5; 5; '2016-05-19 00:00:00';  '2017-08-21 00:00:00'; null; null; null);
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`;  `due_date`; `status_type`; `text`; `comment`) VALUES (6; 'ROUTINE'; 8; 8; '2016-04-18 00:00:00';  '2017-10-10 00:00:00'; null; null; null);
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`;  `due_date`; `status_type`; `text`; `comment`) VALUES (7; 'ROUTINE'; 3; 3; '2016-10-17 00:00:00';  '2017-10-11 00:00:00'; null; null; null);
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`;  `due_date`; `status_type`; `text`; `comment`) VALUES (100; 'ROUTINE'; 100; 100; '2015-10-10 00:00:00';  '2017-10-21 00:00:00'; null; null; null);
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`;  `due_date`; `status_type`; `text`; `comment`) VALUES (103; 'ROUTINE'; 2; 2; '2016-10-11 00:00:00';  '2017-09-11 00:00:00'; null; null; null);
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`;  `due_date`; `status_type`; `text`; `comment`) VALUES (104; 'ROUTINE'; 3; 4; '2016-10-14 00:00:00';  '2017-07-21 00:00:00'; null; null; null);
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`;  `due_date`; `status_type`; `text`; `comment`) VALUES (105; 'ROUTINE'; 4; 3; '2016-10-15 00:00:00';  '2017-06-15 00:00:00'; null; null; null);
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`;  `due_date`; `status_type`; `text`; `comment`) VALUES (106; 'ROUTINE'; 1; 1; '2016-10-18 00:00:00';  '2017-05-16 00:00:00'; null; null; null);
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`;  `due_date`; `status_type`; `text`; `comment`) VALUES (107; 'ROUTINE'; 2; 2; '2016-10-19 00:00:00';  '2017-04-17 00:00:00'; null; null; null);
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`;  `due_date`; `status_type`; `text`; `comment`) VALUES (108; 'ROUTINE'; 4; 4; '2016-10-02 00:00:00';  '2017-03-18 00:00:00'; null; null; null);
INSERT IGNORE INTO `survey`(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`;  `due_date`; `status_type`; `text`; `comment`) VALUES (109; 'ROUTINE'; 3; 3; '2016-10-01 00:00:00';  '2017-02-19 00:00:00'; null; null; null);


INSERT IGNORE INTO `instrument`(`instrument_id`; `ua_id`; `manufacturer`; `model`; `serial_number`; `calibration_frequency_id`; `created_by`; `created_date`; `last_modified_by`; `last_modified_date`; `probe1_model`; `probe1_serial`; `probe2_model`; `probe2_serial`; `comment`; `scale`; `calibration_due_status_type`; `calibration_next_due`) VALUES (1;108;'Ludlum';'5-10EB';'113782';2;102;'2016-10-31 07:00:00';102;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'OFF_SITE';'2018-10-31 00:00:00');(2;109;'Mini-Monitor';'5810EB';'103782';1;104;'2016-10-31 07:00:00';104;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'IN_USE';'2019-10-31 00:00:00');(3;108;'Ludlum';'6-10EB';'113782';3;102;'2016-10-31 07:00:00';102;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'OFF_SITE';'2020-10-31 00:00:00');(4;109;'Ludlum';'8-10EB';'113782';2;102;'2016-10-31 07:00:00';102;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'IN_USE';'2017-12-31 00:00:00');(5;108;'Mini-Monitor';'15-10EB';'113782';2;102;'2016-10-31 07:00:00';102;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'OFF_SITE';'2019-10-31 00:00:00');(6;109;'Ludlum';'25-10EB';'113782';4;102;'2016-10-31 07:00:00';102;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'IN_USE';'2025-10-31 00:00:00');(7;108;'Ludlum';'65-10EB';'113782';1;102;'2016-10-31 07:00:00';102;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'IN_USE';'2016-10-31 00:00:00');(8;109;'Ludlum';'35EB';'113782';2;102;'2016-10-31 07:00:00';102;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'OFF_SITE';'2016-10-31 00:00:00');(9;108;'Pentagon';'r4fv';'113782';4;102;'2016-10-31 07:00:00';102;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'IN_USE';'2016-10-31 00:00:00');(10;109;'Ludlum';'12-10EB';'113782';2;102;'2016-10-31 07:00:00';102;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'OFF_SITE';'2016-10-31 00:00:00');(11;108;'Volvo';'14-10EB';'113782';1;102;'2016-10-31 07:00:00';102;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'IN_USE';'2016-10-31 00:00:00');(12;109;'Ludlum';'17-10EB';'113782';2;102;'2016-10-31 07:00:00';102;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'OFF_SITE';'2016-10-31 00:00:00');(13;108;'Thermal Fischer';'13-10EB';'113782';1;102;'2016-10-31 07:00:00';102;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'IN_USE';'2016-10-31 00:00:00');(14;109;'Ludlum';'22-10EB';'113782';1;102;'2016-10-31 07:00:00';102;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'IN_USE';'2016-10-31 00:00:00');(15;108;'Ludlum';'33-10EB';'113782';1;102;'2016-10-31 07:00:00';102;'2016-10-31 07:00:00';NULL;NULL;NULL;NULL;NULL;'CPM';'IN_USE';'2016-10-31 00:00:00');

INSERT IGNORE INTO `probe` (`id`; `model`; `serial`; `campus_code`) VALUES ('1'; '44-9'; '127001'; '10');

INSERT IGNORE INTO `calibration_source` (`id`; `name`; `calibration_type`; `campus_code`) VALUES ('1'; 'Ludlum 500-2 SN 47202 pulser used'; 'PULSE_GENERATOR_CALIBRATION'; '10');
INSERT IGNORE INTO  `calibration_source` (`id`; `name`; `calibration_type`; `campus_code`) VALUES ('2'; 'Cs-137 Calibration Sources used (5 mCi and 50 mCi)'; 'RANGE_CALIBRATION'; '10');

INSERT IGNORE INTO  `probe_response_check_source` (`id`; `name`; `campus_code`; `active`) VALUES ('1'; 'High Energy (Tc-99 -- 102.2 nCi)'; '10'; '1');
INSERT IGNORE INTO  `probe_response_check_source` (`id`; `name`; `campus_code`; `active`) VALUES ('2'; 'Low Energy (C-14 -- 97.96 nCi)'; '10'; '1');
INSERT IGNORE INTO  `probe_response_check_source` (`id`; `name`; `campus_code`; `active`) VALUES ('3'; 'Low Energy Gamma (I-129 -- 0.1 µCi)'; '10'; '1');

INSERT IGNORE INTO `calibration` (`id`; `probe_id`; `instrument_id`; `comment`; `calibration_date`; `calibrated_by`; `background`; `voltage`; `battery_ok`; `audio_ok`; `cable_ok`; `general_condition_ok`; `calibration_type`; `calibration_source_id`; `created_by`;`last_modified_by`; `created_date`; `last_modified_date`) VALUES ('1'; '1'; '1'; 'This is a test comment'; '2016-10-31 07:00:00'; '104'; '7'; '6'; 'YES'; 'NO'; 'NA'; 'YES'; 'PULSE_GENERATOR_CALIBRATION'; '1'; '104'; '104';'2016-10-31 07:00:00';'2016-10-31 07:00:00');
INSERT IGNORE INTO `calibration` (`id`; `probe_id`; `instrument_id`; `comment`; `calibration_date`; `calibrated_by`; `background`; `voltage`; `battery_ok`; `audio_ok`; `cable_ok`; `general_condition_ok`; `calibration_type`; `calibration_source_id`; `created_by`;`last_modified_by`; `created_date`; `last_modified_date`) VALUES ('2'; '1'; '1'; 'This is another comment'; '2017-10-31 07:00:00'; '104'; '7'; '5'; 'YES'; 'NO'; 'NA'; 'YES'; 'RANGE_CALIBRATION'; '2'; '104'; '104';'2016-10-31 07:00:00';'2016-10-31 07:00:00');


UPDATE `ua_bundle` SET `cs_id`='c8135758-ef82-4cad-9b33-ac173758d4fc'; `name`='RUA-107-SMITH' WHERE `id`='106';
UPDATE `ua_bundle` SET `cs_id`=' f202bb6a-14b7-4834-926a-7ae44268b256'; `name`='RUA-108-SMITH' WHERE `id`='107';
UPDATE `ua_bundle` SET `cs_id`='4fc3b5bf-a0be-41bb-a0b4-5c0e26d312be'; `name`='RUA-109-SMITH' WHERE `id`='108';
UPDATE `ua_bundle` SET `cs_id`='6dc88981-7111-4bdb-9cf4-1cd4df102c03' WHERE `id`='103';
UPDATE `ua_bundle` SET `cs_id`='6dc88981-7111-4bdb-9cf4-1cd4df102c03' WHERE `id`='104';
UPDATE .`ua` SET `expiry_date`='2018-10-31 00:00:00' WHERE `id`='103';
UPDATE `ua` SET `expiry_date`='2019-10-31 00:00:00' WHERE `id`='104';


-- packaging stuff
INSERT IGNORE INTO `ua_limit` (`ua_limit_id`; `chemical_form`; `experiment_possession_limit`; `is_sealed_source`; `requested_possession_limit`; `vial_possession_limit`; `radionuclide_id`; `ua_id`; `physical_form_id`; `use_factor_id`; `eng_control_id`; `form_factor_id`; `unit`; `is_self_receivable`; `entered_date`; `entered_by_person_id`; `active`) VALUES ('1'; 'atp'; '3'; '0'; '3'; '3'; '2'; '109'; '2'; '2'; '1'; '3'; '1'; '0'; '2017-11-20 11:42:39'; '134'; 1);
--INSERT IGNORE INTO `material_package` (`id`; `created_date`; `last_modified_date`; `date_received`; `has_exterior_survey`; `has_primary_survey`; `is_exterior_swipe_contamination_free`; `is_primary_swipe_contamination_free`; `package_number`; `created_by`; `last_modified_by`; `checked_by_id`; `package_type_id`; `package_vendor_id`; `ua_id`) VALUES ('1'; '2017-11-20 11:43:36'; '2017-11-20 11:43:36'; '2017-11-22 00:00:00'; 1; 1; 1; 1; '3'; '134'; '134'; '134'; '50'; '68'; '109');
--INSERT IGNORE INTO `material` (`id`; `created_date`; `last_modified_date`; `chemical_form`; `initial_date`; `created_by`; `last_modified_by`; `material_package_id`; `storage_location_id`; `ua_id`; `is_material_for_test`; `inventory_status_type`; `ss_group_id`; `test_frequency_id`) VALUES ('1'; '2017-11-20 11:43:14'; '2017-11-20 11:43:36'; 'asdfasdf'; '2017-11-14 00:00:00'; '134'; '134'; '1'; '150'; '109'; '0'; 'IN_INVENTORY'; '0'; '2');
--INSERT IGNORE INTO `radionuclide_material` (`id`; `material_id`; `ua_limit_id`; `request_amount`; `initial_amount`) VALUES ('1'; '1'; '1'; '3.00000'; '3.00000');

UPDATE `ua` SET `status_type`='PENDING' WHERE `id`='4';
UPDATE `ua` SET `status_type`='PENDING' WHERE `id`='105';
UPDATE `ua` SET `status_type`='PENDING' WHERE `id`='106';
UPDATE `ua` SET `status_type`='PENDING' WHERE `id`='107';
UPDATE `ua` SET `status_type`='PENDING' WHERE `id`='112';
UPDATE `ua` SET `status_type`='PENDING' WHERE `id`='113';
UPDATE `ua` SET `status_type`='PENDING' WHERE `id`='114';
UPDATE `ua` SET `status_type`='PENDING' WHERE `id`='115';
UPDATE `ua` SET `status_type`='PENDING' WHERE `id`='116';
UPDATE `ua` SET `status_type`='PENDING' WHERE `id`='117';
UPDATE `ua` SET `status_type`='PENDING' WHERE `id`='118';
UPDATE `ua` SET `status_type`='PENDING' WHERE `id`='119';
UPDATE `ua` SET `status_type`='PENDING' WHERE `id`='3';
