-- User data for testing the WASTe/RAD integration requires setting up an approved RUA
-- PI in RAD and in WASTe : Allen Van Deynze

-- Person
/*
-- Query: SELECT * FROM radsafety.Person where first_name like 'Carolyn' or first_name like 'Gerry' or first_name like 'Karen' or first_name like 'Jason'
-- Date: 2017-12-05 10:42
*/
INSERT INTO
`Person`
(`department`; `dob`; `email`; `eppn`; `first_name`; `gender`; `last_name`; `net_id`; `phone`; `status`; `campus_code`; `user_id`; `created_by`)
VALUES
('ENVIRONMENTAL HEALTH &amp; SAFETY'; NULL; 'karen.janiga@ucr.edu'; 'kjaniga@ucr.edu'; 'Karen'; 'FEMALE'; 'Janiga'; '1287917';NULL; 'STAFF'; '05'; 'VUN8MDV8a2phbmlnYUB1Y3IuZWR1'; 1);
('ENVIRONMENTAL HEALTH &amp; SAFETY'; NULL; 'gdwestcot@UCDAVIS.EDU'; 'gw5743@ucdavis.edu'; 'Gerry'; 'MALE'; 'Westcott'; '49725';NULL; 'STAFF'; '03'; 'VUN8MDN8Z3c1NzQzQHVjZGF2aXMuZWR1';1);
('ENVIRONMENTAL HEALTH &amp; SAFETY'; NULL; 'cjmackenzie@berkeley.edu'; 'cjmackenzie@berkeley.edu'; 'Carolyn'; 'FEMALE'; 'Mac Kenzie'; '454798'; '5106437976'; 'STAFF'; '01'; 'VUN8MDF8Y2ptYWNrZW56aWVAYmVya2VsZXkuZWR1'; 1);
('ENVIRONMENTAL HEALTH &amp; SAFETY'; NULL; 'ksmith23@ucmerced.edu'; 'ksmith23@ucmerced.edu'; 'Karen'; 'FEMALE'; 'Smith'; '1424650'; '2092287864'; 'STAFF'; '10'; 'VUN8MTB8a3NtaXRoMjNAdWNtZXJjZWQuZWR1'; 1)
ON DUPLICATE KEY UPDATE created_by=created_by;


---------------------------------- UA details ------------------------------------

-- UA
/*
-- Query: SELECT * FROM radsafety.ua where id = 100
-- Date: 2017-12-05 13:25
*/
-- set base rua number for bundle feasibility
SET @number_max = (SELECT (MAX(u.number)) FROM ua u);
SET @RUA_NUMBER = (SELECT CASE WHEN @number_max > 65000 THEN @number_max ELSE 65000 END);

-- campus = 10

INSERT INTO `ua` (`number`;`status_type`;`type`;`expiry_date`;`created_by`;`last_modified_by`;`pi_person_id`;`is_active`)
VALUES ((@RUA_NUMBER+1);'ACTIVE';'RUA';DATE_ADD(NOW(); INTERVAL 1 YEAR);1;1;(select id from Person where eppn = 'ksmith23@ucmerced.edu');1);
SET @MERCED_RUA_APRVD = LAST_INSERT_ID();

INSERT INTO `ua` (`number`;`status_type`;`type`;`expiry_date`;`created_by`;`last_modified_by`;`pi_person_id`;`is_active`)
VALUES ((SELECT (MAX(u.number) + 1) FROM ua u);'ACTIVE';'MUA';DATE_ADD(NOW(); INTERVAL 1 YEAR);1;1;(select id from Person where eppn = 'ksmith23@ucmerced.edu');1);
SET @MERCED_MUA_APRVD = LAST_INSERT_ID();

INSERT INTO `ua` (`number`;`status_type`;`type`;`expiry_date`;`created_by`;`last_modified_by`;`pi_person_id`;`is_active`)
VALUES ((SELECT (MAX(u.number) + 1) FROM ua u);'PENDING_REVIEW';'RUA';DATE_ADD(NOW(); INTERVAL 1 YEAR);1;1;(select id from Person where eppn = 'ksmith23@ucmerced.edu');1);
SET @MERCED_RUA_PND_RVW = LAST_INSERT_ID();

INSERT INTO `ua` (`number`;`status_type`;`type`;`expiry_date`;`created_by`;`last_modified_by`;`pi_person_id`;`is_active`)
VALUES ((SELECT (MAX(u.number) + 1) FROM ua u);'PENDING_REVIEW';'MUA';DATE_ADD(NOW(); INTERVAL 1 YEAR);1;1;(select id from Person where eppn = 'ksmith23@ucmerced.edu');1);
SET @MERCED_MUA_PND_RVW = LAST_INSERT_ID();

-- campus = 01

INSERT INTO `ua` (`number`;`status_type`;`type`;`expiry_date`;`created_by`;`last_modified_by`;`pi_person_id`;`is_active`)
VALUES ((SELECT (MAX(u.number) + 1) FROM ua u);'PENDING_REVIEW';'RUA';DATE_ADD(NOW(); INTERVAL 1 YEAR);1;1;(select id from Person where eppn = 'cjmackenzie@berkeley.edu');1);
SET @BRKLY_RUA_PND_RVW = LAST_INSERT_ID();

INSERT INTO `ua` (`number`;`status_type`;`type`;`expiry_date`;`created_by`;`last_modified_by`;`pi_person_id`;`is_active`)
VALUES ((SELECT (MAX(u.number) + 1) FROM ua u);'PENDING_REVIEW';'MUA';DATE_ADD(NOW(); INTERVAL 1 YEAR);1;1;(select id from Person where eppn = 'cjmackenzie@berkeley.edu');1);
SET @BRKLY_MUA_PND_RVW = LAST_INSERT_ID();


-- campus = 03

INSERT INTO `ua` (`number`;`status_type`;`type`;`expiry_date`;`created_by`;`last_modified_by`;`pi_person_id`;`is_active`)
VALUES ((SELECT (MAX(u.number) + 1) FROM ua u);'PENDING_REVIEW';'RUA';DATE_ADD(NOW(); INTERVAL 1 YEAR);1;1;(select id from Person where eppn = 'gw5743@ucdavis.edu');1);
SET @DAVIS_RUA_PND_RVW = LAST_INSERT_ID();

INSERT INTO `ua` (`number`;`status_type`;`type`;`expiry_date`;`created_by`;`last_modified_by`;`pi_person_id`;`is_active`)
VALUES ((SELECT (MAX(u.number) + 1) FROM ua u);'PENDING_REVIEW';'MUA';DATE_ADD(NOW(); INTERVAL 1 YEAR);1;1;(select id from Person where eppn = 'gw5743@ucdavis.edu');1);
SET @DAVIS_MUA_PND_RVW = LAST_INSERT_ID();

-- campus = 05

INSERT INTO `ua` (`number`;`status_type`;`type`;`expiry_date`;`created_by`;`last_modified_by`;`pi_person_id`;`is_active`)
VALUES ((SELECT (MAX(u.number) + 1) FROM ua u);'PENDING_REVIEW';'RUA';DATE_ADD(NOW(); INTERVAL 1 YEAR);1;1;(select id from Person where eppn = 'kjaniga@ucr.edu');1);
SET @RVRSIDE_RUA_PND_RVW = LAST_INSERT_ID();

INSERT INTO `ua` (`number`;`status_type`;`type`;`expiry_date`;`created_by`;`last_modified_by`;`pi_person_id`;`is_active`)
VALUES ((SELECT (MAX(u.number) + 1) FROM ua u);'PENDING_REVIEW';'MUA';DATE_ADD(NOW(); INTERVAL 1 YEAR);1;1;(select id from Person where eppn = 'kjaniga@ucr.edu');1);
SET @RVRSIDE_MUA_PND_RVW = LAST_INSERT_ID();


-- UA Limits
/*
-- Query: SELECT * FROM radsafety.ua_limit
-- Date: 2017-12-05 14:04
*/

-- campus = 10

-- SNM Materials
-- INSERT INTO`ua_limit`
-- (`chemical_form`;`experiment_possession_limit`;`is_sealed_source`;`requested_possession_limit`;`vial_possession_limit`;`elemental_mass`;`net_mass`;`contained_mass`;`radionuclide_id`;`ua_id`;`license_line_number_id`;`physical_form_id`;`use_factor_id`;`eng_control_id`;`form_factor_id`;`unit`;`entered_by_person_id`;`entered_date`)
-- VALUES
-- ('SNM1';3;0;3;3;3;3;3;(select radionuclide_id from radionuclide where name = 'U-233');@MERCED_RUA_APRVD;NULL;2;1;1;1;1;(select id from Person where eppn = 'ksmith23@ucmerced.edu'); NOW());
-- ('SNM2';3;0;3;3;3;3;3;(select radionuclide_id from radionuclide where name = 'U-235');@MERCED_RUA_APRVD;NULL;2;1;1;1;1;(select id from Person where eppn = 'ksmith23@ucmerced.edu'); NOW());

-- SS Materials
INSERT INTO`ua_limit`
(`chemical_form`;`experiment_possession_limit`;`is_sealed_source`;`requested_possession_limit`;`vial_possession_limit`;`radionuclide_id`;`ua_id`;`license_line_number_id`;`physical_form_id`;`use_factor_id`;`eng_control_id`;`form_factor_id`;`unit`;`entered_by_person_id`;`entered_date`)
VALUES
('SS1';3;1;3;3;(select radionuclide_id from radionuclide where name = 'Co-60');@MERCED_RUA_APRVD;14;2;1;1;1;1;(select id from Person where eppn = 'ksmith23@ucmerced.edu'); NOW());
('SS2';3;1;3;3;(select radionuclide_id from radionuclide where name = 'Cs-137');@MERCED_RUA_APRVD;23;2;1;1;1;1;(select id from Person where eppn = 'ksmith23@ucmerced.edu'); NOW());

-- Regular Materials
INSERT INTO`ua_limit`
(`chemical_form`;`experiment_possession_limit`;`is_sealed_source`;`requested_possession_limit`;`vial_possession_limit`;`radionuclide_id`;`ua_id`;`license_line_number_id`;`physical_form_id`;`use_factor_id`;`eng_control_id`;`form_factor_id`;`unit`;`entered_by_person_id`;`entered_date`)
VALUES
('atp1';3;0;3;3;(select radionuclide_id from radionuclide where name = 'H-3');@MERCED_RUA_APRVD;25;2;1;1;3;1;(select id from Person where eppn = 'ksmith23@ucmerced.edu'); NOW());
('atp2';3;0;3;3;(select radionuclide_id from radionuclide where name = 'P-32');@MERCED_RUA_APRVD;5;2;1;1;4;1;(select id from Person where eppn = 'ksmith23@ucmerced.edu'); NOW());



---------------------------------- Bundle details ------------------------------------

-- Core bundle

/*
-- Query: SELECT * FROM radsafety.core_bundle
-- Date: 2017-12-05 15:03
*/
INSERT INTO `core_bundle` (`cs_id`;`name`;`pi_person_id`)
VALUES
('6cc87fa7-2364-4fca-9dd0-e48bd49981b7';'RUA-65001-SMITH';(select id from Person where eppn = 'ksmith23@ucmerced.edu'));
('1592580a-c6ff-403f-b2a2-c60bb7fa6fc7';'RUA-65002-SMITH';(select id from Person where eppn = 'ksmith23@ucmerced.edu'))
ON DUPLICATE KEY UPDATE cs_id=cs_id;

-- UA bundle

/*
-- Query: SELECT * FROM radsafety.ua_bundle
-- Date: 2017-12-05 15:03
*/
INSERT INTO `ua_bundle` (`cs_id`;`name`;`ua_id`)
VALUES
((select cs_id from core_bundle where name = 'RUA-65001-SMITH');'RUA-65001-SMITH';@MERCED_RUA_APRVD);
((select cs_id from core_bundle where name = 'RUA-65002-SMITH');'RUA-65002-SMITH';@MERCED_MUA_APRVD)
ON DUPLICATE KEY UPDATE cs_id=cs_id;

-- Location
/*
-- Query: SELECT * FROM radsafety.location where id in (154; 155)
-- Date: 2017-12-05 15:09
*/
INSERT INTO `location`
(`building_display_name`;`building_key`;`building_primary_name`;`campus_code`;`floor_key`;`floor_name`;`room_key`;`room_number`;`room_id`;`location_address`;`building_id`)
VALUES
('Calaveras Hall';'17';'Calaveras Hall';'10';'29';'First Floor';'1218';'163';'MTB8MTd8Mjl8MTIxOA';NULL;'MTB8MTc')
ON DUPLICATE KEY UPDATE location_address=location_address;

INSERT INTO `location`
(`building_display_name`;`building_key`;`building_primary_name`;`campus_code`;`floor_key`;`floor_name`;`room_key`;`room_number`;`room_id`;`location_address`;`building_id`)
VALUES
('Madera Hall';'20';'Madera Hall';'10';'37';'First Floor';'1314';'119';'MTB8MjB8Mzd8MTMxNA';NULL;'MTB8MjA')
ON DUPLICATE KEY UPDATE location_address=location_address;


-- Core bundle location
INSERT INTO `core_bundle_location`
(`core_bundle_id`;`location_id`)
VALUES
((SELECT id FROM core_bundle where name = 'RUA-65001-SMITH' ORDER BY name ASC limit 1); (SELECT id FROM location WHERE room_id = 'MTB8MTd8Mjl8MTIxOA' ORDER BY room_id ASC limit 1));
((SELECT id FROM core_bundle where name = 'RUA-65001-SMITH' ORDER BY name ASC limit 1); (SELECT id FROM location WHERE room_id = 'MTB8MjB8Mzd8MTMxNA' ORDER BY room_id ASC limit 1));
((SELECT id FROM core_bundle where name = 'RUA-65002-SMITH' ORDER BY name ASC limit 1); (SELECT id FROM location WHERE room_id = 'MTB8MTd8Mjl8MTIxOA' ORDER BY room_id ASC limit 1));
((SELECT id FROM core_bundle where name = 'RUA-65002-SMITH' ORDER BY name ASC limit 1); (SELECT id FROM location WHERE room_id = 'MTB8MjB8Mzd8MTMxNA' ORDER BY room_id ASC limit 1));

-- UA bundle location
INSERT INTO `ua_bundle_location`
(`location_id`;`ua_bundle_id`)
VALUES
((SELECT id FROM location WHERE room_id = 'MTB8MTd8Mjl8MTIxOA' ORDER BY room_id ASC limit 1); (SELECT id FROM ua_bundle WHERE name = 'RUA-65001-SMITH' ORDER BY name ASC limit 1));
((SELECT id FROM location WHERE room_id = 'MTB8MjB8Mzd8MTMxNA' ORDER BY room_id ASC limit 1); (SELECT id FROM ua_bundle WHERE name = 'RUA-65001-SMITH' ORDER BY name ASC limit 1));
((SELECT id FROM location WHERE room_id = 'MTB8MTd8Mjl8MTIxOA' ORDER BY room_id ASC limit 1); (SELECT id FROM ua_bundle WHERE name = 'RUA-65002-SMITH' ORDER BY name ASC limit 1));
((SELECT id FROM location WHERE room_id = 'MTB8MjB8Mzd8MTMxNA' ORDER BY room_id ASC limit 1); (SELECT id FROM ua_bundle WHERE name = 'RUA-65002-SMITH' ORDER BY name ASC limit 1));

-- UA bundle person
/*
-- Query: SELECT * FROM radsafety.ua_bundle_person limit 1
-- Date: 2017-12-06 16:38
*/
INSERT INTO
`ua_bundle_person`
(`person_id`;`ua_bundle_id`;`is_authorized_to_work`;`dosimetry_account_id`;`is_delegate`;`created_by`;`created_date`;`last_modified_by`;`last_modified_date`;`date_added`;`date_removed`;`added_to_rua`;`active`)
VALUES
((select id from Person where eppn = 'ksmith23@ucmerced.edu');(select id from ua_bundle where name = 'RUA-65001-SMITH');0;NULL;0;1;'2017-12-06 16:34:35';1;'2017-12-06 16:34:35';'2017-12-06 16:34:35';NULL;0;1);
((select id from Person where eppn = 'ksmith23@ucmerced.edu');(select id from ua_bundle where name = 'RUA-65002-SMITH');0;NULL;0;1;'2017-12-06 16:34:35';1;'2017-12-06 16:34:35';'2017-12-06 16:34:35';NULL;0;1);


------------------------------ RPM Details ------------------------------------------------

/*
-- Query: SELECT * FROM radsafety.rpm
-- Date: 2017-12-05 15:43
*/
INSERT INTO `rpm`
(`machine_id`;`ua_id`;`location_id`;`dph_number`;`type`;`number_of_tubes`;`manufacturer`;`model`;`maximum_current`;`maximum_voltage`;`max_time`;`normal_current`;`normal_voltage`;`normal_time`;`use_code`;`hazard_class`;`active`;`on_license`)
VALUES
('12312';@MERCED_MUA_APRVD;(SELECT id FROM location WHERE room_id = 'MTB8MTd8Mjl8MTIxOA');'233';'sds';2;'sdfdf';'wfsdf2';'2';'2';'22';'2';'2';'22';'XCH';'II';1;1);
('44566';@MERCED_MUA_APRVD;(SELECT id FROM location WHERE room_id = 'MTB8MjB8Mzd8MTMxNA');'112';'sds';2;'sdfdf';'wfsdf2';'2';'2';'22';'2';'2';'22';'XCH';'II';1;1);


-- Survey Data
INSERT INTO `survey`
(`ua_id`; `survey_type`; `assigned_to`; `performed_by`; `performed_date`; `due_date`)
VALUES
(@MERCED_RUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2016-10-31 00:00:00';  '2017-12-25 00:00:00');
(@MERCED_RUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2016-11-26 00:00:00';  '2017-11-24 00:00:00');
(@MERCED_RUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2016-09-22 00:00:00';  '2017-10-23 00:00:00');
(@MERCED_RUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2016-07-19 00:00:00';  '2017-09-20 00:00:00');
(@MERCED_RUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2016-05-19 00:00:00';  '2017-08-21 00:00:00');
(@MERCED_RUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2016-04-18 00:00:00';  '2017-10-10 00:00:00');
(@MERCED_RUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2016-10-17 00:00:00';  '2017-10-11 00:00:00');
(@MERCED_RUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2015-10-10 00:00:00';  '2017-10-21 00:00:00');
(@MERCED_MUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2016-10-11 00:00:00';  '2017-09-11 00:00:00');
(@MERCED_MUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2016-10-14 00:00:00';  '2017-07-21 00:00:00');
(@MERCED_MUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2016-10-15 00:00:00';  '2017-06-15 00:00:00');
(@MERCED_MUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2016-10-18 00:00:00';  '2017-05-16 00:00:00');
(@MERCED_MUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2016-10-19 00:00:00';  '2017-04-17 00:00:00');
(@MERCED_MUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2016-10-02 00:00:00';  '2017-03-18 00:00:00');
(@MERCED_MUA_APRVD; 'ROUTINE'; (select id from Person where eppn = 'ksmith23@ucmerced.edu'); (select id from Person where eppn = 'ksmith23@ucmerced.edu'); '2016-10-01 00:00:00';  '2017-02-19 00:00:00');

/*Core Collection */
INSERT INTO `core_collection` (`id`; `collection_id`; `collection_name`) VALUES ('1'; 'de8b4b14-b2a2-454c-b402-22cc0771d08e'; 'Test Collection');

UPDATE `ua` SET `core_collection_id`='1' WHERE `id`='103';
UPDATE `ua` SET `core_collection_id`='1' WHERE `id`='104';
UPDATE `ua` SET `core_collection_id`='1' WHERE `id`='105';
UPDATE `ua` SET `core_collection_id`='1' WHERE `id`='106';
UPDATE `ua` SET `core_collection_id`='1' WHERE `id`='107';
UPDATE `ua` SET `core_collection_id`='1' WHERE `id`='108';
UPDATE `ua` SET `core_collection_id`='1' WHERE `id`='109';
UPDATE `ua` SET `core_collection_id`='1' WHERE `id`='110';


-- UA TYPE UPDATE --
UPDATE ua SET type = 'RAM' where id  IN (1;2;3;4;5;6;7;8;100;103;104;105;106;107;108;109;110;112;114;116;118);
UPDATE ua SET type = 'RPM' where id  IN (111;113;115;117;119);


-- Ua
UPDATE ua set no_charge = 0 where id IN (1;2;3;4;5;6;7;8;100;103;104;105;106;107;108;109;110;112;114;116;118;111;113;115;117;119);
UPDATE ua set other = 0 where id IN (1;2;3;4;5;6;7;8;100;103;104;105;106;107;108;109;110;112;114;116;118;111;113;115;117;119);
