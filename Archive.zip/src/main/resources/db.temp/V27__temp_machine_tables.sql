

CREATE TABLE temp_xrray  (
	rua       	varchar(25) NULL;
	lastname  	varchar(50) NULL;
	firstname 	varchar(50) NULL;
	department	varchar(50) NULL;
	dept_code 	varchar(25) NULL;
	co_pi1    	varchar(25) NULL;
	rechargeno	varchar(25) NULL;
	building  	varchar(50) NULL;
	room      	varchar(25) NULL;
	typemachin	varchar(25) NULL;
	machcode  	varchar(25) NULL;
	billed    	int(11) NULL;
	purpose   	varchar(25) NULL;
	manufact  	varchar(25) NULL;
	tmanufact 	varchar(25) NULL;
	model     	varchar(25) NULL;
	tmodel    	varchar(25) NULL;
	ucdno     	varchar(25) NULL;
	serialno  	varchar(25) NULL;
	tserialno 	varchar(25) NULL;
	maxma     	int(11) NULL;
	maxkvp    	int(11) NULL;
	normkvp   	int(11) NULL;
	normma    	varchar(25) NULL;
	scheddate 	varchar(25) NULL;
	lastdate  varchar(25) NULL;
	term      	varchar(25) NULL;
	termdate  	varchar(25) NULL;
	comments  	varchar(8000) NULL;
	collimator	varchar(25) NULL;
	cntlmanu  	varchar(25) NULL;
	tubeyear  	varchar(25) NULL;
	cntlmodel 	varchar(25) NULL;
	cntrserl  	varchar(25) NULL
	);

CREATE TABLE temp_muamap  (
	rua 	varchar(25) NULL;
	eppn	varchar(50) NULL
	);


