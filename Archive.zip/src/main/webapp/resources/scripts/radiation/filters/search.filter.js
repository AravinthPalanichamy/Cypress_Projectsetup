'use strict';

angular.module('app').filter('search', function() {
  return function(values, term, fields) {
    term = (term || '').replace(/[.?*+^$,[\]\\(){}#|-]/g, "\\$&").split(' ');
    values = values || [];
    fields = fields || [];

    if (fields.length) {
      return values.filter(function(value) {
        return _.every(term, function(t) {
          return _.some(fields, function(field) {
            return value[field] && value[field].match(new RegExp(t, 'i'));
          });
        });
      });
    } else {
      return values.filter(function(value) {
        return _.every(term, function(t) {
          return value.match(new RegExp(t, 'i'));
        });
      });
    }
  };
});
