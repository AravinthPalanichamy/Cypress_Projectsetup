'use strict';

angular.module('app').filter('ruaPiName', function() {

  // sort by lastname
  function sortByLastName(a, b) {
    var nameA = a.pi.lastName.toUpperCase(); // ignore upper and lowercase
    var nameB = b.pi.lastName.toUpperCase(); // ignore upper and lowercase
    if (nameA < nameB) {
      return -1;
    }
    if (nameA > nameB) {
      return 1;
    }

    // names must be equal
    return 0;
  }

  return function(collection, searchText, pwSearch) {
    var output = [], searchRegex = '';
    searchRegex = '('.concat(searchText.replace(/\s/gi, ')[\\s|\\w|,|-].*(')).concat(')[\\s|\\w|,|-].*');
    var regex = new RegExp(searchRegex, 'gi');

    angular.forEach(collection, function(ua) {
      var radionuclides = ua.radionuclides ? ua.radionuclides.join() : [];
      var fullText = ''.concat(ua.pi.lastName).concat(' ')
        .concat(ua.pi.firstName).concat(' ')
        .concat(ua.number).concat(' ');

      // enable plannedwork / radionuclide / isotope search only for RSO
      fullText = pwSearch ? fullText.concat(radionuclides).concat(' ') : fullText;

      if (fullText.search(regex) !== -1) {
        if (!pwSearch) {
          ua.radionuclides = [];
        }
        output.push(ua);
      }
    });

    (output.length > 0) ? output.sort(sortByLastName) : output.push('No Results Found');
    return output;
  };
});
