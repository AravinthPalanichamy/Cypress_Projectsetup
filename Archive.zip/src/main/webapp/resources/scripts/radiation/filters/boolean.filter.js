'use strict';

angular.module('app').filter('boolean', function() {
  return function(input, visualRepresentation) {
    if (visualRepresentation) {
      return input ? '<div class="text-center"><i class="fa fa-2x fa-check-square-o" aria-hidden="true"></i></div>' : '<div class="text-center"><i class="fa fa-2x fa-square-o" aria-hidden="true"></i></div>';
    }
    return (input).toUpperCase();
  };
});
