'use strict';

angular.module('app').filter('locationGroupBy', function() {
  var generateHtml = function(map) {
    var html = "<ul class='list-unstyled location-group-by'>";
    _.forEach(map, function(value, key) {
      html = html + "<li>";
      html = html + "<strong>" + key + ": &nbsp;</strong><small>" + value.join(", ") + "</small>";
      html = html + "</li>";
    });

    html = html + "</li>";
    return html;
  };

  return function(input) {
    var items = (input || '').split('||') || [];
    var map = {};

    _.forEach(items, function(item) {
      var buildingTokens = item.split('$$') || [];
      var key = buildingTokens[0].trim() || '';
      var room = buildingTokens[2] || buildingTokens[1] || '';

      var array = room.split("::");
      if (array && array.length === 2) {
        if (!map[key]) {
          map[key] = [];
        }
        map[key].push(array[1].trim());
      }
    });
    return generateHtml(map);
  };
});
