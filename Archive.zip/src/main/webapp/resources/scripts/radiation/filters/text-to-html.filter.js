'use strict';

angular.module('app').filter('textToHtml', function($sce) {
  function htmlToPlaintext(text) {
    return String(text).replace(/<[^>]+>/gm, '');
  }

  return function(text) {
    var isCurrentlyInList = false;
    var html = '';

    text = htmlToPlaintext(text);

    if (text) {
      var lines = text.split('\n');

      angular.forEach(lines, function(line) {
        var firstChar = line.trim().charAt(0);

        if (['*', '-'].indexOf(firstChar) >= 0) {
          line = line.substr(1, line.length);

          if (!isCurrentlyInList) {
            line = '<ul><li>' + line + '</li>';
            isCurrentlyInList = true;
          } else {
            line = '<li>' + line + '</li>';
          }
        } else if (isCurrentlyInList) {
          isCurrentlyInList = false;

          line = '</ul>' + line + '<br/>';
        } else {
          isCurrentlyInList = false;

          line = line + '<br/>';
        }

        html = html + line;
      });
    } else {
      html = text;
    }

    return $sce.trustAsHtml(html);
  };
});
