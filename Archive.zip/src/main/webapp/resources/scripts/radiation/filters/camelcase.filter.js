'use strict';

angular.module('app').filter('camelcase', function() {
  var skipMap = {
    NA: 'N/A',
    OFF_SITE: 'Offsite'
  };
  return function(input) {
    input = input ? input : '';
    return skipMap[input] ? skipMap[input] : input.toLowerCase().replace(/_/g, ' ').replace(/^(.)|\s(.)/g, function($1) {
        return $1.toUpperCase();
      });
  };
});
