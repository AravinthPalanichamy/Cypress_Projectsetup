'use strict';

angular.module('app').filter("dateFilter", function() {

  return function(items, from, to) {
    if (from && to) {
      var retArray = [];

      angular.forEach(items, function(obj) {
        angular.forEach(obj.materialOrders, function(materialOrder) {
          var nextDueDate = materialOrder.sealedSourceInfo.nextDueDate;

          if (nextDueDate >= from && nextDueDate <= to) {
            retArray.push(obj);

          }
        });

      });

      return retArray;
    } else {
      return items;
    }
  };

});
