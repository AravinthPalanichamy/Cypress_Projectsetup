'use strict';

angular.module('app').filter('formAccessTitle', function() {
  return function(input, isAdmin, hasId) {
    return (isAdmin) ? (hasId ? 'Edit ' : 'New ') : 'View';
  };
});
