'use strict';

angular.module('app').filter('trainingStatus', function() {
  return function(input, training) {
    var status = (input && !training) ? input : training;
    return (status && status.trainingCompletedDate !== null)
            ? (status.trainingExpired ? 'Expired ' : 'Current ')
            : 'No Records';
  };
});
