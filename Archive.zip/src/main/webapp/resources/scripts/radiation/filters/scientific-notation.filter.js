'use strict';

angular.module('app').filter('scientific', function() {
  return function(input) {
    var numToReturn = _.toNumber(input);
    numToReturn = Number(numToReturn);
    if ((numToReturn || (0 === numToReturn)) && (numToReturn.toPrecision)) {
      if (numToReturn < 1.0e-3) {
        if (numToReturn < 1.0e-10) {
          numToReturn = "0.00000";
        } else {
          numToReturn = numToReturn.toExponential(3);
        }
      } else {
        if (numToReturn < 1000) {
          numToReturn = Number(numToReturn).toFixed(5);
        } else {
          numToReturn = numToReturn.toExponential(3);
        }
      }
    } else {
      numToReturn = "--";
    }
    return numToReturn;
  };
});
