'use strict';

angular.module('app')
      .factory('AuthenticationInterceptor', function($q, $window, $location, $cookies, $injector, TOKEN_URL) {
  return {
    request: function(config) {
      config.headers = config.headers || {};
      var token = $cookies.get('authtoken') ? $cookies.get('authtoken') : $window.sessionStorage.getItem('authtoken');
      if (token) {
        config.headers['Authorization'] = 'Bearer ' + token;
      }
      return config;
    },

    responseError: function(response) {
      //injected manually to get around circular dependency problem.
      var ErrorService = $injector.get('ErrorService');
      if (response.status === 401) {
        $window.location.replace(TOKEN_URL);
      } else if (response.status === 403) {
        $location.path('/deny');
      }
      return $q.reject(ErrorService.error(response));
    }
  };
});
