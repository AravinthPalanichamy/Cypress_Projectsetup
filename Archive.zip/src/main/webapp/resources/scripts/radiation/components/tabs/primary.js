'use strict';

angular.module('app').component("rssTab", {
  templateUrl: 'resources/scripts/radiation/components/tabs/primary.html',
  controllerAs: 'ctrl',

  controller: function($location, $scope, $window, CONTEXT_PATH) {
    var ctrl = this;
    ctrl.hasChanged = false;
    ctrl.secondaryTabs = {};
    ctrl.tabClicked = false;
    ctrl.tabIndex = 0;
    ctrl.url;
    ctrl.basePath = CONTEXT_PATH + '/#';

    ctrl.$onChanges = function() {
      if (ctrl.tabs) {

        var path = $location.path().match(/\/[a-zA-Z-]*/g)[0];
        var index = _.findIndex(ctrl.tabs, function(tab) {
          return tab.url === path;
        });

        if (index > -1) {
          ctrl.tabClicked = true;
          ctrl.tabIndex = index;
          ctrl.url = ctrl.tabs[index].url;
          ctrl.secondaryTabs = ctrl.tabs[index].subGroup;
        } else if (path.match(/home/i)) {
          $window.location = CONTEXT_PATH;
        } else {
          if (path.match(/deny/i) || path.match(/error/i)) {
            $location.search({}); // clears all search params if error is thrown
          }
          $location.path(path);
        }
      }
    };

    $scope.$on('$routeChangeStart', function(next, current) {
      ctrl.$onChanges();
    });

    ctrl.activeCSS = function(index, tab) {
      return ctrl.tabClicked ? ctrl.tabIndex === index : false;
    };
  },

  bindings: {
    tabs: '<'
  }
});
