'use strict';

angular.module('app').controller('RpmDocumentCtrl', function(uiGridConstants, RpmService, AttachmentService, ReferenceService, TableHeaderCollections, UtilService, ConfirmModelService, PermissionService) {
  var $docCtrl = this;
  $docCtrl.options = {
    attachmentType: "RPM",
    attachmentTypes: null
  };
  $docCtrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
  $docCtrl.tableHeaders = {};

  $docCtrl.init = function(rpm) {
    $docCtrl.rpm = rpm;
    $docCtrl.getTableHeader();
    if (PermissionService.hasPermission()) {
      $docCtrl.buttonList = [{
        label: "Add Document",
        action: $docCtrl.uploadDocument
      }];
    }
    $docCtrl.getData();
  };

  $docCtrl.getTableHeader = function() {
    $docCtrl.tableHeaders = {
      EDIT: Object.assign({}, $docCtrl.tableHeaderCollections.EDIT, {cellTemplate: "rpm-attachment-edit.html"}),
      ATTACHMENT_FILENAME: Object.assign({}, $docCtrl.tableHeaderCollections.ATTACHMENT_FILENAME),
      TITLE: Object.assign({}, $docCtrl.tableHeaderCollections.TITLE),
      DESCRIPTION: Object.assign({}, $docCtrl.tableHeaderCollections.DESCRIPTION),
      ATTACHMENT_SIZE: Object.assign({}, $docCtrl.tableHeaderCollections.ATTACHMENT_SIZE),
      ATTACHMENT_REFERENCE_DATE: Object.assign({}, angular.copy($docCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'referenceDate',
        displayName: 'Reference Date',
        width: 150
      }),
      LAST_MODIFIED_DATE: Object.assign({}, angular.copy($docCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'lastModifiedDate',
        displayName: 'Last Modified Date',
        width: 150
      }),
      DELETE: {
        field: 'Delete',
        displayName: 'Delete',
        cellTemplate: 'rpm-attachment-delete.html',
        width: 65
      }
    };

    $docCtrl.columns = Object.values($docCtrl.tableHeaders);
  };
  $docCtrl.getData = function() {
    RpmService.getAllRpmAttachments({rpmId: $docCtrl.rpm.id}).$promise.then(function(data) {
      $docCtrl.data = data;
    });
  };

  $docCtrl.uploadDocument = function() {
    AttachmentService.uploadAttachment($docCtrl.rpm, null, $docCtrl.options, $docCtrl.saveAttachment);
  };

  $docCtrl.editDocument = function(rpmId, attachmentId) {
    var attachment = _.find($docCtrl.data, {id: attachmentId});
    AttachmentService.uploadAttachment($docCtrl.rpm, attachment, $docCtrl.options, $docCtrl.saveAttachment);
  };

  $docCtrl.deleteDocument = function(rpmId, attachmentId) {
    var attachment = _.find($docCtrl.data, {id: attachmentId});
    ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE, {message: "Are you sure you want to delete the document <strong>" + attachment.fileName + "</strong>?"}, function() {
      RpmService.deleteRpmAttachment({
        rpmId: rpmId,
        attachmentId: attachmentId
      }).$promise.then(function() {
        $docCtrl.getData();
      });
    });
  };

  $docCtrl.downloadDocument = function(rpmId, attachmentId) {
    AttachmentService.downloadAttachment(attachmentId);
  };

  $docCtrl.saveAttachment = function(rpm, attachment) {
    var isUpdate = _.some($docCtrl.data, {id: attachment.id});
    var attachments = _.map($docCtrl.data, function(a) {
      return {id: a.id};
    });
    if (!isUpdate) {
      attachments.push({id: attachment.id});
    }
    RpmService.updateRpmAttachments({rpmId: rpm.id}, attachments).$promise.then(function() {
      $docCtrl.getData();
    });
  };

  $docCtrl.checkEditPermissions = function(row) {
    return row.entity.id
            && row.entity.$$action !== 'DELETED'
            && PermissionService.hasPermission();
  };

})
  .run(function($templateCache) {
    var attachmentEditTemplate = '<div class="edit-link">'
      + ' <span ng-if="grid.appScope.parentScope.checkEditPermissions(row)"><a ng-href="" ng-click="grid.appScope.parentScope.editDocument(grid.appScope.parentScope.rpm.id, row.entity.id)" class="glyphicon glyphicon-edit" title="Edit Document"></a></span>'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.downloadDocument(grid.appScope.parentScope.rpm.id, row.entity.id)" target="_blank" title="Download Document" class="glyphicon glyphicon-download-alt"></a></span>'
      + '</div>';
    $templateCache.put('rpm-attachment-edit.html', attachmentEditTemplate);

    var attachmentDeleteTemplate = '<div class="delete-link">'
      + ' <span ng-if="grid.appScope.parentScope.checkEditPermissions(row)"><a ng-href="" ng-click="grid.appScope.parentScope.deleteDocument(grid.appScope.parentScope.rpm.id, row.entity.id)" class="glyphicon glyphicon-trash text-danger" title="Delete Document"></a></span>'
      + '</div>';
    $templateCache.put('rpm-attachment-delete.html', attachmentDeleteTemplate);
  });
