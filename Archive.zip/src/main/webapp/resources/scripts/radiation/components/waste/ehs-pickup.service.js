"use strict";

angular.module('app').factory('EhsPickupService', function(InventoryService, WasteService, PrintService, FileSaver) {

  var service = {

    kickOffProcess: function(wasteTag, container, options, callback) {

      var ruaId = container.ownerRuaId;
      var trackingNumber;
      var errorMessage;

      InventoryService.addContainerWithStatus({active: false}, container, function(containerResponse) {
        wasteTag.container = containerResponse.toJSON();
        var material = _.cloneDeep(options.material);
        material.container = _.cloneDeep(wasteTag.container);
        material.inventoryStatusType = 'IN_LOCAL_WASTE';
        useMaterial(material)
          .then(createWasteTag);
      });

      function useMaterial(material) {
        return InventoryService.useMaterial(material).$promise;
      }

      function createWasteTag() {
        return WasteService.createWasteTag({ruaId: ruaId}, wasteTag)
          .$promise.then(function(wasteResponse) {
            if (wasteResponse.$resolved && wasteResponse.trackingNumber) {
              trackingNumber = wasteResponse.trackingNumber;
              requestPickup(wasteResponse);
            } else {
              callback(trackingNumber, wasteResponse.errorMessage);
            }
          });
      }

      function requestPickup(wasteResponse) {
        WasteService.requestPickup({}, wasteResponse)
          .$promise.then(function(pickupResponse) {
          if (pickupResponse.$resolved && !pickupResponse.errorMessage) {
            emptyContainer(wasteResponse);
          } else if (pickupResponse.errorMessage) {
            errorMessage = pickupResponse.errorMessage;
          }
        });
      }

      function emptyContainer(wasteResponse) {
        InventoryService.emptyContainer({containerId: wasteResponse.container.id}, wasteResponse.container, function(emptyContainerResponse) {
          printWasteTag(wasteResponse.trackingNumber);
          callback(trackingNumber, errorMessage);
        });
      }

      function printWasteTag(trackingNumber) {
        WasteService.getWasteToken({trackingNumber: trackingNumber}).$promise
          .then(function(res) {
            PrintService.printWasteTag({token: res.token}, {})
              .$promise.then(function(response) {
              FileSaver.saveAs(response.data.file, response.data.filename);
            });
          });
      }
    }

  };

  return service;

});
