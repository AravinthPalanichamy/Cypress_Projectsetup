"use strict";

angular.module('app').factory('WasteFormService', function($uibModal, StaticCollections, LocationService) {

  var service = {
    isOpen: false,

    openModal: function(rua, container, options, callback) {

      if (service.isOpen) return true;
      $uibModal.open({
        templateUrl: 'resources/scripts/radiation/components/waste/_waste-form.html',
        controllerAs: '$wasteCtrl',
        size: 'lg',
        keyboard: false,
        backdrop: 'static',
        resolve: {},
        controller: function($uibModalInstance) {
          var $wasteCtrl = this;
          service.isOpen = true;

          $wasteCtrl.init = function() {
            $wasteCtrl.rua = angular.copy(rua);
            $wasteCtrl.container = angular.copy(container);

            $wasteCtrl.chemicalName = [];
            $wasteCtrl.chemicalPercentage = [];
            $wasteCtrl.wasteMaterialTypeHash = StaticCollections.wasteMaterialTypeHash;
            $wasteCtrl.wasteHazardClass = StaticCollections.wasteHazardClass;
            $wasteCtrl.wasteTag = {};
            $wasteCtrl.wasteTag.wasteTagHazards = [];
            $wasteCtrl.wasteTag.wasteTagChemicals = [];
            $wasteCtrl.chemMaterials = [{}];
            $wasteCtrl.totalChemicalPercentage = 0;
            $wasteCtrl.wasteError = {};
            $wasteCtrl.requestingPickup = options.requestingPickup;

            if (options.requestingPickup) {
              $wasteCtrl.requestingPickup = options.requestingPickup;
            }

            if (options.wasteTag) {
              options.updatingWasteTag = true;
              $wasteCtrl.assignExistingValue(options.wasteTag);
            }

            $wasteCtrl.getLocationFromContainerOwer();
          };

          $wasteCtrl.cancel = function() {
            service.isOpen = false;
            $uibModalInstance.dismiss('cancel');
          };

          $wasteCtrl.checkHazardClass = function(hazardClass) {
            $wasteCtrl.wasteError.hazardClassError = false;
            return _.find($wasteCtrl.wasteTag.wasteTagHazards, ['hazardName', hazardClass.hazardName]);
          };

          $wasteCtrl.onHazardClick = function(hazardClass) {
            $wasteCtrl.hazardClassError = false;
            if (!$wasteCtrl.checkHazardClass(hazardClass)) {
              $wasteCtrl.wasteTag.wasteTagHazards.push(hazardClass);
            } else {
              $wasteCtrl.wasteTag.wasteTagHazards.splice($wasteCtrl.wasteTag.wasteTagHazards.indexOf(hazardClass), 1);
            }
          };

          $wasteCtrl.onAddAnotherChemical = function() {
            if ($wasteCtrl.totalChemicalPercentage < 100) {
              $wasteCtrl.chemMaterials.push({});
            }
          };

          $wasteCtrl.onChemValueChange = function() {
            $wasteCtrl.totalChemicalPercentage = 0;
            $wasteCtrl.updateTotalPercentage();
          };

          $wasteCtrl.onFormSubmit = function() {
            $wasteCtrl.wasteError = {};
            $wasteCtrl.wasteTag.container = $wasteCtrl.container;

            $wasteCtrl.wasteTag.wasteTagHazards = _.map($wasteCtrl.wasteTag.wasteTagHazards, function(hazard) {
              return {hazardName: hazard.hazardName};
            });

            $wasteCtrl.wasteTag.wasteTagChemicals = []; // resetting the value before adding new values;
            _.forEach($wasteCtrl.chemicalPercentage, function(value, key) {
              $wasteCtrl.wasteTag.wasteTagChemicals.push({
                chemicalName: $wasteCtrl.chemicalName[key],
                chemicalPercentage: $wasteCtrl.chemicalPercentage[key]
              });
            });

            if ($wasteCtrl.requestingPickup) {
              options.requestingPickup = $wasteCtrl.requestingPickup;
            }

            if ($wasteCtrl.updatingSharedContainer()) {
              var sharedRuas = _.reduce($wasteCtrl.wasteTag.container.ruasWithAccess, function(names, rua) {
                return ' RUA # ' + rua.number + ' ' + names;
              }, '');
              var sharedBag = ' This waste bag is shared by ';
              if (!(_.includes($wasteCtrl.wasteTag.comments, sharedBag))) {
                $wasteCtrl.wasteTag.comments += '\n\n ' + sharedBag + sharedRuas;
              }
            }

            if ($wasteCtrl.isFormValid() && _.isEmpty($wasteCtrl.wasteError)) {
              $wasteCtrl.mapWasteType();
              $wasteCtrl.mapWasteLocation();
              $wasteCtrl.savingInProgress = true;
              callback($wasteCtrl.wasteTag, options);
              $wasteCtrl.cancel();
            }
          };

          $wasteCtrl.updatingSharedContainer = function() {
            return !$wasteCtrl.wasteTag.trackingNumber && !_.isEmpty($wasteCtrl.wasteTag.container) && $wasteCtrl.wasteTag.container.ruasWithAccess.length > 1;
          };

          $wasteCtrl.updateTotalPercentage = function() {
            _.forEach($wasteCtrl.chemicalPercentage, function(value) {
              $wasteCtrl.totalChemicalPercentage += value;
            });
          };

          $wasteCtrl.isFormValid = function() {
            if (!$wasteCtrl.wasteTag.location) {
              $wasteCtrl.wasteError.locationError = true;
            }
            if (!$wasteCtrl.wasteTag.wasteMaterialType) {
              $wasteCtrl.wasteError.wasteMaterialTypeError = true;
            }
            if ($wasteCtrl.wasteTag.wasteMaterialType === 'LIQUID_VIAL' && !$wasteCtrl.wasteTag.cocktail) {
              $wasteCtrl.wasteError.wasteCocktailError = true;
            }
            if (($wasteCtrl.wasteTag.wasteMaterialType === 'LIQUID' || $wasteCtrl.wasteTag.wasteMaterialType === 'MIXED')) {
              if (!$wasteCtrl.wasteTag.pH) {
                $wasteCtrl.wasteError.wastePhError = true;
              }
              if (!$wasteCtrl.wasteTag.wasteSize) {
                $wasteCtrl.wasteError.wasteVolumeError = true;
              }
            }
            if ($wasteCtrl.wasteTag.wasteMaterialType === 'MIXED') {
              if (!$wasteCtrl.wasteTag.wasteTagHazards.length) {
                $wasteCtrl.wasteError.hazardClassError = true;
              }
              if (!$wasteCtrl.wasteTag.wasteTagChemicals.length) {
                $wasteCtrl.wasteError.chemicalsError = true;
              }
            }

            return $wasteCtrl.wasteError;
          };

          $wasteCtrl.mapWasteType = function() {
            if ($wasteCtrl.wasteTag.wasteMaterialType === 'MIXED') {
              $wasteCtrl.wasteTag.wasteTagType = 'MIX';
              $wasteCtrl.wasteTag.wasteMaterialType = 'LIQUID';
            } else {
              $wasteCtrl.wasteTag.wasteTagType = 'RAD';
            }

            if ($wasteCtrl.wasteTag.wasteMaterialType === 'LIQUID' || $wasteCtrl.wasteTag.wasteMaterialType === 'MIXED') {
              $wasteCtrl.wasteTag.wastePhysicalState = "LIQUID";

            } else {
              $wasteCtrl.wasteTag.wastePhysicalState = "SOLID";
            }
          };

          $wasteCtrl.assignExistingValue = function(wasteTag) {
            $wasteCtrl.wasteTag = angular.copy(wasteTag);

            if ($wasteCtrl.wasteTag.wasteTagType === 'MIX') {
              $wasteCtrl.wasteTag.wasteMaterialType = 'MIXED';

              $wasteCtrl.chemMaterials = $wasteCtrl.wasteTag.wasteTagChemicals;
              _.forEach($wasteCtrl.chemMaterials, function(value, key) {
                $wasteCtrl.chemicalName[key] = value.chemicalName;
                $wasteCtrl.chemicalPercentage[key] = value.chemicalPercentage;
              });

              $wasteCtrl.updateTotalPercentage();
            }
          };

          $wasteCtrl.getLocationFromContainerOwer = function() {
            var ownerRua;
            if (_.isEmpty($wasteCtrl.container)) {
              ownerRua = $wasteCtrl.rua;
            } else {
              ownerRua = _.find($wasteCtrl.container.ruasWithAccess, function(rua) {
                return rua.id === $wasteCtrl.container.ownerRuaId;
              });
            }

            LocationService.findCpuLocations().$promise.then(function(response) {
              var cpuLocations = _.forEach(response, function(loc) {
                return loc.roomNumber = loc.roomNumber + ' (Central Pickup)';
              });

              $wasteCtrl.useLocations = _.map(ownerRua.uaBundle.uaBundleLocations, function(bundleLocation) {
                return bundleLocation.location;
              }).concat(cpuLocations);

              $wasteCtrl.wasteTag.location = _.find($wasteCtrl.useLocations, function(location) {
                if (!(_.isEmpty($wasteCtrl.wasteTag.cpuLocation))) {
                  return location.id === $wasteCtrl.wasteTag.cpuLocation.id;
                } else if ($wasteCtrl.wasteTag.location && $wasteCtrl.wasteTag.location.roomId) {
                  return location.roomId === $wasteCtrl.wasteTag.location.roomId;
                } else if ($wasteCtrl.container && $wasteCtrl.container.location) {
                  return location.roomId === $wasteCtrl.container.location.roomId;
                } else if (options.material) {
                  return location.roomId === options.material.storageLocation.roomId;
                }
              });
            });
          };

          $wasteCtrl.mapWasteLocation = function() {
            if ($wasteCtrl.wasteTag.location.isCpu) {
              $wasteCtrl.wasteTag.cpuLocation = $wasteCtrl.wasteTag.location;
              if ($wasteCtrl.wasteTag.container) {
                $wasteCtrl.wasteTag.location = $wasteCtrl.container.location;
              } else {
                $wasteCtrl.wasteTag.location = options.material.storageLocation;
              }
            }
          };
        }
      });
    }
  };

  return service;
});

