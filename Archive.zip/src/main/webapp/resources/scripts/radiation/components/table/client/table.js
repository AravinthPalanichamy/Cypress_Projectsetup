'use strict';

angular.module('app').component("rssTablePlain", {
  templateUrl: 'resources/scripts/radiation/components/table/client/table.html',
  controllerAs: 'ctrl',
  controller: function($interval, $q, uiGridConstants, $scope, $timeout, $location, StaticCollections, PageDomainService) {
    var ctrl = this;

    var SCROLL_NEVER = 0;
    var SCROLL_ALWAYS = 1;
    var SCROLL_WHEN_NEEDED = 2;

    ctrl.tableTemplate = ctrl.name || 'table-client.html';
    ctrl.pageDomainType = StaticCollections.pageDomainType;

    // INIT
    ctrl.tableInit = function() {
      var rowsRenderedTimeout;
      ctrl.gridApi;
      ctrl.gridOptions = {
        headerTemplate: 'resources/scripts/radiation/components/table/headerTemplate.html',
        rowTemplate: 'resources/scripts/radiation/components/table/rowTemplate.html',
        rowHeight: 'auto',
        data: ctrl.data,
        enableFiltering: ctrl.enableFiltering === false ? false : true,
        enableCellEditOnFocus: true,
        gridMenuShowHideColumns: false,
        showGridFooter: false,
        enableGridMenu: false,
        showColumnFooter: false,
        fastWatch: true,
        enableSorting: ctrl.enableSorting === false ? false : true,
        enablePinning: false,
        enablePaginationControls: false,
        paginationPageSize: 10,
        paginationPageSizes: [10, 50, 100, 'All'],
        enableHorizontalScrollbar: SCROLL_WHEN_NEEDED,
        enableVerticalScrollbar: SCROLL_NEVER,
        columnDefs: ctrl.constructColDefs(),
        // Set scope provider to ctrl since we're using ControllerAs syntax
        appScopeProvider: ctrl,
        onRegisterApi: function onRegisterApi(registeredApi) {
          ctrl.gridApi = registeredApi;

          if (ctrl.gridApi.edit) {
            ctrl.gridApi.edit.on.afterCellEdit($scope, function(rowEntity) {
              rowEntity.dirty = true;
            });
          }
          ctrl.gridApi.core.on.rowsRendered(null, function() {
            if (ctrl.parentScope) {
              ctrl.parentScope.filteredRows = ctrl.gridApi.core.getVisibleRows(ctrl.gridApi.grid).map(function(item) {
                return item.entity;
              });
              ctrl.setPageDomain(ctrl.parentScope.filteredRows);
            }
          });
          ctrl.gridApi.core.notifyDataChange(uiGridConstants.dataChange.ALL);
          ctrl.gridApi.core.refreshRows().then(ctrl.tableRefresh);
        },
        excessRows: ctrl.data ? ctrl.data.length : 10
      };
      ctrl.perPage = ctrl.gridOptions.paginationPageSize || 10;
      ctrl.currentPage = 1;
      ctrl.seekPageNumber = 1;
      ctrl.enableClearAllFilters = (ctrl.clearAllFilters !== undefined) ? ctrl.clearAllFilters : true;
      ctrl.setPageDomain();
    };

    ctrl.constructColDefs = function() {
      var columnDefs = [];
      _.forEach(ctrl.columnDef, function(column) {
        var item = ctrl.createItem(column);
        ctrl.handleColumnTypeDefs(item, column);
        columnDefs.push(item);
      });
      return columnDefs;
    };

    ctrl.createItem = function(column) {
      var item = {
        field: column['field'],
        displayName: column['displayName'],
        filter: column['filter'],
        filterCellFiltered: column['filterCellFiltered'],
        enableColumnMenu: column['enableColumnMenu'],
        minWidth: 10,
        width: column['width'],
        enableHiding: false,
        enableCellEdit: column['enableCellEdit'] || false,
        enableFiltering: column['enableFiltering']
      };
      return item;
    };

    ctrl.handleColumnTypeDefs = function(item, column) {
      if (item.displayName === 'Edit' || item.field === 'Delete') {
        ctrl.edit(item, column);
      }
      if (column['cellFilter']) {
        item['cellFilter'] = column['cellFilter'];
      }
      if (column['cellTemplate']) {
        item['cellTemplate'] = column['cellTemplate'];
      }
      if (column['headerCellTemplate']) {
        item['headerCellTemplate'] = column['headerCellTemplate'];
      }
      if (column['editableCellTemplate']) {
        item['editableCellTemplate'] = column['editableCellTemplate'];
      }
      if (column['editDropdownValueLabel']) {
        item['editDropdownValueLabel'] = column['editDropdownValueLabel'];
      }
      if (column['editDropdownIdLabel']) {
        item['editDropdownIdLabel'] = column['editDropdownIdLabel'];
      }
      if (column['editDropdownOptionsArray']) {
        item['editDropdownOptionsArray'] = column['editDropdownOptionsArray'];
      }
      if (column['filterHeaderTemplate']) {
        item['filterHeaderTemplate'] = column['filterHeaderTemplate'];
      }
      if (column['filters']) {
        item['filters'] = column['filters'];
      }
      if (!column['visible']) {
        item['visible'] = column['visible'];
      }
      if (column['sort']) {
        item['sort'] = column['sort'];
      }
      if (column['suppressRemoveSort']) {
        item['suppressRemoveSort'] = column['suppressRemoveSort'];
      }
      if (column['sortDirectionCycle']) {
        item['sortDirectionCycle'] = column['sortDirectionCycle'];
      }
      if (column['cellClass']) {
        item['cellClass'] = column['cellClass'];
      }
      if (column['enableDefaultToDate']) {
        item['enableDefaultToDate'] = column['enableDefaultToDate'];
      }
    };

    ctrl.edit = function(item, column) {
      item['enableFiltering'] = false;
      item['enableSorting'] = false;
      item['enableColumnMenu'] = false;
      item['displayName'] = '';
      item['width'] = column['width'] ? column['width'] : 30;
      item['minWidth'] = 30;
    };

    ctrl.updatePageWithPerPage = function(itemsPerPage) {
      $interval(function() {
        ctrl.gridApi.core.handleWindowResize();
      }, 10);
      itemsPerPage = itemsPerPage === 'All' ? ctrl.gridApi.grid.options.totalItems : itemsPerPage;
      ctrl.gridOptions.paginationPageSize = itemsPerPage;
      ctrl.gridOptions.excessRows = itemsPerPage;
      ctrl.currentPage = 1;
      ctrl.seekPageNumber = 1;
    };

    $scope.$watch('ctrl.data', function(newData, oldData) {
      ctrl.gridOptions.data = newData;
      if (ctrl.gridApi) {
        ctrl.tableRefresh();
      }
    });

    ctrl.href = function(url) {
      $location.path(url);
    };

    ctrl.tableRefresh = function() {
      var rows = ctrl.gridApi.core.getVisibleRows(ctrl.gridApi.grid);
      ctrl.alignPrimaryTable(ctrl.gridApi.grid, rows);
    };

    ctrl.alignPrimaryTable = function(grid, row) {
      var table = _.first(grid.element);
      if ((table || table !== null) && ctrl.gridOptions) {
        $timeout(function() {
          ctrl.isEmptyTable(ctrl.gridOptions.data)
            ? ctrl.isEmptyTable(ctrl.gridOptions.data, table)
            : ctrl.reDrawTable(table);
        }, 10);
      }
    };

    ctrl.isEmptyTable = function(data, table) {
      if ((!data || !data.length) && table) {
        var headerColumns = angular.element(table.getElementsByClassName('ui-grid-header-cell-primary-focus'));
        var maxHeaderHeight = _.get(_.maxBy(headerColumns, 'offsetHeight'), 'offsetHeight', '30px');
        angular.element(table.querySelectorAll('.ui-grid-header-cell-primary-focus')).css('height', maxHeaderHeight + 'px');
        angular.element(table.querySelector('.ui-grid-viewport')).css('height', '0px');
        angular.element(table.querySelector('.ui-grid-viewport')).css('overflow', 'auto !important');
        angular.element(table.querySelector('.ui-grid-viewport')).css('min-height', '0px');
      }
      return !data || !data.length;
    };

    ctrl.reDrawTable = function(table) {
      var headerColumns = angular.element(table.getElementsByClassName('ui-grid-header-cell-primary-focus'));
      var maxHeaderHeight = _.get(_.maxBy(headerColumns, 'offsetHeight'), 'offsetHeight', '30px');
      // set the table elements height
      angular.element(table).parent().css('height', 'auto');
      angular.element(table).css('height', 'auto');

      angular.element(table.querySelector('.ui-grid-header')).css('width', 'fit-content');
      angular.element(table.querySelector('.ui-grid-top-panel')).css('overflow', 'visible');

      angular.element(table.querySelectorAll('.ui-grid-header-cell-primary-focus')).css('height', maxHeaderHeight + 'px');
      angular.element(table.querySelector('.ui-grid-render-container')).css('height', 'auto');
      angular.element(table.querySelector('.ui-grid-render-container-body ')).css('height', 'auto');

      angular.element(table.querySelector('.ui-grid-viewport')).css('height', 'auto');
      angular.element(table.querySelector('.ui-grid-canvas')).css('height', 'auto');
    };

    ctrl.setPageDomain = function(data) {
      ctrl.pageDomain = _.find(ctrl.pageDomainType, {'path': $location.path()});
      if (ctrl.pageDomain) {
        PageDomainService.init(data ? data : ctrl.gridOptions.data, ctrl.pageDomain.key, ctrl.pageDomain.routeTo);
      }
    };

    ctrl.rowHover = function(row) {
      // used to display the changelog items as Add/Update/Delete
      // color identification on mouse hover
      row.isAdded = (row.entity.type === 'I');
      row.isUpdated = (row.entity.type === 'U');
      row.isDeleted = (row.entity.type === 'D');
    };
  },

  bindings: {
    data: '=',
    columnDef: '=',
    name: '=',
    id: '=',
    addRecordUrl: '=',
    parentScope: '=',
    clearAllFilters: '=',
    buttonList: '=',
    onDelete: '&',
    enableFiltering: '=',
    enableSorting: '='
  }

})
  .filter('mapStatus', function(StaticCollections) {
    return function(input) {
      if (!input) {
        return '';
      } else {
        return _.find(StaticCollections.UATypesHash, function(uaObj, key) {
          return uaObj.value === input;
        }).label;
      }
    };
  })
  .run(function($templateCache) {
    $templateCache.put('table-client.html', '<div id="table_client" ui-grid="ctrl.gridOptions" class="data-grid" ng-if="ctrl.gridOptions.data" ui-grid-pinning ui-grid-pagination ui-grid-cellNav></div>');
    $templateCache.put('table-client-editable.html', '<div id="table_client_editable" ui-grid="ctrl.gridOptions" class="data-grid" ng-if="ctrl.gridOptions.data" ui-grid-pinning ui-grid-pagination ui-grid-cellNav ui-grid-edit></div>');
  });
