'use strict';

angular.module('app').directive('personMultiSearch', function() {
  return {
    restrict: 'AE',
    scope: true,
    bindToController: {
      id: '@',
      form: '=',
      label: '@',
      campusCode: '@',
      placeholder: '@',
      allowEmail: '=',
      people: '=',
      selectedPeople: '=ngModel',
      ngRequired: '=ngRequired',
      ngDisabled: '=ngDisabled'
    },
    templateUrl: 'resources/scripts/radiation/components/person-multi-search/person.multi.search.html',
    controllerAs: 'sCtrl',
    link: function(scope) {
      scope.sCtrl.campus_code = {campusCode: scope.sCtrl.campusCode};
    },
    controller: function($http, $q, $filter, PersonService) {
      var sCtrl = this;

      sCtrl.validateTag = function(tag) {
        // valid person object must have userId, firstName, lastName
        if (tag.userId && tag.firstName && tag.lastName) {
          return true;
        }
        if (!sCtrl.allowEmail) {
          return false;
        }

        var pattern = /(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/;
        return pattern.test(tag.email);
      };

      sCtrl.personSearch = function(query, people) {
        return $q(function(resolve, reject) {
          if (!query) {
            return resolve([]);
          }
          if (!people) {
            PersonService.findByName({search: query}).$promise.then(function(response) {
              resolve(response.splice(0, 10));
            }).catch(reject);
          } else {
            resolve($filter('search')(people, query, ['firstName', 'lastName', 'email']));
          }
        });
      };
    }
  };
});
