'use strict';

angular.module('app').directive('ruaMultiSearch', function() {
  return {
    restrict: 'E',
    scope: true,
    bindToController: {
      campusCode: '@',
      ruas: '=',
      selectedRuas: '=ngModel'
    },
    templateUrl: 'resources/scripts/radiation/components/rua-multi-search/rua-multi-search.html',
    controllerAs: 'childCtrl',
    controller: function($http, $q, $filter, PersonService, UaService) {
      var childCtrl = this;

      childCtrl.tags = [];
      childCtrl.placeholder = 'Search for RUA';

      childCtrl.validateTag = function(tag) {
        if (tag.number && tag.id) {
          return true;
        }
      };

      childCtrl.typeaheadLabel = UaService.typeaheadLabel;

      childCtrl.ruaSearch = function(query) {
        return $q(function(resolve, reject) {
          if (query) {
            resolve($filter('search')(childCtrl.ruas, query, ['number']));
          }
        });
      };

      childCtrl.personSearch = function(query, people) {
        return $q(function(resolve, reject) {
          if (!query) {
            return resolve(childCtrl.ruas);
          }
          if (!people) {
            PersonService.findByName({search: query}).$promise.then(function(response) {
              resolve(response.splice(0, 10));
            }).catch(reject);
          } else {
            resolve($filter('search')(childCtrl.ruas, query, ['number']));
          }
        });
      };
    }
  };
});
