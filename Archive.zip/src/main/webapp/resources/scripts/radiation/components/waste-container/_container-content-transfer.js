'use strict';

angular.module('app').controller('ContainerContentTransferCtrl', function($uibModalInstance, InventoryService, container) {
  var $ctrl = this;

  $ctrl.init = function() {
    $ctrl.container = container;
    InventoryService.getTransferableContainers({containerId: $ctrl.container.id}).$promise.then(function(response) {
      $ctrl.wasteContainers = response;
    });
  };

  $ctrl.onSave = function(form, selectedContainer) {
    if (form.$valid) {
      InventoryService.transferContainerMaterials({containerId: $ctrl.container.id}, selectedContainer, function(res) {
        $ctrl.cancel();
      });
    }
  };

  $ctrl.cancel = function() {
    $uibModalInstance.close();
  };

  $ctrl.init();
});
