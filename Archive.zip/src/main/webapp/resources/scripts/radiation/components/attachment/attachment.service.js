'use strict';

angular.module('app').factory('AttachmentService', function($resource, $http, $uibModal, FileSaver, Upload, Blob) {

  var supportBlob = function() {
    try {
      return !!new Blob();
    } catch (e) {
      return false;
    }
  };

  var resource = $resource('api/attachment/:id', {id: '@id'}, {});

  var service = {
    isOpen: false,
    isDownloadSupported: supportBlob(),
    /*
     Options
     - attachmentType: Boolean
     true -> read only display
     ** false-> (default)
     - attachmentTypes: []
     */
    uploadAttachment: function(mainObject, attachment, options, callback) {
      if (service.isOpen) return true;

      $uibModal.open({
        templateUrl: 'resources/scripts/radiation/components/attachment/_attachment-form.html',
        controllerAs: '$ctrl',
        size: 'md',
        keyboard: false,
        windowTopClass: 'attachment-model',
        backdrop: 'static',
        controller: function($uibModalInstance, $q, $filter) {
          var $ctrl = this;

          service.isOpen = true;
          $ctrl.progress = false;
          $ctrl.attachment = angular.copy(attachment || {});
          $ctrl.init = function() {
            $ctrl.isEdit = !!($ctrl.attachment && $ctrl.attachment.fileName);
            $ctrl.hasFile = !!$ctrl.file || !!$ctrl.isEdit;
            $ctrl.attachmentTitle = angular.copy($ctrl.attachment.attachmentType);
            $ctrl.attachmentTitle = _.includes($ctrl.attachmentTitle, '_') ? $ctrl.attachmentTitle.replace('_', ' ') : $ctrl.attachment.attachmentType;
          };

          $ctrl.uploadLimit = "10MB";
          $ctrl.isDownloadSupported = service.isDownloadSupported;
          $ctrl.numPendingFiles = 0;
          $ctrl.category = options.attachmentTypes;

          if (options.attachmentType) {
            $ctrl.attachment.attachmentType = options.attachmentType;
          }

          $ctrl.upload = function(files) {
            if (files && files.length === 1) {
              $ctrl.file = files[0];
              if ($ctrl.isEdit) {
                $ctrl.attachment.fileName = null;
              }
              $ctrl.init();
            }
          };

          $ctrl.removeAttachment = function() {
            $ctrl.file = null;
            $ctrl.init();
          };

          $ctrl.doDownload = function(file) {
            Upload.dataUrl(file, true).then(function(data) {
              var blob = Upload.dataUrltoBlob(data);
              FileSaver.saveAs(blob, file.name);
            });
          };

          $ctrl.downloadAttachment = function(attachment) {
            service.downloadAttachment(attachment.id);
          };

          $ctrl.submit = function(form) {
            if (form.$valid) {
              $ctrl.progress = true;
              $ctrl.attachment.referenceDate = new moment($ctrl.attachment.referenceDate).toDate();
              Upload.upload({
                method: 'POST',
                url: 'api/attachment/' + ($ctrl.attachment.id || ''),
                data: Object.assign({}, {file: $ctrl.file}, _($ctrl.attachment).pick(['id', 'fileName', 'attachmentType', 'referenceDate', 'title', 'description', 'contentType']).pickBy(_.identity).value())
              }).progress(function(evt) {
                if ($ctrl.file) {
                  $ctrl.file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
                }
              }).success(function(data, status, headers, config) {
                $ctrl.progress = false;
                callback(mainObject, data);
                $ctrl.cancel();
              }).catch(function(error) {
                console.log(error);
              });
            }
          };

          $ctrl.cancel = function() {
            service.isOpen = false;
            $uibModalInstance.dismiss('cancel');
          };
          $ctrl.init();
        }
      });
    },
    downloadAttachment: function(attachmentId) {
      if (service.isDownloadSupported) {
        $http.get('api/attachment/' + attachmentId + '/download')
          .then(function(response) {
            var int8Array = new Uint8Array(response.data.content);
            var blob = new Blob([int8Array], {type: "application/octet-stream"});
            FileSaver.saveAs(blob, response.data.fileName);
          });
      }
    }
  };

  return Object.assign({}, resource, service);
});
