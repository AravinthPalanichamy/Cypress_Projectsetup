'use strict';

angular.module('app').component("rssTable", {
  templateUrl: 'resources/scripts/radiation/components/table/server/table.html',
  controllerAs: 'ctrl',
  controller: function($q, $location, $rootScope, $scope, $templateCache, $timeout,
                        uiGridConstants, uiGridGroupingConstants, UtilService,
                        StaticCollections, UaService, TableService, FileSaver, PageDomainService) {
    var ctrl = this;
    var SCROLL_NEVER = 0;
    var SCROLL_ALWAYS = 1;

    var defaultPagination = _.cloneDeep(UtilService.searchDefaults.pagination);
    ctrl.perPage = defaultPagination.itemPerPage;
    ctrl.currentPage = defaultPagination.pageNumber;
    ctrl.seekPageNumber = defaultPagination.pageNumber;
    ctrl.tableTemplate = ctrl.name || 'table-server.html';
    ctrl.pageDomainType = StaticCollections.pageDomainType;

    // components state
    ctrl.state = _.cloneDeep(UtilService.searchDefaults);

    // INIT
    ctrl.tableInit = function() {
      var rowsRenderedTimeout;
      ctrl.enablePaging = ctrl.paging === false ? ctrl.paging : true;
      ctrl.enableExport = ctrl.export === false ? ctrl.export : true;
      ctrl.enableClearFilters = ctrl.clearFilters === false ? ctrl.clearFilters : true;

      ctrl.gridApi;
      ctrl.gridOptions = {
        headerTemplate: 'resources/scripts/radiation/components/table/headerTemplate.html',
        rowTemplate: 'resources/scripts/radiation/components/table/rowTemplate.html',
        rowHeight: 'auto',
        data: ctrl.data,
        enableFiltering: true,
        useExternalFiltering: true,
        gridMenuShowHideColumns: false,
        showGridFooter: false,
        enableGridMenu: false,
        showColumnFooter: false,
        fastWatch: true,
        enableSorting: true,
        useExternalSorting: true,
        enablePinning: false,
        enablePaginationControls: false,
        paginationPageSize: 10,
        paginationPageSizes: {
          "All": ctrl.totalItems,
          "10": 10,
          "50": 50,
          "100": 100
        },
        useExternalPagination: true,
        enableHorizontalScrollbar: SCROLL_NEVER,
        enableVerticalScrollbar: SCROLL_NEVER,
        columnDefs: ctrl.constructColDefs(),
        appScopeProvider: ctrl,
        onRegisterApi: function onRegisterApi(registeredApi) {
          ctrl.gridApi = registeredApi;
          ctrl.gridApi.core.on.filterChanged(null, ctrl.filterChanged);
          ctrl.gridApi.core.on.sortChanged(null, ctrl.sortChanged);
          ctrl.gridApi.core.notifyDataChange(uiGridConstants.dataChange.ALL);
          if (ctrl.gridApi.expandable) {
            ctrl.gridApi.expandable.on.rowExpandedStateChanged(null, ctrl.displaySubTable);
            ctrl.gridApi.expandable.on.rowExpandedBeforeStateChanged(null, ctrl.prepareSubTable);
          }
          ctrl.gridApi.core.refreshRows().then(ctrl.tableRefresh);
        },
        excessRows: ctrl.data.length,
        expandableRowTemplate: 'resources/scripts/radiation/components/table/expandableRowTemplate.html',
        enableExpandableRowHeader: false
      };
      ctrl.setPageDomain();
    };

    ctrl.constructColDefs = function() {
      var columnDefs = [];
      _.forEach(ctrl.columnDef, function(column) {
        var item = ctrl.createItem(column);
        ctrl.handleColumnTypeDefs(item, column);
        columnDefs.push(item);
      });
      return columnDefs;
    };

    ctrl.createItem = function(column) {
      return {
        field: column['field'],
        displayName: column['displayName'],
        filter: column['filter'],
        enableFiltering: column['enableFiltering'],
        useExternalFiltering: column['useExternalFiltering'],
        enableSorting: column['enableSorting'],
        useExternalSorting: column['useExternalSorting'],
        enableColumnMenu: column['enableColumnMenu'],
        filterCellFiltered: column['filterCellFiltered'],
        minWidth: 10,
        width: column['width'],
        defaultSort: {
          direction: uiGridConstants.ASC
        },
        enableHiding: false
      };
    };

    ctrl.handleColumnTypeDefs = function(item, column) {
      if (item.displayName === 'Edit' || item.field === 'Delete') {
        ctrl.edit(item, column);
      }
      if (column['cellFilter']) {
        item['cellFilter'] = column['cellFilter'];
      }
      if (column['cellTemplate']) {
        item['cellTemplate'] = column['cellTemplate'];
      }
      if (column['headerCellTemplate']) {
        item['headerCellTemplate'] = column['headerCellTemplate'];
      }
      if (column['filterHeaderTemplate']) {
        item['filterHeaderTemplate'] = column['filterHeaderTemplate'];
      }
      if (column['filters']) {
        item['filters'] = column['filters'];
      }
      if (column['cellClass']) {
        item['cellClass'] = column['cellClass'];
      }
    };

    ctrl.edit = function(item, column) {
      item['enableFiltering'] = false;
      item['enableSorting'] = false;
      item['enableColumnMenu'] = false;
      item['displayName'] = '';
      item['width'] = column['width'] ? column['width'] : 30;
      item['minWidth'] = 30;
    };

    ctrl.clearAllFilters = function() {
      // the 1st 'true' return you the promise object
      ctrl.gridApi.core.clearAllFilters(true, false, false)
        .then(ctrl.clearSelectFilters)
        .then(ctrl.externalDataCallback);
    };

    ctrl.clearSelectFilters = function(response) {
      ctrl.state.sort = _.cloneDeep(UtilService.searchDefaults.sort);
      ctrl.state.pagination = _.cloneDeep(UtilService.searchDefaults.pagination);
      return new Promise(function(resolve, reject) {
        var columns = ctrl.gridApi.grid.columns;
        for (var i = 0; i < columns.length; i++) {
          if (columns[i].enableFiltering) {
            if (columns[i].filters[0].type === 'select') {
              columns[i].filters[0].term = '';
            }
            if (columns[i].filters[0].type === 'multi-select'
              && columns[i].filters[0].aggregator) {
              columns[i].filters[0].aggregator = 'or';
            }
            columns[i].filters[0].touched = false;
          }
          if (columns[i].enableSorting) {
            columns[i].sort = {};
          }
        }
        resolve(true);
      });
    };

    ctrl.externalDataCallback = function(response) {
      if (response) {
        return ctrl.onStateChange({
          state: ctrl.state
        })
          .then(function(page) {
            var data = page.data || page || [];
            ctrl.totalItems = ctrl.gridOptions.excessRows = page.totalCount || data.length;
            ctrl.gridOptions.data = _.reject(data, function(ua) {
              return _.isEmpty(ua);
            });
            ctrl.setPageDomain();

            ctrl.perPage = ctrl.state.pagination.itemPerPage;
            ctrl.seekPageNumber = ctrl.state.pagination.pageNumber;
            ctrl.currentPage = ctrl.state.pagination.pageNumber;

            ctrl.gridApi.grid.queueGridRefresh(true);
            ctrl.alignPrimaryTable(ctrl.gridApi.grid);
          });
      }
    };

    ctrl.filterChanged = function() {
      var that = this;
      $timeout(function() {
        ctrl.state.filter = [];
        var grid = that.grid;
        var filterTouched = false;

        //Reset the table
        ctrl.state.pagination = _.cloneDeep(UtilService.searchDefaults.pagination);
        ctrl.perPage = ctrl.state.pagination.itemPerPage;
        ctrl.currentPage = ctrl.state.pagination.pageNumber;
        ctrl.seekPageNumber = ctrl.state.pagination.pageNumber;

        _.forEach(grid.columns, function(col, key) {
          _.forEach(col.filters, function(filter, key) {
            if (_.isBoolean(filter.term) || filter.term) { // handling the term change event use-case ;
              filter.touched = true;
              ctrl.state.filter.push({
                filterColumn: col.name,
                filterTerm: filter.term,
                strictSelected: filter.aggregator ? filter.aggregator : undefined,
                mappingColumns: filter.mappingColumns,
                prefix: filter.prefix,
                filterType: filter.filterType
              });
            } else if (filter.term === null || filter.touched) { // handling the cancel event use-case
              filterTouched = true;
            }
          });
        });
        if (ctrl.state.filter.length > 0 || filterTouched) {
          ctrl.externalDataCallback(true);
        }
      }, 200);
    };

    ctrl.sortChanged = function(grid, sortColumns) {
      ctrl.state.sort = [];
      if (!sortColumns.length) {
        ctrl.state.sort.splice(ctrl.state.sort.length - 1, 1);
        /* library doesn't return sort object for default sorted direction */
      }
      _.forEach(sortColumns, function(col) {
        if (col.filters) {
          _.forEach(col.filters, function(filter, key) {
            ctrl.state.sort.push({
              sortColumn: filter.mappingColumns ? filter.mappingColumns[0] : col.name,
              sortDirection: col.sort.direction,
              prefix: filter.prefix
            });
          });
        } else {
          ctrl.state.sort.push({
            sortColumn: col.name,
            sortDirection: col.sort.direction
          });
        }
      });
      ctrl.state.sort = _.uniqWith(ctrl.state.sort, _.isEqual);
      if (ctrl.state.sort.length > 0) {
        ctrl.externalDataCallback(true);
      }
    };

    ctrl.displayItemRange = function() {
      if (ctrl.totalItems === 0) {
        return;
      }
      if (!ctrl.currentPage) {
        ctrl.currentPage = 1;
      }
      var endRange = (!ctrl.perPage) ? ctrl.totalItems :
        ((ctrl.totalItems < (ctrl.currentPage * ctrl.perPage))
          ? ctrl.totalItems : (ctrl.currentPage * ctrl.perPage));
      return '(' + ((ctrl.currentPage - 1) * (!ctrl.perPage ? 0 : ctrl.perPage) + 1) + ' - ' + endRange + ')';
    };

    ctrl.totalPages = function() {
      if (ctrl.totalItems === 0) {
        return 1;
      }
      return (!ctrl.perPage) ? 1 : (Math.ceil(ctrl.totalItems / ctrl.perPage));
    };

    ctrl.nextPage = function() {
      ctrl.state.pagination = {
        pageNumber: ++ctrl.currentPage,
        itemPerPage: ctrl.perPage
      };
      ctrl.externalDataCallback(true);
    };

    ctrl.previousPage = function() {
      ctrl.state.pagination = {
        pageNumber: --ctrl.currentPage,
        itemPerPage: ctrl.perPage
      };
      ctrl.externalDataCallback(true);
    };

    ctrl.firstPage = function() {
      ctrl.state.pagination = {
        pageNumber: 1,
        itemPerPage: ctrl.perPage
      };
      ctrl.externalDataCallback(true);
      ctrl.currentPage = 1;
    };

    ctrl.seekToPage = function(pageNumber) {
      ctrl.state.pagination = {
        pageNumber: pageNumber,
        itemPerPage: ctrl.perPage
      };
      ctrl.externalDataCallback(true);
      ctrl.currentPage = pageNumber;
    };

    ctrl.lastPage = function() {
      ctrl.state.pagination = {
        pageNumber: ctrl.totalPages(),
        itemPerPage: ctrl.perPage
      };
      ctrl.externalDataCallback(true);
      ctrl.currentPage = ctrl.totalPages();
    };

    ctrl.downLoadExcel = function() {
      var data = ctrl.gridOptions.columnDefs;
      ctrl.state.header = [];
      ctrl.state.dataProperty = '';

      for (var i = 1; i < data.length; i++) {
        ctrl.state.header.push(data[i].displayName);
        switch (data[i].field) {

          case 'class':
            data[i].field = 'classs';
            break;

          case 'expirationDate':
            data[i].field = 'displayExpirationDate';
            break;

          case 'createdDate':
            data[i].field = 'displayCreatedDate';
            break;

          case 'dateEmailed':
            data[i].field = 'displayEmailedDate';
            break;

          case 'performedDate':
            data[i].field = 'displayPerformedDate';
            break;

          case 'dueDate':
            data[i].field = 'displayDueDate';
            break;

          case 'ua.expiryDate':
            data[i].field = 'displayExpiryDate';
            break;

          case 'leakTests.testedBy.firstName':
            data[i].field = 'currentLeakTestsTestedByFirstName';
            break;

          case 'leakTests.testedBy.lastName':
            data[i].field = 'currentLeakTestsTestedByLastName';
            break;

          case 'storageLocation':
            data[i].field = 'locationWithBuildingAndRoomNumber';
            break;

          case 'initialDate':
            data[i].field = 'displayInitialDate';
            break;

          case 'nextDue':
            data[i].field = 'displayNextDueDate';
            break;

          case 'dob':
            data[i].field = 'displayDob';
            break;
        }

        ctrl.state.dataProperty = ctrl.state.dataProperty.concat(data[i].field).concat(',');
      }

      ctrl.exportApi()({}, ctrl.state).$promise.then(function(response) {
        FileSaver.saveAs(response.data, ctrl.fileName + '-Report-' + Date.now() + '.xls');
      });
    };

    ctrl.updatePageWithPerPage = function(itemsPerPage) {
      ctrl.state.pagination = {
        pageNumber: 1,
        itemPerPage: !itemsPerPage ? 0 : itemsPerPage
      };
      ctrl.externalDataCallback(true);
      ctrl.currentPage = 1;
      ctrl.seekPageNumber = 1;
    };

    ctrl.prepareSubTable = function(row) {
      row.entity.subGridOptions = {};
      row.entity.subGridOptions.columnDefs = ctrl.subTableData.SUB_TABLE_HEADERS;
      row.entity.subGridOptions.data = ctrl.subTableData.SUB_TABLE_DATA;
      row.entity.subGridOptions.enableColumnMenus = false;
      row.entity.subGridOptions.enableFiltering = true;
      row.entity.subGridOptions.enableHorizontalScrollbar = SCROLL_NEVER;
      row.entity.subGridOptions.enableVerticalScrollbar = SCROLL_NEVER;
      row.entity.subGridOptions.excessRows = ctrl.subTableData.SUB_TABLE_DATA.length;
      // row.expandedRowHeight = (ctrl.subTableData.SUB_TABLE_DATA.length * 29);
    };

    ctrl.displaySubTable = function(row) {
      ctrl.gridApi.core.queueGridRefresh();
      $timeout(function() {
        ctrl.alignExpandableTable(ctrl.gridApi.grid, row);
      }, 10);
    };

    ctrl.href = function(url) {
      $location.path(url);
    };

    ctrl.alignPrimaryTable = function(grid, row) {
      var table = _.first(grid.element);
      if ((table || table !== null) && ctrl.gridOptions) {
        $timeout(function() {
          ctrl.isEmptyTable(ctrl.gridOptions.data)
            ? ctrl.isEmptyTable(ctrl.gridOptions.data, table)
            : ctrl.reDrawTable(table);
        }, 10);
      }
    };

    ctrl.alignExpandableTable = function(grid, row) {
      return new Promise(function(resolve, reject) {
        var expandables = document.querySelector('.expandableRow #NESTED-' + row.entity.id);
        if ((expandables || expandables !== null) && row && row.entity && row.entity.subGridOptions) {
          $timeout(function() {
            angular.element(expandables).css('padding-left', _.first(row.grid.columns).width + 'px');
            ctrl.isEmptyTable(row.entity.subGridOptions.data)
              ? ctrl.isEmptyTable(row.entity.subGridOptions.data, expandables)
              : ctrl.reDrawTable(expandables);
          }, 10);
        }
        resolve(true);
      });
    };

    ctrl.reDrawTable = function(table) {
      var headerColumns = angular.element(table.getElementsByClassName('ui-grid-header-cell-primary-focus'));
      var maxHeaderHeight = _.get(_.maxBy(headerColumns, 'offsetHeight'), 'offsetHeight', '30px');
      // set the table elements height
      angular.element(table).parent().css('height', 'auto');
      angular.element(table).css('height', 'auto');
      angular.element(table.querySelectorAll('.ui-grid-header-cell-primary-focus')).css('height', maxHeaderHeight + 'px');
      angular.element(table.querySelector('.ui-grid-render-container')).css('height', 'auto');
      angular.element(table.querySelector('.ui-grid-render-container-body ')).css('height', 'auto');
      angular.element(table.querySelector('.ui-grid-viewport')).css('height', 'auto');
      angular.element(table.querySelector('.ui-grid-viewport')).css('overflow', 'visible');
      angular.element(table.querySelector('.ui-grid-canvas')).css('height', 'auto');
    };

    ctrl.tableRefresh = function() {
      var rows = ctrl.gridApi.core.getVisibleRows(ctrl.gridApi.grid);
      ctrl.alignPrimaryTable(ctrl.gridApi.grid, rows);
    };

    ctrl.toggleExpandable = function(grid, row) {
      if (row.isExpanded) {
        grid.api.expandable.collapseRow(row.entity);
      } else {
        ctrl.onRowExpanded({
          row: row.entity
        }).then(function(data) {
          ctrl.subTableData = data;
          grid.api.expandable.expandRow(row.entity);
        });
      }
    };

    ctrl.isEmptyTable = function(data, table) {
      if ((!data || !data.length) && table) {
        var headerColumns = angular.element(table.getElementsByClassName('ui-grid-header-cell-primary-focus'));
        var maxHeaderHeight = _.get(_.maxBy(headerColumns, 'offsetHeight'), 'offsetHeight', '30px');
        angular.element(table.querySelectorAll('.ui-grid-header-cell-primary-focus')).css('height', maxHeaderHeight + 'px');
        angular.element(table.querySelector('.ui-grid-viewport')).css('height', '0px');
        angular.element(table.querySelector('.ui-grid-viewport')).css('overflow', 'none');
        angular.element(table.querySelector('.ui-grid-viewport')).css('min-height', '0px');
      }
      return !data || !data.length;
    };

    ctrl.setPageDomain = function() {
      ctrl.pageDomain = _.find(ctrl.pageDomainType, {'path': $location.path()});
      if (ctrl.pageDomain) {
        PageDomainService.init(ctrl.gridOptions.data, ctrl.pageDomain.key, ctrl.pageDomain.routeTo);
      }
    };

    ctrl.rowHover = function(row) {
      // used to display the changelog items as Add/Update/Delete
      // color identification on mouse hover
      row.isAdded = (row.entity.type === 'I');
      row.isUpdated = (row.entity.type === 'U');
      row.isDeleted = (row.entity.type === 'D');
    };
  },
  bindings: {
    data: '=',
    columnDef: '=',
    onStateChange: '&',
    onRowExpanded: '&',
    name: '=',
    parentScope: '=',
    totalItems: '=',
    addRecordUrl: '=',
    exportApi: '&',
    fileName: '=',
    paging: '=',
    export: '=',
    clearFilters: '=',
    buttonList: '='
  }
})

  .filter('mapStatus', function(StaticCollections) {
    return function(input) {
      if (!input) {
        return '';
      } else {
        return _.find(StaticCollections.UATypesHash, function(uaObj, key) {
          return uaObj.value === input;
        }).label;
      }
    };
  })

  .run(function($templateCache) {
    $templateCache.put('table-server.html', '<div id="table_server" ui-grid="ctrl.gridOptions" class="data-grid" ng-if="ctrl.gridOptions.data" ui-grid-pinning ui-grid-pagination ui-grid-cellNav></div>');
    $templateCache.put('table-server-editable.html', '<div id="table_server_editable" ui-grid="ctrl.gridOptions" class="data-grid" ng-if="ctrl.gridOptions.data" ui-grid-pinning ui-grid-pagination ui-grid-cellNav ui-grid-edit></div>');
  });
