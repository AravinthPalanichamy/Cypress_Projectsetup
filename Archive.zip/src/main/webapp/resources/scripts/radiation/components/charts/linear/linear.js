'use strict';

angular.module('app').component("linearChart", {
  template: '<svg class="calibration_graph" viewBox="-100 0 1000 300"></svg>',
  controllerAs: 'ctrl',
  controller: function($scope, $window, $attrs) {
    var ctrl = this;
    $scope.$watch('ctrl.chartData', function(data, oldData) {
        if (data) {
            updateGraph(data);
        }
    });

    var d3 = $window.d3;
    var tickFormatter = function(val) {
        if ($attrs.lineXAxisType == "date") {
            return d3.time.format('%x')(new Date(val));
        } else {
            return val;
        }
    };
    function updateGraph(data) {
        // Reset
        d3.select('#' + $attrs.id + ' svg > *').remove();

        // Set the dimensions of the canvas / graph
        var margin = {top: 30, right: 20, bottom: 40, left: 50},
        width = 800 - margin.left - margin.right,
        height = 300 - margin.top - margin.bottom;

        // Set the ranges
        var x = d3.scale.linear().range([0, width]);
        var y = d3.scale.linear().range([height, 0]);
        if ($attrs.lineXAxisType == "date") {
            x = d3.time.scale().range([0, width]);
        }
        // Define the axes
        var xAxis = d3.svg.axis()
                            .scale(x)
                            .orient("bottom")
                            .ticks(5)
                            .tickFormat(tickFormatter);
        var yAxis = d3.svg.axis()
                            .scale(y)
                            .orient("left")
                            .ticks(5);

        // Define the line
        var valueline = d3.svg.line()
        .x(function(d) { return x(d[$attrs.lineXAxis]); })
        .y(function(d) { return y(d[$attrs.lineYAxis]); });

        // Define the div for the tooltip
        var div = d3.select("body")
                    .append("div")
                    .attr("class", "tooltip")
                    .style("opacity", 0);

        // Adds the svg canvas
        var svg = d3.select('#' + $attrs.id + ' svg')
                    .append("svg")
                    .attr("width", width + margin.left + margin.right)
                    .attr("height", height + margin.top + margin.bottom)
                    .append("g")
                    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

        data.forEach(function(d) {
            d[$attrs.lineXAxis] = d[$attrs.lineXAxis];
            d[$attrs.lineYAxis] = +d[$attrs.lineYAxis];
        });

        // Scale the range of the data
        x.domain(d3.extent(data, function(d) { return d[$attrs.lineXAxis]; }));
        y.domain([0, d3.max(data, function(d) { return d[$attrs.lineYAxis]; })]);

        // Add the valueline path.
        svg.append("path")
            .attr("class", "line")
            .attr("d", valueline(data));

        // Add the scatterplot
        svg.selectAll("dot")
            .data(data)
            .enter().append("circle")
            .attr("r", 4)
            .attr("cx", function(d) { return x(d[$attrs.lineXAxis]); })
            .attr("cy", function(d) { return y(d[$attrs.lineYAxis]); })
            .on("mouseover", function(d) {
                var toolTipValue = $attrs.lineXAxisLabel + " : " + d[$attrs.lineXAxisTickFormat] + "<br/>" + $attrs.lineYAxisLabel + " : " + d[$attrs.lineYAxis];
                div.transition()
                    .duration(200)
                    .style("opacity", '.9');
                div	.html(toolTipValue)
                    .style("left", (d3.event.pageX) + "px")
                    .style("top", (d3.event.pageY - 28) + "px");
                })
            .on("mouseout", function(d) {
                div.transition()
                    .duration(500)
                    .style("opacity", 0);
                });

        svg.append("text")
            .attr("class", "x label")
            .attr("text-anchor", "end")
            .attr("x", width)
            .attr("y", height + 30)
            .text([$attrs.lineXAxisLabel]);

        svg.append("text")
            .attr("class", "y label")
            .attr("text-anchor", "end")
            .attr("y", -40)
            .attr("dy", ".75em")
            .attr("transform", "rotate(-90)")
            .text([$attrs.lineYAxisLabel]);

        // Add the X Axis
        svg.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + height + ")")
            .call(xAxis);

        // Add the Y Axis
        svg.append("g")
            .attr("class", "y axis")
            .call(yAxis);
    }


  },
  bindings: {
      chartData: '='
  }
});
