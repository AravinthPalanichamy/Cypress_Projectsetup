'use strict';
angular.module('app').factory('MaterialUseService', function($uibModal, InventoryService, UaService, ConfirmModelService) {

  var service = {
    isOpen: false,

    openModal: function(useOption, material, callback) {
      if (service.isOpen) {
        return true;
      }
      var controller;

      switch (useOption.id) {
        case 'LOT':
          controller = getLotCtrl(material, callback);
          break;
        case 'CHANGE_LOCATION':
          controller = getLocationChangeCtrl(material, callback);
          break;
        case 'TRANSFER':
          controller = getTransferController(material, callback);
          break;
        case 'ACCEPTED':
          controller = getAcceptOrRejectController(material, callback);
          break;
        default:
          controller = getUseController(useOption, material, callback);
          break;
      }

      $uibModal.open({
        templateUrl: 'resources/scripts/radiation/controllers/material/inventory/use-forms/' + useOption.template,
        controllerAs: '$ctrl',
        size: 'lg',
        keyboard: false,
        backdrop: 'static',
        controller: controller
      });
    }
  };

  function getUseController(useOption, material, callback) {
    return function($uibModalInstance) {
      var $ctrl = this;
      $ctrl.init = function() {
        $ctrl.existingMaterialId = material.id;
        $ctrl.displayMaterial = _.cloneDeep(material);
        $ctrl.material = _.cloneDeep(material);
        $ctrl.material.id = null;
        $ctrl.material.materialPackage = null;
        $ctrl.material.inventoryStatusType = useOption.status;

        $ctrl.useRemaining = $ctrl.material.materialRadionuclides.length > 1;

        $ctrl.useTypes = [];
        // the ordering of this array matters ... precedence is used to pick the default selected type
        // _.toNumber() converts 'possible' strings to numbers. If the current value is unusable (0),
        // then no option will be displayed
        var hasMass = !!(material.currentElementalMass || material.currentNetMass);

        var defaultUseTypeNonSealedSource = { precedence: 1, name: 'Volume (&micro;l)', value: 'requestVolume', validate: 'currentVolume' };
        var defaultUseTypeSealedSource = { precedence: 3, name: 'Elemental Mass (grams)', value: 'requestElementalMass', validate: 'currentElementalMass' };

        if (_.toNumber(material.currentVolume) && !hasMass) { $ctrl.useTypes.push(defaultUseTypeNonSealedSource); }
        if (_.toNumber(material.currentAmount) && !hasMass) { $ctrl.useTypes.push({ precedence: 2, name: 'Amount (mCi)', value: 'requestAmount', validate: 'currentAmount' }); }
        if (_.toNumber(material.currentElementalMass) && hasMass) { $ctrl.useTypes.push(defaultUseTypeSealedSource); }
        if (_.toNumber(material.currentNetMass) && hasMass) { $ctrl.useTypes.push({ precedence: 4, name: 'Net Mass (grams)', value: 'requestNetMass', validate: 'currentNetMass' }); }
        // this sort is just to guarantee that the order is correct
        $ctrl.useTypes = _.sortBy($ctrl.useTypes, ['precedence']);

        if (!$ctrl.useTypes.length) {
          if (hasMass) {
            $ctrl.useTypes.push(defaultUseTypeSealedSource);
          } else {
            $ctrl.useTypes.push(defaultUseTypeNonSealedSource);
          }
        }

        $ctrl.useType = $ctrl.useTypes[0].value;
        $ctrl.clearCurrentValues($ctrl.material);

        // can only update materials that have one radionuclide;
        $ctrl.updateValue = $ctrl.material.materialRadionuclides[0];

        if (useOption.id === 'IN_DISPOSAL') {
          InventoryService.getContainersForUa({uaId: $ctrl.material.ua.id}).$promise.then(function(response) {
            $ctrl.wasteContainers = response;
          });
        }
      };

      $ctrl.assignLocation = function() {
        $ctrl.material.storageLocation = $ctrl.material.container.location;
      };

      $ctrl.clearCurrentValues = function(material) {
        material.materialRadionuclides.forEach(function(materialRadionuclide) {
          materialRadionuclide.requestAmount = null;
          materialRadionuclide.requestVolume = null;
          materialRadionuclide.requestElementalMass = null;
          materialRadionuclide.requestNetMass = null;
        });
      };

      $ctrl.updateUseValue = function(currentUseType) {
        var currentUseValue;
        _.forEach($ctrl.useTypes, function(useType) {
          if ($ctrl.updateValue[useType.value]) {
            currentUseValue = $ctrl.updateValue[useType.value];
            $ctrl.updateValue[useType.value] = null;
          }
        });

        $ctrl.updateValue[currentUseType] = currentUseValue;
      };

      $ctrl.onSave = function(form) {
        $ctrl.errors = {};
        if ($ctrl.useRemaining) {
          $ctrl.material.id = material.id;
          $ctrl.material.materialRadionuclides = _.cloneDeep(material.materialRadionuclides);
          $ctrl.material.inventoryStatusType = useOption.status;
          $ctrl.existingMaterialId = null;

          if (useOption.id === 'NEW_VIAL' && !$ctrl.newVolume) {
            $ctrl.errors.newVolume = true;
          }
        } else {
          $ctrl.material.materialRadionuclides = _.map($ctrl.material.materialRadionuclides, function(materialRadionuclide) { return _.merge(materialRadionuclide, { id: null, material: null }); });

          if (!$ctrl.updateValue[$ctrl.useType]) {
            $ctrl.errors.required = true;
          }

          if (!$ctrl.newVolume && (useOption.id === 'NEW_VIAL' || $ctrl.newVolume <= 0)) {
            $ctrl.errors.newVolume = true;
          }

          var validator = _.find($ctrl.useTypes, function(useType) {
            return useType.value === $ctrl.useType;
          }).validate;
          if ($ctrl.updateValue[$ctrl.useType] < 0 || ($ctrl.updateValue[$ctrl.useType] >= material.materialRadionuclides[0][validator])) {
            $ctrl.errors.amount = true;
          }
        }

        if (form.$valid && _.isEmpty($ctrl.errors)) {
          var options = { existingMaterialId: $ctrl.existingMaterialId, newVialVolume: $ctrl.newVolume };
          callback($ctrl.material, options);
          $ctrl.cancel();
        }
      };

      $ctrl.cancel = function() {
        $uibModalInstance.close();
      };

      $ctrl.init();
    };
  }

  function getLotCtrl(material, callback) {
    return function($uibModalInstance) {
      var $ctrl = this;

      $ctrl.displayMaterial = _.cloneDeep(material);
      $ctrl.material = material;

      $ctrl.save = function(form) {
        if (form.$dirty) {
          callback($ctrl.material);
        }

        $ctrl.cancel();
      };

      $ctrl.cancel = function() {
        $uibModalInstance.close();
      };
    };
  }

  function getLocationChangeCtrl(material, callback) {
    return function($uibModalInstance) {
      var $ctrl = this;

      $ctrl.displayMaterial = _.cloneDeep(material);
      $ctrl.material = material;

      $ctrl.onSave = function(form) {
        $ctrl.locationError = {};
        if (!$ctrl.material.storageLocation || !$ctrl.material.subLocation) {
          $ctrl.locationError.locationError = true;
        }
        if (form.$valid && _.isEmpty($ctrl.locationError)) {
          callback($ctrl.material);
          $ctrl.cancel();
        }
      };

      $ctrl.cancel = function() {
        $uibModalInstance.close();
      };
    };
  }

  function getTransferController(material, callback) {
    return function($uibModalInstance) {
      var $ctrl = this;

      $ctrl.init = function() {
        $ctrl.resetMaterialTransfer();
        InventoryService.getTransferableUas({materialId: material.id}).$promise.then(function(response) {
          $ctrl.uas = _.uniqBy(response, ['number']);
        });
      };

      $ctrl.resetMaterialTransfer = function() {
        $ctrl.materialTransfer = {
          fromUa: material.ua,
          toUa: null,
          material: material,
          materialTransferStatusType: 'PENDING',
          institutionName: null
        };
      };

      $ctrl.save = function(form) {
        $ctrl.errors = {};
        if ($ctrl.institution && !$ctrl.materialTransfer.institutionName) {
          $ctrl.errors.institutionName = true;
        }

        if (!$ctrl.institution && !$ctrl.materialTransfer.toUa) {
          $ctrl.errors.toUa = true;
        }

        if (form.$valid && _.isEmpty($ctrl.errors)) {
          InventoryService.transferMaterial({}, $ctrl.materialTransfer).$promise.then(function(response) {
            callback();
            $ctrl.cancel();
            if (response.institutionName) {
              var desc = "Your request of transferring Material " + response.material.id + " to " + response.institutionName + " is pending. " +
                "A member of the Radiation Safety staff will contact you for more information shortly. " +
                "Please note that there are a number of steps that must be completed before radioactive materials may be transferred to another institution. " +
                "There are also very stringent shipping regulations which require the involvement of an appropriately certified Radiation Safety staff member. " +
                "Lead times will vary, but you should plan for the transfer to take place about two weeks from today (or on a later date that you arrange).";
              ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS, {
                message: desc,
                autoCloseTimeout: 60000
              });
            }
          });
        }
      };

      $ctrl.cancel = function() {
        $uibModalInstance.close();
      };

      $ctrl.init();
    };
  }

  function getAcceptOrRejectController(materialTransfer, callback) {
    return function($uibModalInstance) {
      var $ctrl = this;

      $ctrl.init = function() {
        $ctrl.error = false;
        $ctrl.isValidLimit = false;
        $ctrl.transferMaterialAmount = materialTransfer.material.requestedAmount;
        $ctrl.existingMaterialId = materialTransfer.id;
        $ctrl.materialName = materialTransfer.material.radionuclideNameString;
        $ctrl.materialTransfer = materialTransfer;
        $ctrl.materialId = materialTransfer.material.id;
        $ctrl.ua = materialTransfer.material.ua;
        $ctrl.columns = $ctrl.defineTable();
        _.forEach(materialTransfer.material.materialRadionuclides, function(radionuclide) {
          if (radionuclide.material.id === $ctrl.materialId) {
            $ctrl.licenceLineNumber = radionuclide.uaLimit.licenseLineNumber;
          }
        });
        $ctrl.getTableData();

        $ctrl.buttonList = [];
        $ctrl.buttonList.push({
          label: "Accept",
          action: $ctrl.acceptMaterial
        });
      };

      $ctrl.cancel = function() {
        service.isOpen = false;
        $uibModalInstance.dismiss('cancel');
      };

      $ctrl.limitSelected = function(limitSelected) {
       if (limitSelected) {
         $ctrl.error =false;
         $ctrl.isValidLimit = true;
       }
      };

      $ctrl.acceptMaterial = function() {
        if ($ctrl.isValidLimit) {
          InventoryService.completeTransfer({
            materialTransferId: $ctrl.materialTransfer.id, status: 'ACCEPTED'}, {})
            .$promise
            .then(function() {
              callback();
              $ctrl.cancel();
            });
        } else {
          $ctrl.error = true;
          $ctrl.errorMsg = 'Please select a limit.';
        }
      };

      $ctrl.getTableData = function() {
        UaService.getUaLimitsByUaId({uaId: $ctrl.materialTransfer.toUa.id}).$promise.then(function(response) {
          $ctrl.data = _.filter(response, function(limit) {
           return limit.radionuclide.name === $ctrl.materialName && limit.licenseLineNumber.lineNumber === $ctrl.licenceLineNumber.lineNumber && $ctrl.transferMaterialAmount < limit.requestedPossessionLimit;
          });
        });
      };

      $ctrl.defineTable = function() {
        return [
          {
            displayName: 'Choose Limit',
            field: 'limit',
            cellTemplate: '<div class="ui-grid-cell-contents" ng-if="row.entity"><label>' +
                            '<input class="no-border" name="group1" type="radio" ng-model="row.entity.isLimitSelected" ng-value="true" ng-click="grid.appScope.parentScope.limitSelected(row.entity)">' +
                           '</label></div>'
          },
          { displayName: 'Chemical Form', field: 'chemicalForm'},
          {
            displayName: 'Total Current Activity (mCi)',
            field: 'a',
            cellTemplate: '<div>{{ grid.appScope.parentScope.materials[row.entity.radionuclide.name].totalAmount | scientific }}</div>'
          },
          {
            displayName: 'Total Current Volume (microliter)', field: 'v',
            cellTemplate: '<div>{{ grid.appScope.parentScope.materials[row.entity.radionuclide.name].totalVolume | scientific}}</div>',
            headerCellTemplate: '<div class="ui-grid-cell-contents ui-grid-header-cell-label">Current Volume(&micro;l)</div>'
          },
          {
            displayName: 'Total Current Elemental Mass (grams)',
            field: 'c',
            cellTemplate: '<div>{{ grid.appScope.parentScope.materials[row.entity.radionuclide.name].totalElementalMass | scientific }}</div>'
          },
          {
            displayName: 'Total Current Net Mass (grams)',
            field: 'x',
            cellTemplate: '<div>{{ grid.appScope.parentScope.materials[row.entity.radionuclide.name].totalNetMass | scientific }}</div>'
          },
          { displayName: 'mCi/Exp', field: 'experimentPossessionLimit', cellFilter: 'scientific'},
          { displayName: 'mCi/Order', field: 'vialPossessionLimit', cellFilter: 'scientific'},
          { displayName: 'mCi/Poss', field: 'requestedPossessionLimit', cellFilter: 'scientific'}
        ];
      };
    };
  }

  return service;
});
