'use strict';

angular.module('app').controller('ContainerContentCtrl', function($uibModalInstance, InventoryService, container) {
  var $ctrl = this;

  $ctrl.container = container;

  $ctrl.submit = function() {
    $ctrl.container.materials = _.filter($ctrl.container.materials, function(material) {
      return !material.$checked;
    });
    InventoryService.updateContainer({containerId: container.id}, $ctrl.container, function(res) {
      $ctrl.cancel();
    });
  };

  $ctrl.cancel = function() {
    $uibModalInstance.close();
  };
});
