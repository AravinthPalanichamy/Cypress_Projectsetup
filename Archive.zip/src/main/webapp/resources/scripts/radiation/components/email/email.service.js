'use strict';

angular.module('app').factory('EmailService', function($uibModal) {

  var service = {
    isOpen: false,
    /*
     Options
     - disableRecipients: Boolean
     true -> read only display
     ** false-> (default)
     - addRecipients: Boolean
     ** true  -> will allow to add people
     false -> will allow to delete and pick from given set
     - allowEmail: Boolean
     ** true  -> will allow to add emails (only when addRecipients is true)
     false -> will not allow to add emails
     - addRecipientMessage: String -> custom error message
     */
    getMessage: function(mainObject, notification, campusCode, options, callback) {
      if (service.isOpen) return true;

      $uibModal.open({
        templateUrl: 'resources/scripts/radiation/components/email/_email-form.html',
        controllerAs: '$ctrl',
        size: 'lg',
        keyboard: false,
        windowTopClass: 'email-model',
        backdrop: 'static',
        resolve: {
          notification: function() {
            return angular.copy(notification || {toRecipients: [], ccRecipients: [], subject: null, bodyHtml: null});
          }
        },
        controller: function($uibModalInstance, $q, $filter, notification) {
          var $ctrl = this;
          service.isOpen = true;
          $ctrl.campusCode = campusCode;
          $ctrl.options = Object.assign({}, {
            disableRecipients: false,
            addRecipients: true,
            addRecipientMessage: null
          }, options);

          if ($ctrl.options.addRecipients) {
            $ctrl.options.allowEmail = $ctrl.options.allowEmail === false ? false : true;
          } else {
            $ctrl.options.allowEmail = false;
          }

          $ctrl.notification = notification;
          $ctrl.toRecipients = $ctrl.options.addRecipients ? null : Object.assign([], notification.toRecipients);
          $ctrl.ccRecipients = $ctrl.options.addRecipients ? null : Object.assign([], notification.ccRecipients);

          $ctrl.submit = function() {
            $ctrl.notification.toRecipients = $ctrl.parseRecipients($ctrl.notification.toRecipients);
            $ctrl.notification.ccRecipients = $ctrl.parseRecipients($ctrl.notification.ccRecipients);
            callback(mainObject, $ctrl.notification);
            $ctrl.cancel();
          };

          $ctrl.cancel = function() {
            service.isOpen = false;
            $uibModalInstance.dismiss('cancel');
          };
          $ctrl.parseRecipients = function(recipients) {
            return _.uniqBy(recipients.map(function(recipient) {
              return _.pick(recipient, ['userId', 'email']);
            }), function(item) {
              return item.userId || item.email;
            });
          };
        }
      });
    }
  };
  return service;
});
