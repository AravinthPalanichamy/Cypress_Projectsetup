'use strict';

angular.module('app').directive('diff', function() {
  return {
    restrict: 'AE',
    scope: true,
    bindToController: {
      previousValue: '=',
      currentValue: '=',
      isModified: '=?isModified',
      displayTemplate: '@'
    },
    templateUrl: 'resources/scripts/radiation/components/diff-view/diff.html',
    controllerAs: '$ctrl',
    controller: function() {
      var $ctrl = this;
      $ctrl.toolitpBoolean = (typeof $ctrl.previousValue === 'boolean');
      $ctrl.dynamicTooltipText = $ctrl.previousValue || ' ';
      $ctrl.hasModified = function() {
        return !!$ctrl.isModified || ($ctrl.previousValue !== $ctrl.currentValue);
      };
    }
  };
});
