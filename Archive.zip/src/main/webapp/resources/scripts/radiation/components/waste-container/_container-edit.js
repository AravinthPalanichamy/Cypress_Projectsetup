'use strict';

angular.module('app').controller('ContainerEditCtrl', function($uibModalInstance, InventoryService, LocationService, UaService, StaticCollections, container, rua, profile) {
  var $ctrl = this;
  $ctrl.ruas = [rua];
  $ctrl.currentUser = profile;
  $ctrl.locations = rua.uaBundle.uaBundleLocations;


  $ctrl.init = function() {
    $ctrl.container = {};

    if (!container) {
      $ctrl.ownerRua = rua;
    } else {
      $ctrl.container = container;
      $ctrl.name = container.containerName;
      $ctrl.ruas = container.ruasWithAccess;
      $ctrl.containerId = container.id;
      if (container.location) {
        UaService.getUaDetail({uaId: container.ownerRuaId})
          .$promise
          .then(function(ua) {
            $ctrl.ownerRua = ua;
            $ctrl.locations = ua.uaBundle.uaBundleLocations;
            $ctrl.location = (_.find($ctrl.locations, function(loc) {
              return loc.location.roomId === container.location.roomId;
            })).location;
          });
      }
    }

    UaService.getUaListByStatusAndCampusCode({
      uaStatus: StaticCollections.getKeyByValue(StaticCollections.uaStatusHash, "Active"),
      campusCode: $ctrl.currentUser.campus.code
    }, {}).$promise
      .then(function(response) {
        $ctrl.useAuthorizations = _.filter(response, function(ua) {
          return ua.type === 'RAM';
        });
        _.forEach($ctrl.useAuthorizations, function(ua) {
          ua.number = ua.number.toString();
        });
      });
  };

  $ctrl.submit = function() {
    $ctrl.showError = !$ctrl.name || !$ctrl.ruas.length || !$ctrl.location;
    $ctrl.container.ruasWithAccess = $ctrl.ruas;
    $ctrl.container.containerName = $ctrl.name;
    $ctrl.container.ownerRuaId = $ctrl.ownerRua.id;

    if ($ctrl.location) {
      $ctrl.container.location = {
        roomId: $ctrl.location.roomId,
        buildingId: $ctrl.location.buildingId
      };
    }

    if (!$ctrl.showError) {
      if (!container) {
        InventoryService.createContainer({}, $ctrl.container, function(res) {
          $ctrl.cancel();
        });
      } else {
        InventoryService.updateContainer({containerId: container.id}, $ctrl.container, function(res) {
          $ctrl.cancel();
        });
      }
    }
  };

  $ctrl.cancel = function() {
    $uibModalInstance.close();
  };

  $ctrl.init();

});
