'use strict';

angular.module('app').component("materialHierarchy", {
  templateUrl: 'resources/scripts/radiation/components/material-hierarchy/material-hierarchy.html',
  controllerAs: '$ctrl',

  controller: function(InventoryService, $filter) {

    var ctrl = this;

    ctrl.init = function() {
      InventoryService.getMaterialPackageHierarchy({materialId: ctrl.materialId}, {}).$promise.then(function(response) {
        ctrl.materialHierarchy = response;
        ctrl.materialTemplate = ctrl.buildMaterialHierarchy(ctrl.materialHierarchy);
      });
    };

    ctrl.buildMaterialHierarchy = function(materialHierarchy) {
      ctrl.previousDepth = 0;
      var template = '';
      _.forEach(materialHierarchy, function(mh, index) {
        template += index === 0 ? '<ul>' : '';
        _.forOwn(mh, function(material, depth) {
          if (depth > ctrl.previousDepth) {
            template += '<ul>';
          } else if (depth < ctrl.previousDepth) {
            _.times((ctrl.previousDepth - depth), function() {
              template += '</ul>';
            });
          }

          index === 0 ? template += '<div >' + (material.materialPackage && material.materialPackage.id ?
                'Received in Package: ' + material.materialPackage.id + ' on ' + $filter('date')(material.initialDate, 'MM/dd/yyyy') : 'No Received Package Information') + '<br/><br/></div>' : '';
          template += '<li class=' + (material.id === ctrl.materialId ? 'bold' : '') + '>' +
            '<em>Material #: </em>' + material.id + ', ' +
            '<em> RUA #: </em>' + material.ua.number + ', ' +
            '<em> Status: </em>' + material.inventoryStatusType + ', ' +
            '<em> Loc: </em>' + material.storageLocation.buildingDisplayName + '-' + material.storageLocation.roomNumber + ', ' +
            '<em> Chem. Form: </em>' + material.chemicalForm + ', ' +
            '<em> Phys. Form: </em>' + material.physicalForm + ', ' +
            '<em> Reference Date: </em>' + $filter('date')(material.initialDate, 'MM/dd/yyyy') + ', ' +
            '<em> Init. Activity: </em>' + $filter('scientific')(material.requestedAmount) + 'mCi, ' +
            '<em> Curr. Activity: </em>' + $filter('scientific')(material.currentAmount) + 'mCi, ' +
            '<em> Init. Vol: </em>' + (material.requestedVolume ? material.requestedVolume : 0) + 'm, ' +
            '<em> Curr. Vol: </em>' + (material.currentVolume ? material.currentVolume : 0) + 'm, ' +
            '<em> Init. Net Mass: </em>' + (material.requestedNetMass ? material.requestedNetMass : 0) + 'g, ' +
            '<em> Curr. Cont\'d Mass: </em>' + (material.currentNetMass ? material.currentNetMass : 0) + 'g, ' +
            '<em> Init. Elem. Mass: </em>' + (material.requestedElementalMass ? material.requestedElementalMass : 0) + 'g, ' +
            '<em> Curr. Elem. Mass: </em>' + (material.currentElementalMass ? material.currentElementalMass : 0) + 'g' +
            '</li>';
          ctrl.previousDepth = depth;
          if (index === materialHierarchy.length - 1) {
            _.times(depth, function() {
              template += '</ul>';
            });
          }
        });
      });

      return template;
    };

  },
  bindings: {
    materialId: '='
  }
});
