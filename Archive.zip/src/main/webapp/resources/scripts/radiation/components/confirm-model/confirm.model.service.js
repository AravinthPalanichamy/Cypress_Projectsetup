'use strict';

angular.module('app').factory('ConfirmModelService', function($uibModal, $window) {

  var service = {
    isOpen: false,
    ConfirmType: {
      DELETE: 'DELETE',
      SUCCESS: 'SUCCESS',
      INFO: 'INFO',
      CONFIRM: 'CONFIRM',
      EQUATION: 'EQUATION',
      WARNING: 'WARNING'
    },
    ConfirmMessages: {
      DELETE: 'Delete Confirmation',
      SUCCESS: 'Success',
      INFO: 'Message',
      CONFIRM: 'Confirmation',
      EQUATION: 'Equation',
      WARNING: 'Warning'
    },
    /*
     Options
     - type: ConfirmType
     - model: {
     header: "String - header of the model - optional",
     message: "String - message to be displayed",
     buttons: {
     cancel: {
     label: "Cancel"
     },
     ok: {
     label: "OK"
     }
     },
     autoClose: "Boolean - true for auto close, default auto close for ConfirmType.SUCCESS & ConfirmType.INFO",
     autoCloseTimeout: "Number - in mile seconds, default 3000"
     }
     - callback: success callback
     */
    confirm: function(type, model, success, error) {
      if (service.isOpen) return true;
      var defaultOptions = {
        buttons: {
          cancel: {
            label: "Cancel"
          },
          ok: {
            label: "OK"
          }
        }
      };
      model = Object.assign({}, defaultOptions, model || {});

      $uibModal.open({
        templateUrl: 'resources/scripts/radiation/components/confirm-model/_confirm-model.html',
        controllerAs: '$ctrl',
        windowTopClass: 'confirm-model',
        backdrop: 'static',
        size: (type === service.ConfirmType.EQUATION) ? 'xl' : model.size || 'md',
        controller: function($uibModalInstance, $filter, $timeout, PrintUtil) {
          var $ctrl = this;
          service.isOpen = true;
          $ctrl.successful = false;
          $ctrl.confirmType = type;
          $ctrl.confirmHeader = model.header || service.ConfirmMessages[type] || "Message";
          $ctrl.message = model.message;
          $ctrl.autoClose = type === service.ConfirmType.SUCCESS || type === service.ConfirmType.INFO || !!model.autoClose;
          $ctrl.close = type === service.ConfirmType.EQUATION || service.ConfirmType.WARNING;
          $ctrl.autoCloseTimeout = model.autoCloseTimeout || 3000;
          $ctrl.buttons = model.buttons;
          $ctrl.template = model.template;
          $ctrl.data = model.data;
          $ctrl._ = _;

          $ctrl.headerClassMap = {
            DELETE: 'header-danger',
            SUCCESS: 'header-success',
            INFO: 'header-info',
            CONFIRM: 'header-info',
            EQUATION: 'header-info',
            WARNING: 'header-warning'
          };

          $ctrl.ok = function() {
            $ctrl.successful = true;
            (success || angular.noop)();
            $ctrl.cancel();
          };

          $ctrl.cancel = function() {
            service.isOpen = false;
            if (!$ctrl.successful) {
              (error || angular.noop)();
            }
            $uibModalInstance.dismiss('cancel');
          };

          if ($ctrl.autoClose) {
            $timeout(function() {
              $ctrl.cancel();
            }, $ctrl.autoCloseTimeout);
          }

          $ctrl.init = function() {
            // Initialize MathJax of displaying symbols
            if (type === service.ConfirmType.EQUATION) {
              MathJax.Hub.Configured();
              window.setTimeout(function() {
                var math = document.getElementById("modal-body");
                MathJax.Hub.Queue(["Typeset",MathJax.Hub,math]);
              }, 100);
            }
          };

          $ctrl.print = function() {
            PrintUtil.printHGV($ctrl.data);
          };

          $ctrl.copy = function(ele) {
            var fn = model['copy'].bind(this);
            $ctrl.copied = fn.call($ctrl, ele, $window.document);
          };
        }
      });
    }
  };
  return service;
});
