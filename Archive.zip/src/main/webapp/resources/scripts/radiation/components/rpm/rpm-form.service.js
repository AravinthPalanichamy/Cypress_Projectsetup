'use strict';
angular.module('app').factory('RpmFormService', function($uibModal, StaticCollections, PermissionService, UaService, PersonService, CURRENT_USER) {

  var service = {
    isOpen: false,

    makeForm: function(rua, rpm, options, callback) {
      if (service.isOpen) return true;
      $uibModal.open({
        templateUrl: 'resources/scripts/radiation/components/rpm/rpm-form.html',
        controllerAs: '$ctrl',
        size: 'lg',
        keyboard: false,
        backdrop: 'static',
        resolve: {},
        controller: function($uibModalInstance, RpmService) {
          var $ctrl = this;
          service.isOpen = true;
          $ctrl.panels = {
            GENERAL: 'General'
          };
          $ctrl.refreshParent = false;
          $ctrl.panel = $ctrl.panels.GENERAL;
          $ctrl.rua = rua;
          $ctrl.rpm = rpm;
          $ctrl.noOfTubesOptions = Object.keys(StaticCollections.noOfTubesOptions).map(function(item) {
            return parseInt(item);
          });
          $ctrl.useCodes = StaticCollections.useCodes;
          $ctrl.hazardClasses = StaticCollections.classHash;
          $ctrl.yesNoOptions = StaticCollections.yesNoOptions;
          $ctrl.useLocations = [];
          if ($ctrl.rua) {
            $ctrl.useLocations = $ctrl.rua.uaBundle.uaBundleLocations;
          }
          $ctrl.rpmUsesTypes = Object.keys(StaticCollections.rpmUsesTypes);
          $ctrl.typeaheadLabel = UaService.typeaheadLabel;
          $ctrl.voltageUnit = 'kVp';
          $ctrl.timeUnit = 'sec';
          $ctrl.currentUnit = 'mA';

          $ctrl.init = function() {
            if (!$ctrl.rua) {
                UaService.getUaListByStatusAndTypeAndCampusCode({
                  uaStatus: StaticCollections.getKeyByValue(StaticCollections.uaStatusHash, "Active"),
                  uaType: StaticCollections.getKeyByValue(StaticCollections.uaTypeHash, "Radiation Producing Machines"),
                  campusCode: CURRENT_USER.campus.code
                }, {}).$promise.then(function(response) {
                  $ctrl.useAuthorizations = response;
                  if (response.length > 0) {
                    PermissionService.setData(response[0]);
                  }
                });
            }
            $ctrl.readOnly = !PermissionService.hasPermission();
            if ($ctrl.rpm && $ctrl.rpm.id) {
              $ctrl.panels.DOCUMENTS = 'Documents';
              $ctrl.panels.CHANGELOG = 'Changelog';
            }
          };

          $ctrl.setPanel = function(panel) {
            if (panel === $ctrl.panels.GENERAL) {
              RpmService.get({rpmId: $ctrl.rpm.id}).$promise
                .then(function(response) {
                  $ctrl.rpm = response;
                })
                .then(function() {
                  $ctrl.panel = panel;
                });
            } else {
              $ctrl.panel = panel;
            }
          };

          $ctrl.cancel = function() {
            service.isOpen = false;
            $uibModalInstance.dismiss('cancel');
            callback($ctrl.refreshParent);
          };

          $ctrl.save = function() {
            if ($ctrl.isFormValid()) {
              RpmService.add({}, $ctrl.rpm)
                .$promise
                .then(function(data) {
                  $ctrl.showSuccessMessage = true;
                  $ctrl.refreshParent = true;
                  $ctrl.rpm = angular.copy(data);
                  $ctrl.init();
                });
            }
          };

          $ctrl.onSelectRpm = function(selectedRpm) {
            $ctrl.rpm = selectedRpm;
          };

          $ctrl.toggleLocationError = function() {
            $ctrl.locationError = $ctrl.rpm.location && $ctrl.rpm.location.id ? false : true;
          };

          $ctrl.toggleError = function(type) {
            if (type === 'MACHINE_ID') {
              $ctrl.machineIdError = !$ctrl.rpm.machineId;
            }
            if (type === 'TYPE') {
              $ctrl.rpmTypeError = !$ctrl.rpm.type;
            }
            if (type === 'MANUFACTURER') {
              $ctrl.manufacturerError = !$ctrl.rpm.manufacturer;
            }
            if (type === 'MODEL') {
              $ctrl.modelError = !$ctrl.rpm.model;
            }
          };

          $ctrl.isFormValid = function() {
            $ctrl.locationError = !($ctrl.rpm.location && $ctrl.rpm.location.id);
            $ctrl.machineIdError = !$ctrl.rpm.machineId;
            $ctrl.rpmTypeError = !$ctrl.rpm.type;
            $ctrl.manufacturerError = !$ctrl.rpm.manufacturer;
            $ctrl.modelError = !$ctrl.rpm.model;
            if ($ctrl.locationError || $ctrl.machineIdError || $ctrl.rpmTypeError || $ctrl.manufacturerError || $ctrl.modelError) {
              return false;
            }
            return true;
          };

          $ctrl.showAvailableRPMs = function(cb) {
            RpmService.getAllAvailableRpmsByCampus().$promise.then(function(rpms) {
              $uibModal.open({
                templateUrl: 'resources/scripts/radiation/components/rpm/available-rpms/available-rpms.html',
                controllerAs: '$rpmCtrl',
                size: 'lg',
                keyboard: false,
                backdrop: 'static',
                resolve: {},
                controller: function($uibModalInstance, TableHeaderCollections, RpmService) {
                  var $rpmCtrl = this;
                  $rpmCtrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
                  $rpmCtrl.tableHeaders = {};
                  $rpmCtrl.rpms = angular.copy(rpms || []);

                  $rpmCtrl.init = function() {
                    $rpmCtrl.getTableHeader();
                  };

                  $rpmCtrl.getTableHeader = function() {
                    $rpmCtrl.tableHeaders = {
                      EDIT: Object.assign({}, $rpmCtrl.tableHeaderCollections.EDIT, {cellTemplate: "rua-pick-rpm-edit.html"}),
                      MACHINE_ID: $rpmCtrl.tableHeaderCollections.MACHINE_ID,
                      MACHINE_TYPE: $rpmCtrl.tableHeaderCollections.MACHINE_TYPE,
                      MACHINE_MANUFACTURER: $rpmCtrl.tableHeaderCollections.MACHINE_MANUFACTURER,
                      MACHINE_MODEL: $rpmCtrl.tableHeaderCollections.MACHINE_MODEL
                    };

                    $rpmCtrl.rpmColumns = Object.values($rpmCtrl.tableHeaders);
                  };

                  $rpmCtrl.onPickRpm = function(selectedRpm) {
                    selectedRpm.ua = {
                      id: $ctrl.rua.id,
                      number: $ctrl.rua.number
                    };
                    cb(selectedRpm);
                    $rpmCtrl.cancel();
                  };

                  $rpmCtrl.cancel = function() {
                    $uibModalInstance.dismiss('cancel');
                  };

                  $rpmCtrl.init();
                }
              });
            });
          };

          $ctrl.selectRua = function(rua) {
            UaService.getUa({uaId: rua.id}).$promise
              .then(function(res) {
                $ctrl.rua = res;
                $ctrl.useLocations = $ctrl.rua.uaBundle.uaBundleLocations;
                $ctrl.rpm = {
                  ua: {
                    id: res.id
                  }
                };
              });
          };

          $ctrl.init();
        }
      });
    }
  };

  return service;
})
  .run(function($templateCache) {
    var rpmEditTemplate = '<div class="edit-link">'
      + ' <span><input type="radio" ng-click="grid.appScope.parentScope.onPickRpm(row.entity)"></span>'
      + '</div>';
    $templateCache.put('rua-pick-rpm-edit.html', rpmEditTemplate);
  });
