'use strict';

angular.module('app').component("changelog", {
  templateUrl: 'resources/scripts/radiation/components/changelog/changelog.html',
  controllerAs: '$ctrl',

  controller: function(CONTEXT_PATH, AdminService) {

    var ctrl = this;
    ctrl.data = [];
    ctrl.excludeProps = ['createdBy', 'createdDate', 'lastModifiedBy', 'lastModifiedDate',
                          'enteredBy', 'enteredDate', 'userId', 'id', 'parentMaterial',
                          'buildingId', 'buildingKey', 'floorKey', 'roomId', 'roomKey',
                          'buildingPrimaryName', 'campusCode', ctrl.entityName.toLowerCase()];

    ctrl.stripNestedProps = '(id=|floorName=|buildingPrimaryName=|campusCode=)';

    function toTitleCase(match, offset) {
      return (offset > 0) ? ' ' + match : match.toUpperCase();
    }

    function toSmallCase(match) {
      return (match) ? '<small>' + match + '</small>' : match;
    }

    function titleCasePropertyName(changelog) {
      var titleCaseRegex = new RegExp('^\\w|[A-Z][a-z]', 'gm');
      changelog.propertyDisplayName = changelog.propertyName.replace(titleCaseRegex, toTitleCase);
      if (changelog.propertyName.toLowerCase() === 'ua') { changelog.propertyDisplayName = 'RUA'; }
      return changelog;
    }

    /*
      This fn does the actual searching and replacing the toString impl.
      It does in the below following steps:
      1st: replace performs the searching of the entire string enclosed inside '[ prop=value ]'
            and replaces with empty string.
      2nd: replaces the 'id' property from to simple toString impl to empty string.
      3rd: replaces any '=' to ':' (kind of json format)
      4th: replaces the matching propertyName if present. ex(frequency:monthly -> monthly).
      5th: replaces the last hanging ',' in the string with empty string.
      6th: modifies the prop key with a <small>prop</small> (UI change)
     */
    function searchAndReplace(value, propertyName) {
      if (!value) { return value; }
      var nestedObjMatchRegex = new RegExp('\\w+\\=\\w+\\s\\[[\\S\\s]+\\]\\,|\\w+\\s\\[|\\]', 'gmi');
      var stripPropsRegex = new RegExp(ctrl.stripNestedProps + '[\\w\\s\\w\\.\\(\\)]+', 'gmi');
      var propMatchRegex = new RegExp(propertyName.toLowerCase() + '\\:', 'gm');
      var endRegex = new RegExp('^\\,|\\,\\s+\\,|\\,\\s+$', 'gmi');

      return value.replace(nestedObjMatchRegex, '')
                  .replace(stripPropsRegex, '')
                  .replace(/\=/gmi, ': ')
                  .replace(propMatchRegex, '')
                  .replace(endRegex, '')
                  .replace(/[\S]+(?=\:\s)/gmi, toSmallCase);
    }

    /*
      This fn parses the entire java toString object into a simple user readable 'prop: value'
      string.
      The fn modifies both the oldValue and the newValue to the new format(prop: value).
      The java toString impl returns the complete necessary info to be stored in the db,
      which is not quite informative to the user. So, inorder to reduce the complexity
      we strip out the nested information present in the toString impl.

      Ex(i/p): Ua [id=120, number=4433, type=RAM, statusType=ACTIVE, pi=Person [id=1014, firstName=Praveen, lastName=Gupta, campus=Campus [name=University Of California - Davis], ], expiryDate=08/08/2019, ]

      Ex(o/p):  number:4433, type:RAM, statusType:ACTIVE, expiryDate: 08/08/2019

      In the above ex, we completely strip out the pi and campus info from the
      toString impl.
     */
    function parsePropertyContent(changelog) {
      var nestedObjRegex = new RegExp('[\\[\\,\\]]+');
      var value;
      if (changelog.oldValue && nestedObjRegex.test(changelog.oldValue)) {
        value = searchAndReplace(changelog.oldValue, changelog.propertyName);
        changelog.oldValue = value ? value : changelog.oldValue;
      }
      if (changelog.newValue && nestedObjRegex.test(changelog.newValue)) {
        value = searchAndReplace(changelog.newValue, changelog.propertyName);
        changelog.newValue = value ? value : changelog.newValue;
      }

      return changelog;
    }

    ctrl.defineTable = function() {
      return [
        {displayName: 'Field Name', field: 'propertyDisplayName'},
        {displayName: 'Old Value', field: 'oldValue', cellTemplate: 'old-value-template.html'},
        {displayName: 'New Value', field: 'newValue', cellTemplate: 'new-value-template.html'},
        {displayName: 'Modified By', field: 'modifiedByPersonName'},
        {displayName: 'Date Modified', field: 'lastModifiedDate', cellFilter: 'date:"MM/dd/yyyy"'}
      ];
    };

    ctrl.init = function() {
      AdminService.findChangelog({entityId: ctrl.entityId, entityName: ctrl.entityName}, {}).$promise.then(function(response) {
        ctrl.data = _.reject(response, function(changelog) {
          if (changelog.propertyName) {
            parsePropertyContent(changelog);
            titleCasePropertyName(changelog);
          }
          if ((!changelog.oldValue && !changelog.newValue) ||
              (!changelog.oldValue.trim() && !changelog.newValue.trim())) { return true; }
          return _.includes(ctrl.excludeProps, changelog.propertyName);
        });
      });
      ctrl.columns = ctrl.defineTable();
    };

  },
  bindings: {
    entityId: '=',
    entityName: '='
  }
})
.run(function($templateCache) {
  $templateCache.put('old-value-template.html',
    '<div class="ui-grid-cell-contents" ng-if="row.entity">' +
      '<span ng-if="row.entity.oldValue" ng-bind-html="row.entity.oldValue"></span>' +
    '</div>');

  $templateCache.put('new-value-template.html',
    '<div class="ui-grid-cell-contents" ng-if="row.entity">' +
      '<span ng-if="row.entity.newValue" ng-bind-html="row.entity.newValue"></span>' +
    '</div>');
});
