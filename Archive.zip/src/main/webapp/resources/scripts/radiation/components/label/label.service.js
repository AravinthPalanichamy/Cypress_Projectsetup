'use strict';

angular.module('app').factory('LabelService', function($uibModal) {
  var ssLabelCtrl = this;
  var service = {
    displayLabel: function(data) {
      $uibModal.open({
        templateUrl: 'resources/scripts/radiation/components/label/_label.html',
        controllerAs: '$ctrl',
        size: 'sm',
        keyboard: false,
        windowTopClass: 'label-model',
        backdrop: 'static',
        controller: function($uibModalInstance) {
          var $ctrl = this;
          $ctrl.dataList = data;
          service.isOpen = true;

          $ctrl.cancel = function() {
            service.isOpen = false;
            $uibModalInstance.dismiss('cancel');
          };
        }
      });
    }
  };
  return service;
});
