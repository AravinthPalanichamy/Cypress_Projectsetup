'use strict';

angular.module('app').component("pageDomain", {
  templateUrl: 'resources/scripts/radiation/components/page-domain/page-domain.html',
  controllerAs: '$ctrl',

  controller: function(PageDomainService, $location, StaticCollections) {

    var ctrl = this;

    ctrl.init = function() {
      ctrl.pageDomainType = StaticCollections.pageDomainType[ctrl.key];
      ctrl.pageDomain = PageDomainService.get()[ctrl.pageDomainType.key];
      if (ctrl.pageDomain) {
        ctrl.pageDomain.currentIndex = ctrl.pageDomain.ids.indexOf(ctrl.domainId);
        if (ctrl.pageDomain.currentIndex === -1) {ctrl.pageDomain = null;}
        PageDomainService.save(ctrl.key, ctrl.pageDomain);
      }
    };

    ctrl.onNextClick = function() {
      if (ctrl.pageDomain.currentIndex < ctrl.pageDomain.lastIndex) {
        ctrl.pageDomain.currentIndex += 1;
        ctrl.saveAndRoute();
      }
    };

    ctrl.onPreviousClick = function() {
      if (ctrl.pageDomain.currentIndex > 0) {
        ctrl.pageDomain.currentIndex -= 1;
        ctrl.saveAndRoute();
      }
    };

    ctrl.saveAndRoute = function() {
      PageDomainService.save(ctrl.key, ctrl.pageDomain);
      var path = ctrl.pageDomain.routeUrl + ctrl.pageDomain.ids[ctrl.pageDomain.currentIndex];
      $location.path(path);
    };

  },
  bindings: {
    key: '=',
    domainId: '='
  }
});
