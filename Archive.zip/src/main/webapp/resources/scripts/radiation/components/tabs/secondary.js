'use strict';

angular.module('app').component("secondary", {
  templateUrl: 'resources/scripts/radiation/components/tabs/secondary.html',
  controllerAs: 'ctrl',

  controller: function($scope, $location, CONTEXT_PATH) {
    var ctrl = this;
    ctrl.subGroup = [];
    ctrl.tabClicked = false;
    ctrl.tabIndex = 0;
    ctrl.navLevel3Active = false;

    ctrl.$onChanges = function() {
      if (ctrl.tabs) {
        var matches = $location.path().match(/\/[a-zA-Z-]*/g);
        if (matches[matches.length - 1] === '/') {
          matches.splice(matches.length - 1, 1);
        }
        ctrl.basePath = CONTEXT_PATH + '/#' + ctrl.parentUrl || matches[0];
        var deletedMatch = matches.splice(0, 1);
        var path = matches.join('');
        var index = _.findIndex(ctrl.tabs, function(tab) {
          return (tab.url === '' && !path) || tab.url === path;
        });
        if (index > -1) {
          ctrl.tabClicked = true;
          ctrl.tabIndex = index;
        } else {
          ctrl.tabClicked = true;
          ctrl.tabIndex = 0;
        }
        ctrl.navLevel3Active = new RegExp("/rua/add").test($location.path());
      }
    };

    ctrl.activeCSS = function(index, tab) {
      return ctrl.tabClicked ? ctrl.tabIndex === index : false;
    };

    $scope.$on('$routeChangeStart', function(next, current) {
      ctrl.$onChanges();
      ctrl.navLevel3Active = new RegExp("/rua/add").test($location.path());
    });
  },
  bindings: {
    tabs: '<',
    onTabClick: '&',
    parentUrl: '<'
  }
});
