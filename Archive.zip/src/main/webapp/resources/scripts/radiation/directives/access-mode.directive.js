'use strict';

angular.module('app')
  .directive('accessMode', function($location, PermissionService) {
    return {
      restrict: 'A',
      scope: {},
      link: link
    };

    function link(scope, element, attrs) {
      var permission;

      function modifyDOM() {
        if (PermissionService.result) {
          PermissionService.result.then(successCallback, errorCallback);
        }
      }

      function successCallback(response) {
        permission = PermissionService.getRoleAndScore();
        if (_.inRange(permission.score, 50, 55)) {
          giveFullAccess('rwx');
        } else if (_.inRange(permission.score, 40, 45) || _.inRange(permission.score, 30, 35)) {
          if (permission.score % 10 === 0) {
            givePartialWriteAcess('pw');
          } else if (permission.score % 10 === 1 || permission.score % 10 === 2) {
            giveReadWriteAccess('rw');
          } else if (permission.score % 10 === 3) {
            giveOnlyReadAcess('r');
          } else {
            giveOnlyReadAcess('r');
          }
        } else {
          if (_.eq($location.path(), '/rua/create')) {
            givePartialWriteAcess('pw');
          } else {
            giveOnlyReadAcess('r');
          }
        }
      }

      function errorCallback(error) {
        giveOnlyReadAcess('r');
      }

      function giveFullAccess() {
        console.debug('FULL ACCESS');
        var props;
        if (_.eq((permission.score % 10), 0)) {
          props = ['rua-base', 'signatureDeptChair', 'signatureRsc', 'signatureRso', 'signatureRuaHolder',
          'assessmentFactor', 'noCharge', 'hgv', 'detector', 'dosimetry', 'other', 'terminatedDate',
          'expiryDate', 'frequency', 'organization', 'hazardClass', 'lastUpdatedDate', 'animalUse',
          'description', 'precautions', 'comments','enterDate', 'enteredBy', 'start', 'ua-submit', 'end'];
          _.some(props, recurseDOM);
        } else {
          props = ['specialRequest', 'end', 'ua-submit'];
          _.some(props, recurseDOM);
        }
      }

      function giveWriteAccess() {
        console.debug('ONLY WRITE');
        giveFullAccess();
      }

      function giveReadWriteAccess() {
        console.debug('READ/WRITE');
        var ele = _.head(element);
        var props;
        if (_.eq((permission.score % 10), 1)) {
          props = ['rua-base', 'signatureDeptChair', 'signatureRsc', 'signatureRso', 'signatureRuaHolder',
          'specialRequest', 'assessmentFactor', 'noCharge', 'hgv', 'detector', 'dosimetry', 'other',
          'terminatedDate', 'expiryDate', 'frequency', 'organization', 'status', 'hazardClass',
          'ua-buttons', 'person-dosimetry', 'userExperience', 'addedToRua', 'prsn-comment',
          'radiationContact', 'exceptionalRua', 'rpmUses', 'onLicense', 'rpm-hazardClass', 'useCode', 'hgvcalc', 'amendmentNumber'];
          _.some(props, recurseDOM);
        } else if (_.eq((permission.score % 10), 2)) {
          props = ['specialRequest', 'transfer', 'end', 'ua-submit', 'save-top', 'save-bottom', 'etic', 'hgvcalc'];
          _.some(props, recurseDOM);
          var omitDisableProp = ['change-request'];
          _.some(omitDisableProp, disableDOM);
        }
      }

      function givePartialWriteAcess() {
        console.debug('PARTIAL WRITE');
        var ele = _.head(element);
        var props = ['rua-base', 'contactInfo', 'signatureDeptChair', 'signatureRsc', 'signatureRso',
        'signatureRuaHolder', 'assessmentFactor', 'noCharge', 'hgv', 'detector', 'dosimetry', 'other',
        'terminatedDate', 'expiryDate', 'frequency', 'organization', 'status', 'hazardClass',
        'lastUpdatedDate', 'animalUse', 'description', 'precautions', 'comments','enterDate', 'enteredBy',
        'ruaNumber', 'ua-submit', 'start', 'hgvcalc', 'etic'];
        _.some(props, recurseDOM);
      }

      function giveOnlyReadAcess() {
        console.debug('ONLY READ');
        var ele = _.head(element);
        var props = ['specialRequest'];
        if (permission.score % 10 === 3) {
          props = ['rua-base', 'signatureDeptChair', 'signatureRsc', 'signatureRso', 'signatureRuaHolder',
          'specialRequest', 'assessmentFactor', 'noCharge', 'hgv', 'detector', 'dosimetry', 'other',
          'terminatedDate', 'expiryDate', 'frequency', 'organization', 'status', 'hazardClass',
          'etic', 'start', 'end', 'ua-submit', 'save-top', 'save-bottom', 'transfer', 'hgvcalc', 'amendmentNumber'];
        } else {
          props = ['etic', 'start', 'end', 'ua-submit', 'save-top', 'save-bottom', 'transfer', 'change-request', 'hgvcalc'];
        }
        _.some(props, recurseDOM);
        var omitDisableProp = ['change-request'];
        _.some(omitDisableProp, disableDOM);
      }

      function removeChildNodes(ele) {
        while (ele.firstChild) {
          //The list is LIVE so it will re-index each call
          ele.removeChild(ele.firstChild);
        }
        var parent = ele.parentElement;
        if (parent) { parent.removeChild(ele); }
      }

      function recurseDOM(prop) {
        var ele = _.head(element);
        var idAttr = "[id=\'" + prop + "\']";
        var idElement = ele.querySelector(idAttr);
        if (idElement) { removeChildNodes(ele); return true;}
      }

      function disableDOM(prop) {
        var ele = _.head(element);
        var idAttr = "[id=\'" + prop + "\']";
        var idElement = ele.querySelector(idAttr);
        if (!idElement) { ele.setAttribute('disabled', true); return true;}
      }

      modifyDOM();

    }
  });
