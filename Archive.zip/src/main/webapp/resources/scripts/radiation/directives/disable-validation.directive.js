'use strict';

angular.module('app').directive('disableValidation', function() {
 return {
   terminal: true,
   require: 'ngModel',
   link: function(scope, elem, attrs, ngModelController) {

     function wrapOriginalValidators() {
      var originalValidators = angular.copy(ngModelController.$validators);
      Object.keys(originalValidators).forEach(function(key) {
        ngModelController.$validators[key] = function(modelValue, viewValue) {
          return scope.$eval(attrs.disableValidation) || originalValidators[key](modelValue, viewValue);
        };
      });
     }

     function watchDisableCriteria() {
      scope.$watch(attrs.disableValidation, function() {
        // trigger validation
        ngModelController.$validate();
      });
     }

     wrapOriginalValidators();
     watchDisableCriteria();

     }
 };
});
