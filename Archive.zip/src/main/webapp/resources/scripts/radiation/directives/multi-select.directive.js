'use strict';

angular.module('app')
  .directive('multiSelect', function() {
    return {
      restrict: 'E',
      transclude: true,
      scope: {},
      templateUrl: 'resources/scripts/radiation/components/table/multiSelect.html',
      link: function(scope, element, attr) {
        scope.col = scope.$parent.col;
        scope.filter = scope.col.filter;
        scope.aggregator = scope.filter.aggregator;
        scope.itemSelected = 0;

        scope.init = function() {
          if (!scope.filter || !scope.filter.options) {
            return false;
          }
          var item = _.filter(scope.filter.options, {'label': 'ALL'})[0];
          if (item && item.selected) {
            _.forEach(scope.filter.options, function(opt) {
              return _.set(opt, 'selected', item.selected);
            });
            scope.itemSelected = _.chain(scope.filter.options).filter({'selected': true}).size().value();
          }
        };

        scope.filterChanged = function(item) {
          if (item) {
            if (item.label === 'ALL') {
              _.forEach(scope.filter.options, function(opt) {
                return _.set(opt, 'selected', item.selected);
              });
            } else {
              _.find(scope.filter.options, {'label': 'ALL'}).selected = _.chain(scope.filter.options).reject({'value': 'all'}).filter({'selected': false}).isEmpty().value();
            }
          }
          scope.filter.term = _.chain(scope.filter.options).filter({'selected': true})
            .reject({'value': 'all'}).map('value').value();
          scope.itemSelected = _.chain(scope.filter.options).filter({'selected': true}).size().value();
        };

        scope.toggleAggregator = function(aggregator) {
          scope.aggregator = scope.filter.aggregator = aggregator;
          scope.filterChanged();
        };

        scope.$watch('filter.term', function(newValue, oldValue) {
          if (!newValue) {
            var item = _.filter(scope.filter.options, {'label': 'ALL'})[0];
            item.selected = true;
            scope.filter.term = '';
            item.touched = false;
            scope.aggregator = scope.filter.aggregator;
            scope.init();
          }
        });
      }
    };

  });
