'use strict';

angular.module('app')
  .directive('datePicker', function(uiGridConstants) {
    return {
      restrict: 'E',
      transclude: true,
      scope: {},
      templateUrl: 'resources/scripts/radiation/components/table/datePicker.html',
      link: function(scope, element, attr) {
        scope.filter = scope.$parent.colFilter;
        scope.col = scope.$parent.$parent.col;
        scope.colDef = scope.$parent.$parent.col.colDef;


        scope.today = new Date();
        scope.init = function() {
          scope.filter.dateOptions = {
            formatYear: 'yyyy',
            startingDay: 1,
            showWeeks: false
          };
        };

        scope.toggleDate = function() {
          scope.isOpen = true;
        };

        scope.dateChanged = function(filterName) {
          if (scope.colDef && scope.colDef.enableDefaultToDate) {
             scope.setDefaultToDate(filterName);
          } else {
            // update min and max date on the datepicker
            scope.updateMinMaxDate(filterName);
          }
        };

        scope.updateMinMaxDate = function(filterName) {
          var predicate = {'name': filterName};
          var selectedFilter = _.find(scope.col.filters, predicate);
          var filter = _.reject(scope.col.filters, predicate)[0];
          // condition: uiGridConstants.filter.GREATER_THAN_OR_EQUAL
          if (selectedFilter.condition === uiGridConstants.filter.GREATER_THAN_OR_EQUAL) {
            filter.dateOptions.minDate = new Date(selectedFilter.term);
          }
          // condition: uiGridConstants.filter.LESS_THAN_OR_EQUAL
          if (selectedFilter.condition === uiGridConstants.filter.LESS_THAN_OR_EQUAL) {
            filter.dateOptions.maxDate = new Date(selectedFilter.term);
          }
        };

        scope.setDefaultToDate = function(filterName) {
          var selectedFilter = _.find(scope.col.filters, {'name': filterName});
          if (filterName === 'dateFrom') {
            var t = _.find(scope.col.filters, {'name': 'dateTo'});
            t.term = (moment(selectedFilter.term).endOf('month')).valueOf();
          }
        };

        scope.init();
      }
    };
  })
  .run(function($templateCache) {
    $templateCache.put('calendar-from.html',
      '<span class="fa-stack fa-lg">' +
      '<i class="fa fa-calendar fa-stack-1x fa-lg"></i>' +
      '</span>'
    );
    $templateCache.put('calendar-to.html',
      '<span class="fa-stack fa-lg">' +
      '<i class="fa fa-calendar fa-stack-1x fa-lg"></i>' +
      '</span>'
    );
  });
