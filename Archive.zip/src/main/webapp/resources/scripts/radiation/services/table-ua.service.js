'use strict';

angular.module('app').factory('TableService', function($location, $resource, $rootScope) {
  var service = $resource('api/ua/', {}, {
    searchEmail: {method: 'POST', url: 'api/ua/search/email', isArray: true}
  });

  service.searchAndDisplayEmail = function(state, url) {
    service.searchEmail({}, state).$promise.then(function(response) {
      $rootScope.uaEmailList = response;
      $location.path(url);
    });
  };

  return service;
});
