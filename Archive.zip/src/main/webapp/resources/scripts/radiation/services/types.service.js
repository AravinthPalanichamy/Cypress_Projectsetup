'use strict';

angular.module('app').factory('TypesService', function($resource) {
  return $resource('api/types/', {campusCode: '@campusCode'}, {
    getFrequencyList: {method: 'GET', url: 'api/types/frequency', isArray: true, cache: true},
    getMonitorTypes: {method: 'GET', url: 'api/types/monitor-types', isArray: true, cache: true},
    getAllRsoRst: {method: 'GET', url: 'api/types/role/campus/:campusCode', isArray: true},
    getDetectorTypes: {method: 'GET', url: 'api/types/detector-types', isArray: true, cache: true},
    getPhysicalFormsList: {method: 'GET', url: 'api/types/physical-form', isArray: true, cache: true},
    getEngineeringControlFactors: {method: 'GET', url: 'api/types/eng-controls', isArray: true, cache: true},
    getUseFactors: {method: 'GET', url: 'api/types/use-factors', isArray: true, cache: true},
    getFormFactors: {method: 'GET', url: 'api/types/form-factors', isArray: true, cache: true},
    getUAOthers: {method: 'GET', url: 'api/types/ua-others', isArray: true, cache: true},
    getAllUsePurposes: {method: 'GET', url: 'api/types/use-purposes/campus/:campusCode', isArray: true, cache: true},
    getLicenseLineNumbers: {
      method: 'GET',
      url: 'api/types/license-line-numbers/campus/:campusCode/radionuclide/:radionuclideId',
      isArray: true
    },
    getInventoryStatusTypes: { method: 'GET', url: 'api/types/inventory-status', isArray: true, cache: true }
  });
});
