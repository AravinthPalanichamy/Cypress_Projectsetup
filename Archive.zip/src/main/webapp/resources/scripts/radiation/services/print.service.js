'use strict';

angular.module('app').factory('PrintService', function($resource, ConfirmModelService) {
  var transResp = function(response, headers) {
    if (headers('Content-Disposition')) {
      var filename = headers('Content-Disposition').split('=')[1];
      return {'data': {file: new Blob([response], {type: 'application/octet-stream'}), filename: filename}};
    } else {
      return {'data': null};
    }
  };

  var transRespToFile = function(response, headers) {
    if (headers('Content-Disposition') && response !== null) {
      var filename = headers('Content-Disposition').split('=')[1];
      return {'file': new File([response], filename, {type: 'application/pdf'})};
    } else {
      throw "Something went wrong while creating pdf.";
    }
  };


  var service = $resource('api/print', {}, {
    printLeakTests: {
      method: 'POST',
      url: 'api/print/leaktests',
      responseType: 'arraybuffer',
      transformResponse: transRespToFile
    },
    printWasteTag: {
      method: 'POST',
      url: 'api/print/wasteTag/:token',
      responseType: 'arraybuffer',
      transformResponse: transResp
    },
    printUa: {
      method: 'GET',
      url: 'api/print/:uaId',
      responseType: 'arraybuffer',
      transformResponse: transRespToFile},
    printDosimetryRoutineIssuance: {
      method: 'POST',
      url: 'api/print/dosimetry-routine-issuance',
      responseType: 'arraybuffer',
      transformResponse: transRespToFile
    },
    printDosimetryGroupIssuance: {
      method: 'POST',
      url: 'api/print/dosimetry-group-issuance',
      responseType: 'arraybuffer',
      transformResponse: transRespToFile
    },
    printCalibrationCertificate: {
      method: 'POST',
      url: 'api/print/calibration-certificate',
      responseType: 'arraybuffer',
      transformResponse: transRespToFile
    },
    printPackageReceipts: {
      method: 'POST',
      url: 'api/print/package-receipt',
      responseType: 'arraybuffer',
      transformResponse: transRespToFile
    },
    printPackages: {
      method: 'POST',
      url: 'api/print/package-transfer',
      responseType: 'arraybuffer',
      transformResponse: transRespToFile
    }
  });

  service.openInTab = function(fnName, params) {
    var fn = (service[fnName]).bind(this);
    var win = window.open('', '_blank');
    return fn(params).$promise.then(function(response) {
        win.location = URL.createObjectURL(response.file);
        win.focus();
    }, function(err) {
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.INFO, {header: "Error", message: err});
    });
  };

  return service;

});
