'use strict';

angular.module('app').factory('CollectionService', function($resource) {
  return $resource('', {}, {
    getCollectionByCampus: {method: 'GET', url: 'api/collection', isArray: true}
  });
});
