'use strict';

angular.module('app').factory('LocationService', function($resource) {
  return $resource('api/location/', {}, {
    findBuildings: {method: 'GET', url: 'api/location/search', isArray: true},
    findRooms: {method: 'GET', url: 'api/location/search/rooms/buildings/:buildingId', isArray: true},
    findCpuLocations: {method: 'GET', url: 'api/location/campus/cpu-locations', isArray: true}
  });
});
