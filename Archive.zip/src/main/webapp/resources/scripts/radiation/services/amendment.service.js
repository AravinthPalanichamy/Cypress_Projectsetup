'use strict';

angular.module('app').factory('AmendmentService', function($resource) {

  var service = $resource('api/amendment/:amendmentId', {amendmentId: '@amendmentId'}, {
    getUaAmendment: {method: 'GET', url: 'api/amendment/:amendmentId'}
  });

  service.compareAndMergeObjects = function(source, target, type) {
    var result = [];
    target.forEach(function(t) {
      var matchFound = _.find(source, function(s) {
        return service._determineAndSetPredicate(s, t, type);
      });
      if (matchFound) {
        if (service._determineAndCheckObjEquality(t, matchFound, type)) {
          t.$$action = 'UNTOUCHED';
        } else {
          t.$$action = 'UPDATED';
        }
        result.push(t);
      } else {
        t.$$action = 'ADDED';
        result.push(t);
      }
    });
    source.forEach(function(s) {
      var matchFound = _.find(target, function(t) {
        return service._determineAndSetPredicate(s, t, type);
      });
      if (!matchFound) {
        s.$$action = 'DELETED';
        result.push(s);
      }
    });
    return result;
  };

  service._determineAndSetPredicate = function(s, t, type) {
    switch (type) {
      case 'PERSONNEL':
        return s.person.userId === t.person.userId;
      case 'LIMITS_RADIONUCLIDE':
        return s.enteredDate === t.enteredDate && s.radionuclide.id === t.radionuclide.id;
      case 'LIMITS_SNM':
        return s.enteredDate === t.enteredDate && s.radionuclide.id === t.radionuclide.id;
      case 'DOCUMENTS':
        return s.fileName === t.fileName && s._size === t._size;
      case 'RPM':
        return s.machineId === t.machineId;
    }
  };

  service._determineAndCheckObjEquality = function(a, b, type) {
    switch (type) {
      case 'PERSONNEL':
        return service._isBundlePersonObjectEqual(a, b);
      case 'LIMITS_RADIONUCLIDE':
        return service._isRadionuclideLimitsEqual(a, b);
      case 'LIMITS_SNM':
        return service._isSpecialOrSourceMaterialLimitsEqual(a, b);
      case 'DOCUMENTS':
        return service._isDocumentObjectEqual(a, b);
      case 'RPM':
        return service._isRpmObjectEqual(a, b);
    }
  };

  service._isRpmObjectEqual = function(a, b) {
    return a.location.id === b.location.id
      && a.dphNumber === b.dphNumber
      && a.hazardClass === b.hazardClass
      && a.machineId === b.machineId
      && a.manufacturer === b.manufacturer
      && a.maxTime === b.maxTime
      && a.maximumCurrent === b.maximumCurrent
      && a.maximumVoltage === b.maximumVoltage
      && a.model === b.model
      && a.normalCurrent === b.normalCurrent
      && a.normalTime === b.normalTime
      && a.normalVoltage === b.normalVoltage
      && a.numberOfTubes === b.numberOfTubes
      && a.onLicense === b.onLicense
      && a.type === b.type
      && a.ua.number === b.ua.number
      && a.useCode === b.useCode;
  };

  service._isDocumentObjectEqual = function(a, b) {
    return a.attachmentType === b.attachmentType
      && a.description === b.description
      && a.title === b.title
      && a.referenceDate === b.referenceDate;
  };

  service._isRadionuclideLimitsEqual = function(a, b) {
    return a.enteredDate === b.enteredDate
      && a.radionuclide.id === b.radionuclide.id
      && a.requestedPossessionLimit === b.requestedPossessionLimit
      && a.vialPossessionLimit === b.vialPossessionLimit
      && a.formFactor.id === b.formFactor.id
      && a.useFactor.id === b.useFactor.id
      && a.experimentPossessionLimit === b.experimentPossessionLimit
      && a.engineeringControl.id === b.engineeringControl.id
      && a.chemicalForm === b.chemicalForm
      && a.researchType === b.researchType
      && a.dateAdded === b.dateAdded
      && a.dateRemoved === b.dateRemoved
      && a.isSealedSource === b.isSealedSource;
  };

  service._isSpecialOrSourceMaterialLimitsEqual = function(a, b) {
    return service._isRadionuclideLimitsEqual(a, b)
      && a.gmToMciExpLimit === b.gmToMciExpLimit
      && a.gmToMciPossLimit === b.gmToMciPossLimit
      && a.gmToMciVialLimit === b.gmToMciVialLimit;
  };

  service._isBundlePersonObjectEqual = function(a, b) {
    var ubpToPick = ['addedToRua', 'dateAdded', 'dateRemoved', 'delegate'];
    var bundlePerson = _.pick(a, ubpToPick);
    var otherBundlePerson = _.pick(b, ubpToPick);

    var personToPick = ['comment', 'exceptionalRua', 'hasStatementOfExperience'];
    var person = _.pick(a.person, personToPick);
    var otherPerson = _.pick(b.person, personToPick);

    var dosimetryMap = a.person.$dosimetryMap;
    var otherDosimetryMap = b.person.$dosimetryMap;
    return _.isEqual(bundlePerson, otherBundlePerson) && _.isEqual(person, otherPerson) && _.isEqual(dosimetryMap, otherDosimetryMap);
  };

  return service;
});
