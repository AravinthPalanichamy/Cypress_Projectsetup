'use strict';
angular.module('app').factory('UtilService', function() {

  var service = {
    sortUniqUnion: function(array, mergeArray, mergeLabel) {
      return _.chain(array).union(mergeArray).uniq(mergeLabel).sortBy(mergeLabel).value();
    },
    mapToDropdownOptions: function(array, labelField, valueField) {
      if (!!labelField && !!valueField) {
        return _.map(array, function(item) {
          return {value: item[valueField], label: item[labelField]};
        });
      } else {
        return _.map(array, function(value, label) {
          return {value: value, label: label};
        });
      }
    },
    searchDefaults: {filter: [], sort: [], pagination: {pageNumber: 1, itemPerPage: 10}}
  };

  service.calculateNextDue = function(frequency, previousDate) {
    if (!previousDate) {
      return null;
    }
    var nextDueDate = moment(previousDate).startOf('day');
    switch (frequency) {
      case 'Annually':
        nextDueDate = nextDueDate.add(1, 'years');
        break;
      case 'Monthly':
        nextDueDate = nextDueDate.add(1, 'months');
        break;
      case "Quarterly":
        nextDueDate = nextDueDate.add(3, 'months');
        break;
      case "Semi-Annually":
        nextDueDate = nextDueDate.add(6, 'months');
        break;
    }
    return nextDueDate.toDate();
  };

  service.convertToCampusLimitUnit = function(campusLimitUnit, value) {
    if (campusLimitUnit === 'mCi') {
      return value;
    } else if (campusLimitUnit === 'uCi' || encodeURI(campusLimitUnit) === '%CE%BCCi') { // Encoded value for μCi
      return 1000 * value;
    } else if (campusLimitUnit === 'Ci') {
      return value / 1000;
    } else if (campusLimitUnit === 'g') {
      return value;
    } else if (campusLimitUnit === 'mg') {
      return 1000 * value;
    } else if (campusLimitUnit === 'kg') {
      return value / 1000;
    } else if (campusLimitUnit === 'lb') {
      return 0.00220462 * value;
    }
    return 0.0;
  };
  service.calculateHGV = function(rua) {
    rua.hgvCalculation = {
      sumHGVExt: 0.0,
      sumHGVInt: 0.0,
      sumHGV: 0.0
    };
    _.forEach(rua.uaLimits, function(limit) {
      limit.hgvCalculation = {};
      if (limit.possessionFactor) {
        limit.hgvCalculation.hgvExternal = parseFloat((limit.vialPossessionLimit * limit.radionuclide.eGroup * limit.possessionFactor.possessionFactorValue * limit.engineeringControl.engControlExternal).toFixed(3));
        if (limit.radionuclide.ali > 0) {
          limit.hgvCalculation.hgvInternal = parseFloat(((limit.experimentPossessionLimit / limit.radionuclide.ali) * limit.useFactor.useFactorValue * limit.engineeringControl.engControlInternal * limit.formFactor.formFactorValue).toFixed(3));
        } else {
          limit.hgvCalculation.hgvInternal = 0.0;
        }
        limit.hgvCalculation.individualHGV = parseFloat((limit.hgvCalculation.hgvExternal + limit.hgvCalculation.hgvInternal).toFixed(3));
        rua.hgvCalculation.sumHGVExt += parseFloat(limit.hgvCalculation.hgvExternal.toFixed(3));
        rua.hgvCalculation.sumHGVInt += parseFloat(limit.hgvCalculation.hgvInternal.toFixed(3));
        rua.hgvCalculation.sumHGV += parseFloat(limit.hgvCalculation.individualHGV.toFixed(3));
      }
    });
    rua.hgvCalculation.totalHGV = rua.assessmentFactor.assessmentFactor * rua.hgvCalculation.sumHGV;
    return rua;
  };

  service.findAndGet = function(collection, property, defaultValue='') {
    return function(matchProperty=property, matchValue=defaultValue) {
      return _.get(_.find(collection, [matchProperty, matchValue]), property, defaultValue);
    };
  };

  return service;
});
