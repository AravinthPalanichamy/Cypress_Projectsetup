'use strict';

angular.module('app').factory('AuditService', function($resource) {
  var service = $resource('api/audit', {}, {
    getInventory: {method: 'GET', url: 'api/audit/inventory', isArray: true},
    totalAmountsReport: {method: 'GET', url: 'api/audit/totalAmount', isArray: true},
    roomPresenceReport: {method: 'POST', url: 'api/audit/roomPresence', isArray: true}
  });

  return service;
});
