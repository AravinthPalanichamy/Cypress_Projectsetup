'use strict';

angular.module('app').factory('TileService', function($resource, $http, $window, $location, ENV, BRAND_URL, ORIGINAL_URL_STORAGE_KEY) {
  var storageKey = ORIGINAL_URL_STORAGE_KEY;

  var service = {
    apps: null,
    referrer: '',
    brand: null,
    serviceMap: null,

    initialize: function(callback) {
      if (!this.brand) {
        service.fetchTiles()
          .then(service.generateClientKeys)
          .then(callback);
      } else {
        callback();
      }
    },

    restoreOriginalUrl: function() {
      var url = $window.sessionStorage.getItem(storageKey);
      if (url) {
        $window.sessionStorage.removeItem(storageKey);
        $window.location.href = url;
      }
    },

    generateClientKeys: function() {
      _.forEach(service.apps, function(app) {
        app.clientKey = app.code.toLowerCase();
      });
    },

    fetchTiles: function() {
      var url = BRAND_URL + 'api/branding?environment=' + ENV;
      return $http.get(url).then(function(data) {
        service.apps = data.data.appList;
        service.brand = data.data.brand;
        service.serviceMap = data.data.serviceMap;
        angular.element(document.querySelector('#favicon')).attr('href', service.brand.faviconUrl);
      });
    }
  };

  return service;
});
