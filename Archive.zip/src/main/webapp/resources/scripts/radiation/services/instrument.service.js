'use strict';

angular.module('app').factory('InstrumentService', function($resource) {
  var service = $resource('api/instrument/:instrumentId', {instrumentId: '@instrumentId'}, {
    getAllInstruments: {method: 'GET', url: 'api/instrument/all', isArray: true},
    upsert: {method: 'POST', url: 'api/instrument'},
    updateInstrumentAttachments: {method: 'PUT', url: 'api/instrument/:instrumentId/attachments'},
    getAllAttachments: {method: 'GET', url: 'api/instrument/:instrumentId/attachments', isArray: true},
    deleteInstrumentAttachment: {method: 'DELETE', url: 'api/instrument/:instrumentId/attachment/:attachmentId'},
    getInstrumentCalibrations: {method: 'GET', url: 'api/instrument/:instrumentId/calibrations', isArray: true},
    getCalibration: {method: 'GET', url: 'api/instrument/calibration/:calibrationId'},
    upsertCalibration: {method: 'POST', url: 'api/instrument/calibration'},
    upsertProbe: {method: 'POST', url: 'api/instrument/calibration/probe'},
    upsertCalibrationSource: {method: 'POST', url: 'api/instrument/calibration/calibration-source'},
    upsertProbeResponseCheckSource: {method: 'POST', url: 'api/instrument/calibration/probe-response-check-source'},
    getAllProbes: {method: 'GET', url: 'api/instrument/calibration/probes', isArray: true},
    getAllCalibrationSources: {method: 'GET', url: 'api/instrument/calibration/calibration-sources', isArray: true},
    getAllProbeResponseCheckSources: {
      method: 'GET',
      url: 'api/instrument/calibration/probe-response-check-sources',
      isArray: true
    },
    getMeterRange: {method: 'GET', url: 'api/instrument/calibration/meter-range', isArray: true}
  });
  return service;
});
