'use strict';

angular.module('app').factory('SurveyService', function($resource) {
  var service = $resource('api/survey/:surveyId', {surveyId: '@surveyId'}, {
    getSurveysDue: {
      method: 'GET',
      params: {startDate: '@startDate', endDate: '@endDate'},
      url: 'api/survey/due',
      isArray: true
    },
    getSurveyInspectors: {method: 'GET', url: 'api/survey/inspectors', isArray: true},
    saveSurvey: {method: 'PUT', url: 'api/survey/update'},
    saveSurveys: {method: 'POST', url: 'api/survey/saveOrUpdate', isArray: true},
    sendEmail: {method: 'POST', url: 'api/survey/:surveyId/email'},
    getInspections: {method: 'GET', url: 'api/survey/bundle/:bundleId/inspections', isArray: true},
    getRuaSurveys: {method: 'GET', url: 'api/survey/rua/:ruaId', isArray: true},
    deleteSurvey: {method: 'DELETE', url: 'api/survey/rua/:ruaId/survey/:surveyId'},
    searchSurvey: {method: 'POST', url: 'api/survey/search'},
    updateSurveyAttachments: {method: 'PUT', url: 'api/survey/:surveyId/attachments'},
    deleteSurveyAttachment: {method: 'DELETE', url: 'api/survey/:surveyId/attachment/:attachmentId'},
    getAllSurveyAttachments: {method: 'GET', url: 'api/survey/:surveyId/attachments', isArray: true},
    getEmailTemplate: {method: 'GET', url: 'api/survey/:surveyId/email'}
  });

  service.getDefaultSurveyDueDates = function() {
    var startDate = moment().startOf('month').add(1, 'months');
    var endDate = moment(startDate).endOf('month');
    return {startDate: startDate.toDate(), endDate: endDate.toDate()};
  };

  return service;
});
