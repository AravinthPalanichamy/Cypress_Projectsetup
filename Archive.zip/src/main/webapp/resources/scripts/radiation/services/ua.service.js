'use strict';

angular.module('app').factory('UaService', function($resource) {

  var service = $resource('api/ua/:uaId', {uaId: '@uaId'}, {
    search: {method: 'POST', url: 'api/ua/search'},
    getUa: {method: 'GET', url: 'api/ua/:uaId'},
    updateUa: {method: 'PUT', url: 'api/ua/:uaId'},
    updateUaAttachments: {method: 'PUT', url: 'api/ua/:uaId/attachments'},
    deleteUaAttachment: {method: 'DELETE', url: 'api/ua/:uaId/attachment/:attachmentId'},
    getUaListByStatusAndTypeAndCampusCode: {
      method: 'GET',
      url: 'api/ua/status/:uaStatus/type/:uaType/campus/:campusCode',
      isArray: true
    },
    getUaListByStatusAndCampusCode: {method: 'GET', url: 'api/ua/status/:uaStatus/campus/:campusCode', isArray: true},
    addUa: {method: 'POST', url: 'api/ua/:type/ua-number/:uaNumber/pi/:userId'},
    getUaByUaNumber: {method: 'GET', url: 'api/ua/uaNumber/:uaNumber', isArray: true},
    getAllAttachments: {method: 'GET', url: 'api/ua/:uaId/attachments', isArray: true},
    addPersonToRUA: {method: 'PUT', url: 'api/ua/:uaId/person/:personId'},
    deletePersonFromRUA: {method: 'DELETE', url: 'api/ua/:uaId/remove/person/:userId'},
    getUaPerson: {method: 'GET', url: 'api/ua/:uaId/person/:personId'},
    getUaDetail: {method: 'GET', url: 'api/ua/:uaId/detail'},
    getUaLimitsByUaId: {method: 'GET', url: 'api/ua/:uaId/ua-limit', isArray: true},
    addUaLimit: {method: 'POST', url: 'api/ua/:uaId/ua-limit'},
    deleteUaLimit: {method: 'DELETE', url: 'api/ua/:uaId/ua-limit/:limitId'},
    createAmendment: {method: 'POST', url: 'api/ua/:uaId/amendment/ua-number/:uaNumber'},
    getUAByNumberAndTypeAndStatusType: {method: 'GET', url: 'api/ua/:uaNumber/type/:uaType/status/:uaStatus'},
    approveAmendment: {method: 'PUT', url: 'api/ua/:uaId/amendment/approve'},
    updateSummaryOfChanges: {method: 'PUT', url: 'api/ua/:uaId/amendment/summary-of-changes'},
    getPossessionLimitsByLicense: {method: 'GET', url: 'api/ua/lineNumber/:lineNumberId'},
    getUaBundlePersonTraining: {method: 'GET', url: 'api/ua/:uaId/bundle/person/training', isArray: true},
    reassignRuaPi: {method: 'PUT', url: 'api/ua/:uaId/reassign/pi/:userId'},
    getEmailTemplate: {method: 'GET', url: 'api/ua/:uaId/email'},
    sendEmail: {method: 'POST', url: 'api/ua/email'}
  });

  service.typeaheadLabel = function(ua, value) {
    if (ua && typeof ua !== 'string') {
      var radionuclides = value ? radionuclidesFilter(ua, value) : [];
      var label = 'RUA # ' + ua.number + ' ( ' + ua.pi.lastName + ', ' + ua.pi.firstName + ' )';
      label = radionuclides.length > 0 ? label.concat(' ( ' + radionuclides.join(' / ') + ' )') : label;
      return label;
    }
    return ua;
  };

  service.isAmendment = function(ua) {
    return ua.isAmendment;
  };

  function radionuclidesFilter(ua, value) {
    return ua.radionuclides.filter(function(isotope) {
      return value.split(' ').some(function(input) {
        return isotope.toLowerCase().indexOf(input.toLowerCase()) !== -1;
      });
    });
  }

  return service;
});
