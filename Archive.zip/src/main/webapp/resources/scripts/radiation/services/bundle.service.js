'use strict';

angular.module('app').factory('BundleService', function($resource) {
  var service = $resource('api/bundle/core/:coreBundleId', {coreBundleId: '@coreBundleId'}, {
    addUaBundle: {method: 'POST', url: 'api/bundle/core/:csId/:name/ua/:uaId'},
    createBundle: {method: 'POST', url: 'api/bundle/core/groups'},
    addLocationToGroup: {method: 'PUT', url: 'api/bundle/core/groups/:groupId'},
    findGroupsByUserId: {method: 'GET', url: 'api/bundle/core/groups/person/:userId', isArray: true},
    findGroupByCsId: {method: 'GET', url: 'api/bundle/core/group/:csId', cache: true}
  });

  service.getLabContacts = function(uaBundle) {
    return _(uaBundle ? uaBundle.uaBundlePersons : []).chain()
      .filter(function(uaBundlePerson) { return uaBundlePerson.active && uaBundlePerson.delegate; })
      .map(function(uaBundlePerson) { return uaBundlePerson.person; })
      .value();
  };

  return service;
});
