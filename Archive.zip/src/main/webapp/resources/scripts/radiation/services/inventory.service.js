'use strict';

angular.module('app').factory('InventoryService', function($resource) {
  var service = $resource('api/inventory/:uaId', {uaId: '@uaId'}, {
    calculateRadionuclidePossessionAmount: {method: 'GET', url: 'api/inventory/ua/:uaId/limit/:uaLimitId'},
    getMaterial: { method: 'GET', url: 'api/inventory/material/:materialId'},
    createMaterial: { method: 'POST', url: 'api/inventory/material/create'},
    updateMaterial: { method: 'PUT', url: 'api/inventory/material/:materialId'},
    deleteMaterial: { method: 'DELETE', url: 'api/inventory/material/:materialId'},
    useMaterial: { method: 'POST', url: 'api/inventory/material/use' },
    batchUpdateMaterial: {method: 'POST', url: 'api/inventory/material/update', isArray: true},
    searchMaterials: { method: 'POST', url: 'api/inventory/material/search' },
    getInventoryByUa: { method: 'GET', url: 'api/inventory/material/ua/:uaId', isArray: true },
    getMaterialsByUaAndInventoryStatusType: { method: 'GET', url: 'api/inventory/material/ua/:uaId/status/:inventoryStatusType', isArray: true},
    getMaterialsByInventoryStatusType: { method: 'GET', url: 'api/inventory/material/status/:inventoryStatusType', isArray: true},
    getMaterialsForPackage: { method: 'GET', url: 'api/inventory/material/ua/:uaId/package', isArray: true },
    savePackage: { method: 'PUT', url: 'api/inventory/package/save'},
    getPackage: {method: 'GET', url: 'api/inventory/package/:id'},
    getPackageVendors: {method: 'GET', url: 'api/inventory/package/vendors', isArray: true},
    getPackageTypes: {method: 'GET', url: 'api/inventory/package/types', isArray: true},
    searchPackages: {method: 'GET', url: 'api/inventory/package/search', isArray: true},
    getContainersForUa: {method: 'GET', url: 'api/inventory/ua/:uaId/container', isArray: true},
    createContainer: { method: 'POST', url: 'api/inventory/container'},
    addContainerWithStatus: {method: 'POST', url: 'api/inventory/active/:active/container'},
    updateContainer: {method: 'PUT', url: 'api/inventory/container/:containerId'},
    emptyContainer: {method: 'PUT', url: 'api/inventory/empty/container/:containerId'},
    removeContainer: {method: 'DELETE', url: 'api/inventory/container/:containerId'},
    getTransferableContainers: {method: 'GET', url: 'api/inventory/transferableContainers/container/:containerId', isArray: true},
    transferContainerMaterials: {method: 'PUT', url: 'api/inventory/transfer/container/:containerId'},
    getTransferableUas: { method: 'GET', url: 'api/inventory/transfer/ua/:materialId', isArray: true },
    transferMaterial: { method: 'POST', url: 'api/inventory/transfer/material' },
    completeTransfer: { method: 'PUT', url: 'api/inventory/transfer/:materialTransferId/status/:status' },
    getMaterialTransfersByUaAndStatus: { method: 'GET', url: 'api/inventory/transfer/material/ua/:uaId/status/:status', isArray: true },
    getMaterialTransfersByStatus: { method: 'GET', url: 'api/inventory/transfer/material/status/:status', isArray: true },
    getMaterialTransfersToInstitutionByStatus: { method: 'GET', url: 'api/inventory/transfer/material/institution/status/:status', isArray: true },
    getMaterialPackageHierarchy: {method: 'GET', url: 'api/inventory/material/:materialId/hierarchy', isArray: true},
    findPackageByPackageNumberAndDate: {method: 'GET', url: 'api/inventory/material/package/:packageNumber'},
    isMaterialInUse: {method: 'GET', url: 'api/inventory/material/limit/:limitId'}
  });

  return service;
});
