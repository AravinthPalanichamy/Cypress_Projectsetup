'use strict';

angular.module('app').factory('SealedSourceService', function($resource) {
  return $resource('api/leaktest', {}, {
    getAllLeakTestMaterialsByCampus: {method: 'POST', url: 'api/leaktest/campus'},
    saveTest: {method: 'POST', url: 'api/leaktest/add'},
    batchSaveTest: {method: 'POST', url: 'api/leaktest/batch-add'},
    getTestById: {method: 'GET', url: 'api/leaktest/test/:id'},
    deleteTest: {method: 'DELETE', url: 'api/leaktest/:id'},
    getAllLeakTestAttachments: {method: 'GET', url: 'api/leaktest/material/:id/attachments', isArray: true},
    updateLeakTestAttachments: {method: 'PUT', url: 'api/leaktest/material/:id/attachments'},
    deleteLeakTestAttachment: {method: 'DELETE', url: 'api/leaktest/material/:id/attachment/:attachmentId'}
  });
});
