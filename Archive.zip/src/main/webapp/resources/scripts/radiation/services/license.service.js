'use strict';

angular.module('app').factory('LicenseService', function($resource) {
  return $resource('api/license/licenseId', {}, {
    getLicensesByCampus: {method: 'GET', url: 'api/license/campus/:campusCode'},
    getUAsByLicenseLineNumber: {method: 'GET', url: 'api/license/licenseLineNumber/:licenseLineNumber', isArray: true}
  });
});
