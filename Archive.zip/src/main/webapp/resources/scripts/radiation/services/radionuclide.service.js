'use strict';

angular.module('app').factory('RadionuclideService', function($resource) {
  return $resource('api/radionuclide/:id', {id: '@id'}, {
    getRadionuclidesByName: {
      method: 'GET',
      params: {radionuclideName: '@radionuclideName'},
      url: 'api/radionuclide',
      isArray: true,
      cache: true
    }
  });
});
