'use strict';

angular.module('app').factory('ReferenceService', function($resource) {
  return $resource('api/reference/', {}, {
    getAll: {method: 'GET', url: 'api/reference/', cache: true}
  });
});
