'use strict';

angular.module('app').factory('SettingsService', function($resource) {
  var service = $resource('api/settings/:settingsId', {surveyId: '@settingsId'}, {
    getSettings: { method: 'GET', url: 'api/settings' },
    updateSettings: { method: 'PUT', url: 'api/settings/update' }
  });

  return service;
});
