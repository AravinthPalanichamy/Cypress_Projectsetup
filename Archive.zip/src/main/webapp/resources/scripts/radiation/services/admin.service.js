'use strict';

angular.module('app').factory('AdminService', function($resource) {
  var service = $resource('api/admin/:id', {id: '@id'}, {
    getAllRadionuclides: {method: 'GET', url: 'api/admin/radionuclides', isArray: true},
    saveHgvRange: {method: 'PUT', url: 'api/admin/hgv-range', isArray: true},
    getHgvRangeByCamupus: {method: 'GET', url: 'api/admin/campus/hgv-range', isArray: true},
    findChangelog: {method: 'GET', url: 'api/admin/changelog/entity-name/:entityName/entity-id/:entityId', isArray: true}
  });

  return service;
});
