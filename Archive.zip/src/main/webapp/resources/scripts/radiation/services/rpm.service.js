'use strict';

angular.module('app').factory('RpmService', function($resource) {
  return $resource('api/rpm/:rpmId', {rpmId: '@rpmId'}, {
    add: {method: 'POST', url: 'api/rpm/add'},
    getAllRPMByUaId: {method: 'GET', url: 'api/rpm/ua/:uaId', isArray: true},
    delete: {method: 'DELETE', url: 'api/rpm/:id'},
    getAllByCampus: {method: 'GET', url: 'api/rpm/campus', isArray: true},
    getAllAvailableRpmsByCampus: {method: 'GET', url: 'api/rpm/available/campus', isArray: true},
    updateRpmAttachments: {method: 'PUT', url: 'api/rpm/:rpmId/attachments'},
    deleteRpmAttachment: {method: 'DELETE', url: 'api/rpm/:rpmId/attachment/:attachmentId'},
    getAllRpmAttachments: {method: 'GET', url: 'api/rpm/:rpmId/attachments', isArray: true}
  });
});
