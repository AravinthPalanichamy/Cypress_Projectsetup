'use strict';

angular.module('app').factory('PermissionService', function($location, StaticCollections, PersonService) {
  var uaRole, docAccess, docStatus, scope = {}, data = {}, rwx = {};
  var service = { uaRole: '', docAccess: '', docStatus:'', score: 0 };

  service.setData = function(promiseData, callback) {
    /**
     * This setter accepts a Promise object
     */
    promiseData = recurse(promiseData);
    if (!promiseData || !(promiseData.hasOwnProperty('$$state'))) {
      data = new Promise(function(resolve, reject) {resolve(promiseData || undefined);});
    } else {
      data = promiseData;
    }
    // reset role-permission map everytime when a new data is set
    rwx = {RA:{}, RP: {}, DG: {}, AU: {}, OT: {}}; //RA, RP, I, AU, DG
    service = Object.assign(service, { uaRole: '', docAccess: '', docStatus:'', score: 0 });
    if (data) { service.result = recalculatePrivileges(data, callback); }
  };

  service.getData = function() {
    Object.defineProperty(service, 'data', {
      value: data,
      writable: false,
      enumerable: false,
      configurable: true
    });
    return service.data;
  };

  service.getPiAndBundleInfo = function(data) {
    scope.user = service.getCurrentUser;
    scope.pi = service.getPi;
    var roles = service.getRoles(data);
    scope.role = roles ? roles : function() { return undefined; };
    return data;
  };

  service.getPi = function(data) {
    if (!data || !data.pi) { return undefined; }
    return data.pi;
  };

  service.getRoles = function(data) {
    if (!data || !data.uaBundle || !data.uaBundle.uaBundlePersons) { return undefined; }
    var persons = _.reject(data.uaBundle.uaBundlePersons, {'person': {'id': scope.pi(data).id}});
    var loggedInMember = _.find(persons, {'person': {'id': scope.user().id}});
    return function matchRoleAlg() {
      return (loggedInMember && loggedInMember.delegate)
      ? 'DG' : (scope.user().id === scope.pi(data).id) ? 'RP' : 'AU';
    };
  };

  service.getCurrentUser = function() {
    return PersonService.currentUser;
  };

  service.getRoleAndScore = function() {
    var roleScore = _.find(rwx, 'score');
    service.score = roleScore.score;
    return roleScore;
  };

  service.hasPermission = function() {
    if (service.score >= 50) {
      return true;
    } else if (_.eq(service.score, 40) || _.eq(service.score, 41)
              || _.eq(service.score, 30) || _.eq(service.score, 31)) {
      return true;
    } else {
      return false;
    }
  };

  function setRolePrivilege(data) {
    service.uaRole = PersonService.isAdmin ? 'RA' : scope.role();
    switch (service.uaRole) {
      case 'RA':
        calculateAccessWeightage('50');
        break;
      case 'RP':
        calculateAccessWeightage('40');
        break;
      case 'DG':
        calculateAccessWeightage('30');
        break;
      case 'AU':
        calculateAccessWeightage('20');
        break;
      default:
        calculateAccessWeightage('10');
    }
    return data;
  }

  function setModulePrivilege(data) {
    service.docAccess = data && data && data.isAmendment ? 'CR' : 'REGULAR';
    switch (service.docAccess) {
      case 'REGULAR':
        calculateAccessWeightage('01');
        break;
      case 'CR':
        calculateAccessWeightage('00');
        break;
      default:
        calculateAccessWeightage('01');
    }
    return data;
  }

  function setUaStatusPrivilege(data) {
    if (!data) {
      service.docStatus = 'PENDING';
    } else if (data.amendmentSubmitted) {
      service.docStatus = 'CR-SUBMITTED';
    } else {
      service.docStatus = data.uaSubmitted ? 'UA-SUBMITTED' : data.statusType;
    }
    switch (service.docStatus) {
      case 'ACTIVE':
        calculateAccessWeightage('01');
        break;
      case 'PENDING':
        calculateAccessWeightage('00');
        break;
      case 'UA-SUBMITTED':
        calculateAccessWeightage('02');
        break;
      case 'CR-SUBMITTED':
        calculateAccessWeightage('03');
        break;
      case 'ON_HOLD':
        calculateAccessWeightage('04');
        break;
      case 'TERMINATED':
        calculateAccessWeightage('05');
        break;
      default:
        calculateAccessWeightage('01');
    }
    return data;
  }

  function calculateAccessWeightage(weightage) {
    if (parseInt(weightage) === 50) {
      if (!rwx.RA.score) { defineRoleInfo('RA', 'Admin'); }
      rwx.RA.score = parseInt(weightage);
    } else if (parseInt(weightage) === 40) {
      if (!rwx.RP.score) { defineRoleInfo('RP', 'Resp Person'); }
      rwx.RP.score = parseInt(weightage);
    } else if (parseInt(weightage) === 30) {
      if (!rwx.DG.score) { defineRoleInfo('DG', 'Delegate'); }
      rwx.DG.score = parseInt(weightage);
    } else if (parseInt(weightage) === 20) {
      if (!rwx.AU.score) { defineRoleInfo('AU', 'Auth User'); }
      rwx.AU.score = parseInt(weightage);
    } else if (parseInt(weightage) === 10) {
      if (!rwx.OT.score) { defineRoleInfo('OT', 'Others'); }
      rwx.OT.score = parseInt(weightage);
    }

    if (weightage === '01') {
      rwx.RA.score ? rwx.RA.score += parseInt(weightage) : false;
      rwx.RP.score ? rwx.RP.score += parseInt(weightage) : false;
      rwx.DG.score ? rwx.DG.score += parseInt(weightage) : false;
    }
    if (weightage === '00') {
      rwx.AU.score ? rwx.AU.score += parseInt(weightage) : false;
      rwx.OT.score ? rwx.OT.score += parseInt(weightage) : false;
    }
    if (weightage === '02' || weightage === '03') {
      rwx.RP.score ? rwx.RP.score += parseInt(weightage) : false;
      rwx.DG.score ? rwx.DG.score += parseInt(weightage) : false;
    }
    if (weightage === '04' || weightage === '05') {
      rwx.RP.score ? rwx.RP.score += parseInt(weightage) : false;
      rwx.DG.score ? rwx.DG.score += parseInt(weightage) : false;
      rwx.AU.score ? rwx.AU.score += parseInt(weightage) : false;
      rwx.OT.score ? rwx.OT.score += parseInt(weightage) : false;
    }
  }

  function defineRoleInfo(role, roleName) {
    Object.assign(rwx[role], {name: roleName, score: 0});
  }

  function configureServiceProperties(data) {
    Object.freeze(service.uaRole);
    Object.freeze(service.docAccess);
    Object.freeze(service.docStatus);
    Object.freeze(service.score);
    Object.freeze(service.result);
    Object.preventExtensions(service);
  }

  function recalculatePrivileges(data, callback) {
    return data
      .then(service.getPiAndBundleInfo)
      .then(setRolePrivilege)
      .then(setModulePrivilege)
      .then(setUaStatusPrivilege)
      .then(configureServiceProperties)
      .then(service.getRoleAndScore)
      .then(function() {
        if (callback) { callback(); }
        return true;
      });
  }

  function recurse(parent) {
    var $$stateProperty;
    if (!parent) {return undefined;}
    if (parent) {
      $$stateProperty = parent.hasOwnProperty('$$state');
    }
    return ((!$$stateProperty && parent.$promise) ? recurse(parent.$promise) : parent);
  }

  return service;
})
.run(function($rootScope, PermissionService) {
  $rootScope.$on('$locationChangeSuccess', function(event, newUrl, oldUrl) {
    var urls = newUrl.split('#');
  });
});
