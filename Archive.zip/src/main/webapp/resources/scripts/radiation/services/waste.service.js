'use strict';

angular.module('app').factory('WasteService', function($resource) {
  var service = $resource('api/waste/:ruaId', {ruaId: '@ruaId'}, {

    createWasteTag: {method: 'POST', url: 'api/waste/ruaId/:ruaId/tag'},
    getWasteTagByRuaId: {method: 'GET', url: 'api/waste/tag/ruaId/:ruaId', isArray: true},
    requestPickup: {method: 'PUT', url: 'api/waste/request-pickup'},
    updateWasteTag: {method: 'PUT', url: 'api/waste/ruaId/:ruaId/tag'},
    findWasteTagById: {method: 'GET', url: 'api/waste/wasteTagId/:wasteTagId'},
    getWasteToken: {method: 'GET', url: 'api/waste/public/tag/:trackingNumber/token'},
    updateWasteTagForContainer: {method: 'PUT', url: 'api/waste/tag/ruaId/:ruaId/containerId/:containerId'}
  });

  return service;
});
