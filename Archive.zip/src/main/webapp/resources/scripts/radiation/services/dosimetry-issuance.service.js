'use strict';

angular.module('app').factory('DosimetryIssuanceService', function($resource) {
  var service = $resource('api/dosimetry-issuance/:id', {id: '@id'}, {
    findByCampusCode: { method: 'GET', url: 'api/dosimetry-issuance/campus/:campusCode', isArray: true },
    saveDosimetryIssuance: { method: 'POST', url: 'api/dosimetry-issuance/save' },
    search: { method: 'POST', url: 'api/dosimetry-issuance/search' }
  });

  return service;
});
