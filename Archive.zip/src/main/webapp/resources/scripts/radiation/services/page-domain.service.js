'use strict';

angular.module('app').factory('PageDomainService', function($window) {
  var keyName = 'page-domain';

  var service = {
    get: function() {
      var value = $window.localStorage.getItem(keyName);
      return value ? JSON.parse(value) : {};
    },
    save: function(key, value) {
      var pageDomain = service.get();
      pageDomain[key] = value;
      $window.localStorage.setItem(keyName, JSON.stringify(pageDomain));
    },
    clear: function(key) {
      var pageDomain = service.get();
      pageDomain[key] = null;
      $window.localStorage.setItem(keyName, JSON.stringify(pageDomain));
    },
    init: function(data, key, routeUrl) {
      data = _.map(data, function(d) {return d.id ? d.id : d.userId;});
      var value = data.length ? {ids: data, routeUrl: routeUrl, currentIndex: 0, lastIndex: data.length - 1} : null;
      this.save(key, value);
    }
  };

  return service;
});
