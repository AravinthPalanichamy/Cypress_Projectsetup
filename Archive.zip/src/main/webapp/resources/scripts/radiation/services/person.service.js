'use strict';

angular.module('app').factory('PersonService', function($resource, CURRENT_USER, StaticCollections) {
  var roles = CURRENT_USER.roles;
  var service = $resource('/api/person/:userId', {userId: '@userId'}, {
    getCurrentUserProfile: {method: 'GET', url: 'api/person/profile'},
    findByName: {method: 'GET', url: 'api/person/find', isArray: true},
    getDetail: {method: 'GET', url: 'api/person/:userId/detail'},
    getTrainings: {method: 'GET', url: 'api/person/:userId/trainings', isArray: true},
    getLocalPersonByUserId: {method: 'GET', url: 'api/person/:userId'},
    getCurrentAndPastRUAsByUserId: {method: 'GET', url: 'api/person/:userId/ruas', isArray: true},
    searchPeople: {method: 'POST', url: 'api/person/search', isArray: true},
    updatePerson: {method: 'PUT', url: 'api/person/:userId'},
    getRolesByCampusCode: {method: 'GET', url: 'api/person/role/campus/:campusCode', isArray: true},
    updateRoles: {method: 'PUT', url: 'api/person/role/:userId', isArray: true},
    updateSOEAttachments: {method: 'PUT', url: 'api/person/:userId/attachments'},
    deleteSOEAttachment: {method: 'DELETE', url: 'api/person/:userId/attachment/:attachmentId'},
    getAllSOEs: {method: 'GET', url: 'api/person/:userId/attachments', isArray: true},
    getDscsByCollection: {method: 'GET', url: 'api/person/role/collection/:collectionId', isArray: true},
    getTrainingStatusByUserIdAndRUAType: {method: 'GET', url: 'api/person/:userId/rua/:ruaType/training/status'},
    getAllPersonTrainings: {method: 'GET', url: 'api/person/:userId/trainings/lms', isArray: true}
  });

  service.isAdmin = _.some(roles, {roleType: StaticCollections.rolesHash.RADIATION_ADMIN.code});
  service.isRP = _.some(roles, {roleType: StaticCollections.rolesHash.RESPONSIBLE_PERSON.code});
  service.isDEL = _.some(roles, {roleType: StaticCollections.rolesHash.DELEGATE.code});
  service.isAU = _.some(roles, {roleType: StaticCollections.rolesHash.AUTHORIZED_USER.code});
  service.isAU_OR_RP = service.isAU || service.isRP;
  service.isRP_OR_DEL = service.isRP || service.isDEL;
  service.currentUser = CURRENT_USER;

  return service;
});
