'use strict';

angular.module('app').factory('ExcelService', function($resource, FileSaver) {
  var download = function(response) {
    return {'data': new Blob([response], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'})};
  };
  var service = $resource('api', {}, {
    surveyListExcel: {
      method: 'POST',
      url: 'api/survey/downLoad/surveys',
      responseType: 'arraybuffer',
      transformResponse: download
    },
    ruaExcel: {
      method: 'POST',
      url: 'api/ua/downLoad/rua',
      responseType: 'arraybuffer',
      transformResponse: download
    },
    pendingRuAExcel: {
      method: 'POST',
      url: 'api/ua/downLoad/pendingRua',
      responseType: 'arraybuffer',
      transformResponse: download
    },
    peopleExcel: {
      method: 'POST',
      url: 'api/person/download/excel',
      responseType: 'arraybuffer',
      transformResponse: download
    },
    sealedSourceExcel: {
      method: 'POST',
      url: 'api/leaktest/download/excel',
      responseType: 'arraybuffer',
      transformResponse: download
    },
    inventoryExcel: {
      method: 'POST',
      url: 'api/inventory/download/excel',
      responseType: 'arraybuffer',
      transformResponse: download
    }

  });

  service.export = function(data, name, options) {
    var sheet = XLSX.utils.json_to_sheet(data);

    var workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheet, name);

    var blob = new Blob([XLSX.write(workbook, {booktype: 'xlsx', type: 'array'})]);

    if (options.withTimeStamp) {
      name = name + ' ' + moment(Date.now()).format('MM/DD/YYYY');
    }

    FileSaver.saveAs(blob, name + ".xlsx");
  };

  return service;
});
