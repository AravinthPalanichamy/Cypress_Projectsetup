'use strict';

angular.module('app').factory('TabsService', function(CURRENT_USER, WASTE_URL, NOTIFICATION_TEMPLATE_URL, PROFILE_ROLE_MANAGEMENT_URL) {
  var RA = 'RADIATION_ADMIN';
  var RP = 'RESPONSIBLE_PERSON';
  var I = 'INSPECTOR';
  var AU = 'AUTHORIZED_USER';

  //Radiation Safety Contact
  var DG = 'DELEGATE';

  var service = {
    tabs: [
      {
        title: 'RUA',
        url: '/rua',
        subGroup: [
          {title: 'RUAs', url: '/list'},
          {title: 'RUA Email', url: '/email/download', hide: true},
          {title: 'Pending Requests', url: '/pending/list', roles: [RA, RP, I]},
          {title: 'Pending Requests Email', url: '/pending/email/download', hide: true},
          {title: 'New RUA', url: '/create', hide: true}
        ],
        roles: [RA, RP, I, AU, DG]
      },
      {
        title: 'Surveys',
        url: '/survey',
        subGroup: [
          {title: 'Survey Assignments', url: '/assignment'},
          {title: 'Survey List', url: '/surveylist'},
          {title: 'Edit Survey', url: '/edit', hide: true},
          {title: 'New Survey', url: '/create', hide: true}
        ],
        roles: [RA]
      },
      {
        title: 'People',
        url: '/people',
        subGroup: [
          {title: 'People', url: '/list'}
        ],
        roles: [RA]
      },
      {
        title: 'Dosimetry Issuance',
        url: '/dosimetry-issuance',
        subGroup: [
          {title: 'Group Issuance', url: '/list'},
          {title: 'New Issuance Group', url: '/new', hide: true}
        ],
        roles: [RA]
      },
      {
        title: 'Radioactive Materials',
        url: '/materials',
        subGroup: [
          {title: 'Inventory', url: '/inventory'},
          {title: 'Material Requests', url: '/pending', roles: [RA]},
          {title: 'New Request', url: '/request-create', hide: true},
          {title: 'Edit Request', url: '/request-edit', hide: true},
          {title: 'Packages', url: '/package', roles: [RA]},
          {title: 'New Package', url: '/package-create', hide: true},
          {title: 'Edit Package', url: '/package-edit', hide: true},
          {title: 'Offsite Transfers', url: '/pending-transfers', roles: [RA]},
          {title: 'Search', url: '/search', roles: [RA]}
        ],
        roles: [RA, RP, DG, AU]
      },
      {
        title: 'Sealed Sources',
        url: '/sealedsources',
        subGroup: [
          {title: 'Sealed Sources', url: '/list'}
        ],
        roles: [RA]
      },
      {
        title: 'Radiation Producing Machines',
        url: '/rpm',
        subGroup: [
          {title: 'Machines', url: '/list'}
        ],
        roles: [RA, RP, DG]
      },
      {
        title: 'Instruments',
        url: '/instrument',
        subGroup: [
          {title: 'Instruments', url: '/list'}
        ],
        roles: [RA, DG, RP]
      },
      {
        title: 'Audits',
        url: '/audit',
        subGroup: [
          {title: 'RML Limit Audit', url: '/license'},
          {title: 'Inventory Audit', url: '/inventory'},
          {title: 'Building Report', url: '/buildingreport'}
        ],
        roles: [RA]
      },
      {
        title: 'Waste',
        url: WASTE_URL + '/#/container/primary/radmix/list/readyforpickup',
        external: true,
        roles: [RA]
      },
      {
        title: 'Waste Facility',
        url: '/waste-facility',
        subGroup: [
          {title: 'Waste Facility Totals', url: '/totals'}
        ],
        roles: [RA]
      },
      {
        title: 'Admin',
        url: '/admin',
        subGroup: [
          {title: 'Radionuclides', url: '/radionuclides'},
          {title: 'HGV Hazard Class', url: '/hgv-range'},
          {title: 'Settings', url: '/settings'},
          {title: 'Email Templates', url: NOTIFICATION_TEMPLATE_URL + '/#/', external: true},
          {title: 'Role Management', url: PROFILE_ROLE_MANAGEMENT_URL + '/#/', external:true}
        ],
        roles: [RA]
      }
    ]
  };

  service.hasRole = function(role) {
    return _.some(CURRENT_USER.roles, function(userRole) {
      return userRole.roleType === role;
    });
  };

  service.tabsHash = _.filter(service.tabs, function(tab) {
    var filterTabForRoles = tab.roles && tab.roles.length;
    var hasTab = filterTabForRoles ? _.some(tab.roles, service.hasRole) : true;

    if (hasTab) {
      var subGroup = _.filter(tab.subGroup, function(subGroup) {
        var filterForRoles = subGroup.roles && subGroup.roles.length;
        return filterForRoles ? _.some(subGroup.roles, service.hasRole) : true;
      });

      tab.subGroup = subGroup.length ? subGroup : undefined;
    }

    return hasTab;
  });

  return service;
});
