'use strict';

angular.module('app').factory('ErrorService', function(ConfirmModelService, ENV) {
  var errorTemplate = 'resources/scripts/radiation/components/confirm-model/_error.model.html';
  var defaults = { template: errorTemplate, size: 'lg', buttons: {} };

  function headerText(error) {
    if (!error) { return ''; }
    return (error.statusText) ? error.status + ' - ' + error.statusText : 'Error - ' + error.status;
  }

  var service = {
    error: function(error) {
      // finds the error fn based on the error codes
      var fnName = service['e'.concat(error.status)];
      // if not found, defaulting to eUnknown fn
      if (!fnName) { fnName = service.eUnknown.bind(this); }
      var fn = (fnName).bind(this);
      // builds & exec the custom message and returns the message
      var result = fn.call(service, error);
      // opens the modal with the custom message
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.WARNING, result);
      return error;
    },
    copy: function(elementID, document) {
      // copies the selected / highlighted text to the Clipboard

      var copied = false;
      var copyText = document.getElementById(elementID);
      var range = document.createRange();
      range.selectNode(copyText);
      window.getSelection().removeAllRanges();
      window.getSelection().addRange(range);

      try {
        copied = document.execCommand('copy');
        var msg = copied ? 'successful' : 'unsuccessful';
        console.log('Copy command was ' + msg);
      } catch (err) {
        console.log('Oops, unable to copy');
      }
      return copied;
    },
    e404: function(error) {
      error.data = { 'message': 'No Record Found', 'status': error.status, date: new Date().toString() };
      return _.merge({ header: headerText(error), data: error.data, copy: service.copy }, defaults);
    },
    e503: function(error) {
      _.assign(error.data, { 'message': 'One of our connecting services went down. Try again later.', 'status': error.status });
      return _.merge({ header: headerText(error), data: error.data, copy: service.copy }, defaults);
    },
    e500: function(error) {
      if (error.data && typeof error.data === 'string') { service.eUnknown(error, true); }
      _.assign(error.data, { 'message': 'Internal Error. Please try again after sometime.', 'status': error.status });
      return _.merge({ header: headerText(error), data: error.data, copy: service.copy }, defaults);
    },
    eUnknown: function(error, shortCircuit) { // handles all unknown error codes returned from backend service
      if (typeof error.data === 'string') {
        var trace;
        if (error.data.trim().length > 0
            && (ENV.toUpperCase() !== "Production".toUpperCase()
                || ENV.toUpperCase() !== "Prod".toUpperCase())) {
          // parses the error response page returned from backend
          // and contstruct as a DOM element for easy manipulation
          // https://developer.mozilla.org/en-US/docs/Web/API/DOMParser#Browser_compatibility
          var parser = new DOMParser();
          // Firefox/Opera/IE throw errors on unsupported types
          try {
            // WebKit returns null on unsupported types
            var doc = parser.parseFromString(error.data, "text/html");
            var preArray = doc.getElementsByTagName('pre');
            // preArray[1] gives the root cause, otherwise we default to base cause
            var err = preArray ? (preArray[1] ? preArray[1].textContent : preArray[0].textContent) : '';
            trace = err.split('\n\t', 5); // take only the first 5 lines of error trace
          } catch (ex) {} // doing nothing on catch for now
        }
        // create a JSON instead of string
        error.data = _.assign({}, { date: new Date().toString(), 'status': error.status, 'trace': trace });
      }
      // calling internal error fn since it forms the base error message
      return !shortCircuit ? service.e500(error) : shortCircuit;
    }
  };
  return service;
});
