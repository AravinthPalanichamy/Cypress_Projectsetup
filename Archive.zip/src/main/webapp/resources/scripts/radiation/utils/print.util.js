'use strict';

angular.module('app').factory('PrintUtil', function($templateRequest, $compile) {
  var utils = {
    scope: angular.element(document).scope(),
    printHGV: function(rua) {
      var templateUrl = 'resources/scripts/radiation/components/confirm-model/_hgv-calculation-print.model.html';
      $templateRequest(templateUrl)
        .then(function(tplContent) {
          utils.scope.rua = _.cloneDeep(rua);
          utils.scope._ = _;
          utils.scope.cssurl = window.location.href.split("#")[0] + 'resources/css/project.css';

          var d = $compile(tplContent)(utils.scope);

          var win = window.open('', '_blank');
          win.document.body = document.createElement('body');
          _.forEach(d, function(elem) {
            if (angular.element(elem)[0].tagName) {
              if (angular.element(elem)[0].tagName === 'DIV') {
                win.document.body.appendChild(angular.element(elem)[0]);
              } else {
                win.document.head.innerHTML += angular.element(elem)[0].outerHTML;
              }
            }
          });

          var mjConfigScript = document.createElement("script");
          mjConfigScript.type = "text/javascript";
          var configTextNode = document.createTextNode("window.MathJax = { tex2jax: { inlineMath: [['$','$'], ['\\(','\\)']], processEscapes: true }, TeX: { equationNumbers: { autoNumber: \"AMS\" }, extensions: [\"autobold.js\", \"color.js\", \"enclose.js\"] } };");
          mjConfigScript.appendChild(configTextNode);
          win.document.body.appendChild(mjConfigScript);

          var mjUrlScript = document.createElement("script");
          mjUrlScript.type = "text/javascript";
          mjUrlScript.async = true;
          mjUrlScript.defer = true;
          mjUrlScript.src = "https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.2/MathJax.js?config=TeX-MML-AM_CHTML&delayStartupUntil=configured";
          win.document.body.appendChild(mjUrlScript);

          var mjLoadScript = document.createElement("script");
          mjLoadScript.type = "text/javascript";
          var loadTextNode = document.createTextNode("setTimeout(function(){ MathJax.Hub.Configured(); }, 100);");
          mjLoadScript.appendChild(loadTextNode);
          win.document.body.appendChild(mjLoadScript);

          win.onbeforeunload = utils.closePrintHGV;
          win.onafterprint = utils.closePrintHGV;
          win.focus(); // Required for IE
        });
    },
    closePrintHGV: function() {
      delete utils.scope.rua;
      delete utils.scope._;
      delete utils.scope.cssurl;
      this.close();
    }
  };

  return utils;
});
