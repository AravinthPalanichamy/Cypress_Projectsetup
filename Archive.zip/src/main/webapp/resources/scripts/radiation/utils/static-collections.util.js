'use strict';

angular.module('app').factory('StaticCollections', ['$http', function($http) {
  /**
   * Roles
   */
    //TODO: Refactor this into a proper collection hash and refactor the rest of the code that relies on it.
  var rolesHash = {
      RADIATION_ADMIN: {
        code: 'RADIATION_ADMIN',
        name: 'Radiation Admin'
      },
      INSPECTOR: {
        code: 'INSPECTOR',
        name: 'Radiation Inspector'
      },
      RADIATION_SAFETY_COMMITTEE_MEMBER: {
        code: 'RADIATION_SAFETY_COMMITTEE_MEMBER',
        name: 'Radiation Safety Committee Member'
      },
      RESPONSIBLE_PERSON: {
        code: 'RESPONSIBLE_PERSON',
        name: 'Responsible Person'
      },
      AUTHORIZED_USER: {
        code: 'AUTHORIZED_USER',
        name: 'Authorized User'
      },
      DELEGATE: {
        code: 'DELEGATE',
        name: 'Delegate'
      },
      RAM_SHIPPER: {
        code: 'RAM_SHIPPER',
        name: 'RAM Shipper'
      }
    };

  /**
   * Tab List
   */
  var tabs = function() {
    var req = {
      method: 'GET',
      url: './resources/json/tabs.json',
      headers: {
        'Accept': 'application/json, text/plain',
        'Content-Type': 'application/json'
      }
    };

    return $http(req);
  };

  /**
   * UA Status
   */
  // @deprecated: Use 'uaStatus' instead
  var uaStatusHash = {
    PENDING_REVIEW: 'Pending',
    ON_HOLD: 'On Hold',
    TERMINATED: 'Terminated',
    EXPIRED: 'Expired',
    ACTIVE: 'Active'
  };

  // @deprecated: Use 'UATypesHash' instead
  var uaTypeHash = {
    RAM: "Radioactive Materials",
    RPM: "Radiation Producing Machines"
  };

  var getKeyByValue = function(obj, value) {
    var keys = _.keys(obj);
    var values = _.values(obj);
    var index = values.indexOf(value);
    return index > -1 ? keys[index] : null;
  };

  var classHash = [{
    value: 'I',
    label: 'I'
  },
    {
      value: 'II',
      label: 'II'
    },
    {
      value: 'III',
      label: 'III'
    }];

  /**
   * UA Type
   */
  var UATypes = {
    RPM: {
      value: 'RPM',
      label: 'Machines',
      code: 'RPM',
      description: 'Radiation Producing Machines'
    },
    RAM: {
      value: 'RAM',
      label: 'Materials',
      code: 'RAM',
      description: 'Radioactive Materials'
    }
  };

  var uaUsageInterval = [
    {
      value: '30',
      label: 30
    },
    {
      value: '60',
      label: 60
    },
    {
      value: '90',
      label: 90
    },
    {
      value: '180',
      label: 180
    }];

  var surveyTypes = {
    RENEWAL: 'Renewal',
    ROUTINE: 'Routine',
    SPECIAL: 'Special',
    TERMINATION: 'Termination'
  };

  var requestTypesHash = [{
    label: 'In Process',
    value: false
  }, {
    label: 'Submitted',
    value: true
  }];

  var surveyStatuses = {
    INCOMPLETE: 'Incomplete',
    COMPLETE: 'Complete',
    SKIP: 'Skip'
  };
  var yesNoOptions = [{
    id: 'yes',
    displayName: 'Yes',
    value: true
  }, {
    id: 'no',
    displayName: 'No',
    value: false
  }];

  var ruaSignatureTypes = [{
    id: 'na',
    displayName: 'N/A'
  }, {
    id: 'noSignature',
    displayName: 'No Signature'
  }, {
    id: 'signatureOnFile',
    displayName: 'Signed RUA on file at RS'
  }];

  /**
   * Research Type
   */
  var researchHash = {
    HUMAN: 'Human',
    NON_HUMAN: 'Non-Human'
  };

  var isotopeEnrichmentIds = [87, 88, 89, 90, 91, 92, 93, 98, 99, 270, 271];

  var isotopeContainedIds = [89, 91];

  var useCodes = {
    XDN: 'XDN',
    XDT: 'XDT',
    XDH: 'XDH',
    XRA: 'XRA',
    XHF: 'XHF',
    XRF: 'XRF',
    XBD: 'XBD',
    XCH: 'XCH',
    XCT: 'XCT',
    XCB: 'XCB',
    XMF: 'XMF',
    XMD: 'XMD',
    XMJ: 'XMJ',
    XMB: 'XMB',
    XTL: 'XTL',
    XSM: 'XSM',
    XTM: 'XTM',
    XTS: 'XTS',
    XTI: 'XTI',
    XMR: 'XMR',
    XVR: 'XVR',
    XVF: 'XVF',
    XVD: 'XVD',
    XVT: 'XVT',
    XVC: 'XVC',
    XAL: 'XAL',
    XAS: 'XAS',
    XDF: 'XDF',
    XEM: 'XEM',
    XNF: 'XNF',
    XRP: 'XRP',
    XRS: 'XRS',
    XRC: 'XRC',
    XRD: 'XRD'
  };

  var noOfTubesOptions = {
    1: '1',
    2: '2',
    3: '3',
    4: '4',
    5: '5',
    6: '6',
    7: '7',
    8: '8',
    9: '9',
    10: '10'
  };

  var calibrationDueStatusTypes = {
    IN_USE: 'In Use',
    OUT_OF_SERVICE: 'Out of Service',
    OFF_SITE: 'Offsite'
  };

  var rpmUsesTypes= {
    ANALYTICAL: 'Analytical',
    DIAGNOSTIC: 'Diagnostic'
  };

  var yesNoNaType = {
    YES: 'Yes',
    NO: 'No',
    NA: 'Na'
  };

  var materialStatuses = {
    DRAIN: 'Drain',
    REQUESTED: 'Requested',
    RECEIVED: 'Received',
    IN_INVENTORY: 'In Inventory',
    IN_PROCESS: 'In Progress',
    LOCAL_WASTE: 'Local Waste',
    TRANSFER_TO_RUA_PENDING: 'Transfer To RUA Pending',
    CPU_PENDING: 'CPU Pending',
    PICKUP_PENDING: 'Pickup Pending',
    TRANSFERED_TO_INSTITUTION: 'Transfered To Institution',
    SHIPPED: 'Shipped',
    PENDING_DISPOSAL: 'Pending Disposal',
    TRANSFER_TO_INSTITUTION_PENDING: 'Transfer To Institution Pending'
  };

  var testStatuses = {
    CONTAMINATION_TEST: 'Contamination Test',
    LEAK_TEST: 'Leak Test',
    NO_TEST_NEEDED: 'No Test Needed',
    EITHER_TEST: 'Either Test'
  };

  var wasteMaterialTypeHash = {
    LIQUID_VIAL: 'Liquid Scintillation Vials',
    SOURCE_VIAL: 'Source Vials',
    LIQUID: 'Liquid',
    DRY_SOLID: 'Dry Solid',
    BIOLOGICAL: 'Biological',
    CARCASSES: 'Carcasses',
    MIXED: 'Mixed',
    SHARPS: 'Sharps',
    OTHER: 'Other'
  };

  var wasteHazardClass = [
    {hazardName: 'FLAMMABLE', label: 'Flammable'},
    {hazardName: 'CORROSIVE_ACID', label: 'Corrosive Acid (pH ≤ 2)'},
    {hazardName: 'CORROSIVE_BASE', label: 'Corrosive Base (pH ≥ 12.5)'},
    {hazardName: 'TOXIC', label: 'Toxic'},
    {hazardName: 'REACTIVE', label: 'Reactive'},
    {hazardName: 'OXIDIZER', label: 'Oxidizer'},
    {hazardName: 'EXTREME_HAZARD', label: 'Extremely Hazardous'},
    {hazardName: 'RADIOACTIVE', label: 'Radioactive'}
  ];

  var calibrationSourceType = {
    PROBE: 'PROBE',
    PROBE_RESPONSE_CHECK_SOURCE: 'PROBE_RESPONSE_CHECK_SOURCE',
    CALIBRATION_SOURCE: 'CALIBRATION_SOURCE'
  };
  var uaStatus = [{
    id: 1,
    displayName: 'Active',
    value: 'ACTIVE'
  },
    {
      id: 2,
      displayName: 'On Hold',
      value: 'ON_HOLD'
    },
    {
      id: 3,
      displayName: 'Pending',
      value: 'PENDING'
    },
    {
      id: 4,
      displayName: 'Terminated',
      value: 'TERMINATED'
    }];


  var hazardClassHash = {
    I: 'I',
    II: 'II',
    III: 'III'
  };
  var assessmentFactorHash = [
    {
      id: 1,
      assessmentFactor: 0.1,
      compliance: 'No issues',
      laboratoryStatus: 'Outstanding Laboratory (0.1)'
    },
    {
      id: 2,
      assessmentFactor: 0.5,
      compliance: 'Minor issues',
      laboratoryStatus: 'Good Laboratory (0.5)'
    },
    {
      id: 3,
      assessmentFactor: 1.0,
      compliance: 'Average',
      laboratoryStatus: 'Average Laboratory (1.0)'
    },
    {
      id: 4,
      assessmentFactor: 2.0,
      compliance: 'Below Average',
      laboratoryStatus: 'Below Average Laboratory (2.0)'
    },
    {
      id: 5,
      assessmentFactor: 5.0,
      compliance: 'Poor performance',
      laboratoryStatus: 'Poor Laboratory (5.0)'
    }
  ];

  var materialTransferUseOptions = [
    {value: 'ACCEPTED', label: 'Accept Transfer', confirmValue: 'accepted'},
    {value: 'REJECTED', label: 'Reject Transfer', confirmValue: 'rejected'}
  ];

  var pageDomainType = {
    RUA_ACTIVE: {key: 'RUA_ACTIVE', path: '/rua/list', routeTo: '/rua/'},
    RUA_PENDING: {key: 'RUA_PENDING', path: '/rua/pending/list', routeTo: '/rua/'},
    SURVEY: {key: 'SURVEY', path: '/survey/surveylist', routeTo: '/survey/edit/'},
    INSTRUMENT: {key: 'INSTRUMENT', path: '/instrument/list', routeTo: '/instrument/edit/'},
    PEOPLE: {key: 'PEOPLE', path: '/people/list', routeTo: '/people/'},
    SEALED_SOURCE: {key: 'SEALED_SOURCE', path: '/sealedsources/list', routeTo: '/sealedsources/edit/'}
  };

  var collections = {
    getKeyByValue: getKeyByValue,
    uaStatusHash: uaStatusHash,
    uaTypeHash: uaTypeHash,
    rolesHash: rolesHash,
    classHash: classHash,
    UATypes: UATypes,
    UATypesHash: Object.values(UATypes),
    uaUsageIntervalHash: uaUsageInterval,
    tabs: tabs,
    surveyTypes: surveyTypes,
    surveyStatuses: surveyStatuses,
    yesNoOptions: yesNoOptions,
    ruaSignatureTypes: ruaSignatureTypes,
    calibrationDueStatusTypes: calibrationDueStatusTypes,
    rpmUsesTypes: rpmUsesTypes,
    researchHash: researchHash,
    isotopeEnrichmentIds: isotopeEnrichmentIds,
    isotopeContainedIds: isotopeContainedIds,
    useCodes: useCodes,
    noOfTubesOptions: noOfTubesOptions,
    materialStatuses: materialStatuses,
    testStatuses: testStatuses,
    yesNoNaType: yesNoNaType,
    wasteMaterialTypeHash: wasteMaterialTypeHash,
    wasteHazardClass: wasteHazardClass,
    requestTypesHash: requestTypesHash,
    calibrationSourceType: calibrationSourceType,
    uaStatus: uaStatus,
    hazardClassHash: hazardClassHash,
    assessmentFactorHash: assessmentFactorHash,
    materialTransferUseOptions: materialTransferUseOptions,
    pageDomainType: pageDomainType
  };

  return collections;
}]);
