'use strict';

angular.module('app')
  .run(function($templateCache) {
    var editTemplate = '<div class="edit-link">'
      + ' <span><a href="#/rua/edit/{{row.entity.ruaType}}/{{row.entity.ruaNumber}}" class="glyphicon glyphicon-edit"><span class="hideEditText">Edit</span></a></span>'
      + '</div>';
    $templateCache.put('edit.html', editTemplate);
    $templateCache.put('format-to-camelcase.html', '<div class="ui-grid-cell-contents" >{{grid.getCellValue(row, col)|camelcase}}</div>');
    $templateCache.put('format-to-date.html', '<div class="ui-grid-cell-contents" >{{grid.getCellValue(row, col)|date:\'MM/dd/yyyy\'}}</div>');
    $templateCache.put('format-to-date-with-na.html', '<div class="ui-grid-cell-contents" >{{grid.getCellValue(row, col) ? (grid.getCellValue(row, col)|date:\'MM/dd/yyyy\') : \'NA\'}}</div>');
    $templateCache.put('format-to-location-group.html', '<div class="ui-grid-cell-contents" ng-bind-html="grid.getCellValue(row, col)|locationGroupBy" ></div>');
    $templateCache.put('record-action.html', '<div class="ui-grid-cell-contents"><span class="action-badge {{row.entity.$$action|lowercase}}"></span></div>');
  })
  .factory('TableHeaderCollections', ['$templateCache', 'uiGridConstants', 'uiGridGroupingConstants', 'UtilService', 'StaticCollections',
    function($templateCache, uiGridConstants, uiGridGroupingConstants, UtilService, StaticCollections) {
      return {
        REGULAR_DROPDOWN: {
          width: 90,
          filter: {
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: [{
              value: '',
              label: 'ALL'
            }],
            disableCancelFilterButton: true
          },
          cellTemplate: "format-to-camelcase.html"
        },
        EDIT: {
          field: 'id',
          displayName: 'Edit',
          cellTemplate: $templateCache.get('edit.html'),
          width: 50
        },
        RUA: {
          field: 'ruaNumber',
          displayName: 'RUA',
          width: 60
        },
        RUA_TYPE: {
          field: 'ruaType',
          displayName: 'Type',
          width: 90,
          filter: {
            ariaLabel: 'ruaType',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: [{
              value: '',
              label: 'ALL'
            }],
            aggregator: 'eq',
            disableCancelFilterButton: true
          },
          cellFilter: 'mapStatus'
        },
        REQUEST_STATUS: {
          field: '',
          displayName: 'Request Status',
          width: 100,
          filter: {
            ariaLabel: 'requestType',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: [{
              value: '',
              label: 'ALL'
            }],
            aggregator: 'AND',
            disableCancelFilterButton: true
          },
          cellTemplate: ""
        },
        PI_LAST_NAME: {
          field: 'piLastName',
          displayName: 'PI Last',
          width: 90
        },
        PI_FIRST_NAME: {
          field: 'piFirstName',
          displayName: 'PI First',
          width: 90
        },
        ORGANIZATION: {
          field: 'coreCollection',
          displayName: 'Organization'
        },
        LOCATIONS: {
          field: 'useLocations',
          displayName: 'Locations',
          cellTemplate: "format-to-location-group.html"
        },
        SURVEY_FREQ: {
          field: 'surveyFrequency',
          displayName: 'Survey Frequency',
          width: 90,
          filter: {
            ariaLabel: 'surveyFrequency',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: [{
              value: '',
              label: 'ALL'
            }],
            aggregator: 'eq',
            disableCancelFilterButton: true
          },
          cellTemplate: "format-to-camelcase.html"
        },
        DATE_RANGE_LONG: {
          type: 'date',
          cellFilter: 'date:"longDate"',
          filters: [{
            filterName: "dateAfter",
            condition: uiGridConstants.filter.GREATER_THAN,
            placeholder: 'date after'
          },
            {
              filterName: "dateBefore",
              condition: uiGridConstants.filter.LESS_THAN,
              placeholder: 'date before'
            }
          ]
        },
        DATE_RANGE_SHORT: {
          type: 'date',
          cellFilter: 'date:"MM/dd/yyyy"',
          enableDefaultToDate: false,
          width: 130,
          filterHeaderTemplate: '<div class="ui-grid-filter-container date-picker-filter-container" ng-repeat="colFilter in col.filters track by $index"><date-picker></date-picker></div>',
          filters: [{
            name: "dateFrom",
            condition: uiGridConstants.filter.GREATER_THAN_OR_EQUAL,
            placeholder: 'From',
            term: '',
            calendarTemplate: $templateCache.get('calendar-from.html'),
            aggregator: 'gte',
            disableCancelFilterButton: true
          },
            {
              name: "dateTo",
              condition: uiGridConstants.filter.LESS_THAN_OR_EQUAL,
              placeholder: 'To',
              term: '',
              calendarTemplate: $templateCache.get('calendar-to.html'),
              aggregator: 'lte',
              disableCancelFilterButton: true
            }]

        },
        STATUS: {
          field: 'status',
          displayName: 'Status',
          filterHeaderTemplate: '<div class="ui-grid-filter-container"><multi-select class="multi-select"></multi-select></div>',
          width: 110,
          filter: {
            type: 'multi-select',
            term: '',
            options: [{
              value: 'all',
              label: 'ALL',
              selected: true
            }],
            disableCancelFilterButton: true
          },
          cellTemplate: "format-to-camelcase.html"
        },
        CLASS: {
          field: 'class',
          displayName: 'Class',
          width: 70,
          filter: {
            ariaLabel: 'classs',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: UtilService.sortUniqUnion([{value: '', label: 'ALL'}], StaticCollections.classHash, 'label'),
            aggregator: 'eq',
            disableCancelFilterButton: true
          }
        },
        DOSIMETRY: {
          field: 'dosimetry',
          displayName: 'Dosimetry',
          filterHeaderTemplate: '<div class="ui-grid-filter-container"><multi-select class="multi-select"></multi-select></div>',
          filter: {
            type: 'multi-select',
            term: '',
            options: [{
              value: 'all',
              label: 'ALL',
              selected: true
            }],
            aggregator: 'or',
            disableCancelFilterButton: true
          },
          cellTemplate: "format-to-location-group.html"
        },
        LBL: {
          field: 'other',
          displayName: 'Other',
          width: 70,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.lbl" class="glyphicon glyphicon-ok" ></span></div>',
          filter: {
            ariaLabel: 'other',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: [{
              value: '',
              label: 'ALL'
            },
              {
                value: true,
                label: 'Yes'
              },
              {
                value: false,
                label: 'No'
              }],
            disableCancelFilterButton: true
          }
        },
        LEAK_TEST_REQUIRED: {
          field: 'leakTestDue',
          displayName: 'Leak Test Required',
          width: 75,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.leakTestDue" class="glyphicon glyphicon-ok" ></span></div>',
          filter: {
            ariaLabel: 'Leak Test Required',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: [{
              value: '',
              label: 'ALL'
            },
              {
                value: true,
                label: 'Yes'
              },
              {
                value: false,
                label: 'No'
              }],
            disableCancelFilterButton: true
          }
        },
        SURVEY_DUE: {
          field: 'surveyDue',
          displayName: 'Survey Due'
        },
        SURVEY_TYPE: {
          field: 'surveyType',
          displayName: 'Survey Type',
          filter: {
            ariaLabel: 'surveyType',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: [{
              value: '',
              label: 'ALL'
            }],
            disableCancelFilterButton: true
          },
          cellTemplate: "format-to-camelcase.html"
        },
        SURVEY_STATUS: {
          field: 'statusType',
          displayName: 'Status',
          filter: {
            ariaLabel: 'statusType',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: [{
              value: '',
              label: 'ALL'
            }],
            disableCancelFilterButton: true
          },
          cellTemplate: "format-to-camelcase.html"
        },
        ASSIGNED_TO: {
          field: 'assignedTo.id',
          displayName: 'Assigned To',
          filter: {
            ariaLabel: 'assignedTo',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: [{
              value: '',
              label: 'ALL'
            }],
            disableCancelFilterButton: true
          },
          cellTemplate: "format-to-camelcase.html"
        },
        LATEST_SURVEY_DONE_BY: {
          field: 'latestSurveysDoneBy',
          displayName: 'Latest Survey Done By'
        },
        INTERVAL: {
          field: 'interval',
          displayName: 'Interval',
          filter: {
            ariaLabel: 'interval',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: [{
              value: '',
              label: 'ALL'
            }],
            disableCancelFilterButton: true
          }
        },
        REQUESTOR_LAST_NAME: {
          field: 'requestorLastName',
          displayName: 'Requestor Last'
        },
        REQUESTOR_FIRST_NAME: {
          field: 'requestorFirstName',
          displayName: 'Requestor First'
        },
        COMMENTS: {
          field: 'comment',
          displayName: 'Comments',
          enableFiltering: false,
          useExternalFiltering: false,
          enableSorting: false,
          useExternalSorting: false,
          enableColumnMenu: false,
          cellTemplate: '<div class="ui-grid-cell-contents" ng-bind-html="row.entity.comment"></div>'
        },
        CATEGORY: {
          field: 'category',
          displayName: 'Category'
        },
        ITEM: {
          field: 'item',
          displayName: 'Item'
        },
        OLD_VALUE: {
          field: 'oldValue',
          displayName: 'Old Value'
        },
        NEW_VALUE: {
          field: 'newValue',
          displayName: 'New Value'
        },
        INSTRUMENT_MODEL: {
          field: 'model',
          displayName: 'Model'
        },
        INSTRUMENT_MANUFACTURER: {
          field: 'manufacturer',
          displayName: 'Manufacturer'
        },
        INSTRUMENT_SERIAL_NUMBER: {
          field: 'serialNumber',
          displayName: 'Serial Number'
        },
        INSTRUMENT_USE_LOCATIONS: {
          field: 'useLocations',
          displayName: 'Use Locations'
        },
        CALIBRATION_DUE_STATUS_TYPE: {
          field: 'calibrationDueStatusType',
          displayName: 'Due Status',
          filter: {
            ariaLabel: 'calibrationDueStatusType',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: [{
              value: '',
              label: 'ALL'
            }],
            disableCancelFilterButton: true
          },
          cellTemplate: "format-to-camelcase.html"
        },
        TITLE: {
          field: 'title',
          displayName: 'Title'
        },
        DESCRIPTION: {
          field: 'description',
          displayName: 'Description'
        },
        PERFORMED_BY: {
          field: 'performedBy.displayName',
          displayName: 'Performed By'
        },
        PERFORMED_DATE: {
          field: 'performedDate',
          displayName: 'Performed Date (mm/dd/yyyy)',
          cellFilter: 'date:"MM/dd/yyyy"'
        },
        DELETE: {
          field: 'Delete',
          displayName: 'Delete',
          cellTemplate: $templateCache.get('delete.html'),
          width: 50
        },
        //People table columns
        LAST_NAME: {
          field: 'lastName',
          displayName: 'Last Name'
        },
        FIRST_NAME: {
          field: 'firstName',
          displayName: 'First Name',
          width: 120
        },
        DEPARTMENT: {
          field: 'coreCollection',
          displayName: 'Organization'
        },

        EMAIL: {
          field: 'email',
          displayName: 'Email'
        },
        PHONE_NUMBER: {
          field: 'phone',
          displayName: 'Phone(s)',
          width: 100
        },
        GROUP_ID: {
          field: 'groupId',
          displayName: 'Dosimetry Group ID #',
          width: 100
        },
        IS_ON_RUA: {
          field: 'isOnRua',
          displayName: 'On RUA',
          width: 70,
          enableFiltering: true,
          filter: {
            ariaLabel: 'On Active RUA',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: [{
              value: '',
              label: 'All'
            },
              {
                value: true,
                label: 'Yes'
              },
              {
                value: false, // an approach to query custom column with false value
                label: 'No'
              }],
            disableCancelFilterButton: true
          },
          enableColumnMenu: false
        },
        IS_ON_ACTIVE_RUA: {
          field: 'isOnActiveRua',
          displayName: 'On Active RUA',
          width: 90,
          enableSorting: true,
          filter: {
            ariaLabel: 'On Active RUA',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: [{
              value: '',
              label: 'All'
            },
              {
                value: true,
                label: 'Yes'
              },
              {
                value: false, // an approach to query custom column with false value
                label: 'No'
              }],
            aggregator: 'and',
            disableCancelFilterButton: true
          },
          enableColumnMenu: false
        },
        RUA_CURRENTLY_ON: {
          field: 'ruaCurrentlyOn',
          displayName: 'RUA(s) Currently On',
          width: 110,
          filter: {
            aggregator: 'AND'
          },
          enableColumnMenu: false
        },
        RUA_REMOVED_FROM: {
          field: 'ruaRemovedFrom',
          displayName: 'RUA(s) Removed From',
          width: 120,
          filter: {
            aggregator: 'AND'
          },
          enableColumnMenu: false
        },
        SOE_ON_FILE: {
          field: 'soeOnFile',
          displayName: 'SOE On File',
          width: 80,
          filter: {
            ariaLabel: 'SOE on file',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: [{
              value: '',
              label: 'All'
            },
              {
                value: true,
                label: 'Yes'
              },
              {
                value: false,
                label: 'No'
              }],
            disableCancelFilterButton: true
          },
          enableColumnMenu: false
        },
        UC_NET_ID: {
          field: 'netId',
          displayName: 'UC Net Id',
          width: 100,
          enableColumnMenu: false
        },
        LINE_NUMBER: {
          field: 'lineNumber',
          displayName: 'Line Number',
          enableFiltering: false,
          useExternalFiltering: false,
          enableSorting: false,
          useExternalSorting: false,
          enableColumnMenu: false
        },
        NUCLIDE: {
          field: 'name',
          displayName: 'Nuclide',
          enableFiltering: false,
          useExternalFiltering: false,
          enableSorting: false,
          useExternalSorting: false,
          enableColumnMenu: false
        },
        FORM: {
          field: 'lineNumberRadionuclideForm.lineNumberRadionuclideForm',
          displayName: 'Form',
          enableFiltering: false,
          useExternalFiltering: false,
          enableSorting: false,
          useExternalSorting: false,
          enableColumnMenu: false
        },
        CAMPUS_LIMIT: {
          field: 'description',
          displayName: 'Campus Limit',
          enableFiltering: false,
          useExternalFiltering: false,
          enableSorting: false,
          useExternalSorting: false,
          enableColumnMenu: false
        },
        POSSESSION_LIMIT: {
          field: 'totalPossessionInRUAs',
          displayName: 'Sum of Possession Limits',
          cellTemplate: '<div class="ui-grid-cell-contents" ng-class="{\'limitExceeded\' : (row.entity.totalPossessionInRUAs >= row.entity.campusLimit) }">{{ row.entity.totalPossessionInRUAs }}  {{row.entity.campusLimitUnit.unitName}}</div>',
          enableFiltering: false,
          useExternalFiltering: false,
          enableSorting: false,
          useExternalSorting: false,
          enableColumnMenu: false
        },
        CONTAINED_LIMIT: {
          field: 'totalContainedInRUAs',
          displayName: 'Sum of Total Contained Limit',
          cellTemplate: '<div class="ui-grid-cell-contents" ng-class="{\'limitExceeded\' : (row.entity.totalContainedInRUAs && row.entity.totalContainedInRUAs >= row.entity.limitContained) }">{{ row.entity.totalContainedInRUAs ? row.entity.totalContainedInRUAs : null }}  {{ row.entity.totalContainedInRUAs ? row.entity.containedLimitUnitId.unitName : null}}</div>',
          enableFiltering: false,
          useExternalFiltering: false,
          enableSorting: false,
          useExternalSorting: false,
          enableColumnMenu: false
        },
        WASTE_ACTIVITY: {
          field: 'wasteActivity',
          displayName: 'Sum of Waste Activity',
          cellTemplate: '<div class="ui-grid-cell-contents" ng-class="{\'limitExceeded\' : (row.entity.totalPossessionInRUAs >= row.entity.campusLimit) }">{{ row.entity.wasteActivity }}  {{row.entity.campusLimitUnit.unitName}}</div>',
          enableFiltering: false,
          useExternalFiltering: false,
          enableSorting: false,
          useExternalSorting: false,
          enableColumnMenu: false
        },
        TOTAL: {
          field: 'total',
          displayName: 'Total (Sum of Possession Limits + Waste Activity)',
          cellTemplate: '<div class="ui-grid-cell-contents" ng-class="{\'limitExceeded\' : (row.entity.totalPossessionInRUAs >= row.entity.campusLimit) }">{{ row.entity.total }}  {{row.entity.campusLimitUnit.unitName}}</div>',
          enableFiltering: false,
          useExternalFiltering: false,
          enableSorting: false,
          useExternalSorting: false,
          enableColumnMenu: false
        },
        RADIONUCLIDE: {
          field: 'radionuclideName',
          displayName: 'Radionuclide'
        },
        CHEMICAL_FORM: {
          field: 'chemicalForm',
          displayName: 'Chemical Form'
        },
        PHYSICAL_FORM: {
          field: 'physicalForm',
          displayName: 'Physical Form'
        },
        EXPT: {
          field: 'experimentPossessionLimit',
          displayName: 'mCi/Expt'
        },
        VIAL: {
          field: 'vialPossessionLimit',
          displayName: 'Vial Limit'
        },
        POSS: {
          field: 'requestedPossessionLimit',
          displayName: 'mCi/Poss'
        },
        ELEMENTAL_GRAMS: {
          field: 'possessionLimitElementalMass',
          displayName: 'Poss Limit Elemental Grams'
        },
        NET_GRAMS: {
          field: 'possessionLimitNetMass',
          displayName: 'Poss Limit Net Grams'
        },
        ENRICHMENT: {
          field: 'enrichment',
          displayName: 'Enrichment',
          cellTemplate: '<div class="ui-grid-cell-contents">{{ row.entity.enrichment > 0 ? row.entity.enrichment : \'\' }}</div>'
        },
        CONTAINED_EXPT: {
          field: 'containedExpLimit',
          displayName: 'g/Contd Expt'
        },
        CONTAINED_VIAL: {
          field: 'containedVialLimit',
          displayName: 'g/Contd Vial'
        },
        CONTAINED_POSS: {
          field: 'containedPossLimit',
          displayName: 'g/Contd Poss'
        },
        USE_PURPOSE: {
          field: 'purposeType',
          displayName: 'Use Purpose',
          cellTemplate: "format-to-camelcase.html"
        },
        MACHINE_ID: {
          field: 'machineId',
          displayName: 'Machine Id'
        },
        MACHINE_USE_LOCATION: {
          field: 'location',
          displayName: 'Use location',
          cellTemplate: '<div class="ui-grid-cell-contents">{{ row.entity.location.buildingDisplayName }} - {{row.entity.location.roomNumber}}</div>'
        },
        DPH_NUMBER: {
          field: 'dphNumber',
          displayName: 'CDPH Number'
        },
        MACHINE_TYPE: {
          field: 'type',
          displayName: 'Machine Type'
        },
        MACHINE_MANUFACTURER: {
          field: 'manufacturer',
          displayName: 'Manufacturer'
        },
        MACHINE_MODEL: {
          field: 'model',
          displayName: 'Model'
        },
        MAX_CURRENT: {
          field: 'maximumCurrent',
          displayName: 'Max. Current (mA)'
        },
        MAX_VOLTAGE: {
          field: 'maximumVoltage',
          displayName: 'Max. Voltage (kVP)'
        },
        NORMAL_CURRENT: {
          field: 'normalCurrent',
          displayName: 'Normal Current (mA)'
        },
        MACHINE_USE_CODE: {
          field: 'useCode',
          displayName: 'Use Code',
          width: 65,
          filter: {
            ariaLabel: 'useCode',
            type: uiGridConstants.filter.SELECT,
            condition: uiGridConstants.filter.EXACT,
            term: '',
            selectOptions: UtilService.sortUniqUnion([{
              value: '',
              label: 'ALL'
            }], UtilService.mapToDropdownOptions(StaticCollections.useCodes), 'label'),
            aggregator: 'eq',
            disableCancelFilterButton: true
          }
        },
        HAZARD_CLASS: {
          field: 'hazardClass',
          displayName: 'Hazard Class',
          width: 70
        },
        RUA_NUMBER: {
          field: 'ua.ruaNumber',
          displayName: 'RUA #',
          width: 60
        },
        ATTACHMENT_FILENAME: {
          field: 'fileName',
          displayName: 'File Name'
        },
        ATTACHMENT_SIZE: {
          field: '_size',
          displayName: 'Size',
          width: 100,
          enableFiltering: false,
          cellTemplate: '<div class="ui-grid-cell-contents">{{ row.entity._size | bytes }}</div>'
        },
        AMENDMENT_NUMBER: {
          field: 'amendment',
          displayName: 'Amendment#'
        },
        SUMMARY_OF_CHANGES: {
          field: 'summaryOfChanges',
          displayName: 'Summary of Changes',
          enableFiltering: false,
          useExternalFiltering: false,
          enableSorting: false,
          useExternalSorting: false,
          enableColumnMenu: false
        },
        ACTION: {
          field: '$$action',
          displayName: 'Change Request',
          cellTemplate: 'record-action.html',
          width: 75,
          enableFiltering: false,
          useExternalFiltering: false,
          enableSorting: false,
          useExternalSorting: false,
          enableColumnMenu: false
        }
      };
    }
  ]);
