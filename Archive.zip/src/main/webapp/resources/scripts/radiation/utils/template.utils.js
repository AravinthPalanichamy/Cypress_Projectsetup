'use strict';

angular.module('app').factory('TemplateUtils', function() {
  var utils = {
    getPersonDropdownTemplate: function(options, selectLabel, columnDefinition) {
      var optionsString = "";
      selectLabel = selectLabel || '-- select --';
      options.forEach(function(option) {
        optionsString += '<li ng-class="{\'active\': row.entity.' + columnDefinition.field + ' === ' + option.id + '}" ng-click="row.entity.dirty = true; row.entity.' + columnDefinition.field.split('\.')[0] + '.id = ' + option.id + '; row.entity.' + columnDefinition.field.split('\.')[0] + '.displayName = \'' + option.displayName + '\'"><a href="" tabindex="-1">' + option.displayName + '</a></li>';
      });

      var template = '<form name=\"inputForm\" class="ui-grid-custom-dropdown"><div class="ui-grid-cell-contents">' +
        '<div class="btn-group" uib-dropdown dropdown-append-to-body>' +
        '<div class="dropdown-toggle" uib-dropdown-toggle><span>{{row.entity.' + columnDefinition.field.split('\.')[0] + '.displayName || "' + selectLabel + '"}}</span><span class="caret"></span></div>' +
        '<ul class="dropdown-menu ui-grid-custom-dropdown-menu" role="menu" uib-dropdown-menu>' +
        optionsString +
        '</ul>' +
        '</div>' +
        '</div></form>';
      return template;
    },
    getDropdownTemplate: function(options, selectLabel, columnDefinition) {
      var optionsString = "";
      selectLabel = selectLabel || '-- select --';
      options.forEach(function(option) {
        optionsString += '<li ng-class="{\'active\': row.entity.' + columnDefinition.field + ' === \'' + option.value + '\'}" ng-click="row.entity.dirty = true; row.entity.' + columnDefinition.field + ' = \'' + option.value + '\';"><a href="" tabindex="-1">' + option.label + '</a></li>';
      });


      var template = '<form name=\"inputForm\" class="ui-grid-custom-dropdown"><div class="ui-grid-cell-contents">' +
        '<div class="btn-group" uib-dropdown dropdown-append-to-body>' +
        '<div class="dropdown-toggle" uib-dropdown-toggle><span>{{(row.entity.' + columnDefinition.field + ' |camelcase) || "' + selectLabel + '"}}</span><span class="caret"></span></div>' +
        '<ul class="dropdown-menu ui-grid-custom-dropdown-menu" role="menu" uib-dropdown-menu>' +
        optionsString +
        '</ul>' +
        '</div>' +
        '</div></form>';
      return template;
    }
  };

  return utils;
});
