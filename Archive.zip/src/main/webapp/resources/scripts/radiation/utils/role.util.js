'use strict';

angular.module('app').factory('RoleUtils', function(CURRENT_USER, StaticCollections) {
  var roleUtils = {
    getRoleCode: function() {
      if (_.includes(CURRENT_USER.roles, StaticCollections.rolesHash.RADIATION_ADMIN.code)) {
        return StaticCollections.rolesHash.RADIATION_ADMIN.code;
      } else if (_.includes(CURRENT_USER.roles, StaticCollections.rolesHash.INSPECTOR.code)) {
        return StaticCollections.rolesHash.INSPECTOR.code;
      } else if (_.includes(CURRENT_USER.roles, StaticCollections.rolesHash.RADIATION_SAFETY_COMMITTEE_MEMBER.code)) {
        return StaticCollections.rolesHash.RADIATION_SAFETY_COMMITTEE_MEMBER.code;
      } else if (_.includes(CURRENT_USER.roles, StaticCollections.rolesHash.RESPONSIBLE_PERSON.code)) {
        return StaticCollections.rolesHash.RESPONSIBLE_PERSON.code;
      } else {
        return StaticCollections.rolesHash.AUTHORIZED_USER.code;
      }
    }
  };

  return roleUtils;
});
