'use strict';

angular.module('app').controller('DosimetryIssuanceListCtrl', function($location, DosimetryIssuanceService, PrintService, TableHeaderCollections, page) {
  var ctrl = this;

  ctrl.totalItems = page.totalCount;
  ctrl.data = page.data || [];

  ctrl.init = function() {
    ctrl.columns = ctrl.defineTable();
    ctrl.buttonList = [
      {label: 'Print Issuance Forms', action: ctrl.printIssuanceForms},
      {label: 'New Issuance Group', action: ctrl.newIssuanceGroup}
    ];
  };

  ctrl.defineTable = function() {
    var edit = _.cloneDeep(TableHeaderCollections.EDIT);
    edit.cellTemplate = '<div class="edit-link"><span><a href="#/dosimetry-issuance/edit/{{ row.entity.id }}" class="glyphicon glyphicon-edit"><span class="hideEditText">Edit</span></a></span></div>';

    return [
      edit,
      {displayName: 'Group ID', field: 'groupId', width: 100},
      {displayName: 'Building', field: 'location.buildingPrimaryName'},
      {displayName: 'Room', field: 'location.roomNumber'},
      {displayName: 'Frequency', field: 'frequency.frequency'}
    ];
  };

  ctrl.printIssuanceForms = function(state) {
    var issuanceFormIds = state.map(function(issuance) { return issuance.id; });
    PrintService.openInTab('printDosimetryGroupIssuance', ({}, issuanceFormIds));
  };

  ctrl.newIssuanceGroup = function() {
    $location.path('dosimetry-issuance/new');
  };

  ctrl.getState = function(state) {
  return DosimetryIssuanceService.search({}, state).$promise;
  };

  ctrl.init();

});
