'use strict';

angular.module('app').controller('WasteFacilityInventoryCtrl', function(data) {
  var ctrl = this;


  ctrl.init = function() {
    var materialRadionuclides = [];
    data.forEach(function(material) {
      materialRadionuclides.push(material.materialRadionuclides);
    });

    ctrl.data = _(materialRadionuclides)
      .flatten()
      .groupBy('radionuclideDisplayName')
      .map(ctrl.displayValues)
      .flatten()
      .sortBy('name')
      .value();

    ctrl.columns = ctrl.defineTable();
  };

  ctrl.defineTable = function() {
    return [
      { displayName: 'Radionuclide', field: 'name', width: '200' },
      { displayName: 'Enrichment %', field: 'enrichment',width: '120'},
      { displayName: 'Sealed Source', field: 'isSealedSource', width: '80', cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.isSealedSource" class="glyphicon glyphicon-ok" ></span></div>' },
      { displayName: 'Current Activity (mCi)', field: 'currentAmount', cellFilter: 'scientific' },
      { displayName: 'Current Volume (microliter)', field: 'volume', cellFilter: 'scientific', headerCellTemplate: '<div class="ui-grid-cell-contents ui-grid-header-cell-label">Current Volume(&micro;l)</div>' },
      { displayName: 'Elemental Mass (grams)', field: 'elementalMass', cellFilter: 'scientific' },
      { displayName: 'Net Mass (grams)', field: 'netMass', cellFilter: 'scientific' }
    ];
  };

  ctrl.displayValues = function(materialRadionuclides) {
    return _(materialRadionuclides)
      .groupBy(function(m) {
        return m.uaLimit.enrichment + '-' + m.uaLimit.isSealedSource;
      })
      .map(function(groupedMaterialradionuclide) {
        return {
          name: groupedMaterialradionuclide[0].radionuclideDisplayName,
          isSealedSource: groupedMaterialradionuclide[0].uaLimit.isSealedSource,
          enrichment: groupedMaterialradionuclide[0].uaLimit.enrichment,
          currentAmount: ctrl.calculateValue(groupedMaterialradionuclide, 'currentAmount'),
          volume: ctrl.calculateValue(groupedMaterialradionuclide, 'useVolume'),
          elementalMass: ctrl.calculateValue(groupedMaterialradionuclide, 'currentElementalMass'),
          netMass: ctrl.calculateValue(groupedMaterialradionuclide, 'currentNetMass')
        };
      })
      .value();
  };

  ctrl.calculateValue = function(materialRadionuclides, key) {
    return _.reduce(materialRadionuclides, function(currentValue, materialRadionuclide) {
      return currentValue + materialRadionuclide[key];
    }, 0);
  };

  ctrl.init();

});
