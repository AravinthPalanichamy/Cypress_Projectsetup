'use strict';

angular.module('app').controller('RuaListCtrl', function($q, $templateCache, StaticCollections, FileSaver,
                                                         TableHeaderCollections, TableService, ConfirmModelService, UaService, PrintService,
                                                         ExcelService, TypesService, UtilService, PersonService, profile, data) {
  var ctrl = this;
  var tableHeaderCollections = {};
  ctrl.download = ExcelService.ruaExcel;
  ctrl.report = "RUA";
  ctrl.currentUser = profile;
  ctrl.isAdmin = PersonService.isAdmin;
  ctrl.addRecordUrl = !ctrl.isAdmin ? '' : '/rua/create';

  ctrl.init = function() {
    ctrl.totalItems = data.totalCount;
    ctrl.data = data.data;

    tableHeaderCollections = angular.copy(TableHeaderCollections);
    ctrl.getTableHeader();
    ctrl.dateRangeLabel = {fromDate: 'Generate Survey Assignments for RUAs that have Surveys due from: '};

    if (ctrl.isAdmin) {
      ctrl.buttonList = [
        {label: "Print Dosimetry Routine Issuance", action: ctrl.printDosimetryRoutineIssuance},
        {label: "Email List", action: ctrl.emailList}
      ];
    }

  };

  ctrl.getTableHeader = function() {
    tableHeaderCollections.EDIT.cellTemplate = 'rua-edit.html';
    tableHeaderCollections.DATE_RANGE_SHORT.field = 'expirationDate';
    tableHeaderCollections.DATE_RANGE_SHORT.displayName = 'Expiration Date (mm/dd/yyyy)';
    tableHeaderCollections.DATE_RANGE_SHORT.width = 150;
    tableHeaderCollections.LBL.cellTemplate = '<div class="yes-no-icon"> <span  ng-if="row.entity.other" class="glyphicon glyphicon-ok" ></span></div>';
    tableHeaderCollections.LBL.width = undefined;

    ctrl.columns = ctrl.colDefs();

    ctrl.getTableFilters();
  };

  ctrl.emailList = function() {
    TableService.searchAndDisplayEmail(ctrl.state || Object.assign({}, UtilService.searchDefaults, { pagination: { itemPerPage: ctrl.totalItems } }), "/rua/email/download");
  };

  ctrl.getState = function(state) {
    ctrl.state = state;
    var request = UaService.search({}, state).$promise;
    request.then(function(data) {
      ctrl.data = data.data;
    });
    return request;
  };

  ctrl.printDosimetryRoutineIssuance = function() {
    if (ctrl.data.length > 0) {
      PrintService.openInTab('printDosimetryRoutineIssuance', ({}, _.map(ctrl.data, 'id')));
    } else {
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.INFO, {message:"No Data Found"});
    }
  };

  ctrl.editRua = function(row) {
    //TODO: anything that edit icon click can do ; e.g. firing up http, etc.,
  };

  ctrl.colDefs = function() {
    var list = [
      tableHeaderCollections.EDIT,
      tableHeaderCollections.RUA,
      tableHeaderCollections.RUA_TYPE,
      tableHeaderCollections.PI_LAST_NAME,
      tableHeaderCollections.PI_FIRST_NAME,
      tableHeaderCollections.ORGANIZATION,
      tableHeaderCollections.LOCATIONS,
      tableHeaderCollections.SURVEY_FREQ,
      tableHeaderCollections.DATE_RANGE_SHORT,
      tableHeaderCollections.STATUS,
      tableHeaderCollections.CLASS,
      tableHeaderCollections.DOSIMETRY,
      tableHeaderCollections.LBL
    ];

    return list;
  };

  ctrl.getTableFilters = function() {
    var dosimetryTypes = TypesService.getMonitorTypes({}, {}).$promise;
    var frequencyTypes = TypesService.getFrequencyList({}, {}).$promise;
    $q.all([dosimetryTypes, frequencyTypes]).then(function(values) {

      var dosimetryType = _.map(_.reject(values[0], {'name': "other"}), function(value, key) {
        return {label: value.name, value: value.name};
      });

      var surveyFreq = _.map(values[1], function(value, key) {
        return {label: value.frequency, value: value.frequency};
      });

      var statusType = _.filter(
        _.map(StaticCollections.uaStatusHash, function(value, key) {
          return {label: value, value: key};
        }),
        function(o) {
          return !(o.label === StaticCollections.uaStatusHash.DRAFT || o.label === StaticCollections.uaStatusHash.PENDING_REVIEW);
        });

      ctrl.getSortedFilters(dosimetryType, surveyFreq, statusType);
    });
  };

  ctrl.getSortedFilters = function(dosimetryType, surveyFreq, statusType) {
    tableHeaderCollections.DOSIMETRY.filter.options = UtilService.sortUniqUnion(tableHeaderCollections.DOSIMETRY.filter.options, dosimetryType, 'label');
    tableHeaderCollections.SURVEY_FREQ.filter.selectOptions = UtilService.sortUniqUnion(tableHeaderCollections.SURVEY_FREQ.filter.selectOptions, surveyFreq, 'label');
    tableHeaderCollections.RUA_TYPE.filter.selectOptions = UtilService.sortUniqUnion(tableHeaderCollections.RUA_TYPE.filter.selectOptions, StaticCollections.UATypesHash, 'label');
    tableHeaderCollections.STATUS.filter.options = UtilService.sortUniqUnion(tableHeaderCollections.STATUS.filter.options, statusType, 'label');
  };


  ctrl.onDateRangeSubmit = function() {
    console.log('date range submit ', ctrl.dateRange); //POC for parent component to get date range value
  };

  ctrl.printUa = function(id) {
    PrintService.openInTab('printUa', {uaId: id});
  };

  ctrl.checkOther = function(ua) {
    if (ua.billing === 'Other') {
      return true;
    }
  };
})

  .run(function($templateCache) {
    var editTemplate = '<div class="edit-link">'
      + ' <span><a href="#/rua/{{row.entity.id}}" class="glyphicon {{ !grid.appScope.parentScope.isAdmin ? \'glyphicon-eye-open\' : \'glyphicon-edit\'}}" title="{{ !grid.appScope.parentScope.isAdmin ? \'View RUA \' : \'Edit RUA\'}}"><span class="hideEditText">Edit</span></a></span>'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.printUa(row.entity.id)" class="glyphicon glyphicon glyphicon-print" title="Print RUA #{{row.entity.ruaNumber}}"></a></span>'
      + '</div>';
    $templateCache.put('rua-edit.html', editTemplate);
  });
