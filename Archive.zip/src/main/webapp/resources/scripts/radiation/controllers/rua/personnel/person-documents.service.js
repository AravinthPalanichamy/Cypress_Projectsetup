'use strict';

angular.module('app').factory('PersonDocumentService', function($resource, $http, $uibModal) {


  var service = {
    isOpen: false,
    /*
     - person: Person Object
     [userId, firstName, lastName] - required fields
     */
    showSOEs: function(person) {
      if (service.isOpen) return true;

      var uibModal = $uibModal.open({
        templateUrl: 'resources/scripts/radiation/controllers/rua/personnel/person-documents.html',
        controllerAs: '$docCtrl',
        size: 'xl',
        keyboard: false,
        windowTopClass: 'person-soe-model',
        backdrop: 'static',
        controller: function($uibModalInstance, PersonService, AttachmentService, ConfirmModelService, TableHeaderCollections) {
          var $ctrl = this;
          service.isOpen = true;

          var $docCtrl = this;
          $docCtrl.options = {
            attachmentType: "SOE",
            attachmentTypes: null
          };
          $docCtrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
          $docCtrl.tableHeaders = {};

          $docCtrl.init = function() {
            $docCtrl.person = person;
            $docCtrl.getTableHeader();
            $docCtrl.buttonList = [{
              label: "Add Document",
              action: $docCtrl.uploadDocument
            }];
            $docCtrl.getData();
          };

          $docCtrl.getTableHeader = function() {
            $docCtrl.tableHeaders = {
              EDIT: Object.assign({}, $docCtrl.tableHeaderCollections.EDIT, {cellTemplate: "person-attachment-edit.html"}),
              ATTACHMENT_FILENAME: Object.assign({}, $docCtrl.tableHeaderCollections.ATTACHMENT_FILENAME),
              TITLE: Object.assign({}, $docCtrl.tableHeaderCollections.TITLE),
              DESCRIPTION: Object.assign({}, $docCtrl.tableHeaderCollections.DESCRIPTION),
              ATTACHMENT_SIZE: Object.assign({}, $docCtrl.tableHeaderCollections.ATTACHMENT_SIZE),
              ATTACHMENT_REFERENCE_DATE: Object.assign({}, angular.copy($docCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
                field: 'referenceDate',
                displayName: 'Reference Date',
                width: 150
              }),
              LAST_MODIFIED_DATE: Object.assign({}, angular.copy($docCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
                field: 'lastModifiedDate',
                displayName: 'Last Modified Date',
                width: 150
              }),
              DELETE: {
                field: 'Delete',
                displayName: 'Delete',
                cellTemplate: 'person-attachment-delete.html',
                width: 65
              }
            };

            $docCtrl.columns = Object.values($docCtrl.tableHeaders);
          };
          $docCtrl.getData = function() {
            PersonService.getAllSOEs({userId: $docCtrl.person.userId}).$promise.then(function(data) {
              $docCtrl.data = data;
            });
          };

          $docCtrl.uploadDocument = function() {
            AttachmentService.uploadAttachment($docCtrl.person, null, $docCtrl.options, $docCtrl.saveAttachment);
          };

          $docCtrl.editDocument = function(userId, attachmentId) {
            var attachment = _.find($docCtrl.data, {id: attachmentId});
            AttachmentService.uploadAttachment($docCtrl.person, attachment, $docCtrl.options, $docCtrl.saveAttachment);
          };

          $docCtrl.deleteDocument = function(userId, attachmentId) {
            var attachment = _.find($docCtrl.data, {id: attachmentId});
            ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE, {message: "Are you sure you want to delete the document <strong>" + attachment.fileName + "</strong>?"}, function() {
              PersonService.deleteSOEAttachment({
                userId: userId,
                attachmentId: attachmentId
              }).$promise.then(function() {
                $docCtrl.getData();
              });
            });
          };

          $docCtrl.downloadDocument = function(userId, attachmentId) {
            AttachmentService.downloadAttachment(attachmentId);
          };

          $docCtrl.saveAttachment = function(person, attachment) {
            console.log('calling save Attachment');
            var isUpdate = _.some($docCtrl.data, {id: attachment.id});
            var attachments = _.map($docCtrl.data, function(a) {
              return {id: a.id};
            });
            if (!isUpdate) {
              attachments.push({id: attachment.id});
            }
            PersonService.updateSOEAttachments({userId: person.userId}, attachments).$promise.then(function() {
              $docCtrl.getData();
            });
          };

          $ctrl.cancel = function() {
            service.isOpen = false;
            $uibModalInstance.dismiss('cancel');
          };

          $ctrl.init();
        }
      });

      return uibModal;
    }
  };

  return service;

})
  .run(function($templateCache) {
    var attachmentEditTemplate = '<div class="edit-link">'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.editDocument(grid.appScope.parentScope.person.userId, row.entity.id)" class="glyphicon glyphicon-edit" title="Edit Document"></a></span>'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.downloadDocument(grid.appScope.parentScope.person.userId, row.entity.id)" target="_blank" title="Download Document" class="glyphicon glyphicon-download-alt"></a></span>'
      + '</div>';
    $templateCache.put('person-attachment-edit.html', attachmentEditTemplate);

    var attachmentDeleteTemplate = '<div class="delete-link">'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.deleteDocument(grid.appScope.parentScope.person.userId, row.entity.id)" class="glyphicon glyphicon-trash text-danger" title="Delete Document"></a></span>'
      + '</div>';
    $templateCache.put('person-attachment-delete.html', attachmentDeleteTemplate);
  });
