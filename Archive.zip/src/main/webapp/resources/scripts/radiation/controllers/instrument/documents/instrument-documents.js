'use strict';

angular.module('app').controller('InstrumentDocumentCtrl', function(uiGridConstants, InstrumentService, AttachmentService, TableHeaderCollections, UtilService, ConfirmModelService, PersonService) {
  var $docCtrl = this;
  $docCtrl.isAdmin = PersonService.isAdmin;
  $docCtrl.options = {
    attachmentType: 'INSTRUMENT',
    attachmentTypes: null
  };
  $docCtrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
  $docCtrl.tableHeaders = {};

  $docCtrl.init = function(instrument) {
    $docCtrl.instrument = instrument;
    if ($docCtrl.isAdmin) {
      $docCtrl.buttonList = [
        {
          label: "Add Document",
          action: $docCtrl.uploadDocument
        }
      ];
    }
    $docCtrl.getTableHeader();
    $docCtrl.getData();
  };

  $docCtrl.getTableHeader = function() {
    $docCtrl.tableHeaders = {
      EDIT: Object.assign({}, $docCtrl.tableHeaderCollections.EDIT, {cellTemplate: "instrument-attachment-edit.html"}),
      ATTACHMENT_FILENAME: Object.assign({}, $docCtrl.tableHeaderCollections.ATTACHMENT_FILENAME),
      TITLE: Object.assign({}, $docCtrl.tableHeaderCollections.TITLE),
      DESCRIPTION: Object.assign({}, $docCtrl.tableHeaderCollections.DESCRIPTION),
      ATTACHMENT_SIZE: Object.assign({}, $docCtrl.tableHeaderCollections.ATTACHMENT_SIZE),
      ATTACHMENT_REFERENCE_DATE: Object.assign({}, angular.copy($docCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'referenceDate',
        displayName: 'Reference Date',
        width: 150
      }),
      LAST_MODIFIED_DATE: Object.assign({}, angular.copy($docCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'lastModifiedDate',
        displayName: 'Last Modified Date',
        width: 150
      }),
      DELETE: {
        field: 'Delete',
        displayName: 'Delete',
        cellTemplate: 'instrument-attachment-delete.html',
        width: 65
      }
    };

    if (!$docCtrl.isAdmin) {
      delete $docCtrl.tableHeaders.DELETE;
    }

    $docCtrl.columns = Object.values($docCtrl.tableHeaders);
  };
  $docCtrl.getData = function() {
    InstrumentService.getAllAttachments({instrumentId: $docCtrl.instrument.id}).$promise.then(function(data) {
      $docCtrl.data = data;
    });
  };

  $docCtrl.uploadDocument = function() {
    AttachmentService.uploadAttachment($docCtrl.instrument, null, $docCtrl.options, $docCtrl.saveAttachment);
  };

  $docCtrl.editDocument = function(instrumentId, attachmentId) {
    var attachment = _.find($docCtrl.data, {id: attachmentId});
    AttachmentService.uploadAttachment($docCtrl.instrument, attachment, $docCtrl.options, $docCtrl.saveAttachment);
  };

  $docCtrl.deleteDocument = function(instrumentId, attachmentId) {
    var attachment = _.find($docCtrl.data, {id: attachmentId});
    ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE, {message: "Are you sure you want to delete the document <strong>" + attachment.fileName + "</strong>?"}, function() {
      InstrumentService.deleteInstrumentAttachment({
        instrumentId: $docCtrl.instrument.id,
        attachmentId: attachmentId
      }).$promise.then(function() {
        $docCtrl.getData();
      });
    });
  };

  $docCtrl.downloadDocument = function(instrumentId, attachmentId) {
    AttachmentService.downloadAttachment(attachmentId);
  };

  $docCtrl.saveAttachment = function(instrument, attachment) {
    var isUpdate = _.some($docCtrl.data, {id: attachment.id});
    var attachments = _.map($docCtrl.data, function(a) {
      return {id: a.id};
    });
    if (!isUpdate) {
      attachments.push({id: attachment.id});
    }
    InstrumentService.updateInstrumentAttachments({instrumentId: instrument.id}, attachments).$promise.then(function() {
      $docCtrl.getData();
    });
  };

})
  .run(function($templateCache) {
    var attachmentEditTemplate = '<div class="edit-link">'
      + ' <span><a ng-href=""  ng-click="grid.appScope.parentScope.editDocument(grid.appScope.parentScope.instrument.id, row.entity.id)" class="glyphicon {{ grid.appScope.parentScope.isAdmin ? \'glyphicon-edit\' : \'\'}}" title="Edit Document"></a></span>'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.downloadDocument(grid.appScope.parentScope.instrument.id, row.entity.id)" target="_blank" title="Download Document" class="glyphicon glyphicon-download-alt"></a></span>'
      + '</div>';
    $templateCache.put('instrument-attachment-edit.html', attachmentEditTemplate);

    var attachmentDeleteTemplate = '<div class="delete-link">'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.deleteDocument(grid.appScope.parentScope.instrument.id, row.entity.id)" class="glyphicon glyphicon-trash text-danger" title="Delete Document"></a></span>'
      + '</div>';
    $templateCache.put('instrument-attachment-delete.html', attachmentDeleteTemplate);
  });
