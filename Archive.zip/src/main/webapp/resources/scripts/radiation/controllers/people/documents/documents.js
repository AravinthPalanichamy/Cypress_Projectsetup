'use strict';

angular.module('app').component('peopleDocumentsTab', {
  transclude: true,
  templateUrl: 'resources/scripts/radiation/controllers/people/documents/documents.html',
  controllerAs: 'ctrl',
  controller: function(PersonService, AttachmentService, ConfirmModelService, TableHeaderCollections) {
    var ctrl = this;

    ctrl.options = {
      attachmentType: "SOE",
      attachmentTypes: null
    };
    ctrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
    ctrl.tableHeaders = {};

    ctrl.init = function() {
      ctrl.getTableHeader();
      ctrl.buttonList = ctrl.person ? [{
          label: "Add Document",
          action: ctrl.uploadDocument
        }] : [];
      ctrl.getData();
    };

    ctrl.getTableHeader = function() {
      ctrl.tableHeaders = {
        EDIT: Object.assign({}, ctrl.tableHeaderCollections.EDIT, {cellTemplate: "person-attachment-edit.html"}),
        ATTACHMENT_FILENAME: Object.assign({}, ctrl.tableHeaderCollections.ATTACHMENT_FILENAME),
        TITLE: Object.assign({}, ctrl.tableHeaderCollections.TITLE),
        DESCRIPTION: Object.assign({}, ctrl.tableHeaderCollections.DESCRIPTION),
        ATTACHMENT_SIZE: Object.assign({}, ctrl.tableHeaderCollections.ATTACHMENT_SIZE),
        ATTACHMENT_REFERENCE_DATE: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.DATE_RANGE_SHORT), {
          field: 'referenceDate',
          displayName: 'Reference Date',
          width: 150
        }),
        LAST_MODIFIED_DATE: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.DATE_RANGE_SHORT), {
          field: 'lastModifiedDate',
          displayName: 'Last Modified Date',
          width: 150
        }),
        DELETE: {
          field: 'Delete',
          displayName: 'Delete',
          cellTemplate: 'person-attachment-delete.html',
          width: 65
        }
      };

      ctrl.columns = Object.values(ctrl.tableHeaders);
    };
    ctrl.getData = function() {
      if (ctrl.person) {
        PersonService.getAllSOEs({userId: ctrl.person.userId}).$promise.then(function(data) {
          ctrl.data = data;
        });
      } else {
        ctrl.data = [];
      }
    };

    ctrl.uploadDocument = function() {
      AttachmentService.uploadAttachment(ctrl.person, null, ctrl.options, ctrl.saveAttachment);
    };

    ctrl.editDocument = function(attachmentId) {
      var attachment = _.find(ctrl.data, {id: attachmentId});
      AttachmentService.uploadAttachment(ctrl.person, attachment, ctrl.options, ctrl.saveAttachment);
    };

    ctrl.deleteDocument = function(userId, attachmentId) {
      var attachment = _.find(ctrl.data, {id: attachmentId});
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE, {message: "Are you sure you want to delete the document <strong>" + attachment.fileName + "</strong>?"}, function() {
        PersonService.deleteSOEAttachment({
          userId: userId,
          attachmentId: attachmentId
        }).$promise.then(function() {
          ctrl.getData();
        });
      });
    };

    ctrl.downloadDocument = function(attachmentId) {
      AttachmentService.downloadAttachment(attachmentId);
    };

    ctrl.saveAttachment = function(person, attachment) {
      var isUpdate = _.some(ctrl.data, {id: attachment.id});
      var attachmentIds = _.map(ctrl.data, function(a) {
        return {id: a.id};
      });
      if (!isUpdate) {
        attachmentIds.push({id: attachment.id});
      }
      PersonService.updateSOEAttachments({userId: person.userId}, attachmentIds).$promise.then(function() {
        ctrl.getData();
      });
    };
  },
  bindings: {
    person: '='
  }

})
  .run(function($templateCache) {
    var attachmentEditTemplate = '<div class="edit-link">'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.editDocument(row.entity.id)" class="glyphicon glyphicon-edit" title="Edit Document"></a></span>'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.downloadDocument(row.entity.id)" target="_blank" title="Download Document" class="glyphicon glyphicon-download-alt"></a></span>'
      + '</div>';
    $templateCache.put('person-attachment-edit.html', attachmentEditTemplate);

    var attachmentDeleteTemplate = '<div class="delete-link">'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.deleteDocument(grid.appScope.parentScope.person.userId, row.entity.id)" class="glyphicon glyphicon-trash text-danger" title="Delete Document"></a></span>'
      + '</div>';
    $templateCache.put('person-attachment-delete.html', attachmentDeleteTemplate);
  });
