'use strict';

angular.module('app').component('sealedSourceLeakTestsTab', {
  transclude: true,
  templateUrl: 'resources/scripts/radiation/controllers/sealedsource/edit/leaktest/list/list.html',
  controllerAs: 'ctrl',
  controller: function($templateCache, $uibModal, ConfirmModelService, InventoryService, SurveyService, SealedSourceService, TableHeaderCollections) {
    var ctrl = this;

    ctrl.init = function() {
      ctrl.getLeakTests();
      ctrl.buttonList = [{label: "New Leak Test", action: ctrl.openContainerModal}];
      ctrl.getTableHeader();
    };

    ctrl.getLeakTests = function() {
      InventoryService.getMaterial({materialId: ctrl.material.id})
        .$promise
        .then(function(response) {
          ctrl.material = response;
          ctrl.data = response.leakTests;
        });
    };

    ctrl.getTableHeader = function() {
      var tableHeaders = {
        EDIT: Object.assign({}, angular.copy(TableHeaderCollections.EDIT), {cellTemplate: "leaktest-edit.html"}),
        TEST_DATE: {
          field: 'testDate',
          displayName: 'Test Date',
          cellTemplate: 'format-to-date.html',
          enableFiltering: false,
          enableColumnMenu: false
        },
        TESTED_BY: {
          field: 'testedBy',
          displayName: 'Tested By',
          cellTemplate: '<div class="ui-grid-cell-contents">{{ row.entity.testedBy.lastName }} {{row.entity.testedBy.firstName}}</div>',
          enableFiltering: false,
          enableColumnMenu: false
        },
        TEST_RESULT: {
          field: 'testResult',
          displayName: 'Test Result',
          enableFiltering: false,
          enableColumnMenu: false
        },
        DATE_DUE: {
          field: 'dueDate',
          displayName: 'Date Due',
          cellTemplate: 'format-to-date.html',
          enableFiltering: false,
          enableColumnMenu: false
        },
        ENTRY_DATE: {
          field: 'createdDate',
          displayName: 'Entry Date',
          cellTemplate: 'format-to-date.html',
          enableFiltering: false,
          enableColumnMenu: false
        },
        DELETE: {
          field: 'Delete',
          displayName: '',
          cellTemplate: 'leaktest-delete.html',
          width: 65
        }
      };
      ctrl.columns = Object.values(tableHeaders);
    };

    ctrl.openContainerModal = function(testRecord) {
      $uibModal.open({
        templateUrl: 'resources/scripts/radiation/controllers/sealedsource/edit/leaktest/form.html',
        controller: 'LeakTestFormCtrl',
        controllerAs: 'formCtrl',
        size: 'lg',
        windowTopClass: 'email-model',
        backdrop: 'static',
        resolve: {
          material: function() {
            return ctrl.material;
          },
          testRecord: function() {
            return testRecord;
          },
          inspectors: function(SurveyService) {
            return SurveyService.getSurveyInspectors().$promise;
          }
        }
      }).closed.then(function() {
        ctrl.getLeakTests();
      });
    };

    ctrl.editLeakTest = function(testRecord) {
      ctrl.openContainerModal(testRecord);
    };

    ctrl.deleteLeakTest = function(testId) {
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE, {message: "Are you sure you want to delete the test record?"}, function() {
        SealedSourceService.deleteTest({id: testId})
          .$promise
          .then(function() {
            ctrl.getLeakTests();
          });
      });
    };
  },
  bindings: {
    material: '='
  }
})
  .run(function($templateCache) {
    $templateCache.put('leaktest-edit.html',
      '<div class="edit-link">' +
      '<span><a class="glyphicon glyphicon-edit" ng-click="grid.appScope.parentScope.editLeakTest(row.entity)"><span class="hideEditText">Edit</span></a></span></div>');
    $templateCache.put('leaktest-delete.html',
      '<div class="delete-link">' +
      '<span><a class="glyphicon glyphicon-trash text-danger" ng-click="grid.appScope.parentScope.deleteLeakTest(row.entity.id)"><span class="hideEditText">Delete</span></a></span></div>');
    $templateCache.put('table-leak-test-list.html', '<div id="leakTestList" ui-grid="ctrl.gridOptions" class="data-grid" ng-if="ctrl.gridOptions.data" ui-grid-pagination></div>');
  });
