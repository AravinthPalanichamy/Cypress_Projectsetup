'use strict';

angular.module('app')
  .controller('MainCtrl', function($route, $location, CURRENT_USER, PersonService, TabsService, PermissionService, UaService, PrintService, FileSaver, SettingsService, ConfirmModelService) {
    var ctrl = this;

    ctrl.tabsHash = [];
    ctrl.isAdmin = false;
    ctrl.showTabs = false;
    ctrl.piViewForRSO = false;
    ctrl.isAU = PersonService.isAU;

    ctrl.init = function() {
      ctrl.piViewForRSO = $route.current.params.piViewForRSO;
      if (document.querySelector('rss-tab')) {
        var elem = document.querySelector('#welcomePage');
        elem.style.display = 'none';
        ctrl.welcomePage = false;
      } else {
        ctrl.welcomePage = true;
      }
      ctrl.tabsHash = TabsService.tabsHash;
      ctrl.isAdmin = PersonService.isAdmin;
      ctrl.ruaList = _.sortBy(CURRENT_USER.ruaList, 'number');
      if (ctrl.ruaList.length === 1) {
        ctrl.selectRua(ctrl.ruaList[0]);
      }
      SettingsService.getSettings().$promise.then(function(settings) {
        ctrl.requestMaterials = settings.requestMaterials || ctrl.isAdmin;
      });
    };

    ctrl.selectRua = function(rua) {
      ctrl.rua = undefined;
      UaService.getUa({uaId: rua.id}, {}).$promise.then(function(response) {
        PermissionService.setData(response, function() {ctrl.rua = response;});
      });
    };

    ctrl.onClick = function(url, ruaId) {
      ctrl.showTabs = true;
      ctrl.welcomePage = false;
      ruaId ? $location.path(url).search({ruaId: ruaId}) : $location.path(url).search({});
    };

    ctrl.startAmendment = function() {
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.CONFIRM, {
        header: "Change Request Steps",
        message: "<p>If you would like to make a change to an RUA's:</p>" +
          "<ul>" +
          "<li>Building/Room</li>" +
          "<li>Personnel</li>" +
          "<li>Documents (Procedures, Statements of Experience)</li>" +
          "<li>Radionuclide Limits</li>" +
          "<li>Special Request (Under General tab)</li>" +
          "</ul>" +
          "<p>then please select the appropriate tab(s), make changes and \"Save\".</p>" +
          "<p>When all updates are complete, select \"Submit Change Request\", " +
          "and someone from the Radiation Safety Team will contact you shortly.</p>"
      }, function() {
        var rua = ctrl.rua;
        UaService.createAmendment({uaId: rua.id, uaNumber: rua.number}, []).$promise.then(
          function(response) {
            ctrl.showTabs = true;
            ctrl.welcomePage = false;
            ctrl.rua = response;
            PermissionService.setData(response);
            $location.path('/rua/' + response.id).search({});
          });
      });
    };

    ctrl.printUa = function(id) {
      PrintService.openInTab('printUa', {uaId: id});
    };

  });
