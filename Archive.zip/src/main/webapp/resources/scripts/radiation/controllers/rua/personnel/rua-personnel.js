'use strict';

angular.module('app').component('ruaPersonnelTab', {
  templateUrl: 'resources/scripts/radiation/controllers/rua/personnel/rua-personnel.html',
  controllerAs: 'personnelTabCtrl',
  controller: function($scope, uiGridConstants,
    $templateCache, StaticCollections, TableHeaderCollections, AmendmentService,
    PersonService, UaService, TypesService, DosimetryIssuanceService, ConfirmModelService, PersonTrainingService, PersonDocumentService, UtilService, PermissionService, SettingsService) {
    var personnelTabCtrl = this;
    personnelTabCtrl.isAdmin = PersonService.isAdmin;

    personnelTabCtrl.init = function() {
      UaService.getUaBundlePersonTraining({uaId: personnelTabCtrl.rua.id}, {})
        .$promise
        .then(function(response) {
          personnelTabCtrl.data = _.chain(response)
            .map(calculateExpiredTrainings)
            .map(mapDosimetries)
            .sortBy('createdDate')
            .value();
          return personnelTabCtrl.data;
        })
        .then(buildActiveNDeletedPersonnel)
        .then(personnelTabCtrl._init)
        .then(mapAmendmentDataIfExists);

      DosimetryIssuanceService.findByCampusCode({ campusCode: personnelTabCtrl.rua.pi.campus.code }).$promise.then(function(groups) {
        personnelTabCtrl.dosimetryIssuanceGroups = groups;
      });

      SettingsService.getSettings().$promise.then(function(settings) {
        personnelTabCtrl.validateTrainings = settings.validateTrainings;
      });
    };

    personnelTabCtrl._init = function(data) {
      personnelTabCtrl.addToRuaError = false;
      personnelTabCtrl.isTrainingCurrent = false;
      personnelTabCtrl.trainingError = false;
      personnelTabCtrl.showReAddButton = false;
      personnelTabCtrl.editData = [];
      personnelTabCtrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
      personnelTabCtrl.getTableHeader();
      personnelTabCtrl.showAddPerson = false;
      personnelTabCtrl.isEdit = false;
      personnelTabCtrl.isAmendment = UaService.isAmendment(personnelTabCtrl.rua);
      personnelTabCtrl.buttonList = PermissionService.hasPermission() ? [{
          label: "Add New Person",
          action: personnelTabCtrl.addNewPerson
        }] : [];
      personnelTabCtrl.isDosimetryOther = false;
      personnelTabCtrl.showDuplicateError = false;
      return data;
    };

    personnelTabCtrl.showSOEs = function(person) {
      PersonDocumentService.showSOEs(person);
    };

    personnelTabCtrl.mapPersonDosimetry = function(uaBundlePerson, ua) {
      if (uaBundlePerson.person.id === ua.pi.id) {
        uaBundlePerson.pinned = true;
      }
      uaBundlePerson.person.$dosimetryMap = {};
      uaBundlePerson.person.dosimetries =
        _.forEach(_.filter(uaBundlePerson.person.dosimetries, ['ruaId', ua.id]), function(dosimetry) {
          uaBundlePerson.person.$dosimetryMap[dosimetry.name.toUpperCase().replace(/(\s\-\s)|\s/g, '_')] = true;
        });
      return uaBundlePerson;
    };

    function calculateExpiredTrainings(ubp) {
      var currDate = moment(new Date()).format('YYYY-MM-DD');
      ubp.trainingExpired = (moment(ubp.trainingExpiryDate).isBefore(currDate));
      return ubp;
    }

    function mapDosimetries(ubp) {
      return personnelTabCtrl.mapPersonDosimetry(ubp, personnelTabCtrl.rua);
    }

    function buildActiveNDeletedPersonnel(data) {
      personnelTabCtrl.dataForActivePersonnel = _.filter(data, ['active', true]);
      personnelTabCtrl.dataForDeletedPersonnel = _.filter(data, ['active', false]);
      return data;
    }

    function mapAmendmentDataIfExists(data) {
      if (personnelTabCtrl.isAmendment) {
        return UaService.getUAByNumberAndTypeAndStatusType({
          uaNumber: personnelTabCtrl.rua.number,
          uaType: personnelTabCtrl.rua.type,
          uaStatus: UtilService.findAndGet(StaticCollections.uaStatus, 'displayName', 'Active')()
        }, {})
        .$promise
        .then(function(response) {
          personnelTabCtrl.activePersonnelData = _.chain(response.uaBundle.uaBundlePersons)
                                                  .filter(['active', true])
                                                  .map(function(ubp) {
                                                    return personnelTabCtrl.mapPersonDosimetry(ubp, response);
                                                  }).sortBy('createdDate')
                                                  .value();
          personnelTabCtrl.data = AmendmentService.compareAndMergeObjects(personnelTabCtrl.activePersonnelData, data, 'PERSONNEL');
          return data;
        });
      }
      return data;
    }

    TypesService.getMonitorTypes({}, {}).$promise
      .then(function(response) {
        personnelTabCtrl.dosimetryType = angular.copy(response);
      });

    personnelTabCtrl.getTableHeader = function() {

      personnelTabCtrl.tableHeaders = Object.assign(
        {},
        {
          EDIT: Object.assign({}, personnelTabCtrl.tableHeaderCollections.EDIT, {cellTemplate: "rua-personnel.html", width: 50, enableFiltering: false}),
          PIN: {
            field: 'pinned',
            visible: false,
            sort: {direction: uiGridConstants.ASC, priority: 0},
            suppressRemoveSort: true,
            sortDirectionCycle: [uiGridConstants.ASC]
          },
          LAST_NAME: {
            field: 'person.lastName',
            displayName: 'Last Name',
            enableFiltering: false,
            width: 90
          },
          FIRST_NAME: {
            field: 'person.firstName',
            displayName: 'First Name',
            enableFiltering: false,
            width: 90
          },
          EMAILS: {
            field: 'person.email',
            displayName: 'Email',
            enableFiltering: false,
            width: 100
          },
          DATE_ADDED: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
            field: 'dateAdded',
            displayName: 'Date Added',
            enableFiltering: false,
            width: 100
          }),
          RADIATION_FORM: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'person.hasStatementOfExperience',
            displayName: 'SOE',
            width: 50,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.person.hasStatementOfExperience" class="glyphicon glyphicon-ok" ></span></div>'
          }),
          ON_RUA: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'addedToRua',
            displayName: 'On RUA',
            width: 50,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.addedToRua" class="glyphicon glyphicon-ok" ></span></div>'
          }),
          PI: {
            field: 'Pi',
            displayName: 'PI',
            width: 45,
            cellTemplate: 'rua-personnel-pi.html',
            enableFiltering: false,
            enableColumnMenu: false
          },
          LAB: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'delegate',
            displayName: 'Radiation Contact',
            width: 85,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.delegate" class="glyphicon glyphicon-ok" ></span></div>'
          }),
          TRAINING_STATUS: {
            field: 'trainingStatus',
            displayName: 'Training Status',
            enableFiltering: false,
            width: 90,
            cellTemplate: 'rua-training-status.html'
          },
          LAST_TRAINING_DATE: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
            field: 'trainingCompletedDate',
            displayName: 'Last Training Date',
            enableFiltering: false,
            width: 90
          }),
          FINGER_RING_LEFT: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'person.$dosimetryMap.FINGER_RING_LEFT',
            displayName: ' Finger ring Left ',
            width: 70,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.person.$dosimetryMap.FINGER_RING_LEFT" class="glyphicon glyphicon-ok" ></span></div>'
          }),
          FINGER_RING_RIGHT: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'person.$dosimetryMap.FINGER_RING_RIGHT',
            displayName: 'Finger ring Right',
            width: 70,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.person.$dosimetryMap.FINGER_RING_RIGHT" class="glyphicon glyphicon-ok" ></span></div>'
          }),
          WRIST_BADGE_LEFT: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'person.$dosimetryMap.WRIST_BADGE_LEFT',
            displayName: ' Wrist badge Left',
            width: 70,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.person.$dosimetryMap.WRIST_BADGE_LEFT" class="glyphicon glyphicon-ok" ></span></div>'
          }),
          WRIST_BADGE_RIGHT: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'person.$dosimetryMap.WRIST_BADGE_RIGHT',
            displayName: ' Wrist badge Right',
            width: 70,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.person.$dosimetryMap.WRIST_BADGE_RIGHT" class="glyphicon glyphicon-ok" ></span></div>'
          }),
          BODY_BADGE_COLLAR: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'person.$dosimetryMap.BODY_BADGE_COLLAR',
            displayName: 'Body badge Collar',
            width: 70,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.person.$dosimetryMap.BODY_BADGE_COLLAR" class="glyphicon glyphicon-ok" ></span></div>'
          }),
          BODY_BADGE_WAIST: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'person.$dosimetryMap.BODY_BADGE_WAIST',
            displayName: 'Body badge Waist',
            width: 70,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.person.$dosimetryMap.BODY_BADGE_WAIST" class="glyphicon glyphicon-ok" ></span></div>'
          }),
          BODY_BADGE_CHEST: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'person.$dosimetryMap.BODY_BADGE_CHEST',
            displayName: ' Body badge Chest',
            width: 70,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.person.$dosimetryMap.BODY_BADGE_CHEST" class="glyphicon glyphicon-ok" ></span></div>'
          }),
          THYROID_SCAN: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'person.$dosimetryMap.THYROID_SCAN',
            displayName: 'Thyroid Scan',
            width: 70,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.person.$dosimetryMap.THYROID_SCAN" class="glyphicon glyphicon-ok" ></span></div>'
          }),
          URINALYSIS: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'person.$dosimetryMap.URINALYSIS',
            displayName: 'Urinalysis',
            width: 82,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.person.$dosimetryMap.URINALYSIS" class="glyphicon glyphicon-ok" ></span></div>'
          }),
          FETAL_BADGE: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'person.$dosimetryMap.FETAL_BADGE',
            displayName: ' Fetal badge',
            width: 70,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.person.$dosimetryMap.FETAL_BADGE" class="glyphicon glyphicon-ok" ></span></div>'
          }),
          NEUTRON_BADGE: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'person.$dosimetryMap.NEUTRON_BADGE',
            displayName: 'Neutron Badge',
            width: 70,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.person.$dosimetryMap.NEUTRON_BADGE" class="glyphicon glyphicon-ok" ></span></div>'
          }),
          OTHER: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.LBL), {
            field: 'person.$dosimetryMap.OTHER',
            displayName: 'Other',
            width: 80,
            enableFiltering: false,
            cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.person.$dosimetryMap.OTHER" class="glyphicon glyphicon-ok" ></span></div>'
          })
        });

      personnelTabCtrl.tableHeadersWithAction = Object.assign({},
        {
          ACTION: Object.assign({}, angular.copy(personnelTabCtrl.tableHeaderCollections.ACTION))
        },
        personnelTabCtrl.tableHeaders,
        {
          DELETE: {
            field: 'Delete',
            displayName: '',
            cellTemplate: 'rua-person-remove.html',
            width: 30
          }
        }
      );

      if (!PermissionService.hasPermission()) {
        delete personnelTabCtrl.tableHeadersWithAction.DELETE;
      }

      if (!UaService.isAmendment(personnelTabCtrl.rua)) {
        delete personnelTabCtrl.tableHeadersWithAction.ACTION;
      }
      personnelTabCtrl.columnsWithAction = Object.values(personnelTabCtrl.tableHeadersWithAction);
      personnelTabCtrl.columns = Object.values(personnelTabCtrl.tableHeaders);
    };

    personnelTabCtrl.searchPerson = function(query) {
      if (query.length > 1) {
        return PersonService.findByName({
          search: query
        }).$promise.then(function(response) {
          return _.filter(response, 'email').splice(0, 10);
        });
      } else {
        personnelTabCtrl.selectedPerson = null;
        return [];
      }
    };

    personnelTabCtrl.onAddPerson = function(form) {
      form.$submitted = true;
      if (personnelTabCtrl.validation() && form.$valid) {
        personnelTabCtrl.savingInProgress = true;
        UaService.addPersonToRUA({
          uaId: personnelTabCtrl.rua.id,
          personId: personnelTabCtrl.selectedRuaPerson.person.userId
        }, personnelTabCtrl.editPerson)
          .$promise.then(function(response) {
          form.$setPristine();
          if (UaService.isAmendment(personnelTabCtrl.rua)) {
            UaService.updateSummaryOfChanges({uaId: personnelTabCtrl.rua.id}, {"summaryOfChanges": "Personnel"})
              .$promise.then(function(res) {
              $scope.$parent.$parent.ctrl.init(res);
            });
          }
          personnelTabCtrl.rua = response;
          personnelTabCtrl.init(response);
          personnelTabCtrl.cancelEditPerson();
          personnelTabCtrl.savingInProgress = false;
        });
      }
    };

    personnelTabCtrl.selectPerson = function(person) {
      if (person.userId) {
        PersonService.getDetail({userId: person.userId}).$promise.then(function() {
          personnelTabCtrl.selectedPerson = person;
          UaService.getUaPerson({
            personId: person.userId,
            uaId: personnelTabCtrl.rua.id
          }).$promise
            .then(function(response) {
              personnelTabCtrl.selectedRuaPerson = response;
              if (personnelTabCtrl.selectedRuaPerson.id && !personnelTabCtrl.selectedRuaPerson.active) {
                personnelTabCtrl.showDuplicateError = !!personnelTabCtrl.selectedRuaPerson.id;
              }
              personnelTabCtrl.editActiveRUAPerson = undefined;
              personnelTabCtrl.editPerson = personnelTabCtrl.mapPerson(response);
            });
        });
      }
    };

    personnelTabCtrl.error = function() {
      return !!(personnelTabCtrl.soeError || personnelTabCtrl.trainingError || personnelTabCtrl.addToRuaError);

    };

    personnelTabCtrl.validation = function() {
      var hasSOE = personnelTabCtrl.validateSOE(personnelTabCtrl.editPerson);
      var isException = personnelTabCtrl.isException(personnelTabCtrl.editPerson);
      if (!isException) {
        if (hasSOE) {
          if (personnelTabCtrl.validateTrainings) {
            personnelTabCtrl.validateTraining(personnelTabCtrl.selectedRuaPerson.person.userId);
            return personnelTabCtrl.isTrainingCurrent;
          }
          return true;
        }
      } else return true && personnelTabCtrl.isGroupValid;
      return false;
    };

    personnelTabCtrl.validateIssuanceGroup = function(group) {
      if (!group) {
        personnelTabCtrl.editPerson.dosimetryIssuance = null;
        personnelTabCtrl.isGroupValid = true;
      } else {
        personnelTabCtrl.isGroupValid = _.some(personnelTabCtrl.dosimetryIssuanceGroups, function(issuanceGroup) { return issuanceGroup.id === group.id; });
      }
    };

    personnelTabCtrl.validateTraining = function(userId) {
      PersonService.getTrainingStatusByUserIdAndRUAType({
        userId: userId,
        ruaType: personnelTabCtrl.rua.type
      }).$promise.then(function(response) {
        if (response.trxStatusDesc === 'Completed') {
          personnelTabCtrl.isTrainingCurrent = true;
        } else {
          personnelTabCtrl.trainingError = true;
          personnelTabCtrl.showError = "This person can not be added, their " + personnelTabCtrl.rua.type + " training is expired or due.";
        }
      });
    };

    personnelTabCtrl.validateSOE = function(person) {
      if (!person.hasStatementOfExperience && !person.exceptional) {
        personnelTabCtrl.soeError = true;
        personnelTabCtrl.showError = "This person does not have a Statement of Experience (SOE). " +
        "Please upload their SOE on the Documents tab.";
      } else {
        personnelTabCtrl.soeError = false;
      }
      return person.hasStatementOfExperience;
    };

    personnelTabCtrl.isException = function(person) {
      if (!personnelTabCtrl.isAdmin) { return true; }
      if (person.exceptional) {
        personnelTabCtrl.soeError = !person.exceptional;
        personnelTabCtrl.trainingError = !person.exceptional;
      }
      return person.exceptional;
    };

    personnelTabCtrl.toggleDateOpen = function(type) {
      var newDateOpen = {};
      newDateOpen[type] = true;
      personnelTabCtrl.dateOpen = newDateOpen;
    };

    personnelTabCtrl.isDateOpen = function(type) {
      return personnelTabCtrl.dateOpen === type;
    };

    personnelTabCtrl.setPanel = function(panel) {
      personnelTabCtrl.panel = panel;
    };

    personnelTabCtrl.isDosimetrySelected = function(dosimetry) {
      return personnelTabCtrl.editPerson.monitorTypeIds.indexOf(dosimetry.id) > -1;
    };

    personnelTabCtrl.toggleDosimetry = function(dosimetry) {
      var index = personnelTabCtrl.editPerson.monitorTypeIds.indexOf(dosimetry.id);
      index > -1 ? personnelTabCtrl.editPerson.monitorTypeIds.splice(index, 1) : personnelTabCtrl.editPerson.monitorTypeIds.push(dosimetry.id);
      if (personnelTabCtrl.editPerson.monitorTypeIds.includes(12)) {
        personnelTabCtrl.isDosimetryOther = true;
      } else {
        personnelTabCtrl.isDosimetryOther = false;
      }
    };

    personnelTabCtrl.dosimetryDiffTemplate = function() {
      var str = '';
      if (personnelTabCtrl.editActiveRUAPerson) {
        str = _.join(_.map(personnelTabCtrl.editActiveRUAPerson.monitorTypeIds, function(id) {
          return UtilService.findAndGet(personnelTabCtrl.dosimetryType, 'name')('id', id);
        }), ', ');
      }
      return '<strong>' + str + '</strong>';
    };

    personnelTabCtrl.addNewPerson = function() {
      personnelTabCtrl.showAddPerson = true;
      personnelTabCtrl.isEdit = false;
      personnelTabCtrl.isGroupValid = true;
    };

    personnelTabCtrl.cancelEditPerson = function() {
      personnelTabCtrl.showAddPerson = false;
      personnelTabCtrl.showDuplicateError = false;
      personnelTabCtrl.selectedRuaPerson = null;
      personnelTabCtrl.selectedPerson = null;
      personnelTabCtrl.isDosimetryOther = false;
      personnelTabCtrl.trainingError = false;
      personnelTabCtrl.showReAddButton = false;
      personnelTabCtrl.isGroupValid = false;
    };

    personnelTabCtrl.onEditPerson = function(rua, personId) {
      personnelTabCtrl.isEdit = true;
      personnelTabCtrl.showAddPerson = true;
      personnelTabCtrl.trainingError = false;
      personnelTabCtrl.isGroupValid = true;
      var response = _.find(personnelTabCtrl.data, {id: personId});
      if (rua.isAmendment) {
        personnelTabCtrl.editActiveRUAPerson = {};
        var activeRuaPerson = _.find(personnelTabCtrl.activePersonnelData, {id: response.createdFrom});
        personnelTabCtrl.editActiveRUAPerson = activeRuaPerson ?
        Object.assign(personnelTabCtrl.editActiveRUAPerson, personnelTabCtrl.mapPerson(activeRuaPerson)) :
        undefined;
      }
      if (!response.active) {
        personnelTabCtrl.showReAddButton = true;
      }
      personnelTabCtrl.selectedRuaPerson = response;
      personnelTabCtrl.editPerson = {};
      personnelTabCtrl.editPerson = Object.assign(personnelTabCtrl.editPerson, personnelTabCtrl.mapPerson(response));
      personnelTabCtrl.groupSelected = personnelTabCtrl.editPerson.dosimetryIssuance || false;
    };

    personnelTabCtrl.mapPerson = function(bundlePerson) {
      if (!personnelTabCtrl.isAdmin && !personnelTabCtrl.rua.uaSubmitted) {
        bundlePerson.dateAdded = moment().toDate();
      }
      return {
        monitorTypeIds: _.map((bundlePerson.person.dosimetries), function(dosimetry) {
          // Adding additional field to editPerson Object when other dosimetry selected.
          if (dosimetry.otherDosimetry) {
            personnelTabCtrl.editPerson.otherDosimetry = dosimetry.otherDosimetry;
            personnelTabCtrl.isDosimetryOther = true;
          }

          return dosimetry.id;
        }),
        dosimetryIssuance: bundlePerson.person.dosimetryIssuance || null,
        dateAdded: bundlePerson.dateAdded || moment().toDate(),
        hasStatementOfExperience: bundlePerson.person.hasStatementOfExperience,
        addedToRua: bundlePerson.addedToRua,
        radFormComplete: bundlePerson.person.radFormComplete,
        dob: bundlePerson.person.dob ? moment(bundlePerson.person.dob).toDate() : null,
        exceptional: bundlePerson.exceptional,
        delegate: bundlePerson.delegate,
        comment: bundlePerson.person.comment
      };
    };

    personnelTabCtrl.removePerson = function(ruaId, bundlePersonId) {
      var person = _.find(personnelTabCtrl.data, {id: bundlePersonId});
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE, {
        header: "Remove Confirmation",
        message: "Are you sure you want to remove <strong>" + person.person.firstName + " " + person.person.lastName + "</strong>?"
      }, function() {
        UaService.deletePersonFromRUA({
          uaId: personnelTabCtrl.rua.id,
          userId: person.person.userId
        }).$promise.then(function(response) {
          personnelTabCtrl.rua = response;
          personnelTabCtrl.init(response);
        });
      });
    };

    personnelTabCtrl.checkPi = function(rua, bundlePerson) {
      return rua.pi.id === bundlePerson.person.id;
    };

    personnelTabCtrl.onTraining = function(user) {
      PersonTrainingService.showTrainings(user.person);
    };

    personnelTabCtrl.checkLMS = function(user) {
      PersonTrainingService.checkLMS(user.person);
    };

    personnelTabCtrl.checkEditPermissions = function(row) {
      return row.entity.id
              && row.entity.$$action !== 'DELETED'
              && PermissionService.hasPermission();
    };
  },
  bindings: {
    rua: '='
  }
}).run(function($templateCache) {
  var personRemoveTemplate = '<div class="delete-link" ' +
  'ng-if="grid.appScope.parentScope.checkEditPermissions(row)"><span><a ng-href="" ng-if=" !' +
  'grid.appScope.parentScope.checkPi(grid.appScope.parentScope.rua, row.entity)" ' +
  'ng-click="grid.appScope.parentScope.removePerson(grid.appScope.parentScope.rua.id, row.entity.id)" ' +
  'class="glyphicon glyphicon-trash text-danger" title="Remove Person"></a></span></div>';
  $templateCache.put('rua-person-remove.html', personRemoveTemplate);

  var personnelPiTemplate = '<div class="yes-no-icon"> <span  ng-if="grid.appScope.parentScope.checkPi(grid.appScope.parentScope.rua, row.entity)" class="glyphicon glyphicon-ok" ></span></div>';
  $templateCache.put('rua-personnel-pi.html', personnelPiTemplate);

  var personnelEditAndTrainingTemplate = '<div class="edit-link"><span ng-if="grid.appScope.parentScope.checkEditPermissions(row)">' +
    '<a href ng-click="grid.appScope.parentScope.onEditPerson(grid.appScope.parentScope.rua, row.entity.id)" class="glyphicon glyphicon-edit" title="Edit Person"></a>' +
    '</span><span><a ng-click="grid.appScope.parentScope.onTraining(row.entity)" title="Trainings" class="uc-training"></a></span></div>';
  $templateCache.put('rua-personnel.html', personnelEditAndTrainingTemplate);

  var trainingStatus = '<div>{{row.entity | trainingStatus}} ' +
    '<sup><a ng-click="grid.appScope.parentScope.checkLMS(row.entity)" title="Details">' +
    '<span ng-if="row.entity.trainingCompletedDate == null" class="glyphicon glyphicon-info-sign"></span></a></sup></div>';
  $templateCache.put('rua-training-status.html', trainingStatus);
});
