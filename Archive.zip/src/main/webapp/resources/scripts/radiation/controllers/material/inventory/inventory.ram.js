'use strict';

angular.module('app').controller('InventoryRamCtrl', function($uibModal, FileSaver, InventoryService, ExcelService, LabelService, TableHeaderCollections, MaterialUseService, StaticCollections, WasteService, WasteFormService, PrintService, EhsPickupService, PersonService) {
  var ctrl = this;

  ctrl.data = [];
  ctrl.tableHeaderCollections = _.cloneDeep(TableHeaderCollections);

  ctrl.getTableData = function(uaId) {
    InventoryService.getMaterialsByUaAndInventoryStatusType({
      uaId: uaId,
      inventoryStatusType: 'IN_INVENTORY',
      isSealedSource: false
    }, function(response) {
      ctrl.data = response;
    });
  };

  ctrl.exportExcel = function() {
    var excelData = ctrl.filteredRows.map(function(row) {
      return {
        'Material #': row.id,
        'Receipt Date': row.materialPackage !== null ? ctrl.formatDate(row.materialPackage.receivedDate) : null,
        'Radionuclide': row.radionuclideNameString,
        'Physical Form': row.physicalForm,
        'Chemical Form': row.chemicalForm,
        'Initial Amount (mCi)': row.requestedAmount,
        'Current Activity (mCi)': row.currentAmount,
        'Initial Volume (µl)': row.requestedVolume,
        'Current Volume (µl)': row.currentVolume,
        'Initial Mass (grams)': row.requestedElementalMass,
        'Current Mass (grams)': row.currentElementalMass,
        'Initial Sample Mass (grams)': row.requestedNetMass,
        'Current Sample Mass (grams)': row.currentNetMass,
        'Reference Date': ctrl.formatDate(row.initialDate)
      };
    });

    var name = ctrl.ruaNumber + ' RAM Inventory';
    ExcelService.export(excelData, name, {withTimeStamp: true});
  };

  ctrl.formatDate = function(date) {
    return moment(date).format('MM/DD/YYY');
  };

  ctrl.defineTable = function() {
    var use = _.cloneDeep(ctrl.tableHeaderCollections.EDIT);
    use.displayName = 'Use';
    use.field = 'useMaterial';
    use.enableFiltering = false;
    use.cellTemplate = 'material-use-edit.html';

    var initialDate = _.cloneDeep(ctrl.tableHeaderCollections.DATE_RANGE_SHORT);
    initialDate.field = 'initialDate';
    initialDate.width = 130;
    initialDate.displayName = 'Reference Date (mm/dd/yyyy)';

    var receivedDate = _.cloneDeep(ctrl.tableHeaderCollections.DATE_RANGE_SHORT);
    receivedDate.field = 'materialPackage.dateReceived';
    receivedDate.width = 150;
    receivedDate.displayName = 'Receipt Date (mm/dd/yyyy)';

    return [
      use,
      receivedDate,
      {displayName: 'Material #', field: 'id'},
      {displayName: 'Radionuclide', field: 'radionuclideNameString'},
      {displayName: 'Physical Form', field: 'physicalForm'},
      {displayName: 'Chemical Form', field: 'chemicalForm'},
      {displayName: 'Initial Amount (mCi)', field: 'requestedAmount'},
      {displayName: 'Current Activity (mCi)', field: 'currentAmount'},
      {
        displayName: 'Initial Volume (microliter)', field: 'requestedVolume',
        headerCellTemplate: '<div class="ui-grid-cell-contents ui-grid-header-cell-label">Initial Volume(&micro;l)</div>'
      },
      {
        displayName: 'Current Volume (microliter)', field: 'currentVolume',
        headerCellTemplate: '<div class="ui-grid-cell-contents ui-grid-header-cell-label">Current Volume(&micro;l)</div>'
      },
      {displayName: 'Initial Mass (grams)', field: 'requestedElementalMass'},
      {displayName: 'Current Mass (grams)', field: 'currentElementalMass'},
      {displayName: 'Initial Sample Mass (grams)', field: 'requestedNetMass'},
      {displayName: 'Current Sample Mass (grams)', field: 'currentNetMass'},
      initialDate,
      {
        displayName: 'Building & Room', field: 'storageLocation',
        cellTemplate: '<div class="ui-grid-cell-contents">{{ row.entity.storageLocation.buildingPrimaryName }} - {{row.entity.storageLocation.roomNumber}}</div>'
      },
      {displayName: 'Location', field: 'subLocation'}
    ];
  };

  ctrl.onUseMaterial = function(option, material) {
    ctrl.currentMaterial = angular.copy(material);
    if (option.id === 'CHANGE_LOCATION' || option.id === 'LOT') {
      MaterialUseService.openModal(option, ctrl.currentMaterial, ctrl.updateMaterial);
    } else if (option.id === 'TRANSFER') {
      MaterialUseService.openModal(option, ctrl.currentMaterial, ctrl.resetData);
    } else {
      MaterialUseService.openModal(option, ctrl.currentMaterial, ctrl.onSave);
    }
  };

  ctrl.updateMaterial = function(material) {
    InventoryService.updateMaterial({ materialId: material.id }, material).$promise.then(ctrl.resetData);
  };

  ctrl.onSave = function(material, options) {
    InventoryService.useMaterial(options, material).$promise.then(function(response) {
      ctrl.resetData();
      if (material.containerId) {
        WasteService.updateWasteTagForContainer({ruaId: ctrl.ruaId, containerId: material.containerId}, {});
      }
    });
  };

  ctrl.resetData = function() {
    ctrl.getTableData(ctrl.ruaId);
  };

  ctrl.printLabel = function(option, material) {
    LabelService.displayLabel([
      {label: 'EH&S Material #', value: material.id},
      {label: 'Radionuclide(s)', value: material.radionuclideNameString},
      {label: 'Initial Amount', value: material.requestedAmount},
      {label: 'Lot #', value: material.lotNumber},
      {label: 'Reference Date', value: moment(material.initialDate).format('MM/DD/YYYY')}
    ]);
  };

  ctrl.onDonePickup = function(trackingNumber, errorMessage) {
    ctrl.resetData();

    if (errorMessage) {
      ctrl.handleErrorMessage(errorMessage);
    } else if (trackingNumber) {
      ctrl.saveMessage = 'Material is successfully requested for an EH&S pickup. Available to view in Pending Pickup. Tracking # : ' + trackingNumber;
    }

  };

  ctrl.onRequestPickup = function(option, material) {
    ctrl.wasteTag = {};
    var options = {requestingPickup: true, nonDispose: true, material: material};
    WasteFormService.openModal(ctrl.rua, null, options, ctrl.onFormSubmit);
  };

  ctrl.onFormSubmit = function(wasteTag, options) {
    ctrl.wasteTag = wasteTag;
    ctrl.wasteTag.ownerRuaId = ctrl.ruaId;
    ctrl.container = {
      ruasWithAccess: [ctrl.rua],
      containerName: 'EH&S_Pickup_RUA_' + ctrl.rua.number,
      ownerRuaId: ctrl.rua.id
    };

    EhsPickupService.kickOffProcess(ctrl.wasteTag, ctrl.container, {material: options.material}, ctrl.onDonePickup);

  };

  ctrl.closeMessage = function() {
    ctrl.saveMessage = undefined;
    ctrl.saveError = undefined;
  };

  ctrl.handleErrorMessage = function(errorMessage) {
    ctrl.saveError = 'Unable to create an EH&S Pickup in WASTe application. ';
    ctrl.saveErrorDetail = ctrl.parseError(errorMessage);
  };

  ctrl.actionMenuValidation = function(validationReqd, entity) {
    if (!validationReqd) { return true; }
    return entity.materialRadionuclides.length === 1 && !entity.isMaterialForTest;
  };

  ctrl.buildOption = function(id, label, template, status, fn, validationReqd, order) {
    return Object.assign({}, { id: id,
                                label: label,
                                template: template,
                                status: status,
                                onClick: fn,
                                validationReqd: validationReqd,
                                order: order
                              });
  };

  ctrl.hasInventoryAccess = function() {
    return PersonService.isAdmin || PersonService.isRP_OR_DEL;
  };

  ctrl.useOptions = [
    ctrl.buildOption('IN_PROCESS', 'Use in Process', 'in-process-form.html',
                      'IN_PROCESS', ctrl.onUseMaterial, true, 2),
    ctrl.buildOption('IN_DISPOSAL', 'Dispose in Local Waste Container', 'in-waste-container-form.html',
                      'IN_LOCAL_WASTE', ctrl.onUseMaterial, false, 3),
    ctrl.buildOption('PRINT', 'Print Label', '', '', ctrl.printLabel, false, 0)
  ];

  ctrl.adminUseOptions = [
    ctrl.buildOption('LOT', 'Update Lot Information', 'update-lot-form.html',
                      '', ctrl.onUseMaterial, false, 1),
    ctrl.buildOption('NEW_VIAL', 'Create New Stock Vial', 'new-vial-form.html',
                      'IN_INVENTORY', ctrl.onUseMaterial, true, 4),
    ctrl.buildOption('CHANGE_LOCATION', 'Change Location', 'change-location-form.html',
                      '', ctrl.onUseMaterial, false, 5),
    ctrl.buildOption('EHS_PICKUP', 'Request EH&S Pickup', '',
                      '', ctrl.onRequestPickup, false, 6),
    ctrl.buildOption('TRANSFER', 'Transfer Material', 'transfer-form.html',
                      '', ctrl.onUseMaterial, false, 7)
  ];

  ctrl.init = function(parent) {
    ctrl.ruaNumber = parent.rua.number;
    ctrl.rua = parent.rua;
    ctrl.ruaId = parent.rua.id;
    ctrl.buttonList = [{label: 'Export', action: ctrl.exportExcel}];
    if (ctrl.hasInventoryAccess()) {
      ctrl.useOptions = ctrl.useOptions.concat(ctrl.adminUseOptions);
    }
    ctrl.getTableData(ctrl.ruaId);
    ctrl.columns = ctrl.defineTable();
  };

}).run(function($templateCache) {
  var useEditTemplate = '<span uib-dropdown dropdown-append-to-body class="edit-link">' +
    '<a href uib-dropdown-toggle class="glyphicon glyphicon-edit"><span class="hideEditText">Print</span></a>' +
    '<ul class="dropdown-menu" uib-dropdown-menu>' +
      '<li ng-repeat="option in grid.appScope.parentScope.useOptions | orderBy : \'order\' track by option.order" ng-if="grid.appScope.parentScope.actionMenuValidation(option.validationReqd, row.entity)" ng-click="option.onClick(option, row.entity)"><a href>{{ option.label }}</a></li>' +
    '</ul>' +
    '</span>';

  $templateCache.put('material-use-edit.html', useEditTemplate);

});
