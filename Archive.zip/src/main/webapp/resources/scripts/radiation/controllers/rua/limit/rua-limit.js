'use strict';

angular.module('app').controller('RuaLimitCtrl', function($location, CURRENT_USER, UaService, UtilService, AmendmentService, PersonService, RadionuclideService, TypesService, StaticCollections, TableHeaderCollections, ConfirmModelService, $scope, InventoryService, PermissionService) {
  var limitCtrl = this;
  limitCtrl.showLimitForm = false;
  limitCtrl.rua = null;
  limitCtrl.materialUnit = 'mCi';
  limitCtrl.isSM_or_SNM = false;
  limitCtrl.isSNM = false;
  limitCtrl.radionuclideInputDisabled = false;
  limitCtrl.licenseList = [];
  limitCtrl.nuclideType = {
    LIMITS: {name: 'LIMITS', text: 'Radioactive Materials', label: 'Limits'},
    SM_SNM_LIMITS: {name: 'SM_SNM_LIMITS', text: 'Source Material and SNM', label: 'SM/SNM Limits'}
  };
  limitCtrl.type = limitCtrl.nuclideType.LIMITS;
  limitCtrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
  limitCtrl.isAdmin = PersonService.isAdmin;
  // initialize ; filling up data
  limitCtrl.init = function(rua, type) {
    limitCtrl.type = limitCtrl.nuclideType[type];
    limitCtrl.rua = rua;
    limitCtrl.uaLimit = {};
    limitCtrl.ruaNumber = limitCtrl.rua.number;
    limitCtrl.currentUser = CURRENT_USER;

    limitCtrl.researchHash = StaticCollections.researchHash;
    limitCtrl.isotopeEnrichmentIds = StaticCollections.isotopeEnrichmentIds;
    limitCtrl.isotopeContainedIds = StaticCollections.isotopeContainedIds;

    TypesService.getAllUsePurposes({campusCode: limitCtrl.currentUser.campus.code}).$promise
      .then(function(response) {
        limitCtrl.usePurposeList = angular.copy(response);
      });

    TypesService.getPhysicalFormsList({}, {}).$promise
      .then(function(response) {
        limitCtrl.physicalFormsList = response;
      });

    TypesService.getEngineeringControlFactors({}, {}).$promise
      .then(function(response) {
        limitCtrl.engControlFactors = angular.copy(response);
      });

    TypesService.getUseFactors({}, {}).$promise
      .then(function(response) {
        limitCtrl.useFactorList = angular.copy(response);
      });

    TypesService.getFormFactors({}, {}).$promise
      .then(function(response) {
        limitCtrl.formFactorList = angular.copy(response);
      });

    limitCtrl.buttonList = PermissionService.hasPermission() ? [{
      label: "Add New Limit",
      action: limitCtrl.onAddNewLimit
    }] : [];

    limitCtrl.getTableHeader();
    limitCtrl.getData(true);
  };

  limitCtrl.getTableHeader = function() {
    if (limitCtrl.type.name === limitCtrl.nuclideType.LIMITS.name) {
      getTableHeaderForRegularNuclides();
    } else if (limitCtrl.type.name === limitCtrl.nuclideType.SM_SNM_LIMITS.name) {
      getTableHeaderForSN_SNM_Nuclides();
    }
  };

  function getTableHeaderForRegularNuclides() {
    limitCtrl.tableHeaders = {
      RADIONUCLIDE: {
        field: 'radionuclide.name',
        displayName: 'Radionuclide'
      },
      CHEMICAL_FORM: {
        field: 'chemicalForm',
        displayName: 'Chemical Form',
        width: 120
      },
      PHYSICAL_FORM: {
        field: 'physicalForm.physicalFormDescription',
        displayName: 'Physical Form',
        width: 120
      },
      EXP_LIMIT: {
        field: 'experimentPossessionLimit',
        displayName: 'mCi/Exp',
        cellFilter: 'scientific'
      },
      VIAL_LIMIT: {
        field: 'vialPossessionLimit',
        displayName: 'mCi/Order',
        cellFilter: 'scientific'
      },
      POSS_LIMIT: {
        field: 'requestedPossessionLimit',
        displayName: 'mCi/Poss',
        cellFilter: 'scientific'
      },
      DATE_ADDED: Object.assign({}, angular.copy(limitCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'dateAdded',
        displayName: 'Date Added',
        width: 100
      }),
      DATE_REMOVED: Object.assign({}, angular.copy(limitCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'dateRemoved',
        displayName: 'Date Removed',
        width: 100
      }),
      USE_PURPOSES: {
        field: 'usePurpose.usePurposeName',
        displayName: 'Use Purpose'
      }
    };

    limitCtrl.tableHeadersWithActionItem = Object.assign(
      {},
      {ACTION: Object.assign({}, angular.copy(limitCtrl.tableHeaderCollections.ACTION))},
      {EDIT: Object.assign({}, limitCtrl.tableHeaderCollections.EDIT, {cellTemplate: "rua-limit-edit.html"})},
      limitCtrl.tableHeaders,
      {
        DELETE: {
          field: 'Delete',
          displayName: '',
          cellTemplate: 'rua-limit-delete.html'
        }
      });

    delete limitCtrl.tableHeadersWithActionItem.DATE_REMOVED;

    if (!limitCtrl.isAmendment()) {
      delete limitCtrl.tableHeadersWithActionItem.ACTION;
    }

    if (!PermissionService.hasPermission()) {
      delete limitCtrl.tableHeadersWithActionItem.EDIT;
      delete limitCtrl.tableHeadersWithActionItem.DELETE;
    }

    limitCtrl.columns = Object.values(limitCtrl.tableHeaders);
    limitCtrl.columnsWithActionItem = Object.values(limitCtrl.tableHeadersWithActionItem);
  }

  function getTableHeaderForSN_SNM_Nuclides() {
    limitCtrl.tableHeaders = Object.assign(
      {},
      {
        RADIONUCLIDE: {
          field: 'radionuclide.name',
          displayName: 'Radionuclide'
        }
      },
      {
        PERCENTAGE_ENRICHMENT: {field: 'enrichment', displayName: '% Enrichment'}
      },
      {
        CHEMICAL_FORM: {
          field: 'chemicalForm',
          displayName: 'Chemical Form'
        }
      },
      {
        PHYSICAL_FORM: {
          field: 'physicalForm.physicalFormDescription',
          displayName: 'Physical Form'
        }
      },
      {
        G_EXP_LIMIT: {field: 'experimentPossessionLimit', displayName: 'net Grams/exp', cellFilter: 'scientific'}
      },
      {
        G_VIAL_LIMIT: {field: 'vialPossessionLimit', displayName: 'net Grams/order', cellFilter: 'scientific'}
      },
      {
        G_POSS_LIMIT: {field: 'requestedPossessionLimit', displayName: 'net Grams/poss', cellFilter: 'scientific'}
      },
      {
        DATE_ADDED: Object.assign({}, angular.copy(limitCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
          field: 'dateAdded',
          displayName: 'Date Added',
          width: 125
        })
      },
      {
        DATE_REMOVED: Object.assign({}, angular.copy(limitCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
          field: 'dateRemoved',
          displayName: 'Date Removed',
          width: 125
        })
      },
      {
        USE_PURPOSES: {
          field: 'usePurpose.usePurposeName',
          displayName: 'Use Purpose'
        }
      }
    );

    limitCtrl.tableHeadersWithActionItem = Object.assign(
      {},
      {ACTION: angular.copy(limitCtrl.tableHeaderCollections.ACTION)},
      {EDIT: Object.assign({}, limitCtrl.tableHeaderCollections.EDIT, {cellTemplate: "rua-limit-edit.html"})},
      limitCtrl.tableHeaders,
      {
        DELETE: {
          field: 'Delete',
          displayName: '',
          cellTemplate: 'rua-limit-delete.html'
        }
      }
    );

    delete limitCtrl.tableHeadersWithActionItem.DATE_REMOVED;

    if (!limitCtrl.isAmendment()) {
      delete limitCtrl.tableHeadersWithActionItem.ACTION;
    }

    if (!PermissionService.hasPermission()) {
      delete limitCtrl.tableHeadersWithActionItem.EDIT;
      delete limitCtrl.tableHeadersWithActionItem.DELETE;
    }

    limitCtrl.columns = Object.values(limitCtrl.tableHeaders);
    limitCtrl.columnsWithActionItem = Object.values(limitCtrl.tableHeadersWithActionItem);
  }

  function isSM_SNM(radionuclide) {
    return radionuclide.isSpecialNuclearMaterial || radionuclide.isSourceMaterial;
  }

  limitCtrl.getData = function(firstCall) {
    UaService.getUaLimitsByUaId({uaId: limitCtrl.rua.id}).$promise
      .then(function(response) {
        limitCtrl.data = response;
        if (limitCtrl.type.name === limitCtrl.nuclideType.LIMITS.name) {
          limitCtrl.dataForNuclides = _.filter(response, function(data) {
            return !isSM_SNM(data.radionuclide) && !!data.active;
          });
          limitCtrl.dataForDeletedNuclides = _.filter(response, function(data) {
            return !isSM_SNM(data.radionuclide) && !data.active;
          });
        } else if (limitCtrl.type.name === limitCtrl.nuclideType.SM_SNM_LIMITS.name) {
          limitCtrl.dataForNuclides = _.filter(response, function(data) {
            return isSM_SNM(data.radionuclide) && !!data.active;
          });

          limitCtrl.dataForDeletedNuclides = _.filter(response, function(data) {
            return isSM_SNM(data.radionuclide) && !data.active;
          });
        }
        if (limitCtrl.isAmendment()) {
          limitCtrl.dataForRegNuclides = _.filter(response, function(data) {
            return !isSM_SNM(data.radionuclide) && !!data.active;
          });
          limitCtrl.dataForSM_SNM_Nuclides = _.filter(response, function(data) {
            return isSM_SNM(data.radionuclide) && !!data.active;
          });
        }

      });

    if (limitCtrl.isAmendment()) {
      UaService.getUAByNumberAndTypeAndStatusType({
        uaNumber: limitCtrl.rua.number,
        uaType: limitCtrl.rua.type,
        uaStatus: UtilService.findAndGet(StaticCollections.uaStatus, 'displayName', 'Active')()
      }, {}).$promise.then(function(ua) {
        UaService.getUaLimitsByUaId({uaId: ua.id}).$promise.then(function(limits) {
          limitCtrl.activeRuaDataForRegNuclides = _.filter(limits, function(data) {
            return !isSM_SNM(data.radionuclide) && !!data.active;
          });
          limitCtrl.activeRuaDataForSnSnm = _.filter(limits, function(data) {
            return isSM_SNM(data.radionuclide) && !!data.active;
          });

          if (limitCtrl.type.name === limitCtrl.nuclideType.LIMITS.name) {
            limitCtrl.dataForNuclides = AmendmentService.compareAndMergeObjects(limitCtrl.activeRuaDataForRegNuclides, limitCtrl.dataForRegNuclides, 'LIMITS_RADIONUCLIDE');

          } else if (limitCtrl.type.name === limitCtrl.nuclideType.SM_SNM_LIMITS.name) {
            limitCtrl.dataForNuclides = AmendmentService.compareAndMergeObjects(limitCtrl.activeRuaDataForSnSnm, limitCtrl.dataForSM_SNM_Nuclides, 'LIMITS_SNM');
          }
        });
      });

      if (!firstCall) {
        UaService.updateSummaryOfChanges({uaId: limitCtrl.rua.id}, {"summaryOfChanges": limitCtrl.type.label})
          .$promise.then(function(res) {
          limitCtrl.rua = res;
          $scope.$parent.$parent.ctrl.init(res);
        });
      }
    }
  };

  limitCtrl.setForm = function(form) {
    limitCtrl.form = form;
  };

  // Radionuclide typeahead behavior
  limitCtrl.getRadionuclidesByName = function(radionuclideName) {
    limitCtrl.licenseList = [];
    return RadionuclideService.getRadionuclidesByName({
      radionuclideName: radionuclideName
    }).$promise
      .then(function(response) {
        if (response.length > 0) {
          if (limitCtrl.type.name === limitCtrl.nuclideType.LIMITS.name) {
            return _.filter(response, function(radionuclide) {
              return !isSM_SNM(radionuclide);
            });
          } else if (limitCtrl.type.name === limitCtrl.nuclideType.SM_SNM_LIMITS.name) {
            return _.filter(response, isSM_SNM);
          }
        } else {
          limitCtrl.noResultsFound = true;
          limitCtrl.licenseList = [];
          return false;
        }
      });
  };

  limitCtrl.selectRadionuclide = function(radionuclide) {
    if (radionuclide && radionuclide.hasOwnProperty('id')) {
      limitCtrl.isSM_or_SNM = (radionuclide.isSourceMaterial || radionuclide.isSpecialNuclearMaterial);
      limitCtrl.isSNM = radionuclide.isSpecialNuclearMaterial;
      limitCtrl.materialUnit = limitCtrl.isSM_or_SNM ? 'g' : 'mCi';
      limitCtrl.enableEnrichment = _.find(limitCtrl.isotopeEnrichmentIds, function(id) {
        return id === limitCtrl.uaLimit.radionuclide.id;
      });
    }
  };

  limitCtrl.getLicense = function(isOnChange) {
    if (limitCtrl.uaLimit.physicalForm && limitCtrl.uaLimit.usePurpose && limitCtrl.uaLimit.radionuclide) {
      TypesService.getLicenseLineNumbers({
        campusCode: limitCtrl.currentUser.campus.code,
        radionuclideId: limitCtrl.uaLimit.radionuclide.id
      })
        .$promise
        .then(function(response) {
          limitCtrl.licenseList = [];
          limitCtrl.licenseList = _.filter(response, function(licenseLineNumber) {
            return (
              licenseLineNumber.isSealedSource === limitCtrl.uaLimit.isSealedSource &&
              licenseLineNumber.usePurposeId === limitCtrl.uaLimit.usePurpose.id &&
              limitCtrl.checkPhysicalForm(licenseLineNumber)
            );
          });
          if (isOnChange && limitCtrl.licenseList.length > 0) {
            limitCtrl.uaLimit.licenseLineNumber = {
              id: limitCtrl.licenseList[0].lineNumberId
            };
            limitCtrl.selectedLicenseLineNumber = limitCtrl.licenseList[0];
          } else {
            limitCtrl.selectedLicenseLineNumber = _.find(limitCtrl.licenseList, function(license) {
              return license.lineNumberId === limitCtrl.uaLimit.licenseLineNumber.id;
            });
          }
          limitCtrl.validateCampusLimit();
        });
    } else {
      limitCtrl.licenseList = [];
    }
  };

  limitCtrl.setFormFactor = function(isSealedSource) {
    limitCtrl.uaLimit.formFactor = isSealedSource ? _.find(limitCtrl.formFactorList, {description: 'Sealed sources'}) : limitCtrl.uaLimit.formFactor = "";
  };

  limitCtrl.checkPhysicalForm = function(licenseLineNumber) {
    if (limitCtrl.uaLimit.physicalForm.physicalFormDescription === 'Solid' && licenseLineNumber.isSolid) {
      return true;
    }
    if (limitCtrl.uaLimit.physicalForm.physicalFormDescription === 'Liquid' && licenseLineNumber.isLiquid) {
      return true;
    }
    if (limitCtrl.uaLimit.physicalForm.physicalFormDescription === 'Gas' && licenseLineNumber.isGas) {
      return true;
    }
    if (limitCtrl.uaLimit.physicalForm.physicalFormDescription === 'Powder' && licenseLineNumber.isPowder) {
      return true;
    }
    if (limitCtrl.uaLimit.physicalForm.physicalFormDescription === 'Any' &&
      licenseLineNumber.isSolid && licenseLineNumber.isLiquid &&
      licenseLineNumber.isGas && licenseLineNumber.isPowder
    ) {
      return true;
    }
    return false;
  };

  limitCtrl.setLicense = function() {
    if (_.find(limitCtrl.licenseList, ['lineNumberId', limitCtrl.uaLimit.licenseLineNumber.id])) {
      limitCtrl.selectedLicenseLineNumber = _.find(limitCtrl.licenseList, ['lineNumberId', limitCtrl.uaLimit.licenseLineNumber.id]);
      limitCtrl.validateCampusLimit();
    }

  };

  limitCtrl.validateRadionuclide = function() {
    if (!limitCtrl.uaLimit.radionuclide) {
      limitCtrl.form.radionuclide.$setValidity('required', false);
      limitCtrl.licenseList = [];
    }
  };

  limitCtrl.validateLicence = function() {
    if (!limitCtrl.selectedLicenseLineNumber) {
      limitCtrl.form.radionuclide.$setValidity('required', false);
    }
  };

  limitCtrl.toggleAddedDate = function($event) {
    $event.stopPropagation();
    $event.preventDefault();
    this.isaddedDateOpen = !this.isaddedDateOpen;
  };

  limitCtrl.toggleRemovedDate = function($event) {
    $event.stopPropagation();
    $event.preventDefault();
    this.isRemovedDateOpen = !this.isRemovedDateOpen;
  };

  limitCtrl.validateExperimentLimit = function() {
    if (limitCtrl.uaLimit.requestedPossessionLimit && limitCtrl.uaLimit.experimentPossessionLimit) {
      if (limitCtrl.uaLimit.experimentPossessionLimit > limitCtrl.uaLimit.requestedPossessionLimit) {
        limitCtrl.form.experimentPossessionLimit.$setValidity('experimentPossessionLimit', false);
      } else {
        limitCtrl.form.experimentPossessionLimit.$setValidity('experimentPossessionLimit', true);
      }
    }
    if (limitCtrl.isSNM && limitCtrl.uaLimit.containedExpLimit) {
      if (limitCtrl.uaLimit.containedExpLimit > limitCtrl.uaLimit.experimentPossessionLimit) {
        limitCtrl.form.containedExpLimit.$setValidity('containedExpGtTotalExp', false);
      } else {
        limitCtrl.form.containedExpLimit.$setValidity('containedExpGtTotalExp', true);
      }
      if (limitCtrl.uaLimit.containedPossLimit) {
        if (limitCtrl.uaLimit.containedPossLimit && limitCtrl.uaLimit.containedExpLimit > limitCtrl.uaLimit.containedPossLimit) {
          limitCtrl.form.containedExpLimit.$setValidity('containedExpGtContainedPoss', false);
        } else {
          limitCtrl.form.containedExpLimit.$setValidity('containedExpGtContainedPoss', true);
        }
      }
    }
  };

  limitCtrl.validateVialLimit = function() {
    if (limitCtrl.uaLimit.requestedPossessionLimit && limitCtrl.uaLimit.vialPossessionLimit) {
      if (limitCtrl.uaLimit.vialPossessionLimit > limitCtrl.uaLimit.requestedPossessionLimit) {
        limitCtrl.form.vialPossessionLimit.$setValidity('vialPossessionLimit', false);
      } else {
        limitCtrl.form.vialPossessionLimit.$setValidity('vialPossessionLimit', true);
      }
    }
    if (limitCtrl.isSNM && limitCtrl.uaLimit.containedVialLimit) {
      if (limitCtrl.uaLimit.containedVialLimit > limitCtrl.uaLimit.vialPossessionLimit) {
        limitCtrl.form.containedVialLimit.$setValidity('containedVialGtTotalVial', false);
      } else {
        limitCtrl.form.containedVialLimit.$setValidity('containedVialGtTotalVial', true);
      }
      if (limitCtrl.uaLimit.containedPossLimit) {
        if (limitCtrl.uaLimit.containedVialLimit > limitCtrl.uaLimit.containedPossLimit) {
          limitCtrl.form.containedVialLimit.$setValidity('containedVialGtContainedPoss', false);
        } else {
          limitCtrl.form.containedVialLimit.$setValidity('containedVialGtContainedPoss', true);
        }
      }
    }
  };

  limitCtrl.validatePossessionLimit = function() {
    if (limitCtrl.isSNM && !limitCtrl.checkUraniumRadionuclideWithEnrichment()) {
      if (limitCtrl.uaLimit.containedPossLimit && limitCtrl.uaLimit.containedPossLimit > limitCtrl.uaLimit.requestedPossessionLimit) {
        limitCtrl.form.containedPossLimit.$setValidity('containedPossGtTotalPoss', false);
      } else {
        limitCtrl.form.containedPossLimit.$setValidity('containedPossGtTotalPoss', true);
      }
    }
    limitCtrl.validateVialLimit();
    limitCtrl.validateExperimentLimit();
    if (limitCtrl.isAmendment() && limitCtrl.rua.createdFrom && limitCtrl.uaLimit.createdFrom) {
      limitCtrl.validateRadionuclidePossessionAmount(limitCtrl.rua.createdFrom, limitCtrl.uaLimit.createdFrom);
    } else if (limitCtrl.uaLimit.id) {
      limitCtrl.validateRadionuclidePossessionAmount(limitCtrl.rua.id, limitCtrl.uaLimit.id);
    }
  };

  limitCtrl.checkUraniumRadionuclideWithEnrichment = function() {
   return limitCtrl.uaLimit.radionuclide.name === 'U-233' || limitCtrl.uaLimit.radionuclide.name === 'U-235';
  };

  limitCtrl.validateCampusLimit = function() {
    if (limitCtrl.uaLimit.enrichment && limitCtrl.uaLimit.requestedPossessionLimit) {
    limitCtrl.uaLimit.containedPossLimit = limitCtrl.uaLimit.requestedPossessionLimit * limitCtrl.uaLimit.enrichment / 100;
    }
    if (limitCtrl.selectedLicenseLineNumber) {
      UaService.getPossessionLimitsByLicense({lineNumberId: limitCtrl.selectedLicenseLineNumber.lineNumberId})
        .$promise
        .then(function(response) {
          var currentCampusPossession = response.totalCampusPossession
            ? (limitCtrl.uaLimit.id
              ? response.totalCampusPossession - limitCtrl.oldPossession + limitCtrl.uaLimit.requestedPossessionLimit
              : response.totalCampusPossession + limitCtrl.uaLimit.requestedPossessionLimit)
            : (limitCtrl.uaLimit.requestedPossessionLimit);
          var currentCampusContained = response.totalCampusContainedPossession
            ? (limitCtrl.uaLimit.id && limitCtrl.uaLimit.containedPossLimit
              ? response.totalCampusContainedPossession - limitCtrl.oldContained + limitCtrl.uaLimit.containedPossLimit
              : response.totalCampusContainedPossession + limitCtrl.uaLimit.containedPossLimit)
            : (limitCtrl.uaLimit.containedPossLimit);
          var limitIds = response.limitIds ? response.limitIds : [];

          currentCampusPossession = UtilService.convertToCampusLimitUnit(limitCtrl.selectedLicenseLineNumber.campusLimitUnit, currentCampusPossession);

          if (limitCtrl.selectedLicenseLineNumber.maxItems) {
            if (limitIds.length > 0 && limitIds.length >= limitCtrl.selectedLicenseLineNumber.maxItems && !limitCtrl.uaLimit.id) {
              limitCtrl.form[limitCtrl.selectedLicenseLineNumber.lineNumberId].$setValidity('exceededCampusMaxSources', false);
            } else {
              limitCtrl.form[limitCtrl.selectedLicenseLineNumber.lineNumberId].$setValidity('exceededCampusMaxSources', true);
            }
          }

          if (limitCtrl.selectedLicenseLineNumber.elementalLimit) {
            var reqEmementalLimit = limitCtrl.uaLimit.requestedPossessionLimit;
            if (limitCtrl.selectedLicenseLineNumber.elementalLimitUnit !== 'mCi' || limitCtrl.selectedLicenseLineNumber.elementalLimitUnit !== 'g') {
              reqEmementalLimit = UtilService.convertToCampusLimitUnit(limitCtrl.selectedLicenseLineNumber.elementalLimitUnit, limitCtrl.uaLimit.requestedPossessionLimit);
            }
            if (reqEmementalLimit > limitCtrl.selectedLicenseLineNumber.elementalLimit) {
              limitCtrl.form.requestedPossessionLimit.$setValidity('requestedPossGtCampusSSLimit', false);
            } else {
              limitCtrl.form.requestedPossessionLimit.$setValidity('requestedPossGtCampusSSLimit', true);
            }
          }

          if (currentCampusPossession > limitCtrl.selectedLicenseLineNumber.campusLimit) {
            limitCtrl.form.requestedPossessionLimit.$setValidity('requestedPossGtCampusLimit', false);
          } else {
            limitCtrl.form.requestedPossessionLimit.$setValidity('requestedPossGtCampusLimit', true);
          }
          if (limitCtrl.isSNM && !limitCtrl.checkUraniumRadionuclideWithEnrichment()) {
            if (currentCampusContained > limitCtrl.selectedLicenseLineNumber.campusContainedLimit) {
              limitCtrl.form.containedPossLimit.$setValidity('containedPossGtCampusLimit', false);
            } else {
              limitCtrl.form.containedPossLimit.$setValidity('containedPossGtCampusLimit', true);
            }
          }
        });
    }
  };

  limitCtrl.validateForm = function() {
    if (limitCtrl.uaLimit.isSealedSource) {
      return true;
    } else if (!limitCtrl.uaLimit.isSealedSource &&
      limitCtrl.uaLimit.experimentPossessionLimit &&
      limitCtrl.uaLimit.vialPossessionLimit) {
      return true;
    } else {
      return false;
    }
  };

  limitCtrl.onSave = function() {
    limitCtrl.validatePossessionLimit();
    limitCtrl.validateCampusLimit();
    limitCtrl.validateForm();
    limitCtrl.validateLicence();

    if (limitCtrl.form.$invalid) {
      angular.forEach(limitCtrl.form.$error, function(controls, errorName) {
        angular.forEach(controls, function(control) {
          control.$setDirty();
          control.$setTouched();
        });
      });
    }

    if (limitCtrl.form.$valid) {
      limitCtrl.uaLimit.uaId = limitCtrl.rua.id;
      limitCtrl.uaLimit.enteredBy = limitCtrl.uaLimit.enteredBy || limitCtrl.currentUser;

      UaService.addUaLimit({uaId: limitCtrl.uaLimit.uaId}, limitCtrl.uaLimit).$promise
        .then(function(response) {
          limitCtrl.uaLimit.id = response.id;
          limitCtrl.getData();
          limitCtrl.showLimitForm = false;
        });
    }
  };

  limitCtrl.cancelAdd = function() {
    limitCtrl.uaLimit = {};
    limitCtrl.getData();
    limitCtrl.showLimitForm = false;
  };

  limitCtrl.onAddNewLimit = function() {
    limitCtrl.activeUaLimit = limitCtrl.uaLimit = {};
    limitCtrl.radionuclideInputDisabled = false;
    limitCtrl.showLimitForm = true;
    limitCtrl.isSM_or_SNM = false;
    limitCtrl.isSNM = false;
    limitCtrl.selectedLicenseLineNumber = {};
    limitCtrl.licenseList = [];
    limitCtrl.oldPossession = 0;
    limitCtrl.oldContained = 0;

    /* assigned default value */
    limitCtrl.uaLimit.isSealedSource = false;
    limitCtrl.uaLimit.dateAdded = limitCtrl.uaLimit.dateAdded || Date.now();
    limitCtrl.uaLimit.enteredDate = limitCtrl.uaLimit.enteredDate || Date.now();
    limitCtrl.uaLimit.enteredBy = limitCtrl.uaLimit.enteredBy || limitCtrl.currentUser;
  };

  limitCtrl.onEditLimit = function(ruaId, limitId) {
    InventoryService.isMaterialInUse({limitId: limitId}).$promise.then(function(response) {
      if (response.inUse) { limitCtrl.radionuclideInputDisabled = response.inUse; }
    });
    limitCtrl.uaLimit = _.find(limitCtrl.data, {id: limitId});
    limitCtrl.activeUaLimit = _.find(limitCtrl.activeRuaDataForRegNuclides, {id: limitCtrl.uaLimit.createdFrom});
    limitCtrl.getLicense(false);
    limitCtrl.uaLimit.isSealedSource = !!limitCtrl.uaLimit.isSealedSource;
    limitCtrl.uaLimit.enteredDate = limitCtrl.uaLimit.enteredDate || Date.now();
    limitCtrl.uaLimit.enteredBy = limitCtrl.uaLimit.enteredBy || limitCtrl.currentUser;

    limitCtrl.oldPossession = angular.copy(limitCtrl.uaLimit.requestedPossessionLimit);
    limitCtrl.oldContained = angular.copy(limitCtrl.uaLimit.containedPossLimit);

    limitCtrl.selectRadionuclide(limitCtrl.uaLimit.radionuclide);
    limitCtrl.showLimitForm = true;
  };

  limitCtrl.onDeleteLimit = function(ruaId, limitId) {
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE, {message: "Are you sure you want to delete the limit record?"}, function() {
        UaService.deleteUaLimit({uaId: ruaId, limitId: limitId}).$promise
          .then(function(response) {
            if (!response.deleted) {
              var limit = _.find(limitCtrl.data, {id: limitId});
              ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE,
                {
                  autoClose: true,
                  header: "Unable to remove Limit",
                  message: "Limit can not be adjusted or deleted until all " + limit.radionuclide.name + " has been removed from the inventory."
                }
              );
            }
            limitCtrl.getData();
          });
      });
  };

  limitCtrl.isAmendment = function() {
    return UaService.isAmendment(limitCtrl.rua);
  };

  limitCtrl.validateRadionuclidePossessionAmount = function(uaId, limitId) {
    InventoryService.calculateRadionuclidePossessionAmount({
      uaId: uaId,
      uaLimitId: limitId
    }).$promise.then(function(result) {
      limitCtrl.radionuclidePossessionAmount = result.radionuclidePossessionAmount;
      if (limitCtrl.uaLimit.requestedPossessionLimit < result.radionuclidePossessionAmount) {
        limitCtrl.form.requestedPossessionLimit.$setValidity('requestedPossLtCurrentPossAmount', false);
      } else {
        limitCtrl.form.requestedPossessionLimit.$setValidity('requestedPossLtCurrentPossAmount', true);
      }
    });
  };

  limitCtrl.checkEditPermissions = function(row) {
    return row.entity.$$action !== 'DELETED'
            && PermissionService.hasPermission();
  };

})
  .run(function($templateCache) {
    var limitEditTemplate = '<div class="edit-link" ng-if="grid.appScope.parentScope.checkEditPermissions(row)">'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.onEditLimit(grid.appScope.parentScope.rua.id, row.entity.id)" class="glyphicon glyphicon-edit" title="Edit Limit"></a></span>'
      + '</div>';
    $templateCache.put('rua-limit-edit.html', limitEditTemplate);

    var limitDeleteTemplate = '<div class="delete-link" ng-if="grid.appScope.parentScope.checkEditPermissions(row)">'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.onDeleteLimit(grid.appScope.parentScope.rua.id, row.entity.id)" class="glyphicon glyphicon-trash text-danger" title="Delete Limit"></a></span>'
      + '</div>';
    $templateCache.put('rua-limit-delete.html', limitDeleteTemplate);
  });
