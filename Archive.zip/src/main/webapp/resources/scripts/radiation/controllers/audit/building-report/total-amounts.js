'use strict';
angular.module('app').controller('TotalAmountsTab', function($q, AuditService, UtilService) {


  var totalAmountsCtrl = this;
  totalAmountsCtrl.totalAmountsData;


  totalAmountsCtrl.init = function() {
    var postParam = UtilService.searchDefaults;
    AuditService.totalAmountsReport({}, postParam)
    .$promise
    .then(function(res) {
      totalAmountsCtrl.totalAmountsData = _.filter(res, function(row) {
        if (!(_.isEmpty(row))) {
           return true;
        }
      });
    });
    totalAmountsCtrl.getTableHeader();
  };


  totalAmountsCtrl.getTableHeader = function() {
      totalAmountsCtrl.tableHeaders = {
      BUILDING: {
        field: 'buildingName',
        displayName: 'Building'
      },
      ROOM: {
        field: 'roomNumber',
        displayName: 'Room'
      },
      RUA: {
        field: 'ruaNumbers',
        displayName: 'RUA #s'
      },
      RADIONUCLIDE_NAME: {
        field: 'radionuclideName',
        displayName: 'Radionuclide'
      },
      RADIOACTIVE_MATERIAL_TOTAL: {
        field: 'totalRadioactiveMaterial',
        displayName: 'Radioactive Material Total (mCi)',
        cellFilter: 'scientific'
      },
      SEALED_SOURCE_TOTAL: {
       field: 'totalSealedSource',
       displayName: 'Sealed Source Total (mCi)',
        cellFilter: 'scientific'
      }

      };
      totalAmountsCtrl.columns = Object.values(totalAmountsCtrl.tableHeaders);
  };

});
