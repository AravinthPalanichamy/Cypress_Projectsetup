'use strict';

angular.module('app').controller('InventorySearchCtrl', function(uiGridConstants, InventoryService, ExcelService, TypesService, TableHeaderCollections, page, $filter) {
  var ctrl = this;

  ctrl.totalCount = page.totalCount;
  ctrl.data = page.data;
  ctrl.download = ExcelService.inventoryExcel;
  ctrl.fileName = "Inventory";

  ctrl.init = function() {
    TypesService.getInventoryStatusTypes().$promise.then(function(statusTypes) {
      ctrl.mapToFilter(statusTypes);
      ctrl.columns = ctrl.defineTable();
    });
  };

  ctrl.mapToFilter = function(statusTypes) {
    var sTypes = _.map(statusTypes, function(statusType) {
      return { value: statusType, label: $filter('camelcase')(statusType) };
    });

    ctrl.statusFilter = {
      type: 'multi-select',
      term: '',
      options: _.concat([{ value: 'all', label: 'ALL', selected: true }], sTypes),
      aggregator: 'or',
      disableCancelFilterButton: true
    };
  };

  ctrl.isSealedSource = function(material) {
    return _.some(material.materialRadionuclides, function(materialRadionuclide) {
      return materialRadionuclide.uaLimit.isSealedSource;
    });
  };

  ctrl.defineTable = function() {
    var edit = _.cloneDeep(TableHeaderCollections.EDIT);
    edit.field = 'edit';
    edit.cellTemplate = '<div class="edit-link"><span><a href="#/materials/search/edit/{{ row.entity.id }}" class="glyphicon glyphicon-edit"><span class="sr-only">Edit</span></a></span></div>';

    var initialDate = _.cloneDeep(TableHeaderCollections.DATE_RANGE_SHORT);
    initialDate.field = 'initialDate';
    initialDate.displayName = 'Reference Date (mm/dd/yyyy)';

    var ssFilter = {
      ariaLabel: 'On Active RUA',
      type: uiGridConstants.filter.SELECT,
      condition: uiGridConstants.filter.EXACT,
      term: '',
      selectOptions: [
        { value: '', label: 'All' },
        { value: true, label: 'Yes' },
        { value: false, label: 'No' }
      ]
    };

    return [
      edit,
      { displayName: 'Material #', field: 'id', width: 75 },
      { displayName: 'Tracking #', field: 'wasteTag.trackingNumber', width: 75 },
      { displayName: 'RUA', field: 'ua.number', width: 100 },
      { displayName: 'PI First', field: 'ua.pi.firstName' },
      { displayName: 'PI Last', field: 'ua.pi.lastName' },
      { displayName: 'Location', field: 'storageLocation.buildingDisplayName', cellTemplate: '<div ng-if="row.entity.storageLocation" class="ui-grid-cell-contents">{{ row.entity.storageLocation.buildingDisplayName }} - {{ row.entity.storageLocation.roomNumber}} <span ng-if = "row.entity.subLocation">: {{row.entity.subLocation}}</span></div>' },
      { displayName: 'Radionculdies', field: 'radionuclideNameString', filters: [{filterType: 'TRANSIENT'}] },
      { displayName: 'Sealed Source', field: 'isSealedSource', cellTemplate: '<div class="yes-no-icon"> <span  ng-if="grid.appScope.parentScope.isSealedSource(row.entity)" class="glyphicon glyphicon-ok"></span></div>', width: 75, filter: ssFilter, filters: [{filterType: 'TRANSIENT'}] },
      { displayName: 'Chemical Form', field: 'chemicalForm' },
      { displayName: 'Physical Form', field: 'physicalForm', filters: [{filterType: 'TRANSIENT'}] },
      initialDate,
      { displayName: 'Initial Amount', field: 'requestedAmount', filters: [{filterType: 'TRANSIENT'}] },
      { displayName: 'Current Amount', field: 'currentAmount', filters: [{filterType: 'TRANSIENT'}] },
      { displayName: 'Status', field: 'inventoryStatusType', filterHeaderTemplate: '<div class="ui-grid-filter-container"><multi-select class="multi-select"></multi-select></div>', filter: ctrl.statusFilter, cellFilter: 'camelcase' }
    ];
  };

  ctrl.getState = function(state) {
    var filter = _.find(state.filter, {'filterColumn': 'storageLocation.buildingDisplayName'});
    if (filter) {
      filter['filterColumn'] = ['storageLocation.buildingDisplayName', 'storageLocation.roomNumber', 'subLocation'];
      filter.multipleTerms = true;
    }
    return InventoryService.searchMaterials({}, state).$promise;
  };

  ctrl.init();
});
