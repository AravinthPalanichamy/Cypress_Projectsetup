'use strict';

angular.module('app').controller('PackageCtrl', function($location, ConfirmModelService, LabelService, PrintService, FileSaver, InventoryService, StaticCollections, UaService, inspectors, materialPackage, packageTypes, packageVendors, profile) {
  var ctrl = this;

  ctrl.currentUser = profile;
  ctrl.inspectors = _.uniqBy(inspectors, 'userId');
  ctrl.packageTypes = packageTypes;
  ctrl.packageVendors = packageVendors;
  ctrl.pendingRequests = undefined;
  ctrl.package = materialPackage;
  ctrl.isEdit = !!materialPackage.id;
  ctrl.textLimit = 100;
  ctrl.panels = {
    GENERAL: 'General'
  };

  ctrl.init = function() {
    if (ctrl.package.id) {
      ctrl.selectUa(ctrl.package.ua);
      ctrl.package.packageType = _.find(ctrl.packageTypes, {'id': ctrl.package.packageType.id});
      ctrl.package.checkedBy = ctrl.findInspector();
      ctrl.panels.CHANGELOG = 'Changelog';
    }

    UaService.getUaListByStatusAndTypeAndCampusCode({
      uaStatus: StaticCollections.getKeyByValue(StaticCollections.uaStatusHash, "Active"),
      uaType: StaticCollections.getKeyByValue(StaticCollections.uaTypeHash, "Radioactive Materials"),
      campusCode: ctrl.currentUser.campus.code
    }, {}).$promise.then(function(response) {
      ctrl.useAuthorizations = response;
    });

    ctrl.setPanel(ctrl.panels[$location.search().activePackageTab] || ctrl.panels.GENERAL);
  };

  ctrl.initPackage = function(ua) {
    ctrl.package.ua = ua;
    if (!ctrl.isEdit) {
      ctrl.package.materials = [];
      ctrl.package.hasExteriorSurvey = true;
      ctrl.package.hasExteriorSwipeContaminationFree = true;
      ctrl.package.hasPrimarySurvey = true;
      ctrl.package.hasPrimarySwipeContaminationFree = true;
      ctrl.package.isDryIceOk = true;
      ctrl.package.dateReceived = moment().toDate();
    }
  };

  ctrl.setPanel = function(panel) {
    ctrl.panel = panel;
    $location.search("activePackageTab", panel.toUpperCase());
  };

  ctrl.typeaheadLabel = function(ua, value) {
    if (ua && typeof ua !== 'string') {
      var radionuclides = value ? radionuclidesFilter(ua, value) : [];
      var piFirstName = ua.pi ? ua.pi.firstName : ua.piFirstName;
      var piLastName = ua.pi ? ua.pi.lastName : ua.piLastName;
      var label = 'RUA # ' + ua.number + ' ( ' + piLastName + ', ' + piFirstName + ' )';
      label = radionuclides.length > 0 ? label.concat(' ( ' + radionuclides.join(' / ') + ' )') : label;
      return label;
    }
    return ua;
  };

  function radionuclidesFilter(ua, value) {
    return ua.radionuclides.filter(function(isotope) {
      return value.split(' ').some(function(input) {
        return isotope.toLowerCase().indexOf(input.toLowerCase()) !== -1;
      });
    });
  }

  ctrl.selectUa = function(ua) {
    ctrl.initPackage(ua);
    InventoryService.getMaterialsForPackage({ uaId: ua.id, packageId: ctrl.package.id || null }).$promise.then(function(response) {
      ctrl.pendingRequests = response;
    });
  };

  ctrl.selectVendor = function(packageVendor) {
    ctrl.package.packageVendor = packageVendor;
    ctrl.invalidVendor = false;
  };

  ctrl.validateVendor = function(vendor) {
    ctrl.invalidVendor = vendor ? !_.some(ctrl.packageVendors, {'id': vendor.id}) : true;
  };

  ctrl.findMaterialIndexInPackage = function(material) {
    return _.findIndex(ctrl.package.materials, function(packageMaterial) {
      return material.id === packageMaterial.id;
    });
  };

  ctrl.updatePackageMaterials = function(material) {
    var index = ctrl.findMaterialIndexInPackage(material);
    if (index > -1) {
      ctrl.package.materials.splice(index, 1);
    } else {
      ctrl.package.materials.push(material);
    }
  };

  ctrl.validatePackageNumber = function(packageNumber) {
    if (packageNumber) {
      InventoryService.findPackageByPackageNumberAndDate({packageNumber: packageNumber}).$promise.then(function(response) {
        ctrl.invalidPackageNumber = !!response.id;
      });
    }
  };

  ctrl.viewLabel = function(material) {
    LabelService.displayLabel([
      {label: 'EH&S Material #', value: material.id},
      {label: 'Radionuclide(s)', value: material.radionuclideNameString},
      {label: 'Initial Amount', value: material.requestedAmount},
      {label: 'Lot #', value: material.lotNumber},
      {label: 'Reference Date', value: (material.initialDate === null) ? '' : moment(material.initialDate).format('MM/DD/YYYY')}
    ]);
  };

  ctrl.savePackage = function(form) {
    ctrl.package.materials.forEach(function(packageMaterial) {
      var request = _.find(ctrl.pendingRequests, function(request) {
        return request.id === packageMaterial.id;
      });
      if (request) {
        packageMaterial.isMaterialForTest = request.isMaterialForTest;
      }
    });

    if (ctrl.package.materials.length > 0 && form.$valid && !ctrl.invalidPackageNumber) {
      InventoryService.savePackage({}, ctrl.package).$promise.then(function(materialPackage) {
        ctrl.package = materialPackage;
        ctrl.package.checkedBy = ctrl.findInspector();
        ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS, {message: 'Package number ' + ctrl.package.packageNumber + ' successfully saved'}, null, function() {
          $location.path('/materials/package-edit/' + ctrl.package.id);
        });
      });
    } else {
      form.$invalid = true;
    }
  };

  ctrl.printTransferForm = function() {
    PrintService.printPackages({}, [ctrl.package.id]).$promise.then(function(results) {
      FileSaver.saveAs(results.file, results.file.name);
    });
  };

  ctrl.findInspector = function() {
    return _.find(ctrl.inspectors, {'id': ctrl.package.checkedBy.id});
  };

  ctrl.init();

});
