'use strict';

angular.module('app').controller('InventoryInstitutionTransferCtrl', function(ConfirmModelService, InventoryService, TableHeaderCollections, StaticCollections, materialTransfers) {
  var ctrl = this;

  ctrl.init = function() {
    ctrl.data = materialTransfers;
    ctrl.useOptions = StaticCollections.materialTransferUseOptions;
    ctrl.columns = ctrl.defineTable();
  };

  ctrl.defineTable = function() {
    var useTemplate = '<span uib-dropdown dropdown-append-to-body class="edit-link">' +
                          '<a href uib-dropdown-toggle class="glyphicon glyphicon-edit"><span class="hideEditText">Use Material Transfer</span></a>' +
                          '<ul class="dropdown-menu" uib-dropdown-menu>' +
                          '   <li ng-repeat="useOption in grid.appScope.parentScope.useOptions" ng-click="grid.appScope.parentScope.updateTransferStatus(row.entity, useOption)"><a href>{{ useOption.label }}</a></li>' +
                          '</ul>' +
                          '</span>';

    var referenceDate = _.cloneDeep(TableHeaderCollections.DATE_RANGE_SHORT);
    referenceDate.field = 'material.initialDate';
    referenceDate.width = 150;
    referenceDate.displayName = 'Reference Date (mm/dd/yyyy)';
    referenceDate.enableFiltering = false;

    return [
      {displayName: 'Use', field: 'edit', width: 50, cellTemplate: useTemplate, enableSorting: false},
      {displayName: 'Material #', field: 'material.id', width: 100},
      {displayName: 'Radionuclide', field: 'material.radionuclideNameString'},
      {displayName: 'Chemical Form', field: 'material.chemicalForm'},
      {displayName: 'Initial Amount (mCi)', field: 'material.requestedAmount'},
      {displayName: 'Current Activity (mCi)', field: 'material.currentAmount'},
      {displayName: 'Initial Volume', headerCellTemplate: '<div class="ui-grid-cell-contents ui-grid-header-cell-label">Initial Volume(&micro;l)</div>', field: 'material.requestedVolume'},
      {displayName: 'Current Volume', headerCellTemplate: '<div class="ui-grid-cell-contents ui-grid-header-cell-label">Current Volume(&micro;l)</div>', field: 'material.currentVolume'},
      {displayName: 'Initial Mass (grams)', field: 'material.requestedElementalMass'},
      {displayName: 'Current Mass (grams)', field: 'material.currentElementalMass'},
      {displayName: 'Initial Net Mass (grams)', field: 'material.requestedNetMass'},
      {displayName: 'Current Net Mass (grams)', field: 'material.currentNetMass'},
      referenceDate,
      {displayName: 'From RUA', field: 'fromUa.number'},
      {
        displayName: 'Location',
        field: 'material.storageLocation.buildingDisplayName',
        cellTemplate: '<div class="ui-grid-cell-contents">{{ row.entity.material.storageLocation.buildingPrimaryName }} - {{row.entity.material.storageLocation.roomNumber}} {{ row.entity.material.subLocation ? " (" + row.entity.material.subLocation + ")" : "" }}</div>'
      },
      {displayName: 'Institution Name', field: 'institutionName'}
    ];
  };

  ctrl.updateTransferStatus = function(materialTransfer, useOption) {
    ConfirmModelService.confirm(ConfirmModelService.ConfirmType.CONFIRM, { message: 'Are you sure you want to ' + useOption.label.toLowerCase() + ' for material ' + materialTransfer.material.id + ' to ' + materialTransfer.institutionName }, function() {
      InventoryService.completeTransfer({ materialTransferId: materialTransfer.id, status: useOption.value }, {}).$promise.then(function() {
        ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS, { message: 'Transfer for material ' + materialTransfer.material.id + ' to ' + materialTransfer.institutionName + ' has been ' + useOption.confirmValue + '.' });
        InventoryService.getMaterialTransfersToInstitutionByStatus({ status: 'PENDING' }).$promise.then(function(results) {
          ctrl.data = results;
        });
      });
    });
  };

  ctrl.init();
});
