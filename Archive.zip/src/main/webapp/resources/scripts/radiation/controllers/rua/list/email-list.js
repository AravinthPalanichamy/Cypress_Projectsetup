'use strict';

angular.module('app').controller('RuaEmailListCtrl', function($rootScope) {
  var ctrl = this;

  ctrl.queryStates = [];
  ctrl.init = function() {
    ctrl.formatUaEmailList();
  };

  ctrl.formatUaEmailList = function() {

    ctrl.uaEmailList = $rootScope.uaEmailList;
    ctrl.labPis = _(ctrl.uaEmailList)
      .uniqBy('piEmail')
      .map(function(pi) {
        return {name: pi.piFirstName + ' ' + pi.piLastName, email: pi.piEmail};
      })
      .sortBy('name')
      .value();

    ctrl.labContacts = _(ctrl.uaEmailList)
      .filter(function(contact) {
        return contact.isDelegate;
      })
      .uniqBy('memberEmail')
      .map(function(contact) {
        return {name: contact.memberFirstName + ' ' + contact.memberLastName, email: contact.memberEmail};
      })
      .sortBy('name')
      .value();

    ctrl.labPiAndContacts = _(ctrl.labPis)
      .concat(ctrl.labContacts)
      .uniqBy('name')
      .sortBy('name')
      .value();
  };

  ctrl.generateExcel = function(elem, groupType) {
    var currentDate = moment().format('M-D-YYYY');
    ctrl.reportName = "RUA " + groupType + "_" + currentDate;
    var header = '<meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">';
    var blob = new Blob([header + document.getElementById(elem).innerHTML], {
      type: "data:application/vnd.ms-excel;charset=UTF-8"
    });
    saveAs(blob, ctrl.reportName + ".xls");
  };

});
