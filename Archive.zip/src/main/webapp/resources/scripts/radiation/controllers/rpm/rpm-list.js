'use strict';

angular.module('app').controller('RpmListCtrl', function(RpmService, RpmFormService, StaticCollections, UaService, TableHeaderCollections, UtilService, PermissionService, PersonService) {
  var ctrl = this;

  ctrl.tableHeaderCollections = angular.copy(TableHeaderCollections);

  ctrl.init = function() {
    ctrl.buttonList = [];
    ctrl.isAdmin = PersonService.isAdmin;
    ctrl.getTableHeader();
    ctrl.getData();

    if (ctrl.isAdmin) {
      ctrl.buttonList.push({
        label: "Add New RPM",
        action: ctrl.onAddNewRpm
      });
    }
  };

  ctrl.getData = function() {
    RpmService.getAllByCampus().$promise
      .then(function(response) {
        ctrl.data = angular.copy(response);
        ctrl.data.forEach(function(item) {
          if (item.location) {
            item.location.$display = item.location.buildingDisplayName + ' - ' + item.location.roomNumber;
          }
        });
      });
  };

  ctrl.onAddNewRpm = function() {
    RpmFormService.makeForm(ctrl.rua, ctrl.rpm, {'isAdmin': ctrl.isAdmin}, ctrl.save);
  };

  ctrl.onEditRpm = function(rpmId) {
    ctrl.editedRpmId = rpmId;
    ctrl.rpm = _.clone(_.find(ctrl.data, {id: rpmId}), true);
    ctrl.rpm.numberOfTubes = (ctrl.rpm && ctrl.rpm.numberOfTubes) ? JSON.stringify(ctrl.rpm.numberOfTubes) : '';
    UaService.getUaDetail({uaId: ctrl.rpm.ua.id})
      .$promise
      .then(function(ua) {
        ctrl.rua = ua;
        RpmFormService.makeForm(ctrl.rua, ctrl.rpm, {}, ctrl.save);
      });
  };

  ctrl.save = function(refreshParent) {
    if (refreshParent) {
      ctrl.getData();
    }
  };

  ctrl.getTableHeader = function() {
    ctrl.tableHeaders = {
      EDIT: Object.assign({}, ctrl.tableHeaderCollections.EDIT, {cellTemplate: "rua-rpm-edit.html"}),
      MACHINE_USE_LOCATION: Object.assign({}, ctrl.tableHeaderCollections.MACHINE_USE_LOCATION, {field: "location.$display"}),
      MACHINE_ID: ctrl.tableHeaderCollections.MACHINE_ID,
      DPH_NUMBER: ctrl.tableHeaderCollections.DPH_NUMBER,
      MACHINE_TYPE: ctrl.tableHeaderCollections.MACHINE_TYPE,
      MACHINE_MANUFACTURER: ctrl.tableHeaderCollections.MACHINE_MANUFACTURER,
      MACHINE_MODEL: ctrl.tableHeaderCollections.MACHINE_MODEL,
      MAX_CURRENT: ctrl.tableHeaderCollections.MAX_CURRENT,
      MAX_VOLTAGE: ctrl.tableHeaderCollections.MAX_VOLTAGE,
      NORMAL_CURRENT: ctrl.tableHeaderCollections.NORMAL_CURRENT,
      MACHINE_USE_CODE: ctrl.tableHeaderCollections.MACHINE_USE_CODE,
      HAZARD_CLASS: Object.assign({}, ctrl.tableHeaderCollections.CLASS, ctrl.tableHeaderCollections.HAZARD_CLASS),
      ON_LICENSE: Object.assign({}, ctrl.tableHeaderCollections.LBL, {
        field: 'onLicense',
        displayName: 'On License?',
        cellTemplate: '<div class="yes-no-icon"><span  ng-if="row.entity.onLicense" class="glyphicon glyphicon-ok" ></span></div>'
      }),
      RUA_NUMBER: ctrl.tableHeaderCollections.RUA_NUMBER
    };
    ctrl.columns = Object.values(ctrl.tableHeaders);
  };

  ctrl.checkEditPermissions = function(row) {
    return row.entity.id
            && row.entity.$$action !== 'DELETED'
            && ctrl.isAdmin;
  };

})
  .run(function($templateCache) {
    var rpmEditTemplate = '<div class="edit-link">'
      + ' <span ng-if="!grid.appScope.parentScope.checkEditPermissions(row)"><a ng-href="" ng-click="grid.appScope.parentScope.onEditRpm(row.entity.id)" class="glyphicon glyphicon-eye-open" title="View RPM"><span class="hideEditText">Edit</span></a></span>'
      + ' <span ng-if="grid.appScope.parentScope.checkEditPermissions(row)"><a ng-href="" ng-click="grid.appScope.parentScope.onEditRpm(row.entity.id)" class="glyphicon glyphicon-edit" title="Edit RPM"></a></span>'
      + '</div>';
    $templateCache.put('rua-rpm-edit.html', rpmEditTemplate);
  });
