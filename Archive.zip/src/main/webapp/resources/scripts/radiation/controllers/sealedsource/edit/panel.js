'use strict';

angular.module('app').controller('PanelCtrl', function($location, material) {
  var ctrl = this;

  ctrl.panels = {
    GENERAL: 'General',
    LEAK_TEST: 'Leak Test',
    MATERIAL_HIERARCHY: 'Material Hierarchy',
    DOCUMENTS: 'Documents',
    CHANGELOG: 'Changelog'
  };

  ctrl.init = function() {
    ctrl.material = material;
    ctrl.isSealedSource = ctrl.material.isMaterialForTest || _.some(ctrl.material.materialRadionuclides, ['uaLimit.isSealedSource', true]);
    ctrl.setPanel(ctrl.panels[$location.search().activeSealedSourceTab] || ctrl.panels.GENERAL.toUpperCase());
  };

  ctrl.setPanel = function(panel) {
    ctrl.panel = panel.replace(/\s/g, '_').toUpperCase();
    $location.search("activeSealedSourceTab", ctrl.panel).replace();
  };

  ctrl.getPanelValue = function(panel) {
    return panel ? panel.replace(/\s/g, '_').toUpperCase() : ctrl.panels.GENERAL.toUpperCase();
  };
});
