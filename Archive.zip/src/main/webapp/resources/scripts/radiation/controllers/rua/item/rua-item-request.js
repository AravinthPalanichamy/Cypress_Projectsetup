'use strict';

angular.module('app').controller('ItemRequestTab', function(StaticCollections, TableHeaderCollections, InventoryService) {
  var itemRequestCtrl = this;

  itemRequestCtrl.init = function(ruaId) {
    itemRequestCtrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
    itemRequestCtrl.getTableHeader();
    itemRequestCtrl.getData(ruaId);
  };

  itemRequestCtrl.getTableHeader = function() {
    itemRequestCtrl.tableHeaders = {
      RADIONUCLIDE: {
        field: 'radionuclideNameString',
        displayName: 'Radionuclide'
      },
      CHEMICAL_FORM: {
        field: 'chemicalForm',
        displayName: 'Chemical Form'
      },
      PHYSICAL_FORM: {
        field: 'physicalForm',
        displayName: 'Physical Form'
      },
      AMOUNT_MCI: {
        field: 'requestedAmount',
        displayName: 'Amount mCi'
      },
      AMOUNT_GRAMS: {
        field: 'requestedElementalMass',
        displayName: 'Amount grams',
        width: 150
      },
      REQUEST_DATE: Object.assign({}, angular.copy(itemRequestCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'createdDate',
        displayName: 'Request Date',
        width: 200
      })
    };
    itemRequestCtrl.columns = Object.values(itemRequestCtrl.tableHeaders);
  };

  itemRequestCtrl.getData = function(ruaId) {
    InventoryService.getMaterialsByUaAndInventoryStatusType({
      uaId: ruaId,
      inventoryStatusType: 'REQUESTED',
      isSealedSource: false
    }, {}).$promise.then(function(response) {
      itemRequestCtrl.data = response;
    });
  };
});
