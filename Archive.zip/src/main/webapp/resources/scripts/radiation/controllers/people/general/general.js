'use strict';

angular.module('app').component('peopleGeneralTab', {
  transclude: true,
  templateUrl: 'resources/scripts/radiation/controllers/people/general/general.html',
  controllerAs: 'ctrl',
  controller: function(StaticCollections, $location, $timeout, PersonService, PersonDocumentService,TableHeaderCollections) {
    var ctrl = this;
    ctrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
    ctrl.tableHeaders = {};

    ctrl.init = function() {
      ctrl.getTableHeader();
      ctrl.importedPerson = {};
      if (ctrl.person) {
        ctrl.personDisplayName = ctrl.person.firstName + ' ' + ctrl.person.lastName + ' (' + ctrl.person.email + ')';
        ctrl.person.dob = new Date(ctrl.person.dob);
      }
      ctrl.dobMaxDate = new Date();

      if (ctrl.person) {
        PersonService.getCurrentAndPastRUAsByUserId({userId:ctrl.person.userId})
          .$promise.then(function(response) {
            ctrl.data = ctrl.mapPersonDosimetry(response);
          });
      }

    };

    ctrl.mapPersonDosimetry = function(ruas) {
      return _.forEach(ruas, function(rua) {
        rua.$dosimetryMap = {};
         _.map(rua.dosimetries, function(dosimetry) {
          rua.$dosimetryMap[dosimetry.name.toUpperCase().replace(/(\s\-\s|\s)/g, '_')] = true;
        });
      });
    };

    ctrl.getTableHeader = function() {
      ctrl.tableHeaders = {
        RUA_NUMBER: {
          field: 'ruaNumber',
          displayName: 'RUA#',
          enableFiltering: false,
          width: 60
        },
        PI_NAME: {
          field: 'piName',
          displayName: 'PI Name',
          enableFiltering: false
        },
        RUA_TYPE: {
          field: 'ruaType',
          displayName: 'RUA Type',
          enableFiltering: false,
          width: 60
        },

        STATUS: {
          field: 'status',
          displayName: 'Status',
          enableFiltering: false,
          width: 80
        },

        FINGER_RING_LEFT: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
          field: '$dosimetryMap.FINGER_RING_LEFT',
          displayName: ' Finger ring Left',
          width: 75,
          enableFiltering: false,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.$dosimetryMap.FINGER_RING_LEFT" class="glyphicon glyphicon-ok" ></span></div>'
        }),
        FINGER_RING_RIGHT: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
          field: '$dosimetryMap.FINGER_RING_RIGHT',
          displayName: 'Finger ring Right',
          width: 75,
          enableFiltering: false,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.$dosimetryMap.FINGER_RING_RIGHT" class="glyphicon glyphicon-ok" ></span></div>'
        }),
        BODY_BADGE_CHEST: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
          field: '$dosimetryMap.BODY_BADGE_CHEST',
          displayName: ' Body badge Chest',
          width: 75,
          enableFiltering: false,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.$dosimetryMap.BODY_BADGE_CHEST" class="glyphicon glyphicon-ok" ></span></div>'
        }),
        BODY_BADGE_WAIST: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
          field: '$dosimetryMap.BODY_BADGE_WAIST',
          displayName: 'Body badge Waist',
          width: 75,
          enableFiltering: false,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.$dosimetryMap.BODY_BADGE_WAIST" class="glyphicon glyphicon-ok" ></span></div>'
        }),
        BODY_BADGE_COLLAR: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
          field: '$dosimetryMap.BODY_BADGE_COLLAR',
          displayName: 'Body badge Collar',
          width: 75,
          enableFiltering: false,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.$dosimetryMap.BODY_BADGE_COLLAR" class="glyphicon glyphicon-ok" ></span></div>'
        }),
        WRIST_BADGE_LEFT: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
          field: '$dosimetryMap.WRIST_BADGE_LEFT',
          displayName: ' Wrist badge Left',
          width: 75,
          enableFiltering: false,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.$dosimetryMap.WRIST_BADGE_LEFT" class="glyphicon glyphicon-ok" ></span></div>'
        }),
        WRIST_BADGE_RIGHT: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
          field: '$dosimetryMap.WRIST_BADGE_RIGHT',
          displayName: ' Wrist badge Right',
          width: 75,
          enableFiltering: false,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.$dosimetryMap.WRIST_BADGE_RIGHT" class="glyphicon glyphicon-ok" ></span></div>'
        }),
        NEUTRON_BADGE: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
          field: '$dosimetryMap.NEUTRON_BADGE',
          displayName: 'Neutron Badge',
          width: 75,
          enableFiltering: false,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.$dosimetryMap.NEUTRON_BADGE" class="glyphicon glyphicon-ok" ></span></div>'
        }),
        FETAL_BADGE: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
          field: '$dosimetryMap.FETAL_BADGE',
          displayName: ' Fetal badge',
          width: 75,
          enableFiltering: false,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.$dosimetryMap.FETAL_BADGE" class="glyphicon glyphicon-ok" ></span></div>'
        }),
        THYROID_SCAN: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
          field: '$dosimetryMap.THYROID_SCAN',
          displayName: 'Thyroid Scan',
          width: 75,
          enableFiltering: false,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.$dosimetryMap.THYROID_SCAN" class="glyphicon glyphicon-ok" ></span></div>'
        }),
        URINALYSIS: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
          field: '$dosimetryMap.URINALYSIS',
          displayName: 'Urinalysis',
          width: 90,
          enableFiltering: false,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.$dosimetryMap.URINALYSIS" class="glyphicon glyphicon-ok" ></span></div>'
        }),
        OTHER: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
          field: '$dosimetryMap.OTHER',
          displayName: 'Other',
          width: 90,
          enableFiltering: false,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.$dosimetryMap.OTHER" class="glyphicon glyphicon-ok" ></span></div>'
        }),
        DATE_ADDED: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.DATE_RANGE_SHORT), {
          field: 'dateAdded',
          displayName: 'Date Added',
          enableFiltering: false
        }),
        DATE_REMOVED: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.DATE_RANGE_SHORT), {
          field: 'dateRemoved',
          displayName: 'Date Removed',
          enableFiltering: false
        }),
        LAB: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
          field: 'radiationContact',
          displayName: 'Radiation Contact',
          width: 80,
          enableFiltering: false,
          cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.radiationContact" class="glyphicon glyphicon-ok" ></span></div>'
        }),
        TRAINING_STATUS: {
          field: 'trainingStatus',
          displayName: 'Training Status',
          enableFiltering: false,
          width: 85
        }
      };

      ctrl.columns = Object.values(ctrl.tableHeaders);
    };

    ctrl.search = {
      people: {
        selected: undefined,
        search: function(query) {
          if (query.length > 1) {
            return PersonService.findByName({
              search: query
            }).$promise.then(function(response) {
              return _.filter(response, 'email').splice(0, 10);
            });
          } else {
            return [];
          }
        },
        select: function($item) {
          if ($item.userId) {
            this.selected = $item;
            ctrl.userId = $item.userId;
            ctrl.validatingPerson = true;
            PersonService.getLocalPersonByUserId({userId: $item.userId})
              .$promise
              .then(function(response) {
                if (response.id) {
                  ctrl.validatingPerson = false;
                  ctrl.person = response;
                } else {
                  PersonService.getDetail({
                    userId: $item.userId
                  }).$promise
                    .then(function(response) {
                      ctrl.person = response;
                      ctrl.validatingPerson = false;
                    });
                }
              });
          }
        }
      }
    };

    ctrl.toggleDateOpen = function(type) {
      var newDateOpen = {};
      newDateOpen[type] = true;
      ctrl.dateOpen = newDateOpen;
    };

    ctrl.showSOEs = function() {
      PersonDocumentService.showSOEs(ctrl.person);
    };

    ctrl.onAddPerson = function() {
      if (ctrl.person.id) {
        ctrl.savingInProgress = true;

        ctrl.importedPerson = {
          dob: ctrl.person.dob,
          //nrccbcCompletedDate: ctrl.person.nrccbcCompletedDate,
          hasStatementOfExperience: ctrl.person.hasStatementOfExperience,
          comment: ctrl.person.comment
        };

        PersonService.updatePerson({userId: ctrl.person.userId}, ctrl.importedPerson)
          .$promise.then(function(response) {
          if (response.$resolved) {
            ctrl.savingInProgress = false;
            ctrl.successMessage = 'Person has been saved.';
            $timeout(function() {
              ctrl.href('people');
            }, 1000);
          }
        });
      } else {
        ctrl.invalidPerson = true;
      }
    };

    ctrl.onPersonSearchChange = function() {
      ctrl.person = {};
    };

    ctrl.cancelImportPerson = function() {
      ctrl.href('people');
    };

    ctrl.href = function(url) {
      $location.path(url);
    };

    ctrl.hideSuccessMsg = function() {
      ctrl.successMessage = null;
    };
  },
  bindings: {
    person: '='
  }
});
