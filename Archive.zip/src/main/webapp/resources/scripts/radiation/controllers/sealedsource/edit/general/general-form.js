'use strict';

angular.module('app').component('sealedSourceGeneralTab', {
  transclude: true,
  templateUrl: 'resources/scripts/radiation/controllers/sealedsource/edit/general/general-form.html',
  controllerAs: 'ctrl',
  controller: function($location, $uibModal, ConfirmModelService, TypesService, InventoryService, LabelService) {
    var ctrl = this;

    ctrl.init = function() {
      TypesService.getFrequencyList({}, {})
        .$promise
        .then(function(data) {
          ctrl.testFrequencies = _.map(data, function(value) {
            return {label: value.frequency, value: value.id};
          });
        });
    };

    ctrl.toggleInitialDate = function($event) {
      $event.stopPropagation();
      $event.preventDefault();
      ctrl.isInitialDateOpen = !ctrl.isInitialDateOpen;
    };

    ctrl.toggleNextDue = function($event) {
      $event.stopPropagation();
      $event.preventDefault();
      ctrl.isNextDueOpen = !ctrl.isNextDueOpen;
    };

    ctrl.isSealedSource = function(material) {
      var isSealedSource = _.some(material.materialRadionuclides, function(radionuclide) { return radionuclide.uaLimit.isSealedSource; });
      var isLeakTest = material.isMaterialForTest;

      return isSealedSource || isLeakTest;
    };

    ctrl.canDeleteMaterial = function() {
       var sealedSource = ctrl.isSealedSource(ctrl.material) && ctrl.material.inventoryStatusType === 'IN_INVENTORY';
       var pendingRequest = ctrl.material.inventoryStatusType === 'REQUESTED';

       return sealedSource || pendingRequest;
    };

    ctrl.deleteMaterial = function() {
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE, {message: 'Are you sure you want to delete this sealed source material?'}, function(answer) {
        InventoryService.deleteMaterial({materialId: ctrl.material.id}).$promise.then(function() {
          ctrl.onCancel();
        });
      });
    };

    ctrl.save = function() {
      if (!ctrl.material.id) {
        InventoryService.createMaterial({}, ctrl.material).$promise
          .then(function(response) {
            ctrl.material = response;
            ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS, {message: 'Material #' + ctrl.material.id + ' Saved Successfully'});
          });
      } else {
        InventoryService.updateMaterial({materialId: ctrl.material.id}, ctrl.material).$promise
          .then(function(response) {
            ctrl.material = response;
            ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS, {message: 'Material #' + ctrl.material.id + ' Updated Successfully'});
          });
      }
    };

    ctrl.onCancel = function() {
      $location.path().includes("search") ? $location.path('/materials/search') : $location.path('/sealedsources');
    };

    ctrl.displayLabel = function() {
      var labels = [
        {label: 'EH&S Material', value: ctrl.material.id},
        {label: 'Radionuclide(s)', value: ctrl.material.radionuclideNameString},
        {label: 'Initial Amount', value: ctrl.material.requestedAmount},
        {label: 'Reference Date', value: moment(ctrl.material.initialDate).format('MM/DD/YYYY')}
      ];
      LabelService.displayLabel(labels);
    };
  },
  bindings: {
    material: '=',
    isSealedSource: '='
  }
});
