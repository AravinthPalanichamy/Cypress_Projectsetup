'use strict';

angular.module('app').controller('InstrumentListCtrl', function($location, $templateCache, StaticCollections, TableHeaderCollections, TypesService, UtilService, data, PrintService, FileSaver, ConfirmModelService, PersonService, ExcelService) {
  var ctrl = this;
  ctrl.isAdmin = PersonService.isAdmin;
  ctrl.addRecordUrl = !ctrl.isAdmin ? '' : '/instrument/new';

  var tableHeaderCollections = {};
  ctrl.filteredRows = [];
  ctrl.init = function() {
    ctrl.data = data;
    ctrl.editData = [];
    ctrl.buttonList = [{label: 'Export', action: ctrl.exportExcel}];
    tableHeaderCollections = angular.copy(TableHeaderCollections);
    ctrl.getTableHeader();

    if (ctrl.isAdmin) {
      ctrl.buttonList.unshift(
        {
          label: "Print Certificate",
          action: ctrl.printCertificate
        }
      );
    }
  };

  ctrl.getTableHeader = function() {
    tableHeaderCollections.RUA.field = 'ua.number';
    tableHeaderCollections.ORGANIZATION.field = 'ua.coreCollection.collectionName';
    tableHeaderCollections.ORGANIZATION.displayName = 'Organization';
    tableHeaderCollections.PI_FIRST_NAME.field = 'ua.pi.firstName';
    tableHeaderCollections.PI_LAST_NAME.field = 'ua.pi.lastName';
    tableHeaderCollections.SURVEY_FREQ.field = 'calibrationFrequency.frequency';
    tableHeaderCollections.SURVEY_FREQ.displayName = 'Calibration Frequency';
    tableHeaderCollections.SURVEY_FREQ.width = 150;
    tableHeaderCollections.INSTRUMENT_USE_LOCATIONS.cellTemplate = $templateCache.get('use-locations.html');
    var nextDue = angular.copy(tableHeaderCollections.DATE_RANGE_SHORT);
    nextDue.field = 'calibrationNextDue';
    nextDue.displayName = 'Next Due';
    nextDue.enableDefaultToDate = true;
    nextDue.enableFiltering = true;
    tableHeaderCollections['NEXT_DUE'] = nextDue;
    tableHeaderCollections.EDIT.cellTemplate = $templateCache.get('instrument-table-edit.html');
    tableHeaderCollections.EDIT.width = '70';

    ctrl.columns = ctrl.colDefs();

    ctrl.getTableFilters();
  };

  ctrl.href = function(path) {
    $location.path(path);
  };

  ctrl.getTableFilters = function() {
    ctrl.calibrationDueStatusTypes = [];
    TypesService.getFrequencyList({}, {})
      .$promise
      .then(function(data) {
        var surveyFreq = _.map(data, function(value, key) {
          return {label: value.frequency, value: value.frequency};
        });
        for (var key in StaticCollections.calibrationDueStatusTypes) {
          ctrl.calibrationDueStatusTypes.push({label: StaticCollections.calibrationDueStatusTypes[key], value: key});
        }
        ctrl.getSortedFilters(surveyFreq, ctrl.calibrationDueStatusTypes);
      });
  };

  ctrl.getSortedFilters = function(surveyFreq, calibrationDueStatusTypes) {
    tableHeaderCollections.SURVEY_FREQ.filter.selectOptions = UtilService.sortUniqUnion(TableHeaderCollections.SURVEY_FREQ.filter.selectOptions, surveyFreq, 'label');
    tableHeaderCollections.CALIBRATION_DUE_STATUS_TYPE.filter.selectOptions = UtilService.sortUniqUnion(TableHeaderCollections.CALIBRATION_DUE_STATUS_TYPE.filter.selectOptions, calibrationDueStatusTypes, 'label');
  };

  ctrl.colDefs = function() {
    return [
      tableHeaderCollections.EDIT,
      tableHeaderCollections.RUA,
      tableHeaderCollections.ORGANIZATION,
      tableHeaderCollections.PI_FIRST_NAME,
      tableHeaderCollections.PI_LAST_NAME,
      tableHeaderCollections.INSTRUMENT_MODEL,
      tableHeaderCollections.INSTRUMENT_MANUFACTURER,
      tableHeaderCollections.INSTRUMENT_SERIAL_NUMBER,
      tableHeaderCollections.INSTRUMENT_USE_LOCATIONS,
      tableHeaderCollections.SURVEY_FREQ,
      tableHeaderCollections.NEXT_DUE,
      tableHeaderCollections.CALIBRATION_DUE_STATUS_TYPE
    ];
  };

  ctrl.printCertificate = function() {
    if (ctrl.data.length > 0) {
      var params = ctrl.filteredRows.map(function(row) {return row.id;});
      PrintService.openInTab('printCalibrationCertificate', ({}, params));
    } else {
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.INFO, {header: "Print", message: "No Data Found"});
    }
  };

  ctrl.exportExcel = function() {
    var excelData = ctrl.filteredRows.map(function(row) {
      return {
        'RUA': row.ua.number,
        'Organization': row.ua.coreCollection ? row.ua.coreCollection.collectionName : "",
        'PI First': row.ua.pi.firstName,
        'PI Last': row.ua.pi.lastName,
        'Model': row.model,
        'Manufacturer': row.manufacturer,
        'Serial Number': row.serialNumber,
        'Use Locations': row.useLocations,
        'Calibration Frequency': row.calibrationFrequency.frequency,
        'Next Due': row.calibrationNextDue !== null ? ctrl.formatDate(row.calibrationNextDue) : null,
        'Due Status': ctrl.calibrationDueStatusTypes.find(function(type) {
          return type.value === row.calibrationDueStatusType;
        }).label
      };
    });
    ExcelService.export(excelData, 'Instrument List', {withTimeStamp: true});
  };

  ctrl.formatDate = function(date) {
    return moment(date).format('MM/DD/YYYY');
  };
})
  .run(function($templateCache) {
    var instrumentEditTemplate = '<div class="edit-link"><span ng-if="row.entity.id"><a href="#/instrument/edit/{{row.entity.id}}" class="glyphicon {{ !grid.appScope.parentScope.isAdmin ? \'glyphicon-eye-open\' : \'glyphicon-edit\'}}" title="{{ !grid.appScope.parentScope.isAdmin ? \'View Instrument \' : \'Edit Instrument\'}}"></a></span></div>';
    $templateCache.put('instrument-table-edit.html', instrumentEditTemplate);
    var useLocationsTemplate = '<span ng-bind-html="row.entity[col.field]"></span>';
    $templateCache.put('use-locations.html', useLocationsTemplate);
  });
