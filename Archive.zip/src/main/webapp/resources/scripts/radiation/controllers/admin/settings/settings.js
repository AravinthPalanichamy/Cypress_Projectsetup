'use strict';

angular.module('app').controller('SettingsCtrl', function(ConfirmModelService, SettingsService, settings) {
  var ctrl = this;

  ctrl.settings = _.cloneDeep(settings);

  ctrl.onCancel = function() {
    ctrl.settings = _.cloneDeep(settings);
  };

  ctrl.save = function(settings) {
    SettingsService.updateSettings(settings).$promise.then(function(settings) {
      ctrl.settings = settings;
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS, { message: 'Successfully saved settings' });
    });
  };
});
