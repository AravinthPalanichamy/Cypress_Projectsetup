'use strict';

angular.module('app').controller('PackageListCtrl', function($location, ConfirmModelService, FileSaver, InventoryService, PrintService, TableHeaderCollections, UtilService, page) {
  var ctrl = this;

  ctrl.page = page;
  ctrl.tableHeaderCollections = _.cloneDeep(TableHeaderCollections);
  ctrl.init = function() {
    ctrl.columns = ctrl.defineTable();
    ctrl.buttonList = [
      {label: "Print Receipts", action: ctrl.printPackageReceipts},
      {label: "Print Transfer Forms", action: ctrl.printPackageForms},
      {label: "New Package", action: ctrl.newPackage}
    ];
  };

  ctrl.defineTable = function() {
    ctrl.tableHeaderCollections.EDIT.cellTemplate = '<div class="edit-link"><span><a href="#/materials/package-edit/{{ row.entity.id }}" class="glyphicon glyphicon-edit"><span class="hideEditText">Edit</span></a></span></div>';
    ctrl.tableHeaderCollections.RUA.field = 'ua.number';
    ctrl.tableHeaderCollections.PI_FIRST_NAME.field = 'ua.pi.firstName';
    ctrl.tableHeaderCollections.PI_LAST_NAME.field = 'ua.pi.lastName';

    var dateRecieved = _.cloneDeep(ctrl.tableHeaderCollections.DATE_RANGE_SHORT);
    dateRecieved.field = 'dateReceived';
    dateRecieved.displayName = 'Date Received (mm/dd/yyyy)';


    var initialDate = _.cloneDeep(ctrl.tableHeaderCollections.DATE_RANGE_SHORT);
    initialDate.field = 'initialDate';
    initialDate.displayName = 'Reference Date (mm/dd/yyyy)';

    return [
      ctrl.tableHeaderCollections.EDIT,
      {displayName: 'Package', field: 'packageNumber', width: 75},
      ctrl.tableHeaderCollections.RUA,
      ctrl.tableHeaderCollections.PI_FIRST_NAME,
      ctrl.tableHeaderCollections.PI_LAST_NAME,
      dateRecieved,
      {displayName: 'Checked by', field: 'checkedBy.displayName'},
      {displayName: 'Package Type', field: 'packageType.packageTypeName', width: 100},
      {displayName: 'Transport Index', field: 'transportIndex', width: 100, cellFilter: 'scientific'},
      {displayName: 'Number of Vials', field: 'materials.length', width: 100, filters: [{filterType: 'TRANSIENT'}]},
      {displayName: 'Radionuclides', field: 'packageRadionuclideString', filters: [{filterType: 'TRANSIENT'}]},
      {displayName: 'Total amount', field: 'packageTotalAmount', cellFilter: 'scientific', filters: [{filterType: 'TRANSIENT'}]}
    ];
  };


  ctrl.newPackage = function() {
    $location.path('materials/package-create');
  };

  ctrl.getPackageIds = function(packages) {
    return packages.map(function(materialPackage) { return materialPackage.id; });
  };

  ctrl.printPackageReceipts = function() {
    PrintService.openInTab('printPackageReceipts', ctrl.filteredRows);
  };

  ctrl.printPackageForms = function() {
    var packages = ctrl.getPackageIds(ctrl.page);
    if (packages.length > 0) {
      PrintService.openInTab('printPackages', ({}, packages));
    } else {
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.INFO, {header: "Print", message: "No Package Found"});
    }
  };

  ctrl.init();
})
  .run(function($templateCache) {
    $templateCache.put('package-table.html', '<div id="grid2" ui-grid="ctrl.gridOptions" class="data-grid" ng-if="ctrl.gridOptions.data" ui-grid-pinning ui-grid-pagination ui-grid-edit></div>');
  });
