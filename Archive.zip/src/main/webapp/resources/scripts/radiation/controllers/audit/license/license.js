'use strict';

angular.module('app').controller('LicenseCtrl', function($sce, $templateCache, $filter, LicenseService, profile, StaticCollections, TableHeaderCollections) {
  var ctrl = this;

  ctrl.currentUser = profile;
  var tableHeaderCollections = {};

  ctrl.init = function() {
    LicenseService.getLicensesByCampus({campusCode: ctrl.currentUser.campus.code}, {}).$promise
      .then(function(response) {
        ctrl.data = _.forEach(ctrl.processLicense(response.lineNumbers), function(lineNumber) {
          lineNumber.total = lineNumber.totalPossessionInRUAs + lineNumber.wasteActivity;
          lineNumber.total = $filter('scientific')(lineNumber.total);
          lineNumber.totalPossessionInRUAs = $filter('scientific')(lineNumber.totalPossessionInRUAs);
          lineNumber.wasteActivity = $filter('scientific')(lineNumber.wasteActivity);
        });
        tableHeaderCollections = angular.copy(TableHeaderCollections);
        ctrl.getTableHeader();
      });
  };

  ctrl.getTableHeader = function() {
    tableHeaderCollections.EDIT.cellTemplate = $templateCache.get('edit-license-list.html');
    ctrl.columns = ctrl.colDefs();
  };

  ctrl.colDefs = function() {
    var edit = angular.copy(tableHeaderCollections.EDIT);
    var lineNumber = angular.copy(tableHeaderCollections.LINE_NUMBER);
    var nuclide = angular.copy(tableHeaderCollections.NUCLIDE);
    var licenseUsePurpose = angular.copy(tableHeaderCollections.USE_PURPOSE);
    var form = angular.copy(tableHeaderCollections.FORM);
    var campusLimit = angular.copy(tableHeaderCollections.CAMPUS_LIMIT);
    var possessionLimit = angular.copy(tableHeaderCollections.POSSESSION_LIMIT);
    possessionLimit.cellFilter = 'scientific';
    var wasteActivity = angular.copy(tableHeaderCollections.WASTE_ACTIVITY);
    var total = angular.copy(tableHeaderCollections.TOTAL);

    lineNumber.width = 100;
    possessionLimit.width = 180;
    licenseUsePurpose.field = 'usePurpose.usePurposeName';
    licenseUsePurpose.enableFiltering = false;
    licenseUsePurpose.useExternalFiltering = false;
    licenseUsePurpose.enableSorting = false;
    licenseUsePurpose.useExternalSorting = false;
    licenseUsePurpose.enableColumnMenu = false;
    return [
      edit, lineNumber, nuclide, licenseUsePurpose, form, campusLimit, possessionLimit, wasteActivity, total
    ];
  };

  ctrl.onRowExpanded = function(row) {
    var massUnits = ['mg', 'g', 'kg', 'lb'];
    return new Promise(function(resolve, reject) {

      var rua = angular.copy(TableHeaderCollections.RUA);
      var radionuclide = angular.copy(TableHeaderCollections.RADIONUCLIDE);
      var chemicalForm = angular.copy(TableHeaderCollections.CHEMICAL_FORM);
      var physicalForm = angular.copy(TableHeaderCollections.PHYSICAL_FORM);
      var experiemnt = angular.copy(TableHeaderCollections.EXPT);
      var vial = angular.copy(TableHeaderCollections.VIAL);
      var possession = angular.copy(TableHeaderCollections.POSS);
      var containedExpt = angular.copy(TableHeaderCollections.CONTAINED_EXPT);
      var containedVial = angular.copy(TableHeaderCollections.CONTAINED_VIAL);
      var containedPoss = angular.copy(TableHeaderCollections.CONTAINED_POSS);
      var dateAdded = angular.copy(TableHeaderCollections.DATE_RANGE_SHORT);

      dateAdded.field = 'dateAdded';
      dateAdded.displayName = 'Date Added';
      dateAdded.width = '150';
      radionuclide.width = 100;
      chemicalForm.width = 120;
      physicalForm.width = 110;
      experiemnt.width = 90;
      experiemnt.cellFilter = 'scientific';
      vial.width = 90;
      vial.cellFilter = 'scientific';
      possession.width = 90;
      possession.cellFilter = 'scientific';

      if (massUnits.indexOf(row.campusLimitUnit.unitName) > -1) {
        experiemnt.displayName = 'g/Expt';
        experiemnt.width = 80;
        vial.displayName = 'g/Vial';
        vial.width = 80;
        possession.displayName = 'g/Poss';
        possession.width = 80;
      }

      LicenseService.getUAsByLicenseLineNumber({licenseLineNumber: row.id}, {})
        .$promise
        .then(function(ruaLimits) {
          var hasContainedMass = false;
          var isSealedSource = false;
          _.forEach(ruaLimits, function(ruaLimit) {
            if (ruaLimit.containedExpLimit > 0) {
              hasContainedMass = true;
            } else if (ruaLimit.isSealedSource) {
              isSealedSource = true;
            }
          });

          if (isSealedSource) {
            vial.displayName = 'mCi/Order';
          }

          if (hasContainedMass) {
            experiemnt.displayName = 'g/Total Expt';
            experiemnt.width = 100;
            vial.displayName = 'g/Total Vial';
            vial.width = 90;
            possession.displayName = 'g/Total Poss';
            possession.width = 100;
            physicalForm.width = 110;
            containedExpt.width = 110;
            containedVial.width = 110;
            containedPoss.width = 110;
            dateAdded.width = 130;
          }

          var subTableHeaders = [
            rua, radionuclide, chemicalForm, physicalForm, experiemnt, vial, possession, dateAdded
          ];
          if (massUnits.indexOf(row.campusLimitUnit.unitName) > -1) {
            var index = subTableHeaders.indexOf(dateAdded);
            if (hasContainedMass) {
              subTableHeaders.splice(index, 0, containedExpt, containedVial, containedPoss);
            }

          }
          var doc = {
            SUB_TABLE_HEADERS: subTableHeaders,
            SUB_TABLE_DATA: ruaLimits
          };
          return resolve(doc);
        });
    });
  };

  ctrl.processLicense = function(licenseLineNumbers) {
    return ctrl.sortLicense(licenseLineNumbers);
  };

  ctrl.sortLicense = function(licenseLineNumbers) {
    return licenseLineNumbers.sort(function(a, b) {
      a = a.lineNumber.split('.');
      b = b.lineNumber.split('.');

      return ctrl.compareLineNumbers(a, b, 0);
    });
  };

  ctrl.compareLineNumbers = function(a, b, index) {
    var x = isNaN(a[index]) ? a[index] : parseInt(a[index]);
    var y = isNaN(b[index]) ? b[index] : parseInt(b[index]);

    if (x < y) {
      return -1;
    }

    if (x > y) {
      return 1;
    }

    if (x === y) {
      if (index >= a.length - 1 || index >= b.length - 1) {
        return 0;
      }
      return ctrl.compareLineNumbers(a, b, index + 1);
    }
  };
})

  .run(function($templateCache) {
    $templateCache.put('edit-license-list.html',
      '<div class="edit-link">' +
      '<span class="ui-grid-row-header-cell ui-grid-expandable-buttons-cell"><i ng-class="{ \'ui-grid-icon-plus-squared\' : row.entity.ruaLimitExist && !row.isExpanded, \'ui-grid-icon-minus-squared\' : row.isExpanded, \'ng-grid-cell\': row.entity.subGridOptions.data.length == 0 }" ng-click="grid.appScope.toggleExpandable(grid, row)"></i></span></div>');
    $templateCache.put('table-licenseList.html', '<div id="licenseList" ui-grid="ctrl.gridOptions" class="data-grid" ng-if="ctrl.gridOptions.data" ui-grid-expandable></div>');
  });
