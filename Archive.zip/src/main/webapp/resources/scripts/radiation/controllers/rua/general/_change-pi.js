'use strict';

angular.module('app').controller('ChangePICtrl', function($uibModalInstance, PersonService, UaService, rua, ConfirmModelService) {
  var $ctrl = this;

  $ctrl.init = function() {
    UaService.getUa({uaId: rua.id}, {}).$promise.then(function(response) {
      $ctrl.rua = response;
    });
    $ctrl.error = false;
  };

  $ctrl.search = {
    people: {
      selected: undefined,
      search: function(query) {
        $ctrl.error = false;
        if (query.length > 1) {
          return PersonService.findByName({
            search: query
          }).$promise.then(function(response) {
            return _.filter(response, 'email').splice(0, 10);
          });
        } else {
          return [];
        }
      },
      select: function($item) {
        if ($item.userId) {
          this.selected = $item;
          $ctrl.userId = $item.userId;
          $ctrl.loadSpinner = true;
          PersonService.getDetail({
            userId: $item.userId
          }).$promise
            .then(function(response) {
              if (response) {
                $ctrl.pi = response;
                $ctrl.ruaPi = $ctrl.pi.firstName + ' ' + $ctrl.pi.lastName;
              }
              $ctrl.loadSpinner = false;
            });
        }
      }
    }
  };

  function isTrainingExpired(training) {
    var currDate = moment(new Date()).format('YYYY-MM-DD');
    training.trainingExpired = (moment(training.trxExpiryDate).isBefore(currDate));
    training.trainingCompletedDate = training.trxExpiryDate ;
    return training;
  }

  function isRemovedPerson() {
    return _.some($ctrl.rua.uaBundle.uaBundlePersons, function(uaBundlePerson) {
      return (uaBundlePerson.person.userId === $ctrl.pi.userId && !!uaBundlePerson.dateRemoved) ;
    });
  }

  $ctrl.onSave = function() {
    if (!$ctrl.pi) {
      $ctrl.error = true;
      $ctrl.errorMsg = 'Please select a valid PI.';
    } else if (!$ctrl.pi.hasStatementOfExperience) {
      $ctrl.error = true;
      $ctrl.errorMsg = 'You can not add this person. This person does not have a Statement of Experience (SOE).';
    } else if (isRemovedPerson()) {
      $ctrl.error = true;
      $ctrl.errorMsg = 'This person is either inactive/removed on this RUA. Please re-add this person first in-order to make any changes further.';
    } else {
      PersonService.getTrainingStatusByUserIdAndRUAType({
        userId: $ctrl.pi.userId,
        ruaType: $ctrl.rua.type
      }).$promise.then(function(response) {
        if (response && !isTrainingExpired(response).trainingExpired) {
          UaService.reassignRuaPi({
            uaId: $ctrl.rua.id,
            userId: $ctrl.pi.userId
          }, {}).$promise
            .then(function(response) {
              $uibModalInstance.close({'$value': response.pi});
              var piChangeMsg = 'PI has been changed for Rua #' + $ctrl.rua.number + '.';
              ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS,
                {message: piChangeMsg, buttons: undefined, close: false, autoClose: true, autoCloseTimeout: 3000});
            });
        } else {
          $ctrl.error = true;
          $ctrl.errorMsg = 'You can\'t add this person. This person does not have ' + $ctrl.rua.type + ' training.';
        }
      });
    }
  };

  $ctrl.cancel = function() {
    $uibModalInstance.dismiss({'$value': 'canceled'});
  };

  $ctrl.init();
});
