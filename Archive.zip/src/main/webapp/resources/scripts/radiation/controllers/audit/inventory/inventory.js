'use strict';

angular.module('app').controller('InventoryAuditCtrl', function(TableHeaderCollections, data) {
  var ctrl = this;
  ctrl.filteredRows = [];

  ctrl.init = function() {
    ctrl.data = data;
    ctrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
    ctrl.getTableHeader();
  };

  ctrl.getTableHeader = function() {
    ctrl.tableHeaders = {
      RADIONUCLIDE_NAME: {
        field: 'radionuclideName',
        displayName: 'Radionuclide',
        sort: {direction: 'asc', priority: 0}
      },
      Z_VALUE: {
        field: 'zValue',
        displayName: 'Z Value'
      },
      RADIOACTIVE_MATERIAL_TOTAL: {
        field: 'totalRadioactiveMaterialFormatted',
        displayName: 'Radioactive Material Total(mCi)',
        cellFilter: 'scientific'
      },
      SEALED_SOURCE_MATERIAL_TOTAL: {
        field: 'totalSealedSourceFormatted',
        displayName: 'Sealed Source Material Total(mCi)'
      }
    };
    ctrl.columns = Object.values(ctrl.tableHeaders);
  };

});
