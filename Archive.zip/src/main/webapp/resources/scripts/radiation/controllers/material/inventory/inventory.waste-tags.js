'use strict';

angular.module('app').controller('InventoryWasteTagCtrl', function($uibModal, $http, $window, $timeout,
                                                                    FileSaver, TableHeaderCollections, StaticCollections,
                                                                    ConfirmModelService,
                                                                    InventoryService, WasteFormService, WasteService, PrintService) {
  var ctrl = this;

  ctrl.wasteTagTableHeaderCollection = _.cloneDeep(TableHeaderCollections);
  ctrl.wasteMaterialType = StaticCollections.wasteMaterialTypeHash;
  ctrl.rua = parent.rua;
  ctrl.containerData = [];

  ctrl.init = function(parent) {
    ctrl.rua = parent.rua;
    ctrl.getData(ctrl.rua.id);
    ctrl.wasteTagsColumns = ctrl.defineWasteTagsColumns();
  };

  ctrl.getData = function(uaId) {
    return InventoryService.getContainersForUa({uaId: uaId}).$promise.then(function(response) {
      ctrl.containerData = response;
      return ctrl.getWasteTags(uaId);
    });
  };

  ctrl.getWasteTags = function(uaId) {
    return WasteService.getWasteTagByRuaId({ruaId: uaId}).$promise.then(function(response) {
      ctrl.wasteTags = _.orderBy(_.filter(response, function(tag) {
        return tag.wasteTagStatus === 'READY_FOR_PICKUP';
      }), ['lastModifiedDate'], ['desc']);

      return ctrl.wasteTags;
    });
  };

  ctrl.printWasteTag = function(wasteTag) {
    WasteService.getWasteToken({trackingNumber: wasteTag.trackingNumber}).$promise
      .then(function(res) {
        PrintService.printWasteTag({token: res.token}, {})
          .$promise.then(function(response) {
          FileSaver.saveAs(response.data.file, response.data.filename);
        });
      });
  };

  ctrl.getRadionuclides = function(wasteTag) {
    return _.uniq(ctrl.getMaterialNames(wasteTag.materials)).join(', ');
  };

  ctrl.getMaterialNames = function(materials) {
    return _.map(materials, function(material) { return material.radionuclideNameString; });
  };

  ctrl.getLabel = function(wasteTag) {
    if (wasteTag.wasteTagType === 'MIX') {
      return 'Mixed';
    } else {
      return ctrl.wasteMaterialType[wasteTag.wasteMaterialType];
    }
  };

  ctrl.defineWasteTagsColumns = function() {

    var pickupRequestedDate = {
      field: 'requestPickUpDate',
      displayName: 'Pickup Requested Date',
      width: 130,
      cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.requestPickUpDate"> {{row.entity.requestPickUpDate | date:"MM/dd/yyyy" }}</span></div>',
      enableFiltering: false,
      enableColumnMenu: false
    };

    return [
      {
        displayName: 'Print Tag',
        field: 'id',
        width: 80,
        enableFiltering: false,
        enableColumnMenu: false,
        cellTemplate: 'print-pdf-template.html'
      },
      {displayName: 'Tracking #', field: 'trackingNumber'},
      {
        displayName: 'Radionuclide(s)',
        field: 'materialUses',
        cellTemplate: '<div class="ui-grid-cell-contents">{{ grid.appScope.parentScope.getRadionuclides(row.entity) }}</div>'
      },
      {displayName: 'Total Activity (mCi)', field: 'totalActivity'},
      {
        displayName: 'Waste Material Type', field: 'wasteMaterialType',
        cellTemplate: '<div class="ui-grid-cell-contents">{{grid.appScope.parentScope.getLabel(row.entity)}}</div>'
      },
      {
        displayName: 'Storage Location',
        field: 'location',
        width: 200,
        cellTemplate: '<div class="ui-grid-cell-contents">{{ row.entity.location.buildingDisplayName }} - {{row.entity.location.roomNumber}}</div>'
      },
      {displayName: 'Lab Location', field: 'labLocation'},
      pickupRequestedDate,
      {displayName: 'Comments', field: 'comments', width: 250}
    ];
  };

}).run(function($templateCache) {
  var printPdfTemplate = '<div ng-if="row.entity.trackingNumber" ng-click="grid.appScope.parentScope.printWasteTag(row.entity)" class="edit-link"><span title="Download PDF to print waste tag"><a herf class="glyphicon glyphicon-print"></a></span></div>';

  $templateCache.put('print-pdf-template.html', printPdfTemplate);
  $templateCache.put('table-client-waste.html', '<div id="table-client-waste" ui-grid="ctrl.gridOptions" class="data-grid" ng-if="ctrl.gridOptions.data" ui-grid-pinning ui-grid-pagination ui-grid-cellnav></div>');
});
