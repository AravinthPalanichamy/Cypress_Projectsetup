'use strict';

angular.module('app').controller('InventorySealedSourcesCtrl', function(ExcelService, InventoryService, LabelService, TableHeaderCollections, MaterialUseService, EhsPickupService, WasteFormService) {
  var ctrl = this;

  ctrl.data = [];
  ctrl.tableHeaderCollections = _.cloneDeep(TableHeaderCollections);
  ctrl.useOptions = [
    {id: 'LOT', label: 'Update Lot Information', template: 'update-lot-form.html'},
    {id: 'CHANGE_LOCATION', label: 'Change Location', template: 'change-location-form.html'},
    {id: 'EHS_PICKUP', label: 'Request EH&S Pickup', template: ''},
    {id: 'TRANSFER', label: 'Transfer Material', template: 'transfer-form.html'}
  ];

  ctrl.init = function(parent) {
    ctrl.rua = parent.rua;
    ctrl.ruaNumber = parent.rua.number;
    ctrl.buttonList = [{label: 'Export', action: ctrl.exportExcel}];
    ctrl.getTableData(parent.rua.id);
    ctrl.columns = ctrl.defineTable();
  };

  ctrl.getTableData = function(uaId) {
    InventoryService.getMaterialsByUaAndInventoryStatusType({
      uaId: uaId || ctrl.rua.id,
      inventoryStatusType: 'IN_INVENTORY',
      isSealedSource: true
    }, function(response) {
      ctrl.data = response;
    });
  };

  ctrl.defineTable = function() {
    var initialDate = _.cloneDeep(ctrl.tableHeaderCollections.DATE_RANGE_SHORT);
    initialDate.field = 'initialDate';
    initialDate.width = 150;
    initialDate.displayName = 'Reference Date (mm/dd/yyyy)';
    initialDate.enableFiltering = false;

    var receivedDate = _.cloneDeep(ctrl.tableHeaderCollections.DATE_RANGE_SHORT);
    receivedDate.field = 'materialPackage.dateReceived';
    receivedDate.width = 150;
    receivedDate.displayName = 'Receipt Date (mm/dd/yyyy)';
    receivedDate.enableFiltering = false;

    return [
      {displayName: 'Use', field: 'edit', width: 50, cellTemplate: "ss-material-use.html", enableSorting: false},
      {displayName: 'Material #', field: 'id', width: 100},
      receivedDate,
      {displayName: 'Radionuclide', field: 'radionuclideNameString'},
      {displayName: 'Initial Amount (mCi)', field: 'requestedAmount'},
      {displayName: 'Current Activity (mCi)', field: 'currentAmount'},
      {displayName: 'Initial Mass (grams)', field: 'requestedElementalMass'},
      {displayName: 'Current Mass (grams)', field: 'currentElementalMass'},
      initialDate,
      {
        displayName: 'Building & Room', field: 'storageLocation',
        cellTemplate: '<div class="ui-grid-cell-contents">{{ row.entity.storageLocation.buildingPrimaryName }} - {{row.entity.storageLocation.roomNumber}}</div>'
      },
      {displayName: 'Location', field: 'subLocation'}
    ];
  };

  ctrl.exportExcel = function() {
    var excelData = ctrl.filteredRows.map(function(row) {
      return {
        'Material #': row.id,
        'Receipt Date': row.materialPackage !== null ? ctrl.formatDate(row.materialPackage.dateReceived) : null,
        'Radionuclide': row.radionuclideNameString,
        'Physical Form': row.physicalForm,
        'Chemical Form': row.chemicalForm,
        'Initial Amount (mCi)': row.requestedAmount,
        'Current Activity (mCi)': row.currentAmount,
        'Initial Mass (grams)': row.requestedElementalMass,
        'Current Mass (grams)': row.currentNetMass,
        'Reference Date': ctrl.formatDate(row.initialDate),
        'Building & Room': row.storageLocation.buildingPrimaryName + ' - ' + row.storageLocation.roomNumber,
        'Location': row.subLocation
      };
    });

    var name = ctrl.ruaNumber + ' Sealed Sources';
    ExcelService.export(excelData, name, {withTimeStamp: true});
  };

  ctrl.formatDate = function(date) {
    return moment(date).format("MM/DD/YYYY");
  };

  ctrl.printLabel = function(material) {
    LabelService.displayLabel([
      {label: 'EH&S Material #', value: material.id},
      {label: 'Radionuclide(s)', value: material.radionuclideNameString},
      {label: 'Initial Amount', value: material.requestedAmount},
      {label: 'Lot #', value: material.lotNumber},
      {label: 'Reference Date', value: moment(material.initialDate).format('MM/DD/YYYY')}
    ]);
  };

  ctrl.onUseMaterial = function(option, material) {
    if (option.id === 'EHS_PICKUP') {
      ctrl.onRequestPickup(material);
      return;
    }

    ctrl.currentMaterial = angular.copy(material);
    var callback = ctrl.save;
    if (option.id === 'TRANSFER') {
      callback = function() { ctrl.getTableData(ctrl.rua.id); };
    }
    MaterialUseService.openModal(option, ctrl.currentMaterial, ctrl.getTableData);
  };

  ctrl.onSave = function(material) {
    InventoryService.updateMaterial({ materialId: material.id }, material)
      .$promise.then(function(material) {
      ctrl.getTableData(material.ua.id);
    });
  };

  ctrl.onRequestPickup = function(material) {
    ctrl.wasteTag = {};
    var options = {requestingPickup: true, nonDispose: true, material: material};
    WasteFormService.openModal(ctrl.rua, null, options, ctrl.onFormSubmit);
  };

  ctrl.onFormSubmit = function(wasteTag, options) {
    ctrl.wasteTag = wasteTag;
    ctrl.wasteTag.ownerRuaId = ctrl.ruaId;
    ctrl.container = {
      ruasWithAccess: [ctrl.rua],
      containerName: 'EH&S_Pickup_RUA_' + ctrl.rua.number,
      ownerRuaId: ctrl.rua.id
    };

    EhsPickupService.kickOffProcess(ctrl.wasteTag, ctrl.container, {material: options.material}, ctrl.onDonePickup);
  };

  ctrl.onDonePickup = function(trackingNumber, errorMessage) {
    ctrl.getTableData(ctrl.rua.id);

    if (errorMessage) {
      ctrl.handleErrorMessage(errorMessage);
    } else if (trackingNumber) {
      ctrl.saveMessage = 'Material is successfully requested for an EH&S pickup. Available to view in Pending Pickup. Tracking # : ' + trackingNumber;
    }
  };

})
  .run(function($templateCache) {

    var ssEditTemplate = '<span uib-dropdown dropdown-append-to-body class="edit-link">' +
      '<a href uib-dropdown-toggle class="glyphicon glyphicon-edit"><span class="hideEditText">Use</span></a>' +
      '<ul class="dropdown-menu" uib-dropdown-menu>' +
      '   <li ng-click="grid.appScope.parentScope.printLabel(row.entity)"><a href>Print Label</a></li>' +
      ' <li ng-repeat="option in grid.appScope.parentScope.useOptions" ng-click="grid.appScope.parentScope.onUseMaterial(option, row.entity)"><a href>{{ option.label }}</a></li>' +
      '</ul>' +
      '</span>';

    $templateCache.put('ss-material-use.html', ssEditTemplate);
  });
