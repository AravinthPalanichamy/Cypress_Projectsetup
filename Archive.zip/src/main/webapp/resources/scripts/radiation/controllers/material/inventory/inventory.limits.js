'use strict';

angular.module('app').controller('InventoryLimitCtrl', function($filter, ExcelService, InventoryService, UaService, TableHeaderCollections) {
  var ctrl = this;

  ctrl.data = [];
  ctrl.tableHeaderCollections = _.cloneDeep(TableHeaderCollections);

  ctrl.init = function(parent) {
    ctrl.ruaNumber = parent.rua.number;
    ctrl.buttonList = [{label: 'Export', action: ctrl.exportExcel}];

    UaService.getUaLimitsByUaId({uaId: parent.rua.id}).$promise.then(function(response) {
      ctrl.data = _.filter(response, 'active');
    });

    InventoryService.getInventoryByUa({ uaId: parent.rua.id }).$promise.then(function(response) {
      ctrl.materials = ctrl.buildIsotopeAmountValueMap(response);
    });

    ctrl.columns = ctrl.defineTable();
  };

  ctrl.defineTable = function() {
    return [
      {displayName: 'Radionuclide', field: 'radionuclide.name'},
      {displayName: 'Chemical Form', field: 'chemicalForm'},
      {
        displayName: 'Sealed Source',
        field: 'isSealedSource',
        cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.isSealedSource" class="glyphicon glyphicon-ok" ></span></div>'
      },
      {
        displayName: 'Total Current Activity (mCi)',
        field: 'a',
        cellTemplate: '<div>{{ grid.appScope.parentScope.materials[row.entity.id].totalAmount || null | scientific }}</div>'
      },
      {
        displayName: 'Total Current Volume (microliter)', field: 'v',
        cellTemplate: '<div>{{ grid.appScope.parentScope.materials[row.entity.id].totalVolume || null | scientific}}</div>',
        headerCellTemplate: '<div class="ui-grid-cell-contents ui-grid-header-cell-label">Current Volume(&micro;l)</div>'
      },
      {
        displayName: 'Total Current Elemental Mass (grams)',
        field: 'c',
        cellTemplate: '<div>{{ grid.appScope.parentScope.materials[row.entity.id].totalElementalMass || null | scientific }}</div>'
      },
      {
        displayName: 'Total Current Net Mass (grams)',
        field: 'x',
        cellTemplate: '<div>{{ grid.appScope.parentScope.materials[row.entity.id].totalNetMass || null  | scientific }}</div>'
      },
      {displayName: 'mCi/Exp', field: 'experimentPossessionLimit', cellFilter: 'scientific'},
      {displayName: 'mCi/Order', field: 'vialPossessionLimit', cellFilter: 'scientific'},
      {displayName: 'mCi/Poss', field: 'requestedPossessionLimit', cellFilter: 'scientific'}
    ];
  };

  ctrl.exportExcel = function() {
    var excelData = ctrl.filteredRows.map(function(row) {
      return {
        'Radionuclide': row.radionuclide.name,
        'Chemical Form': row.chemicalForm,
        'Sealed Source': row.isSealedSource ? 'Yes' : 'No',
        'Total Current Activity (mCi)': ctrl.materials[row.id] !== undefined ? ctrl.materials[row.id].totalAmount : null,
        'Total Current Volume (µl)': ctrl.materials[row.id] !== undefined ? ctrl.materials[row.id].totalVolume : null,
        'Total Current Mass (grams)': ctrl.materials[row.id] !== undefined ? ctrl.materials[row.id].totalElementalMass : null,
        'Total Current Net Mass (grams)': ctrl.materials[row.id] !== undefined ? ctrl.materials[row.id].totalNetMass : null,
        'mCi/Exp': $filter('scientific')(row.experimentPossessionLimit),
        'mCi/Order': $filter('scientific')(row.vialPossessionLimit),
        'mCi/Poss': $filter('scientific')(row.requestedPossessionLimit)
      };
    });

    var name = 'RUA ' + ctrl.ruaNumber + ' Limits';
    ExcelService.export(excelData, name, {withTimeStamp: true});
  };

  ctrl.buildIsotopeAmountValueMap = function(inventoryMaterials) {
    return inventoryMaterials.reduce(function(materials, currentMaterial) {
    if (typeof currentMaterial.materialRadionuclides !== "undefined") {
      currentMaterial.materialRadionuclides.forEach(function(materialRadionuclide) {
        var key = materialRadionuclide.uaLimit.id;
        var material = materials[key];
        if (!material) {
          materials[key] = {
            totalAmount: null,
            totalVolume: null,
            totalElementalMass: null,
            totalNetMass: null
          };
          material = materials[key];
        }

        material.totalAmount = material.totalAmount + materialRadionuclide.currentAmount;
        material.totalVolume = material.totalVolume + materialRadionuclide.currentVolume;
        material.totalElementalMass = material.totalElementalMass + materialRadionuclide.currentElementalMass;
        material.totalNetMass = material.totalNetMass + materialRadionuclide.currentNetMass;
      });

    }
      return materials;
    }, {});
  };

});
