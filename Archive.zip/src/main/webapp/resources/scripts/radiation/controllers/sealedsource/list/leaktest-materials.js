'use strict';

angular.module('app').controller('LeakTestMaterialsCtrl', function($location, $rootScope, $templateCache, $uibModal, page, FileSaver, ConfirmModelService, PrintService, SealedSourceService, SurveyService, StaticCollections, TableHeaderCollections, uiGridConstants, UtilService, ExcelService) {
  var ctrl = this;
  ctrl.download = ExcelService.sealedSourceExcel;
  ctrl.fileName = "Leak Test";

  ctrl.init = function() {
    ctrl.totalItems = page.totalCount;
    ctrl.data = page.data;
    ctrl.buttonList = [
      {label: "Print Leak Tests List", action: ctrl.printLeakTests},
      {label: "Batch Update Leak Tests", action: ctrl.batchUpdateLeakTests}
    ];
    ctrl.getTableHeader();
  };

  ctrl.getTableHeader = function() {
    ctrl.createTableHeader();
    ctrl.getTableFilters();
  };

  ctrl.createTableHeader = function() {
    ctrl.tableHeader = {
      EDIT: Object.assign({}, angular.copy(TableHeaderCollections.EDIT), {field: 'edit', cellTemplate: "edit-sealedsource.html"}),
      MATERIAL: {field: 'id', displayName: 'Material #'},
      RUA: Object.assign({}, angular.copy(TableHeaderCollections.RUA), {field: 'ua.number'}),
      TEST_ASSIGNEE_LAST_NAME: {
        field: 'leakTests.testedBy.lastName',
        displayName: 'Performed By Last Name',
        cellTemplate: '<div class="ui-grid-cell-contents">{{ row.entity.leakTests[0].testedBy.lastName }}</div>',
        filters: [{
          mappingColumns: ['testedBy.lastName'],
          prefix: 'l'
        }]
      },
      TEST_ASSIGNEE_FIRST_NAME: {
        field: 'leakTests.testedBy.firstName',
        displayName: 'Performed By First Name',
        cellTemplate: '<div class="ui-grid-cell-contents">{{ row.entity.leakTests[0].testedBy.firstName }}</div>',
        filters: [{
          mappingColumns: ['testedBy.firstName'],
          prefix: 'l'
        }]
      },
      PI_LAST_NAME: Object.assign({}, angular.copy(TableHeaderCollections.PI_LAST_NAME), {field: 'ua.pi.lastName'}),
      PI_FIRST_NAME: Object.assign({}, angular.copy(TableHeaderCollections.PI_FIRST_NAME), {field: 'ua.pi.firstName'}),
      RADIO_NUCLIDE_NAMES: {
        field: 'radionuclideNameString',
        displayName: 'Radionuclide Names',
        filters: [{
          filterType: 'TRANSIENT'
        }]
      },
      INITIAL_DATE: Object.assign({}, angular.copy(TableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'initialDate',
        displayName: 'Reference Date'
      }),
      LOCATION: {
        field: 'storageLocation',
        displayName: 'Location',
        cellTemplate: '<div class="ui-grid-cell-contents">{{ row.entity.storageLocation.buildingDisplayName }} - {{row.entity.storageLocation.roomNumber}}</div>',
        filters: [{
          mappingColumns: ['storageLocation.buildingPrimaryName', 'storageLocation.roomNumber'],
          name: "storageLocation",
          aggregator: 'OR'
        }]
      },
      ORIGINAL_ACTIVITY_IN_MCI: {
        field: 'requestedAmount',
        displayName: 'Original Activity in mCi',
        filters: [{
          filterType: 'TRANSIENT'
        }]
      },
      CURRENT_ACTIVITY_IN_MCI: {
        field: 'currentAmount',
        displayName: 'Current Activity in mCi',
        filters: [{
          filterType: 'TRANSIENT'
        }]
      },
      STATUS: Object.assign({}, angular.copy(TableHeaderCollections.STATUS), {field: 'inventoryStatusType'}),
      DUE_DATE: Object.assign({}, angular.copy(TableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'nextDue',
        displayName: 'Due Date'
      })
    };
    ctrl.columns = Object.values(ctrl.tableHeader);
  };

  ctrl.getTableFilters = function() {
    var materialStatuses = _.map(StaticCollections.materialStatuses, function(value, key) {
      return {label: value, value: key};
    });
    ctrl.getSortedFilters(materialStatuses);
  };

  ctrl.getSortedFilters = function(materialStatuses, testStatuses) {
    ctrl.tableHeader.STATUS.filter.options = UtilService.sortUniqUnion(ctrl.tableHeader.STATUS.filter.options, materialStatuses, 'label');
  };

  ctrl.getState = function(state) {
    var storageLocationSort = _.find(state.sort, {sortColumn: 'storageLocation.buildingPrimaryName'});
    if (!storageLocationSort) {
      state.sort.push({sortColumn: 'storageLocation.buildingPrimaryName', sortDirection: 'asc'});
    }
    var request = SealedSourceService.getAllLeakTestMaterialsByCampus({}, state).$promise;
    request.then(function(value) {
      ctrl.data = value.data;
    });
    return request;
  };

  ctrl.printLeakTests = function() {
    if (ctrl.data.length > 0) {
      PrintService.openInTab('printLeakTests', ({}, _.map(ctrl.data, 'id')));
    } else {
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.INFO, {header: "Print", message: "No Data Found"});
    }
  };

  ctrl.batchUpdateLeakTests = function(data, externalDataCallback) {
    if (data.length > 0) {
      $uibModal.open({
        templateUrl: 'resources/scripts/radiation/controllers/sealedsource/list/batch-update.html',
        controller: 'BatchUpdateLeakTestCtrl',
        controllerAs: 'ctrl',
        size: 'lg',
        windowTopClass: 'email-model',
        backdrop: 'static',
        resolve: {
          materials: function() {
            return data;
          },
          inspectors: function(SurveyService) {
            return SurveyService.getSurveyInspectors().$promise;
          }
        }
      }).closed.then(function() {
        ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS, {message: 'Leak Test batch updates successfully saved.'});
        externalDataCallback(true);
      });
    } else {
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.INFO, {
        header: "Batch Update Leak Tests",
        message: "No Data Found"
      });
    }
  };
})

  .run(function($templateCache) {
    $templateCache.put('edit-sealedsource.html',
      '<div class="edit-link">' +
      '<span><a href="#/sealedsources/edit/{{row.entity.id}}" class="glyphicon glyphicon-edit"><span class="hideEditText">Edit</span></a></span></div>');
    $templateCache.put('table-testable-materials.html', '<div id="testableMaterialsList" ui-grid="ctrl.gridOptions" class="data-grid" ng-if="ctrl.gridOptions.data" ui-grid-pinning ui-grid-pagination></div>');
  });
