'use strict';

angular.module('app').controller('RuaPendingListCtrl', function($q, $templateCache, StaticCollections, TableService,
  TableHeaderCollections, AmendmentService, UaService, ExcelService, TypesService, UtilService,
  PersonService, PermissionService, profile, data) {
  var ctrl = this;
  ctrl.download = ExcelService.pendingRuAExcel;
  ctrl.report = "PENDING-RUA";
  ctrl.currentUser = profile;
  ctrl.isAdmin = PersonService.isAdmin;
  ctrl.addRecordUrl = !ctrl.isAdmin ? '' : '/rua/create';
  var tableHeaderCollections = {};

  ctrl.init = function() {
    if (ctrl.isAdmin) {
      ctrl.buttonList = [
        {label: "Email List", action: ctrl.emailList}
      ];
    }

    ctrl.totalItems = data.totalCount;
    var filteredData = data.data;
    var displayExpandIcon = false;
    for (var i = 0; i < filteredData.length; i++) {
      if (!filteredData[i].amendmentId) {
        filteredData[i].subGridOptions = {
          disableRowExpandable: true
        };
      } else {
        displayExpandIcon = true;
        filteredData[i].SUB_TABLE_HEADING = "Summary Of Changes";
      }
    }
    ctrl.data = filteredData;
    tableHeaderCollections = angular.copy(TableHeaderCollections);
    ctrl.getTableHeader(displayExpandIcon);
  };

  ctrl.getTableHeader = function(displayExpandIcon) {
    tableHeaderCollections.PI_LAST_NAME.width = '130';
    tableHeaderCollections.PI_FIRST_NAME.width = '130';
    tableHeaderCollections.REQUESTOR_LAST_NAME.width = '130';
    tableHeaderCollections.REQUESTOR_FIRST_NAME.width = '130';

    tableHeaderCollections.DATE_RANGE_SHORT.field = 'createdDate';
    tableHeaderCollections.DATE_RANGE_SHORT.displayName = 'Requested Date';
    tableHeaderCollections.DATE_RANGE_SHORT.width = '130';

    tableHeaderCollections.REQUEST_STATUS.field = 'amendmentSubmitted';
    tableHeaderCollections.REQUEST_STATUS.cellTemplate = '<span>{{row.entity.amendmentSubmitted || row.entity.uaSubmitted ? "Submitted" : "In Process"}}</span>';

    tableHeaderCollections.EDIT.cellTemplate = $templateCache.get('edit-expand.html');
    tableHeaderCollections.EDIT.width = displayExpandIcon ? '70' : '50';
    tableHeaderCollections.AMENDMENT_NUMBER.width = '110';
    tableHeaderCollections.AMENDMENT_NUMBER.cellTemplate = '<div class="yes-no-icon"> <span>{{row.entity.amendment}}</span></div>';
    ctrl.columns = ctrl.colDefs();

    ctrl.getTableFilters();
  };

  ctrl.emailList = function() {
    TableService.searchAndDisplayEmail(ctrl.state || Object.assign({}, UtilService.searchDefaults, { pagination: { itemPerPage: ctrl.totalItems }, category: 'PENDING' }), "/rua/pending/email/download");
  };

  ctrl.getState = function(state) {
    var amendmentRequestFound = _.find(state.filter, {'filterColumn': 'amendmentSubmitted'});
    if (amendmentRequestFound) {
      if (amendmentRequestFound.filterTerm) {
        state.filter.push({filterColumn: "uaSubmitted", filterTerm: amendmentRequestFound.filterTerm, strictSelected: "OR"});
      } else {
        state.filter.push({filterColumn: "uaSubmitted", filterTerm: amendmentRequestFound.filterTerm, strictSelected: "AND"});
      }
    }
    ctrl.state = state;
    return $q(function(resolve, reject) {
      state['category'] = 'PENDING';
      UaService.search({}, state)
        .$promise
        .then(function(data) {
          for (var i = 0; i < data.length; i++) {
            if (!data[i].amendmentId) {
              data[i].subGridOptions = {
                disableRowExpandable: true
              };
            } else {
              data[i].SUB_TABLE_HEADING = "Summary Of Changes";
            }
          }
          return resolve(data);
        });
    });

  };

  ctrl.onRowExpanded = function(row) {
    return new Promise(function(resolve, reject) {
      AmendmentService
        .getUaAmendment({amendmentId: row.amendmentId})
        .$promise
        .then(function(data) {
          var subTableData = [];
          for (var i = 0; i < data.amendmentItems.length; i++) {
            subTableData.push({
              category: data.amendmentItems[i].tableName,
              item: data.amendmentItems[i].columnName,
              oldValue: data.amendmentItems[i].oldValue,
              newValue: data.amendmentItems[i].newValue
            });
          }
          var doc = {
            SUB_TABLE_HEADERS: [
              tableHeaderCollections.CATEGORY,
              tableHeaderCollections.ITEM,
              tableHeaderCollections.OLD_VALUE,
              tableHeaderCollections.NEW_VALUE
            ],
            SUB_TABLE_DATA: subTableData
          };
          return resolve(doc);
        });
    });
  };

  ctrl.colDefs = function() {
    var list = [
      tableHeaderCollections.EDIT,
      tableHeaderCollections.RUA,
      tableHeaderCollections.AMENDMENT_NUMBER,
      tableHeaderCollections.RUA_TYPE,
      tableHeaderCollections.PI_LAST_NAME,
      tableHeaderCollections.PI_FIRST_NAME,
      tableHeaderCollections.REQUESTOR_LAST_NAME,
      tableHeaderCollections.REQUESTOR_FIRST_NAME,
      tableHeaderCollections.DATE_RANGE_SHORT,
      tableHeaderCollections.COMMENTS,
      tableHeaderCollections.SUMMARY_OF_CHANGES,
      tableHeaderCollections.REQUEST_STATUS
    ];

    if (ctrl.isAU) {
      list = list.filter(function(item) {
        return item !== tableHeaderCollections.EDIT;
      });
    }

    return list;
  };

  ctrl.getTableFilters = function() {
    tableHeaderCollections.RUA_TYPE.filter.selectOptions = UtilService.sortUniqUnion(tableHeaderCollections.RUA_TYPE.filter.selectOptions, StaticCollections.UATypesHash, 'label');
    tableHeaderCollections.REQUEST_STATUS.filter.selectOptions = UtilService.sortUniqUnion(tableHeaderCollections.REQUEST_STATUS.filter.selectOptions, StaticCollections.requestTypesHash, 'label');
  };
})
.run(function($templateCache) {
  $templateCache.put('edit-expand.html',
    '<div class="edit-link">' +
    ' <span><a href="#/rua/{{row.entity.id}}" class="glyphicon glyphicon-edit"><span class="hideEditText">Edit</span></a></span>' +
    ' <span class="ui-grid-row-header-cell ui-grid-expandable-buttons-cell"><i ng-class="{ \'ui-grid-icon-plus-squared\' : row.entity.amendmentId && !row.isExpanded, \'ui-grid-icon-minus-squared\' : row.isExpanded, \'ng-grid-cell\': row.entity.subGridOptions.data.length == 0 }" ng-click="grid.api.expandable.toggleRowExpansion(row.entity)"></i></span>' +
    ' </div>');
});
