'use strict';

angular.module('app').controller('MaterialRequestCtrl', function($window, $location, $route, $uibModal, ConfirmModelService, PersonService, InventoryService, StaticCollections, TypesService, UaService, material, profile, settings) {
  var ctrl = this;

  ctrl.currentUser = profile;
  ctrl.isEdit = !!material.id;
  ctrl.useAuthorizations = [];
  ctrl.settings = settings;
  ctrl.isAdmin = PersonService.isAdmin;

  ctrl.init = function() {
    ctrl.material = material;
    ctrl.material.materialRadionuclides = ctrl.material.materialRadionuclides || [];
    if (ctrl.isEdit || $route.current.params.ruaId) {
      var uaId = (ctrl.material.ua && ctrl.material.ua.id) ? ctrl.material.ua.id : $route.current.params.ruaId;
      ctrl.selectUa(uaId);
    } else {
      UaService.getUaListByStatusAndTypeAndCampusCode({
        uaStatus: StaticCollections.getKeyByValue(StaticCollections.uaStatusHash, "Active"),
        uaType: StaticCollections.getKeyByValue(StaticCollections.uaTypeHash, "Radioactive Materials"),
        campusCode: ctrl.currentUser.campus.code
      }, {}).$promise.then(function(response) {
        ctrl.useAuthorizations = response;
      });
    }

    TypesService.getPhysicalFormsList({}, {}).$promise.then(function(response) {
      ctrl.physicalFormsList = response;
    });

    TypesService.getFrequencyList({}, {}).$promise
      .then(function(response) {
        ctrl.materialFrequencyType = angular.copy(response);
      });
  };

  ctrl.typeaheadLabel = function(ua, value) {
    if (ua && typeof ua !== 'string') {
      var radionuclides = value ? radionuclidesFilter(ua, value) : [];
      var label = 'RUA # ' + ua.number + ' ( ' + ua.pi.lastName + ', ' + ua.pi.firstName + ' )';
      label = radionuclides.length > 0 ? label.concat(' ( ' + radionuclides.join(' / ') + ' )') : label;
      return label;
    }
    return ua;
  };

  function radionuclidesFilter(ua, value) {
    return ua.radionuclides.filter(function(isotope) {
      return value.split(' ').some(function(input) {
        return isotope.toLowerCase().indexOf(input.toLowerCase()) !== -1;
      });
    });
  }

  ctrl.selectUa = function(uaId) {
    UaService.get({uaId: uaId}).$promise.then(function(uaDetail) {
      ctrl.material.ua = uaDetail;

      if (ctrl.isEdit) {
        ctrl.material.storageLocation = _.find(ctrl.material.ua.uaBundle.uaBundleLocations, function(uaBundleLocation) {
          return ctrl.material.storageLocation.id === uaBundleLocation.location.id;
        }).location;
      }
    });
  };

  ctrl.openFormModal = function(materialRadionuclide) {
    $uibModal.open({
      templateUrl: 'resources/scripts/radiation/controllers/material/request/request-material-form.html',
      backdrop: 'static',
      size: 'lg',
      keyboard: false,
      controllerAs: '$ctrl',
      controller: function($uibModalInstance) {
        var $ctrl = this;
        $ctrl.uaLimits = _.sortBy(ctrl.material.ua.uaLimits, ['radionuclide.name']);

        $ctrl.init = function() {
          $ctrl.materialRadionuclide = materialRadionuclide || {};

          if (materialRadionuclide) {
            $ctrl.materialRadionuclide.uaLimit = _.find($ctrl.uaLimits, { 'id': $ctrl.materialRadionuclide.uaLimit.id });
            $ctrl.calculateRadionuclidePossessionAmount($ctrl.materialRadionuclide.uaLimit.id);
          }
        };

        $ctrl.gramsToCuries = function(grams, mciPerGram) {
          return _.multiply($ctrl.radionuclidePossessionAmount, $ctrl.selectedLimit.radionuclide.activityMciPerGram);
        };

        $ctrl.calculateRadionuclidePossessionAmount = function(limitId) {
          if (limitId) {
            $ctrl.selectedLimit = _.find($ctrl.uaLimits, {'id': limitId});
            $ctrl.isSourceOrSpecialNuclearMaterial = $ctrl.selectedLimit.radionuclide.isSourceMaterial || $ctrl.selectedLimit.radionuclide.isSpecialNuclearMaterial;
            $ctrl.requestType = $ctrl.isSourceOrSpecialNuclearMaterial ? 'requestElementalMass' : 'requestAmount';

            var request = { uaId: ctrl.material.ua.id, uaLimitId: limitId };
            InventoryService.calculateRadionuclidePossessionAmount(request).$promise.then(function(result) {
              $ctrl.radionuclidePossessionAmount = result.radionuclidePossessionAmount;
            });

            var index = _.findIndex(ctrl.material.materialRadionuclides, function(materialRadionuclide) { return materialRadionuclide.uaLimit.id === limitId; });
            if (index > -1) {
              $ctrl.materialRadionuclide = _.cloneDeep(ctrl.material.materialRadionuclides[index]);
            }
          }
        };

        $ctrl.calculateCurrentPossessionWithRequest = function(currentPossessionAmount) {
          var currentRequestAmount = _(ctrl.material.materialRadionuclides)
            .filter(function(materialRadionuclide) {
              return !materialRadionuclide.id && materialRadionuclide.uaLimit.id === $ctrl.selectedLimit.id;
            })
            .reduce(function(requestAmount, materialRadionuclide) {
              return requestAmount += (materialRadionuclide[$ctrl.requestType] || 0);
            }, 0);

          return currentPossessionAmount + currentRequestAmount;
        };

        $ctrl.validateMaterialRadionuclide = function() {
          $ctrl.errors = {};
          if ($ctrl.isSourceOrSpecialNuclearMaterial) {
            if (!$ctrl.materialRadionuclide.requestElementalMass) {
              $ctrl.errors.elementalMass = true;
            }
            if ($ctrl.materialRadionuclide.uaLimit.containedVialLimit && ($ctrl.materialRadionuclide.requestElementalMass > $ctrl.materialRadionuclide.uaLimit.containedVialLimit)) {
              $ctrl.errors.containedVial = true;
            }
            if ($ctrl.materialRadionuclide.uaLimit.containedPossLimit && ($ctrl.materialRadionuclide.requestElementalMass > $ctrl.materialRadionuclide.uaLimit.containedPossLimit)) {
              $ctrl.errors.containedPoss = true;
            }
            if (!$ctrl.materialRadionuclide.requestNetMass) {
              $ctrl.errors.requestNetMass = true;
            }
            if ($ctrl.materialRadionuclide.requestNetMass > $ctrl.materialRadionuclide.uaLimit.vialPossessionLimit) {
              $ctrl.errors.possessionVial = true;
            }
            if ($ctrl.materialRadionuclide.requestNetMass > $ctrl.materialRadionuclide.uaLimit.requestedPossessionLimit) {
              $ctrl.errors.totalPossession = true;
            }
            if ($ctrl.materialRadionuclide.requestNetMass && !$ctrl.errors.possessionVial && !$ctrl.errors.totalPossession && $ctrl.materialRadionuclide.uaLimit.radionuclide.name === 'U-233' || $ctrl.materialRadionuclide.uaLimit.radionuclide.name === 'U-235') {
              $ctrl.materialRadionuclide.requestElementalMass = $ctrl.materialRadionuclide.requestNetMass * ($ctrl.materialRadionuclide.uaLimit.enrichment / 100);
            } else if ($ctrl.materialRadionuclide.uaLimit.radionuclide.name === 'U-233' || $ctrl.materialRadionuclide.uaLimit.radionuclide.name === 'U-235' && (!$ctrl.materialRadionuclide.requestNetMass || $ctrl.errors.possessionVial || $ctrl.errors.totalPossession)) {
              $ctrl.materialRadionuclide.requestElementalMass = 0;
            }
          } else {
            if (!$ctrl.materialRadionuclide.requestAmount) {
              $ctrl.errors.amount = true;
            }
          }

          if ($ctrl.materialRadionuclide.requestAmount
              && $ctrl.materialRadionuclide.requestAmount > ($ctrl.materialRadionuclide.uaLimit.requestedPossessionLimit - $ctrl.calculateCurrentPossessionWithRequest($ctrl.radionuclidePossessionAmount))) {
            $ctrl.errors.uaLimit = true;

          }

          if ($ctrl.materialRadionuclide && $ctrl.materialRadionuclide.uaLimit
            && $ctrl.materialRadionuclide.requestAmount > $ctrl.materialRadionuclide.uaLimit.vialPossessionLimit) {
            $ctrl.errors.vialLimit = true;
          }

          return _.isEmpty($ctrl.errors);
        };

        $ctrl.onSave = function(form) {
          if ($ctrl.validateMaterialRadionuclide() && form.$valid) {
            var index = _.findIndex(ctrl.material.materialRadionuclides, function(materialRadionuclide) { return materialRadionuclide.uaLimit.id === $ctrl.materialRadionuclide.uaLimit.id; });
            if (index === -1) {
              ctrl.material.materialRadionuclides.push($ctrl.materialRadionuclide);
            } else {
              ctrl.material.materialRadionuclides[index] = _.cloneDeep($ctrl.materialRadionuclide);
            }
            $ctrl.cancel();
          }
        };

        $ctrl.cancel = function() {
          $uibModalInstance.close();
        };

        $ctrl.init();
      }
    });
  };

  ctrl.requestMaterial = function(form) {
    ctrl.errors = {};
    if (!ctrl.material.materialRadionuclides.length) {
      ctrl.errors.materialRadionuclide = true;
    }

    if (ctrl.material.isBackfill) {
      if (!ctrl.material.initialDate) {
        ctrl.errors.initialDate = true;
      }
    }

    if (ctrl.material.isBackfill && ctrl.material.isMaterialForTest) {
      if (!ctrl.material.testFrequency) {
        ctrl.errors.testFrequency = true;
      }
    }

    if (form.$valid && _.isEmpty(ctrl.errors)) {
      InventoryService.createMaterial({}, ctrl.material).$promise.then(function(response) {
        ctrl.material = response;

        ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS, {message: ctrl.getSaveMessage()}, null, function() {
          if (ctrl.material.isBackfill) {
            $location.path('/materials').search({ruaId: ctrl.material.ua.id});
          } else {
            $location.path('/materials/request-edit/' + response.id);
          }
        });
      });
    }
  };

  ctrl.getSaveMessage = function() {
    if (ctrl.material.isBackfill) {
      var isSealedSource = _.some(ctrl.material.materialRadionuclides, function(materialRadionuclide) {
        return materialRadionuclide.uaLimit.isSealedSource;
      });
      return 'Material number ' + ctrl.material.id + ' is added to Inventory' + (isSealedSource ? '<strong> Sealed Sources.</strong>' : '.');
    } else {
      return 'Request number ' + ctrl.material.id + ' successfully saved';
    }
  };

  ctrl.findLimitIndex = function(limit) {
    return _.findIndex(ctrl.material.ualimits, function(materialLimit) {
      return limit.id === materialLimit.id;
    });
  };

  ctrl.deleteRequest = function() {
    ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE, {message: 'Are you sure you want to delete this material request?'}, function(answer) {
      InventoryService.deleteMaterial({materialId: ctrl.material.id}).$promise.then(function() {
        ctrl.onCancel();
      });
    });
  };

  ctrl.onCancel = function() {
    if (ctrl.isAdmin) {
      var returnTo = $route.current.params.cancel === 'INVENTORY' ? '/materials' : '/materials/pending';
      $location.path(returnTo).search('cancel', null);
    } else {
      $window.history.back();
    }
  };

  ctrl.init();

  ctrl.clearTestValues = function() {
    ctrl.material.idNumber = "";
    ctrl.material.ssd = "";
    ctrl.material.testFrequency = null;
  };

  ctrl.clearBackfillMaterialDetail = function() {
    ctrl.material.initialDate = "";
    ctrl.material.isMaterialForTest = false;
    ctrl.clearTestValues();
  };
});
