'use strict';

angular.module('app').controller('SealedSourceTab', function($location, $scope, TableHeaderCollections, InventoryService) {
  var sealedSourceTabCtrl = this;

  sealedSourceTabCtrl.init = function(ruaId) {
    sealedSourceTabCtrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
    sealedSourceTabCtrl.getTableHeader();
    sealedSourceTabCtrl.getData(ruaId);
  };

  sealedSourceTabCtrl.getTableHeader = function() {
    sealedSourceTabCtrl.tableHeaders = {
      MATERIAL: {
        field: 'id',
        displayName: 'Material #'
      },
      // Todo proper field name, once sealed source details story is done
      ID_NUMBER: {
        field: 'idNumber',
        displayName: 'Id Number'
      },
      RADIONUCLIDE: {
        field: 'radionuclideNameString',
        displayName: 'Radionuclide'
      },
      PHYSICAL_FORM: {
        field: 'physicalForm',
        displayName: 'Physical Form'
      },
      RECEIVED_ACTIVITY: {
        field: 'requestedAmount',
        displayName: 'Received Activity',
        width: 150
      },
      REMAINING_ACTIVITY: {
        field: 'remainingActivity',
        displayName: 'Remaining Activity',
        width: 150
      },
      INITIAL_DATE: Object.assign({}, angular.copy(sealedSourceTabCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'initialDate',
        displayName: 'Reference Date (mm/dd/yyyy)',
        width: 200
      }),
      LABEL: {
        field: 'label',
        displayName: 'Label',
        enableFiltering: false
      }
    };
    sealedSourceTabCtrl.columns = Object.values(sealedSourceTabCtrl.tableHeaders);
  };

  sealedSourceTabCtrl.getData = function(uaId) {
    InventoryService.getMaterialsByUaAndInventoryStatusType({
      uaId: uaId,
      inventoryStatusType: 'IN_INVENTORY',
      isSealedSource: true
    }, {}).$promise.then(function(response) {
      sealedSourceTabCtrl.data = response;
    });
  };
});
