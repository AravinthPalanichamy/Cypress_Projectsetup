'use strict';
angular.module('app').controller('HomeCtrl', function($window, $location, $http, StaticCollections, UaService, profile, PersonService, InventoryService) {
  var ctrl = this;
  ctrl.myUas = null;
  ctrl.myUseAuthorizations = null;
  ctrl.init = function() {
    ctrl.currentUser = profile;
    PersonService.getDetail({userId: ctrl.currentUser.userId}).$promise
      .then(function(response) {
        ctrl.personDetail = response;
      });

    UaService.getUaListByPI({userId: ctrl.currentUser.userId}, {}).$promise
      .then(function(response) {
        if (response[0]) {
          ctrl.myUas = response;
        }
      });

    ctrl.isAdmin = _.includes(ctrl.currentUser.roles, StaticCollections.rolesHash.RADIATION_ADMIN.code);
    ctrl.isInspector = _.includes(ctrl.currentUser.roles, StaticCollections.rolesHash.INSPECTOR.code);
    ctrl.isRSCM = _.includes(ctrl.currentUser.roles, StaticCollections.rolesHash.RADIATION_SAFETY_COMMITTEE_MEMBER.code);
    ctrl.isRP = _.includes(ctrl.currentUser.roles, StaticCollections.rolesHash.RESPONSIBLE_PERSON.code);
    ctrl.isAU = _.includes(ctrl.currentUser.roles, StaticCollections.rolesHash.AUTHORIZED_USER.code);

    ctrl.isEhsAdmin = ctrl.isAdmin || ctrl.isInspector;
    ctrl.isUaMember = ctrl.isRP || ctrl.isAU;

    ctrl.employmentStatuses = StaticCollections.employmentStatuses;
    ctrl.genders = StaticCollections.genders;

    ctrl.getPendingUseAuthorizations = function() {
      if (ctrl.isEhsAdmin || ctrl.isRSCM) {
        return UaService.getUaListByStatusAndTypeAndCampusCode({
          uaStatus: StaticCollections.getKeyByValue(StaticCollections.uaStatusHash, "Pending Review"),
          uaType: 'ALL',
          campusCode: ctrl.currentUser.campus.code
        }, {});
      } else {
        return [];
      }
    };
    ctrl.pendingUseAuthorizations = ctrl.getPendingUseAuthorizations();


    ctrl.getMyUseAuthorizations = function() {
      var useAuthorizations = [];

      UaService.getUaListByMember({userId: ctrl.currentUser.userId}, {}).$promise
        .then(function(res) {
          res.map(function(ua) {
            useAuthorizations.push(ua);
          });

          if (ctrl.isRP) {
            UaService.getUaListByPI({userId: ctrl.currentUser.userId}, {}).$promise
              .then(function(res) {
                res.map(function(uaForPI) {
                  useAuthorizations.push(uaForPI);
                });
              });
          }
        })
        .then(function() {
          ctrl.myUseAuthorizations = useAuthorizations;
        });
    };
    ctrl.getMyUseAuthorizations();

    if (ctrl.isEhsAdmin) {
      ctrl.backFillInventoryUas = [];

      InventoryService.getMaterialRequestsByRoleAndStatusAndBackFill({
        userId: ctrl.currentUser.userId,
        requestStatusId: 1,
        isBackFill: true
      }, {}).$promise
        .then(function(response) {
          response.forEach(function(obj) {
            // extract the uas from inventory objects into ctrl.backFillInventoryUas
            if (!_.some(ctrl.backFillInventoryUas, (obj.uaPlannedWork.ua))) {
              obj.uaPlannedWork.ua.requestedInventory = [];
              ctrl.backFillInventoryUas.push(obj.uaPlannedWork.ua);
            }
          });
          // iterate through ctrl.backFillInventoryUas and inventory objects to group by ua
          ctrl.backFillInventoryUas.forEach(function(ua) {
            response.forEach(function(obj) {
              if (obj.uaPlannedWork.ua.id === ua.id) {
                ua.requestedInventory.push(obj);
              }
            });
          });
        });

      UaService.cleanUp({}, {}).$promise
        .then(function() {

        });
    }
  };

  ctrl.reviewBackFillInventory = function(uaId) {
    $location.path('/inventory/back-fill-receive/ua/' + uaId);
  };

  ctrl.groupBackFillByUa = function() {
    return _.groupBy(ctrl.pendingBackFillInventory, function(obj) {
      return obj.uaPlannedWork.ua.id;
    });
  };

  ctrl.hasUa = function() {
    if ((ctrl.myUas && ctrl.myUas.length) || (ctrl.myUseAuthorizations && ctrl.myUseAuthorizations.length)) {
      return true;
    } else {
      return false;
    }
  };

  ctrl.canSeeInventory = function() {
    if (ctrl.isRP || ctrl.isAU) {
      return true;
    }
    return false;
  };

  ctrl.isDelegateForUA = function(ua) {
    if (ua.uaBundle) {
      return ua.uaBundle.isCurrentUserDelegateForUA;
    }
    return false;
  };
  /**
   * Shared
   */
  ctrl.getStatus = function(status) {
    return StaticCollections.uaStatusHash[status];
  };

  ctrl.getMyUaLink = function(ua) {
    if (ua.statusType === 'DRAFT' || ua.statusType === 'DECLINED') {
      return '#/ua/' + ua.id;
    } else {
      return '#/ua/' + ua.id + '/summary/';
    }
  };

  ctrl.getUaLink = function(ua) {
    return '#/admin/ua/' + ua.id;
  };

  ctrl.canSeeUA = function(ua) {
    return (ua.pi.userId === ctrl.currentUser.userId ||
    ctrl.isDelegateForUA(ua) ||
    (ua.statusType === 'PENDING_REVIEW' || ua.statusType === 'ACTIVE'));
  };

  ctrl.href = function(url) {
    $location.path(url);
  };

  /**
   * Card component
   * @returns {{show: boolean, toggle: Function}}
   * @constructor
   */
  var card = function(show) {
    show = show || false;

    return {
      show: show,
      toggle: function() {
        this.show = !this.show;
      }
    };
  };

  /**
   * New Use Authorizations Card
   */
  ctrl.newUasCard = card(true);

  /**
   * Recent Activity Card
   */
  ctrl.recentActivityCard = card(true);
});
