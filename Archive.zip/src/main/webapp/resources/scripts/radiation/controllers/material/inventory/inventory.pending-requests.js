'use strict';

angular.module('app').controller('InventoryPendingRequestCtrl', function($location, InventoryService, PersonService, SettingsService, TableHeaderCollections) {
  var ctrl = this;

  ctrl.data = [];
  ctrl.buttonList = [];
  ctrl.tableHeaderCollections = _.cloneDeep(TableHeaderCollections);

  ctrl.init = function(parent) {
    ctrl.ruaId = parent.rua.id;
    ctrl.getTableData(ctrl.ruaId);
    ctrl.columns = ctrl.defineTable();

    SettingsService.getSettings().$promise.then(function(settings) {
      if (settings.requestMaterials || PersonService.isAdmin) {
        ctrl.buttonList.push({label: 'New Request', action: ctrl.newMaterialRequest});
      }
    });
  };

  ctrl.newMaterialRequest = function() {
    $location.path('materials/request-create').search({cancel: 'INVENTORY', ruaId: ctrl.ruaId});
  };

  ctrl.getTableData = function(uaId) {
    InventoryService.getMaterialsByUaAndInventoryStatusType({
      uaId: uaId,
      inventoryStatusType: 'REQUESTED'
    }, function(response) {
      ctrl.data = response;
    });
  };

  ctrl.defineTable = function() {
    return [
      {displayName: 'Material #', field: 'id', width: 100},
      {displayName: 'Radionuclide', field: 'radionuclideNameString'},
      {displayName: 'Requested Amount (mCi)', field: 'requestedAmount', cellFilter: 'scientific'},
      {
        displayName: 'Requested Volume (microliter)', field: 'requestedVolume', cellFilter: 'scientific',
        headerCellTemplate: '<div class="ui-grid-cell-contents ui-grid-header-cell-label">Requested Volume(&micro;l)</div>'
      },
      {displayName: 'Requested Mass (grams)', field: 'requestedElementalMass', cellFilter: 'scientific'},
      {displayName: 'Requested Sample Mass (grams)', field: 'requestedNetMass', cellFilter: 'scientific'},
      {
        displayName: 'Building & Room', field: 'storageLocation',
        cellTemplate: '<div class="ui-grid-cell-contents">{{ row.entity.storageLocation.buildingPrimaryName }} - {{row.entity.storageLocation.roomNumber}}</div>'
      },
      {displayName: 'Location', field: 'subLocation'}
    ];
  };
});
