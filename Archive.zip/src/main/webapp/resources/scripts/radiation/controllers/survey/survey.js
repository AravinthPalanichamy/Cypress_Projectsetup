'use strict';

angular.module('app').controller('SurveyCtrl', function($location, PersonService, SurveyService, UaService, BundleService, StaticCollections, profile, surveyInspectors, survey, EmailService, ConfirmModelService) {
  var ctrl = this;
  ctrl.survey = survey;
  ctrl.currentUser = profile;
  ctrl.useAuthorizations = [];
  ctrl.surveyTypes = Object.keys(StaticCollections.surveyTypes);
  ctrl.surveyStatuses = Object.keys(StaticCollections.surveyStatuses);
  ctrl.surveyInspectors = surveyInspectors;
  ctrl.inspections = [];
  ctrl.dscs = [];
  ctrl.selectedInspection = null;
  ctrl.ruaTypes = StaticCollections.uaTypeHash;
  ctrl.panels = {
    GENERAL: 'General'
  };

  ctrl.typeaheadLabel = UaService.typeaheadLabel;

  ctrl.init = function(survey) {
    if (survey.id) {
      ctrl.panels.DOCUMENTS = 'Documents';
      ctrl.panels.CHANGELOG = 'Changelog';
      ctrl.survey = survey;
      ctrl.survey.assignedTo = _.find(ctrl.surveyInspectors, {id: ctrl.survey.assignedTo ? ctrl.survey.assignedTo.id : null});
      ctrl.survey.performedBy = _.find(ctrl.surveyInspectors, {id: ctrl.survey.performedBy ? ctrl.survey.performedBy.id : null});
      ctrl.ruaHolder = ctrl.survey.ua.pi.firstName + ' ' + ctrl.survey.ua.pi.lastName;
      if (ctrl.survey.ua.coreCollection) {
        PersonService.getDscsByCollection({collectionId: ctrl.survey.ua.coreCollection.collectionId}).$promise.then(function(people) {
          ctrl.dscs = people;
        });
      }
      if (ctrl.survey.ua.csId) {
        SurveyService.getInspections({bundleId: ctrl.survey.ua.csId}).$promise.then(function(inspections) {
          ctrl.inspections = angular.copy(inspections);
          if (ctrl.survey.inspectionId) {
            ctrl.selectedInspection = _.find(ctrl.inspections, {_id: ctrl.survey.inspectionId});
            ctrl.updateSurveyFromInspection(ctrl.survey, ctrl.selectedInspection);
          }
        });
      }
    } else {
      ctrl.survey = {
        surveyType: 'RENEWAL',
        statusType: 'INCOMPLETE'
      };

      UaService.getUaListByStatusAndTypeAndCampusCode({
        uaStatus: StaticCollections.getKeyByValue(StaticCollections.uaStatusHash, "Active"),
        uaType: StaticCollections.getKeyByValue(StaticCollections.uaTypeHash, "Radioactive Materials"),
        campusCode: ctrl.currentUser.campus.code
      }, {}).$promise
        .then(function(response) {
          ctrl.useAuthorizations = response;
        });
    }

    ctrl.setPanel(ctrl.panels[$location.search().activeSurveyTab] || ctrl.panels.GENERAL);
  };

  ctrl.setPanel = function(panel) {
    ctrl.panel = panel;
    $location.search("activeSurveyTab", panel.toUpperCase());
  };

  ctrl.updateSurveyFromInspection = function(survey, selectedInspection) {
    if (selectedInspection && selectedInspection._id) {
      survey.inspectionId = selectedInspection._id;
      survey.performedDate = survey.performedDate || moment(selectedInspection.createdDate).toDate();
      survey.text = survey.text || '<p><br><br><br><a id="inspectLink" href="' + selectedInspection.deepLink + '">' + selectedInspection.deepLink + '</a></p>';
      survey.performedBy = survey.performedBy || _.find(ctrl.surveyInspectors, {userId: selectedInspection.contributedBy[0].userId});
    } else {
      survey.inspectionId = null;
      survey.performedDate = null;
      survey.performedBy = null;
    }
  };

  ctrl.onSave = function(showNotification) {
    if (ctrl.survey.ua && ctrl.survey.ua.id) {
      SurveyService.saveSurvey({}, ctrl.survey).$promise.then(function(survey) {
        // Update url when it's an add operation
        if (!ctrl.survey.id) {
          $location.url('/survey/edit/' + survey.id);
        }
        if (showNotification) {
          ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS, {message: 'Survey has been saved.'}, function() {
          });
        }
      });
    } else {
      ctrl.showErrors = true;
    }
  };

  ctrl.selectRua = function(ua) {
    ctrl.survey.ua = ua;
    if (ua) {
      ctrl.ruaHolder = ctrl.survey.ua.pi.lastName + ', ' + ctrl.survey.ua.pi.firstName;
      ctrl.showErrors = false;
    }
  };

  ctrl.openDatePicker = function(type) {
    ctrl.isOpen = {};
    ctrl.isOpen[type] = true;
  };

  ctrl.openEmail = function(selectedInspection) {
    var options = {
      addRecipients: true,
      allowEmail: false,
      addRecipientMessage: ''
    };
    ctrl.onSave(false);
    SurveyService.getEmailTemplate({surveyId: ctrl.survey.id}).$promise.then(function(notification) {
      EmailService.getMessage(ctrl.survey, buildNotification(selectedInspection ? selectedInspection.email : {}, notification), null, options, ctrl.sendNotification);
    });
  };

  ctrl.sendNotification = function(survey, notification) {
    SurveyService.sendEmail({surveyId: ctrl.survey.id}, notification).$promise.then(function(survey) {
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS, {message: 'Survey has been sent.'}, function() {
      });
      ctrl.init(survey);
    });
  };

  ctrl.onCancel = function() {
    $location.url("/survey/surveylist");
  };

  function buildNotification(emails, notification) {
    return {
      toRecipients: _.uniqBy([{
        userId: ctrl.survey.ua.pi.userId,
        firstName: ctrl.survey.ua.pi.firstName,
        lastName: ctrl.survey.ua.pi.lastName
      }].concat(emails.toRecipients || []), function(item) {
        return item.userId;
      }),
      ccRecipients: _.concat(BundleService.getLabContacts(ctrl.survey.ua.uaBundle), ctrl.dscs),
      subject: notification.subject,
      bodyHtml: notification.body
    };
  }
});
