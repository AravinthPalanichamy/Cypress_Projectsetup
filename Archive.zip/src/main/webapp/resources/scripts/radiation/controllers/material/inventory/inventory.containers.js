'use strict';

angular.module('app')
        .controller('InventoryContainersCtrl', function($uibModal, $http, $window, $timeout, FileSaver, TableHeaderCollections, StaticCollections, ConfirmModelService, InventoryService, WasteFormService, WasteService, PrintService, PersonService) {
    var ctrl = this;

    ctrl.containerData = [];
    ctrl.tableHeaderCollections = _.cloneDeep(TableHeaderCollections);
    ctrl.wasteTagTableHeaderCollection = _.cloneDeep(TableHeaderCollections);
    ctrl.wasteMaterialType = StaticCollections.wasteMaterialTypeHash;

    ctrl.init = function(parent) {
      ctrl.rua = parent.rua;
      ctrl.profile = parent.currentUser;
      ctrl.saveMessage = undefined;
      ctrl.buttonList = [];

      if (ctrl.hasContainerAccess()) {
        ctrl.buttonList.push({
          label: "Add Container",
          action: ctrl.openContainerModal
        });
      }

      ctrl.getData(ctrl.rua.id);
      ctrl.columns = ctrl.defineContainerTable();
    };

    ctrl.getData = function(uaId) {
      return InventoryService.getContainersForUa({uaId: uaId}).$promise.then(function(response) {
        ctrl.containerData = response;
        return ctrl.getWasteTags(uaId);
      });
    };

    ctrl.hasContainerAccess = function() {
      return PersonService.isAdmin || PersonService.isRP_OR_DEL;
    };

    ctrl.getWasteTags = function(ruaId) {
      return WasteService.getWasteTagByRuaId({ruaId: ruaId}).$promise.then(function(response) {
        ctrl.wasteTags = _.orderBy(response, ['lastModifiedDate'], ['desc']);
        return ctrl.wasteTags;
      });
    };

    ctrl.openContainerContentModal = function(container) {
      $uibModal.open({
        templateUrl: 'resources/scripts/radiation/components/waste-container/_container-content.html',
        controller: 'ContainerContentCtrl',
        controllerAs: '$ctrl',
        size: 'lg',
        windowTopClass: 'container-modal',
        backdrop: 'static',
        resolve: {
          container: container
        }
      }).closed.then(function() {
        ctrl.getData(ctrl.rua.id);
      });
    };

  ctrl.containerContentTransfer = function(container) {
    $uibModal.open({
      templateUrl: 'resources/scripts/radiation/components/waste-container/_container-content-transfer.html',
      controller: 'ContainerContentTransferCtrl',
      controllerAs: '$ctrl',
      size: 'md',
      windowTopClass: 'container-modal',
      backdrop: 'static',
      resolve: {
        container: container
      }
    }).closed.then(function() {
      ctrl.getData(ctrl.rua.id);
    });
  };

  ctrl.openContainerModal = function(container) {
      $uibModal.open({
        templateUrl: 'resources/scripts/radiation/components/waste-container/_container-edit.html',
        controller: 'ContainerEditCtrl',
        controllerAs: '$ctrl',
        size: 'lg',
        windowTopClass: 'container-modal',
        backdrop: 'static',
        resolve: {
          profile: ctrl.profile,
          container: container,
          rua: function() {
            return ctrl.rua;
          }
        }
      }).closed.then(function() {
        ctrl.getData(ctrl.rua.id);
      });
    };

    ctrl.openWasteTagModal = function(container, options) {
      WasteFormService.openModal(ctrl.rua, container, options, ctrl.onFormSubmit);
    };

    ctrl.onFormSubmit = function(wasteTag, options) {
      if (!wasteTag.trackingNumber) {
        ctrl.createWasteTag(wasteTag, options);
      } else {
        ctrl.updatePickupWasteTag(wasteTag, options);
      }
    };

    ctrl.createWasteTag = function(wasteTag, options) {
      WasteService.createWasteTag({ruaId: wasteTag.container.ownerRuaId}, wasteTag).$promise.then(function(response) {
        if (response.$resolved && response.trackingNumber) {
          ctrl.saveMessage = options.requestingPickup ? undefined : 'Container is successfully tagged. Waste Tag Tracking #: ' + response.trackingNumber;
          if (options.requestingPickup) {
            ctrl.requestPickup(response);
            ctrl.printWasteTag(wasteTag.container, response.trackingNumber);
          } else {
            ctrl.getData(ctrl.rua.id).then(function(res) {
              ctrl.printWasteTag(wasteTag.container, response.trackingNumber);
            });
          }
        } else if (response.errorMessage) {
          ctrl.handleErrorMessage(response.errorMessage, 'create');
        }
      });
    };

    ctrl.updatePickupWasteTag = function(wasteTag, options) {
      WasteService.updateWasteTag({ruaId: wasteTag.container.ownerRuaId}, wasteTag).$promise.then(function(response) {
        if (response.$resolved && response.trackingNumber && !response.errorMessage) {
          ctrl.saveMessage = options.requestingPickup ? undefined : 'Waste tag is updated successfully. Tracking #: ' + wasteTag.trackingNumber;
          if (options.requestingPickup) {
            ctrl.requestPickup(wasteTag);
          } else {
            ctrl.getData(ctrl.rua.id).then(function(res) {
              ctrl.printWasteTag(wasteTag.container, response.trackingNumber);
            });
          }
        } else if (response.errorMessage) {
          ctrl.handleErrorMessage(response.errorMessage, 'update');
        }
      });
    };

    ctrl.printWasteTag = function(container, trackingNumber) {
      var wTag = (_.find(ctrl.wasteTags, function(tag) {
        return tag.id === container.currentWasteTagId;
      }));

      var tNumber = trackingNumber || wTag.trackingNumber;

      WasteService.getWasteToken({trackingNumber: tNumber}).$promise
        .then(function(res) {
          PrintService.printWasteTag({token: res.token}, {})
            .$promise.then(function(response) {
            FileSaver.saveAs(response.data.file, response.data.filename);
          });
        });
    };

    ctrl.onCreateWasteTag = function(container) {
      var options = {creatingWasteTag: true};
      ctrl.openWasteTagModal(container, options);
    };

    ctrl.openRemoveConfirmation = function(container) {
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE, {message: "Are you sure you want to delete the container <strong>" + container.containerName + "</strong>?"}, function() {
        ctrl.remove(container);
      });
    };

    ctrl.remove = function(container) {
      InventoryService.removeContainer({containerId: container.id})
        .$promise
        .then(function(results) {
          ctrl.getData(ctrl.rua.id);
        });
    };

    ctrl.updateWasteTag = function(container) {
      var wasteTag = _.find(ctrl.wasteTags, function(tag) {
        return tag.id === container.currentWasteTagId;
      });

      ctrl.openWasteTagModal(container, {wasteTag: wasteTag});
    };

    ctrl.requestPickupOnContainer = function(container) {
      var wasteTag = _.find(ctrl.wasteTags, function(tag) {
        return tag.id === container.currentWasteTagId;
      });
      var options = {requestingPickup: true, wasteTag: wasteTag};

      ctrl.openWasteTagModal(container, options);
    };

    ctrl.requestPickup = function(wasteTag) {
      WasteService.requestPickup({}, wasteTag).$promise.then(function(response) {
        if (response.$resolved && !response.errorMessage) {
          ctrl.saveMessage = 'Waste tag is successfully requested for EH&S pickup. Tracking # : ' + response.trackingNumber;

          var container = _.find(ctrl.containerData, function(container) {
            return container.id === wasteTag.container.id;
          });

          InventoryService.emptyContainer({containerId: container.id}, container, function(res) {
            ctrl.getData(ctrl.rua.id);
          });
        }
      });
    };

    ctrl.getRadionuclides = function(container) {
      return _.uniq(ctrl.getMaterialNames(container.materials)).join(', ');
    };

    ctrl.getMaterialNames = function(materials) {
      return _.reduce(materials, function(names, material) {
        return material.radionuclideNameString.split(', ').concat(names);
      }, []);
    };

    ctrl.getTagTrackingNumber = function(container) {
      var wTag = !!ctrl.wasteTags.length && _.find(ctrl.wasteTags, function(tag) {
          return tag.id === container.currentWasteTagId;
        });
      return !!wTag && wTag.trackingNumber || '';
    };

    ctrl.closeMessage = function() {
      ctrl.saveMessage = undefined;
      ctrl.saveError = undefined;
    };

    ctrl.parseError = function(errorDetail) {
      return errorDetail.replace(/_/g, ' ');
    };

    ctrl.handleErrorMessage = function(errorMessage, status) {
      ctrl.saveError = 'Unable to ' + status + ' a waste tag in WASTe.';
      ctrl.saveErrorDetail = ctrl.parseError(errorMessage);
    };

    ctrl.defineContainerTable = function() {
      var use = ctrl.tableHeaderCollections.EDIT;
      use.displayName = 'Action';
      use.field = 'useContainer';
      use.enableFiltering = false;
      use.enableColumnMenu = false;
      use.width = 60;
      use.cellTemplate = 'container-use.html';

      var deleteContainer = angular.copy(ctrl.tableHeaderCollections.EDIT);
      deleteContainer.displayName = 'Remove';
      deleteContainer.field = 'id';
      deleteContainer.width = 80;
      deleteContainer.enableFiltering = false;
      deleteContainer.enableColumnMenu = false;
      deleteContainer.cellTemplate = 'container-remove-edit.html';

      var colDefs = [
        use,
        {
          displayName: 'Tracking #', field: 'currentWasteTagId',
          cellTemplate: '<div class="ui-grid-cell-contents" ng-if="row.entity.currentWasteTagId && grid.appScope.parentScope.wasteTags">{{ grid.appScope.parentScope.getTagTrackingNumber(row.entity) }}</div>'
        },
        {displayName: 'Container Name', field: 'containerName'},
        {
          displayName: 'Location',
          field: 'location',
          cellTemplate: '<div ng-if="row.entity.location" class="ui-grid-cell-contents">{{ row.entity.location.buildingDisplayName }} - {{ row.entity.location.roomNumber}}</div>'
        },
        {
          displayName: 'Radionuclide(s)',
          field: 'materials',
          cellTemplate: '<div class="ui-grid-cell-contents">{{ grid.appScope.parentScope.getRadionuclides(row.entity) }}</div>'
        },
        {displayName: 'Total Activity (mCi)', field: 'totalActivity', cellFilter: 'scientific', width: 200},
        {
          displayName: 'Total Volume (microliter)', field: 'totalVolume', cellFilter: 'scientific', width: 200,
          headerCellTemplate: '<div class="ui-grid-cell-contents ui-grid-header-cell-label">Total Volume(&micro;l)</div>'
        },
        {displayName: 'Total Net Mass (grams)', field: 'totalNetMass', cellFilter: 'scientific', width: 200},
        {displayName: 'Total Elemental Mass(grams)', field: 'totalElementalMass', cellFilter: 'scientific', width: 200},
        deleteContainer
      ];

      if (!ctrl.hasContainerAccess()) {
        colDefs.splice(0, 1);
        colDefs.splice(-1, 1);
      }
      return colDefs;
    };

    ctrl.getLabel = function(wasteTag) {
      if (wasteTag.wasteTagType === 'MIX') {
        return 'Mixed';
      } else {
        return ctrl.wasteMaterialType[wasteTag.wasteMaterialType];
      }
    };

  }
).run(function($templateCache) {
  var removeTemplate = '<div class="delete-link">'
    + '<span ng-if="!row.entity.materials.length && !row.entity.isWasteTagged"><a ng-href="" ng-click="grid.appScope.parentScope.openRemoveConfirmation(row.entity)" class="glyphicon glyphicon-trash text-danger" title="Remove container"></a></span></div>';

  var containerUseTemplate = '<span uib-dropdown dropdown-append-to-body class="edit-link">' +
    '<a href uib-dropdown-toggle class="glyphicon glyphicon-edit"><span class="hideEditText">Use Container</span></a>' +
    '<ul class="dropdown-menu" uib-dropdown-menu>' +
    '<li ng-click="grid.appScope.parentScope.openContainerModal(row.entity)"><a href>Edit Container</a></li>' +
    '<li ng-click="grid.appScope.parentScope.openContainerContentModal(row.entity)"><a href>View/Edit Container Contents</a></li>' +
    '<li ng-click="grid.appScope.parentScope.onCreateWasteTag(row.entity)" ng-if="!row.entity.currentWasteTagId && row.entity.materials.length"><a href>Create Tag</a></li>' +
    '<li ng-click="grid.appScope.parentScope.printWasteTag(row.entity)" ng-if="row.entity.currentWasteTagId"><a href>Print Tag</a></li>' +
    '<li ng-click="grid.appScope.parentScope.updateWasteTag(row.entity)" ng-if="row.entity.currentWasteTagId && row.entity.materials.length"><a href>Update Tag</a></li>' +
    '<li ng-click="grid.appScope.parentScope.requestPickupOnContainer(row.entity)" ng-if="row.entity.materials.length"><a href>Request EH&S Pickup</a></li>' +
    '<li ng-click="grid.appScope.parentScope.containerContentTransfer(row.entity)" ng-if="row.entity.materials.length"><a href>Transfer Contents of Waste Container</a></li>' +
    '</ul>' +
    '</span>';

  $templateCache.put('container-use.html', containerUseTemplate);
  $templateCache.put('container-remove-edit.html', removeTemplate);
  $templateCache.put('table-client-container.html', '<div id="table-client-container" ui-grid="ctrl.gridOptions" class="data-grid" ng-if="ctrl.gridOptions.data" ui-grid-pinning ui-grid-pagination ui-grid-cellnav></div>');
  $templateCache.put('totalVolume.html', '<div>Total Volume(&micro;) huhu</div>');
});
