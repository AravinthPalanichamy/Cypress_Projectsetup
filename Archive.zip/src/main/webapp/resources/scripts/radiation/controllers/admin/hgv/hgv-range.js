'use strict';

angular.module('app').controller('HgvRangeCtrl', function(StaticCollections, AdminService) {
  var ctrl = this;

  ctrl.hazardClassHash = StaticCollections.hazardClassHash;
  ctrl.init = function() {
    ctrl.populateRgvValues();
  };

  ctrl.onEditHgv = function() {
    ctrl.editing = true;
    ctrl.hgvRange.floorValue1 = 0;
  };

  ctrl.onCancel = function() {
    ctrl.editing = false;
  };

  ctrl.onSaveHgv = function(form) {
    if (ctrl.validateForm(form) && _.isEmpty(ctrl.hgvRangeError)) {
      AdminService.saveHgvRange({}, ctrl.hgvRange)
        .$promise
        .then(function(response) {
          ctrl.editing = false;
        });
    }
  };

  ctrl.populateRgvValues = function() {
    ctrl.hgvRange = {};
    AdminService.getHgvRangeByCamupus()
      .$promise
      .then(function(response) {
        _.forEach(response, function(hgv) {
          if (hgv.hazardClass === ctrl.hazardClassHash.I) {
            ctrl.hgvRange.floorValue1 = hgv.floorValue;
            ctrl.hgvRange.ceilingValue1 = hgv.ceilingValue;
          } else if (hgv.hazardClass === ctrl.hazardClassHash.II) {
            ctrl.hgvRange.floorValue2 = hgv.floorValue;
            ctrl.hgvRange.ceilingValue2 = hgv.ceilingValue;
          } else if (hgv.hazardClass === ctrl.hazardClassHash.III) {
            ctrl.hgvRange.floorValue3 = hgv.floorValue;
            ctrl.hgvRange.ceilingValue3 = hgv.ceilingValue;
          }
        });
      });
  };

  ctrl.onCeilingBlur = function(hazardClass) {
    if (hazardClass === ctrl.hazardClassHash.I) {
      ctrl.hgvRange.floorValue2 = ctrl.hgvRange.ceilingValue1 + 1;
    }
    if (hazardClass === ctrl.hazardClassHash.II) {
      ctrl.hgvRange.floorValue3 = ctrl.hgvRange.ceilingValue2 + 1;
    }
    ctrl.hgvRangeError = {};
  };

  ctrl.validateForm = function(form) {
    ctrl.hgvRangeError = {};
    if (form.$valid &&
      ctrl.hgvRange.ceilingValue1 > ctrl.hgvRange.floorValue1 &&
      ctrl.hgvRange.floorValue2 > ctrl.hgvRange.ceilingValue1 &&
      ctrl.hgvRange.ceilingValue2 > ctrl.hgvRange.floorValue2 &&
      ctrl.hgvRange.floorValue3 > ctrl.hgvRange.ceilingValue2 &&
      ctrl.hgvRange.ceilingValue3 > ctrl.hgvRange.floorValue3) {
      return true;
    } else {
      ctrl.hgvRangeError.rangeError = true;
      return false;
    }
  };

});

