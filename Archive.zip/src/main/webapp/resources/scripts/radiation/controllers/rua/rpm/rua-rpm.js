'use strict';

angular.module('app').controller('RuaRpmCtrl', function($scope, RpmService, RpmFormService, UaService, StaticCollections, TableHeaderCollections, ConfirmModelService, AmendmentService, PersonService, PermissionService) {
  var ctrl = this;

  ctrl.tableHeaderCollections = angular.copy(TableHeaderCollections);

  ctrl.init = function(rua) {
    ctrl.rua = rua;
    ctrl.isAdmin = PersonService.isAdmin;
    ctrl.buttonList = [];

    if (PermissionService.hasPermission()) {
      ctrl.buttonList.push({
        label: "Add New RPM",
        action: ctrl.onAddNewRpm
      });
    }


    ctrl.setDataAndTableReady(false);
    ctrl.getData(true);
  };

  ctrl.getTableHeader = function() {
    ctrl.tableHeaders = {
      ACTION: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.ACTION)),
      EDIT: Object.assign({}, ctrl.tableHeaderCollections.EDIT, {cellTemplate: "rpm-edit.html"}),
      MACHINE_USE_LOCATION: Object.assign({}, ctrl.tableHeaderCollections.MACHINE_USE_LOCATION, {field: "location.$display"}),
      MACHINE_ID: ctrl.tableHeaderCollections.MACHINE_ID,
      DPH_NUMBER: ctrl.tableHeaderCollections.DPH_NUMBER,
      MACHINE_TYPE: ctrl.tableHeaderCollections.MACHINE_TYPE,
      MACHINE_MANUFACTURER: ctrl.tableHeaderCollections.MACHINE_MANUFACTURER,
      MACHINE_MODEL: ctrl.tableHeaderCollections.MACHINE_MODEL,
      MAX_CURRENT: ctrl.tableHeaderCollections.MAX_CURRENT,
      MAX_VOLTAGE: ctrl.tableHeaderCollections.MAX_VOLTAGE,
      NORMAL_CURRENT: ctrl.tableHeaderCollections.NORMAL_CURRENT,
      MACHINE_USE_CODE: ctrl.tableHeaderCollections.MACHINE_USE_CODE,
      HAZARD_CLASS: Object.assign({}, ctrl.tableHeaderCollections.CLASS, ctrl.tableHeaderCollections.HAZARD_CLASS),
      ON_LICENSE: Object.assign({}, ctrl.tableHeaderCollections.LBL, {
        field: 'onLicense',
        displayName: 'On License?',
        cellTemplate: '<div class="yes-no-icon"><span  ng-if="row.entity.onLicense" class="glyphicon glyphicon-ok" ></span></div>'
      }),
      DELETE: {
        field: 'Delete',
        displayName: 'Delete',
        cellTemplate: 'rua-rpm-delete.html',
        width: 65
      }
    };
    if (!UaService.isAmendment(ctrl.rua)) {
      delete ctrl.tableHeaders.ACTION;
    }
    if (!PermissionService.hasPermission()) {
      delete ctrl.tableHeaders.EDIT;
      delete ctrl.tableHeaders.DELETE;
    }
    ctrl.columns = Object.values(ctrl.tableHeaders);
  };

  ctrl.getData = function(firstCall) {
    RpmService.getAllRPMByUaId({uaId: ctrl.rua.id}).$promise
      .then(function(response) {
        ctrl.data = angular.copy(response);
        ctrl.data.forEach(function(item) {
          if (item.location) {
            item.location.$display = item.location.buildingDisplayName + ' - ' + item.location.roomNumber;
          }
        });
        if (UaService.isAmendment(ctrl.rua)) {
          UaService.getUAByNumberAndTypeAndStatusType({
            uaNumber: ctrl.rua.number,
            uaType: ctrl.rua.type,
            uaStatus: 'Active'
          }, {}).$promise.then(function(ua) {
            RpmService.getAllRPMByUaId({uaId: ua.id}).$promise.then(function(res) {
              ctrl.activeRpmData = angular.copy(res);
              ctrl.activeRpmData.forEach(function(item) {
                if (item.location) {
                  item.location.$display = item.location.buildingDisplayName + ' - ' + item.location.roomNumber;
                }
              });
              ctrl.data = AmendmentService.compareAndMergeObjects(ctrl.activeRpmData, ctrl.data, 'RPM');
            }).then(function() {
              ctrl.setDataAndTableReady(true);
            });
          });
          if (!firstCall) {
            UaService.updateSummaryOfChanges({uaId: ctrl.rua.id}, {"summaryOfChanges": "RPM"})
              .$promise.then(function(res) {
              ctrl.rua = res;
              $scope.$parent.$parent.ctrl.init(res);
            });
          }
        } else {
          ctrl.setDataAndTableReady(true);
        }
      });
  };

  ctrl.setDataAndTableReady = function(isReady) {
    if (isReady) {
      ctrl.getTableHeader();
      ctrl.isDataNTableSync = isReady;
    }
  };

  ctrl.onAddNewRpm = function() {
    ctrl.rpm = {
      ua: {
        id: ctrl.rua.id
      }
    };
    RpmFormService.makeForm(ctrl.rua, ctrl.rpm, {'isAdmin': ctrl.isAdmi}, ctrl.save);
  };

  ctrl.onEditRpm = function(rpmId) {
    ctrl.rpm = _.clone(_.find(ctrl.data, {id: rpmId}), true);
    ctrl.rpm.numberOfTubes = (ctrl.rpm && ctrl.rpm.numberOfTubes) ? JSON.stringify(ctrl.rpm.numberOfTubes) : '';
    RpmFormService.makeForm(ctrl.rua, ctrl.rpm, {}, ctrl.save);
  };

  ctrl.onDeleteRpm = function(rpmId) {
    ctrl.rpm = _.find(ctrl.data, {id: rpmId});
    ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE, {message: "Are you sure you want to delete the <strong>RPM with machine# " + ctrl.rpm.machineId + "</strong>?"}, function() {
      RpmService.delete({id: rpmId}).$promise
        .then(function() {
          ctrl.getData();
        });
    });
  };

  ctrl.cancel = function() {
    ctrl.rpm = {};
  };

  ctrl.save = function(refreshParent) {
    ctrl.cancel();
    if (refreshParent) {
      ctrl.getData();
    }
  };

  ctrl.checkEditPermissions = function(row) {
    return row.entity.id
            && row.entity.$$action !== 'DELETED'
            && PermissionService.hasPermission();
  };
})
  .run(function($templateCache) {
    var rpmEditTemplate = '<div class="edit-link" ng-if="grid.appScope.parentScope.checkEditPermissions(row)">'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.onEditRpm(row.entity.id)" class="glyphicon glyphicon-edit" title="Edit RPM"></a></span>'
      + '</div>';
    $templateCache.put('rpm-edit.html', rpmEditTemplate);

    var rpmDeleteTemplate = '<div class="delete-link" ng-if="grid.appScope.parentScope.checkEditPermissions(row)">'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.onDeleteRpm(row.entity.id)" class="glyphicon glyphicon-trash text-danger" title="Delete RPM"></a></span>'
      + '</div>';
    $templateCache.put('rua-rpm-delete.html', rpmDeleteTemplate);
  });
