'use strict';

angular.module('app').controller('InventoryCtrl', function($route, StaticCollections, InventoryService, UaService, profile) {
  var ctrl = this;

  ctrl.currentUser = profile;

  ctrl.typeaheadLabel = UaService.typeaheadLabel;

  ctrl.ruaTypes = StaticCollections.uaTypeHash;

  ctrl.panels = {
    RAM_INVENTORY: 'RAM Inventory',
    IN_PROCESS: 'In Process',
    WASTE_CONTAINERS: 'Waste Containers',
    PENDING_DISPOSAL: 'Pending Pickup',
    SEALED_SOURCES: 'Sealed Sources',
    PENDING_TRANSFER: 'Pending Transfer',
    PENDING_REQUESTS: 'Requested Materials',
    LIMITS: 'Limits'
  };

  ctrl.setPanel = function(panel) {
    ctrl.panel = panel;
  };

  ctrl.init = function() {
    if ($route.current.params.ruaId) {
      UaService.get({uaId: $route.current.params.ruaId}).$promise.then(function(uaDetail) {
        ctrl.rua = uaDetail;
      });
    }

    ctrl.setPanel(ctrl.panels.RAM_INVENTORY);

    UaService.getUaListByStatusAndCampusCode({
      uaStatus: StaticCollections.getKeyByValue(StaticCollections.uaStatusHash, "Active"),
      campusCode: ctrl.currentUser.campus.code
    }, {}).$promise
      .then(function(response) {
        ctrl.useAuthorizations = _.filter(response, function(r) {
          return r.type === 'RAM';
        });
      });
  };

  ctrl.selectRua = function(rua) {
    UaService.getUAByNumberAndTypeAndStatusType({uaNumber: rua.number, uaType: rua.type, uaStatus: 'Active'}).$promise
      .then(function(res) {
        ctrl.rua = res;
      });
  };

  ctrl.init();

});
