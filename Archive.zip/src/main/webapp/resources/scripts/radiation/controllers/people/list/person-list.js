'use strict';

angular.module('app').controller('PersonListCtrl', function($q, $location, $uibModal, $templateCache, StaticCollections, TableHeaderCollections, UtilService, UaService, PersonService, data, PersonTrainingService, ExcelService) {
  var ctrl = this;
  var tableHeaderCollections = {};
  ctrl.download = ExcelService.peopleExcel;
  ctrl.report = "People";

  ctrl.init = function() {
    ctrl.totalItems = data.length;
    ctrl.data = _.filter(data, function(row) {
      if (!(_.isEmpty(row))) {
        return row;
      }
    });

    tableHeaderCollections = angular.copy(TableHeaderCollections);
    ctrl.getTableHeader();
    ctrl.buttonList = [
      {
        label: "Import People",
        action: ctrl.onImportPeople
      },
      {
        label: "Email List",
        action: ctrl.getPeopleEmailList,
        data: ctrl.data
      }
    ];
  };

  ctrl.getPeopleEmailList = function() {
    $uibModal.open({
      templateUrl: 'resources/scripts/radiation/controllers/people/list/email-list.html',
      backdrop: 'static',
      size: 'md',
      keyboard: false,
      controllerAs: '$ctrl',
      controller: function($uibModalInstance) {
        var $ctrl = this;

        $ctrl.init = (function() {
          PersonService.searchPeople({}, Object.assign({}, (ctrl.state || UtilService.searchDefaults), { pagination: { itemPerPage: ctrl.totalItems } })).$promise.then(function(people) {
            $ctrl.data = _.chain(people).uniq().value();
            var emails = _.map($ctrl.data, "email");
            $ctrl.emailListToCopy = emails.join(', ');
          });
        })();

        $ctrl.cancel = function() {
          $uibModalInstance.close();
        };

        $ctrl.copyToClipboard = function() {
          var emailList = document.getElementById("emailList");
          emailList.focus();
          emailList.select();
          document.execCommand("Copy");
        };
      }
    });
  };

  ctrl.getTableHeader = function() {
    tableHeaderCollections.EDIT.field = 'Edit';
    tableHeaderCollections.EDIT.displayName = 'Edit';
    tableHeaderCollections.EDIT.cellTemplate = $templateCache.get('editPerson.html');
    tableHeaderCollections.EDIT.width = 70;
    //TODO : Commented out to hide it from UI, might be we need it in future.
//  tableHeaderCollections.IS_ON_RUA.cellTemplate = $templateCache.get('isOnRua.html');
    tableHeaderCollections.IS_ON_ACTIVE_RUA.cellTemplate = $templateCache.get('isOnActiveRua.html');
    tableHeaderCollections.SOE_ON_FILE.cellTemplate = $templateCache.get('soeOnFile.html');
    tableHeaderCollections.DATE_RANGE_SHORT.field = 'dob';
    tableHeaderCollections.DATE_RANGE_SHORT.displayName = 'Birthdate';
    tableHeaderCollections.DATE_RANGE_SHORT.width = 120;

    ctrl.columns = ctrl.colDefs();
  };

  ctrl.colDefs = function() {
    return [
      tableHeaderCollections.EDIT,
      tableHeaderCollections.LAST_NAME,
      tableHeaderCollections.FIRST_NAME,
      tableHeaderCollections.DEPARTMENT,
      tableHeaderCollections.DATE_RANGE_SHORT,
      tableHeaderCollections.EMAIL,
      tableHeaderCollections.PHONE_NUMBER,
//    tableHeaderCollections.IS_ON_RUA,
      tableHeaderCollections.IS_ON_ACTIVE_RUA,
      tableHeaderCollections.RUA_CURRENTLY_ON,
      tableHeaderCollections.RUA_REMOVED_FROM,
      tableHeaderCollections.SOE_ON_FILE,
      tableHeaderCollections.GROUP_ID,
      tableHeaderCollections.UC_NET_ID
    ];
  };

  ctrl.getState = function(state) {
    ctrl.state = state;
    return $q(function(resolve, reject) {
      return PersonService.searchPeople({}, state)
        .$promise
        .then(function(res) {
          return resolve(res);
        });
    });
  };

  ctrl.onTraining = function(user) {
    PersonTrainingService.showTrainings(user);
  };

  ctrl.onImportPeople = function() {
    $location.path('people/new');
  };

})
  .run(function($templateCache) {
    $templateCache.put('editPerson.html', '<div class="edit-link" ng-if="row.entity.userId"><span ><a href="#/people/{{row.entity.userId}}?activePeopleTab=GENERAL" class="glyphicon glyphicon-edit"></a></span><span><a ng-href="" ng-click="grid.appScope.parentScope.onTraining(row.entity)" title="Trainings" class="uc-training"></a></span></div>');
    $templateCache.put('isOnRua.html', '<div class="yes-no-icon"><span  ng-if="row.entity.isOnRua" class="glyphicon glyphicon-ok" ></span></div>');
    $templateCache.put('isOnActiveRua.html', '<div class="yes-no-icon"><span  ng-if="row.entity.isOnActiveRua" class="glyphicon glyphicon-ok" ></span></div>');
    $templateCache.put('soeOnFile.html', '<div class="yes-no-icon"><span  ng-if="row.entity.soeOnFile" class="glyphicon glyphicon-ok" ></span></div>');
  });
