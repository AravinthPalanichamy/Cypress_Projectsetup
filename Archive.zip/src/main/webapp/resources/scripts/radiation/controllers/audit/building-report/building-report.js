'use strict';
angular.module('app').controller('BuildingReportCtrl', function($location) {

  var ctrl = this;

  ctrl.panels = {
    TOTAL_AMOUNTS: 'Total Amounts',
    ROOM_PRESENCE: 'Room Presence'
  };

  ctrl.init = function() {
    ctrl.setPanel(ctrl.panels[$location.search().activeReportTab] || ctrl.panels.TOTAL_AMOUNTS);
  };

  ctrl.setPanel = function(panel) {
    ctrl.panel = panel;
    $location.search("activeReportTab", panel.toUpperCase()).replace();
  };

});
