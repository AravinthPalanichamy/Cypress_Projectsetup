'use strict';

angular.module('app').controller('UaBaseCtrl', function($location, UaService, PersonService, BundleService, TypesService, StaticCollections) {
  var ctrl = this;

  ctrl.init = function() {
    ctrl.disablePISelection = false;
    if (!PersonService.isAdmin) {
      ctrl.generateRuaNoAndPI();
      ctrl.disablePISelection = true;
    }
    ctrl.ruaTypes = _.map(StaticCollections.uaTypeHash, function(val, key) {
      return {id: key, displayName: val, value: key};
    });
    ctrl.savingInProgress = false;
    ctrl.errorWhileCreatingGroupInCore = false;
  };

  ctrl.createUaAndGroup = function() {

    ctrl.validateRuaNumber();
    ctrl.validatePi();
    ctrl.validateRuaType();

    if (ctrl.ruaNumber && ctrl.ruaType && ctrl.pi) {
      ctrl.savingInProgress = true;
      UaService.getUaByUaNumber({
        uaNumber: ctrl.ruaNumber
      }, {}).$promise
        .then(ctrl.createUA);
    }
  };

  ctrl.createUA = function(response) {
    if (response.length === 0) {
      ctrl.createOrUpdateBundle();
    } else if (!PersonService.isAdmin && response.length > 0) {
      ctrl.ruaNumber = ctrl.generateRuaNumber();
      ctrl.createUaAndGroup();
    } else {
      ctrl.showAlreadyExistError = true;
      ctrl.ruaError = false;
      ctrl.alreadyExistError = ctrl.ruaType.value + ' - ' + ctrl.ruaNumber + ' already exists. ';
      ctrl.savingInProgress = false;
    }
  };

  ctrl.createOrUpdateBundle = function() {
    // find and create/update bundle
    BundleService.findGroupsByUserId({
      userId: ctrl.pi.userId
    }).$promise
      .then(ctrl.findAllGroupsByUserId)
      .then(ctrl.addBundleToUA);
  };

  ctrl.findAllGroupsByUserId = function(response) {
    var groupName = 'RUA' + '-' + ctrl.ruaNumber + '-' + ctrl.pi.lastName.toUpperCase();
    return _.chain(response).filter({'name': groupName}).head().value();
  };

  ctrl.addBundleToUA = function(bundle) {
    if (!_.isEmpty(bundle)) {
      UaService.addUa({
        type: ctrl.ruaType.value,
        uaNumber: ctrl.ruaNumber,
        userId: ctrl.pi.userId
      }, {}).$promise.then(function(value) {

        var csId = bundle.csId ? bundle.csId : bundle.groupId;
        var name = bundle.name ? bundle.name : bundle.groupName;
        BundleService.addUaBundle({
          uaId: value.id,
          csId: csId,
          name: name
        }, {}).$promise
          .then(function() {
            ctrl.savingInProgress = false;
            $location.path('/rua/' + value.id);
          });
      });
    } else {
      BundleService.createBundle({
        groupName: 'RUA' + '-' + ctrl.ruaNumber + '-' + ctrl.pi.lastName.toUpperCase(), /* To minimize name collision in core services during testing */
        userId: ctrl.pi.userId
      }).$promise
        .then(function(response) {
          ctrl.addBundleToUA(response);
        });
    }
  };

  ctrl.search = {
    people: {
      selected: undefined,
      search: function(query) {
        ctrl.showDetail = false;
        ctrl.showNullUserIdMessage = false;
        ctrl.saved = false;
        ctrl.notSaved = false;
        if (query.length > 1) {
          return PersonService.findByName({
            search: query
          }).$promise.then(function(response) {
            return _.filter(response, 'email').splice(0, 10);
          });
        } else {
          return [];
        }
      },
      select: function($item) {
        if ($item.userId) {
          this.selected = $item;
          ctrl.userId = $item.userId;
          ctrl.loadSpinner = true;
          PersonService.getDetail({
            userId: $item.userId
          }).$promise
            .then(function(response) {
              if (response) {
                ctrl.pi = response;
                ctrl.ruaPi = ctrl.pi.firstName + ' ' + ctrl.pi.lastName;
                ctrl.showPiError = false;
              } else {
                ctrl.validatePi();
              }
              ctrl.loadSpinner = false;
            });
        } else {
          ctrl.showNullUserIdMessage = true;
        }
      }
    }
  };

  ctrl.validateRuaType = function() {
    ctrl.showRuaError = !ctrl.ruaType;
  };

  ctrl.validateRuaNumber = function() {
    if (!ctrl.ruaNumber) {
      ctrl.ruaError = !ctrl.ruaNumber;
    } else {
      ctrl.ruaError = false;
      ctrl.showAlreadyExistError = false;
    }

  };

  ctrl.validatePi = function() {
    if (!ctrl.ruaPi || !ctrl.pi) {
      ctrl.showPiError = true;
    } else {
      ctrl.showPiError = false;
    }
  };

  ctrl.generateRuaNoAndPI = function() {
    ctrl.ruaNumber = ctrl.generateRuaNumber();
    ctrl.ruaPi = ctrl.generatePiInfo();
  };

  ctrl.generateRuaNumber = function() {
    return _.random(1, 9999);
  };

  ctrl.generatePiInfo = function() {
    ctrl.pi = PersonService.currentUser;
    return ctrl.pi.firstName + ' ' + ctrl.pi.lastName;
  };

});
