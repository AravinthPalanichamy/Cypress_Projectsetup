'use strict';

angular.module('app').controller('DosimetryIssuanceFormCtrl', function($location, ConfirmModelService, DosimetryIssuanceService, LocationService, dosimetryIssuance, frequencyList) {
  var ctrl = this;

  ctrl.dosimetryIssuance = dosimetryIssuance || {};
  ctrl.frequencyList = frequencyList;

  ctrl.init = function() {
    ctrl.locationSearch.building.selected = ctrl.dosimetryIssuance.location || null;
    ctrl.locationSearch.room.selected = ctrl.dosimetryIssuance.location || null;
    ctrl.dosimetryIssuance.frequency = ctrl.findFrequency();
  };

  ctrl.findFrequency = function() {
    return ctrl.dosimetryIssuance.frequency ? _.find(ctrl.frequencyList, function(frequency) { return frequency.id === ctrl.dosimetryIssuance.frequency.id ;}) : null;
  };

  ctrl.locationSearch = {
    building: {
      selected: null,
      select: function($item) {
        ctrl.locationSearch.buildingSelected = $item;
      },
      search: function(query) {
        ctrl.buildingSelected = false;
        return LocationService.findBuildings({ search: query}).$promise;
      }
    },
    room: {
      selected: null,
      select: function($item) {
        ctrl.dosimetryIssuance.location = $item;
      },
      search: function(query) {
        return LocationService.findRooms({ buildingId: ctrl.locationSearch.building.selected.buildingKey, search: query }).$promise;
      }
    }
  };

  ctrl.cancel = function() {
    $location.path('dosimetry-issuance/list');
  };

  ctrl.save = function(form) {
    if (form.$valid) {
      DosimetryIssuanceService.saveDosimetryIssuance({}, ctrl.dosimetryIssuance).$promise.then(function(result) {
        ctrl.dosimetryIssuance = result;
        ctrl.dosimetryIssuance.frequency = ctrl.findFrequency();
        ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS, {message: 'Successfully saved dosimetry issuance group ' + ctrl.dosimetryIssuance.groupId });
      });
    }
  };

  ctrl.init();

});
