'use strict';
angular.module('app').controller('radionuclideListCtrl', function($location, $scope, $templateCache, StaticCollections, TableHeaderCollections,
                                                                   AdminService, data) {
  var ctrl = this;

  ctrl.init = function() {
    ctrl.data = data;
    ctrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
    ctrl.getTableHeader();
  };

  ctrl.getTableHeader = function() {
    ctrl.tableHeaders = {
      RADIONUCLIDE_NAME: {
        field: 'displayName',
        displayName: 'Name'
      },
      HALF_LIFE: {
        field: 'displayHalfLife',
        displayName: 'Half Life (days)',
        width: 125,
        cellFilter: 'scientific'
      },
      RADIO_TOXICITY: {
        field: 'radiotoxicity',
        displayName: 'Radio toxicity'

      },
      Z_VALUE: {
        field: 'zValue',
        displayName: 'Z Value',
        width: 60
      },
      EGROUP: {
        field: 'eGroup',
        displayName: 'E Group',
        width: 60
      },
      SCHEDULE_C: {
        field: 'scheduleC',
        displayName: 'C Schedule',
        width: 80,
        cellFilter: 'scientific'
      },
      ALI: {
        field: 'ali',
        displayName: 'ALI (mCi)',
        width: 120,
        cellFilter: 'scientific'
      },
      ACTIVITY: {
        field: 'activityMciPerGram',
        displayName: 'Activity mCi Per Gram',
        width: 120,
        cellFilter: 'scientific'
      },
      SEWER_DISPOSAL: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
        field: 'isSewerDisposal',
        displayName: 'Sewer Disposal',
        width: 80,
        cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.isSewerDisposal" class="glyphicon glyphicon-ok" ></span></div>'
      }),
      SOURCE_MATERIAL: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
        field: 'isSourceMaterial',
        displayName: 'SM',
        width: 60,
        cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.isSourceMaterial" class="glyphicon glyphicon-ok" ></span></div>'
      }),
      SPECIAL_NUCLEAR_MATERIAL: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
        field: 'isSpecialNuclearMaterial',
        displayName: 'SNM',
        width: 60,
        cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.isSpecialNuclearMaterial" class="glyphicon glyphicon-ok" ></span></div>'
      }),
      ALPHA_EMITTER: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
        field: 'isAlphaEmitter',
        displayName: 'Alpha Emitter',
        cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.isAlphaEmitter" class="glyphicon glyphicon-ok" ></span></div>'
      }),
      BETA_EMITTER: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
        field: 'isBetaEmitter',
        displayName: 'Beta Emitter',
        cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.isBetaEmitter" class="glyphicon glyphicon-ok" ></span></div>'
      }),
      GAMMA_EMITTER: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
        field: 'isGammaEmitter',
        displayName: 'Gamma Emitter',
        width: 80,
        cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.isGammaEmitter" class="glyphicon glyphicon-ok" ></span></div>'
      }),
      NEUTRON_EMITTER: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
        field: 'isNeutronEmitter',
        displayName: 'Neutron Emitter',
        width: 80,
        cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.isNeutronEmitter" class="glyphicon glyphicon-ok" ></span></div>'
      }),
      RADIONUCLIDE_STATUS: Object.assign({}, angular.copy(ctrl.tableHeaderCollections.LBL), {
        field: 'isStatusActive',
        displayName: 'Active Status',
        cellTemplate: '<div class="yes-no-icon"> <span  ng-if="row.entity.isStatusActive" class="glyphicon glyphicon-ok" ></span></div>'
      })
    };
    ctrl.columns = Object.values(ctrl.tableHeaders);
  };

  ctrl.getData = function() {
    return AdminService.getAllRadionuclides().$promise;
  };
});

