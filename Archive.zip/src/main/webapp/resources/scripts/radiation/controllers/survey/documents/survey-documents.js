'use strict';

angular.module('app').controller('SurveyDocumentCtrl', function(uiGridConstants, SurveyService, AttachmentService, ReferenceService, TableHeaderCollections, UtilService, ConfirmModelService) {
  var $docCtrl = this;
  $docCtrl.options = {
    attachmentType: "SURVEY",
    attachmentTypes: null
  };
  $docCtrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
  $docCtrl.tableHeaders = {};

  $docCtrl.init = function(survey) {
    $docCtrl.survey = survey;
    $docCtrl.getTableHeader();
    $docCtrl.buttonList = [{
      label: "Add Document",
      action: $docCtrl.uploadDocument
    }];
    $docCtrl.getData();
  };

  $docCtrl.getTableHeader = function() {
    $docCtrl.tableHeaders = {
      EDIT: Object.assign({}, $docCtrl.tableHeaderCollections.EDIT, {cellTemplate: "survey-attachment-edit.html"}),
      ATTACHMENT_FILENAME: Object.assign({}, $docCtrl.tableHeaderCollections.ATTACHMENT_FILENAME),
      TITLE: Object.assign({}, $docCtrl.tableHeaderCollections.TITLE),
      DESCRIPTION: Object.assign({}, $docCtrl.tableHeaderCollections.DESCRIPTION),
      ATTACHMENT_SIZE: Object.assign({}, $docCtrl.tableHeaderCollections.ATTACHMENT_SIZE),
      ATTACHMENT_REFERENCE_DATE: Object.assign({}, angular.copy($docCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'referenceDate',
        displayName: 'Reference Date',
        width: 150
      }),
      LAST_MODIFIED_DATE: Object.assign({}, angular.copy($docCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'lastModifiedDate',
        displayName: 'Last Modified Date',
        width: 150
      }),
      DELETE: {
        field: 'Delete',
        displayName: 'Delete',
        cellTemplate: 'survey-attachment-delete.html',
        width: 65
      }
    };

    $docCtrl.columns = Object.values($docCtrl.tableHeaders);
  };
  $docCtrl.getData = function() {
    SurveyService.getAllSurveyAttachments({surveyId: $docCtrl.survey.id}).$promise.then(function(data) {
      $docCtrl.data = data;
    });
  };

  $docCtrl.uploadDocument = function() {
    AttachmentService.uploadAttachment($docCtrl.survey, null, $docCtrl.options, $docCtrl.saveAttachment);
  };

  $docCtrl.editDocument = function(surveyId, attachmentId) {
    var attachment = _.find($docCtrl.data, {id: attachmentId});
    AttachmentService.uploadAttachment($docCtrl.survey, attachment, $docCtrl.options, $docCtrl.saveAttachment);
  };

  $docCtrl.deleteDocument = function(surveyId, attachmentId) {
    var attachment = _.find($docCtrl.data, {id: attachmentId});
    ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE, {message: "Are you sure you want to delete the document <strong>" + attachment.fileName + "</strong>?"}, function() {
      SurveyService.deleteSurveyAttachment({
        surveyId: surveyId,
        attachmentId: attachmentId
      }).$promise.then(function() {
        $docCtrl.getData();
      });
    });
  };

  $docCtrl.downloadDocument = function(surveyId, attachmentId) {
    AttachmentService.downloadAttachment(attachmentId);
  };

  $docCtrl.saveAttachment = function(survey, attachment) {
    var isUpdate = _.some($docCtrl.data, {id: attachment.id});
    var attachments = _.map($docCtrl.data, function(a) {
      return {id: a.id};
    });
    if (!isUpdate) {
      attachments.push({id: attachment.id});
    }
    SurveyService.updateSurveyAttachments({surveyId: survey.id}, attachments).$promise.then(function() {
      $docCtrl.getData();
    });
  };

})
  .run(function($templateCache) {
    var attachmentEditTemplate = '<div class="edit-link">'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.editDocument(grid.appScope.parentScope.survey.id, row.entity.id)" class="glyphicon glyphicon-edit" title="Edit Document"></a></span>'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.downloadDocument(grid.appScope.parentScope.survey.id, row.entity.id)" target="_blank" title="Download Document" class="glyphicon glyphicon-download-alt"></a></span>'
      + '</div>';
    $templateCache.put('survey-attachment-edit.html', attachmentEditTemplate);

    var attachmentDeleteTemplate = '<div class="delete-link">'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.deleteDocument(grid.appScope.parentScope.survey.id, row.entity.id)" class="glyphicon glyphicon-trash text-danger" title="Delete Document"></a></span>'
      + '</div>';
    $templateCache.put('survey-attachment-delete.html', attachmentDeleteTemplate);
  });
