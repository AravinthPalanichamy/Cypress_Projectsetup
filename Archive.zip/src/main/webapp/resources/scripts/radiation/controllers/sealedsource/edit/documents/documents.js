'use strict';

angular.module('app').component('sealedSourceDocumentsTab', {
  transclude: true,
  templateUrl: 'resources/scripts/radiation/controllers/sealedsource/edit/documents/documents.html',
  controllerAs: 'ctrl',
  controller: function(AttachmentService, InventoryService, SealedSourceService, TableHeaderCollections, ConfirmModelService) {
    var ctrl = this;

    ctrl.options = {
      attachmentType: "LEAK_TEST",
      attachmentTypes: null
    };
    ctrl.tableHeaders = {};

    ctrl.init = function() {
      ctrl.getTableHeader();
      ctrl.buttonList = [{
        label: "Add Document",
        action: ctrl.uploadDocument
      }];
      ctrl.getData();
    };

    ctrl.getTableHeader = function() {
      ctrl.tableHeaders = {
        EDIT: Object.assign({}, angular.copy(TableHeaderCollections.EDIT), {cellTemplate: "leaktest-attachment-edit.html"}),
        ATTACHMENT_FILENAME: {
          field: 'fileName',
          displayName: 'File Name'
        },
        TITLE: angular.copy(TableHeaderCollections.TITLE),
        DESCRIPTION: Object.assign({}, angular.copy(TableHeaderCollections.DESCRIPTION)),
        ATTACHMENT_REFERENCE_DATE: Object.assign({}, angular.copy(TableHeaderCollections.DATE_RANGE_SHORT), {
          field: 'referenceDate',
          displayName: 'Reference Date',
          width: 150
        }),
        LAST_MODIFIED_DATE: Object.assign({}, angular.copy(TableHeaderCollections.DATE_RANGE_SHORT), {
          field: 'lastModifiedDate',
          displayName: 'Last Modified Date',
          width: 150
        }),
        ATTACHMENT_SIZE: {
          field: '_size',
          displayName: 'Size',
          width: 100,
          enableFiltering: false,
          cellTemplate: '<div class="ui-grid-cell-contents">{{ row.entity._size | bytes }}</div>'
        },
        DELETE: {
          field: 'Delete',
          displayName: '',
          cellTemplate: 'leaktest-attachment-delete.html',
          width: 65
        }
      };
      ctrl.columns = Object.values(ctrl.tableHeaders);
    };
    ctrl.getData = function() {
      InventoryService.getMaterial({materialId: ctrl.material.id}).$promise.then(function(data) {
        ctrl.material = data;
        ctrl.data = ctrl.material.attachments;
      });
    };

    ctrl.uploadDocument = function() {
      AttachmentService.uploadAttachment(ctrl.material, null, ctrl.options, ctrl.saveAttachment);
    };

    ctrl.editDocument = function(materialId, attachmentId) {
      var attachment = _.find(ctrl.data, {id: attachmentId});
      AttachmentService.uploadAttachment(ctrl.material, attachment, ctrl.options, ctrl.saveAttachment);
    };

    ctrl.deleteDocument = function(materialId, attachmentId) {
      var attachment = _.find(ctrl.data, {id: attachmentId});
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE, {message: "Are you sure you want to delete the document <strong>" + attachment.fileName + "</strong>?"}, function() {
        SealedSourceService.deleteLeakTestAttachment({
          id: materialId,
          attachmentId: attachmentId
        }).$promise.then(function(response) {
          ctrl.getData();
        });
      });
    };

    ctrl.downloadDocument = function(materialId, attachmentId) {
      AttachmentService.downloadAttachment(attachmentId);
    };

    ctrl.saveAttachment = function(material, attachment) {
      var isUpdate = _.some(ctrl.data, {id: attachment.id});
      var attachments = _.map(ctrl.data, function(a) {
        return {id: a.id};
      });
      if (!isUpdate) {
        attachments.push({id: attachment.id});
      }
      SealedSourceService.updateLeakTestAttachments({id: material.id}, attachments)
        .$promise
        .then(function() {
          ctrl.getData();
        });
    };
  },
  bindings: {
    material: '='
  }

})
  .run(function($templateCache) {
    var attachmentEditTemplate = '<div class="edit-link">'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.editDocument(grid.appScope.parentScope.material.id, row.entity.id)" class="glyphicon glyphicon-edit" title="Edit Document"></a></span>'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.downloadDocument(grid.appScope.parentScope.material.id, row.entity.id)" target="_blank" title="Download Document" class="glyphicon glyphicon-download-alt"></a></span>'
      + '</div>';
    $templateCache.put('leaktest-attachment-edit.html', attachmentEditTemplate);

    var attachmentDeleteTemplate = '<div class="delete-link">'
      + ' <span><a ng-href="" ng-click="grid.appScope.parentScope.deleteDocument(grid.appScope.parentScope.material.id, row.entity.id)" class="glyphicon glyphicon-trash text-danger" title="Delete Document"></a></span>'
      + '</div>';
    $templateCache.put('leaktest-attachment-delete.html', attachmentDeleteTemplate);
  });
