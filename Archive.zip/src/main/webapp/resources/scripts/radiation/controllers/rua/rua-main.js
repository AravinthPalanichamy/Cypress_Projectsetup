'use strict';
angular.module('app').controller('UaMainCtrl', function($q, $location, $window, UaService, BundleService, PersonService, TypesService, LocationService, ReferenceService, uaId, ua, StaticCollections, FileSaver, PrintService, ConfirmModelService, PrintUtil, UtilService, EmailService, PermissionService) {
  var ctrl = this;
  ctrl.isAU = PersonService.isAU;
  ctrl.isAdmin = PersonService.isAdmin;
  ctrl.dscs = [];

  ctrl.panels = {
    GENERAL: 'General',
    PERSONNEL: 'Personnel',
    SURVEYS: 'Surveys',
    DOCUMENTS: 'Documents'
  };

  // initialize
  ctrl.init = function(rua) {
    TypesService.getMonitorTypes({}, {}).$promise
      .then(function(dosimetries) {
        ctrl.dosimetryType = dosimetries;
      });
    ctrl.currentUser = PersonService.getCurrentUserProfile();
    ctrl.rua = rua || ua;
    ctrl.ruaTypes = StaticCollections.uaTypeHash;
    if (ctrl.rua.coreCollection) {
      PersonService.getDscsByCollection({collectionId: ctrl.rua.coreCollection.collectionId}).$promise.then(function(people) {
        ctrl.dscs = people;
      });
    }

    if (ctrl.rua && ctrl.rua.type === 'RPM') {
      ctrl.panels.RPM = 'RPM';
    } else if (ctrl.rua && ctrl.rua.type === 'RAM') {
      ctrl.panels.RAM_INVENTORY = 'RAM Inventory';
      ctrl.panels.SEALED_SOURCES_INVENTORY = 'Sealed Sources Inventory';
      ctrl.panels.LIMITS = 'Limits';
      ctrl.panels.SM_SNM_LIMITS = 'SM/SNM Limits';
      ctrl.panels.ITEM_REQUESTS = 'Item Requests';

    }
    ctrl.panels.CHANGELOG = 'Changelog';

    if (UaService.isAmendment(ctrl.rua)) {
      delete ctrl.panels.SURVEYS;
      delete ctrl.panels.RAM_INVENTORY;
      delete ctrl.panels.SEALED_SOURCES_INVENTORY;
      delete ctrl.panels.ITEM_REQUESTS;
      delete ctrl.panels.CHANGELOG;
    } else if (!PersonService.isAdmin) {
      // delete ctrl.panels.SURVEYS;
      delete ctrl.panels.SEALED_SOURCES_INVENTORY;
      delete ctrl.panels.ITEM_REQUESTS;
      delete ctrl.panels.CHANGELOG;
    }

    ctrl.setPanel(ctrl.panels[$location.search().activeRuaTab] || ctrl.panels.GENERAL);
  };

  ctrl.setPanel = function(panel) {
    ctrl.panel = panel;
    $location.search("activeRuaTab", panel.replace(/(\/)|(\s)/gmi, '_').toUpperCase()).replace();
  };

  ctrl.printUa = function(id) {
    PrintService.openInTab('printUa', {uaId: id});
  };

  ctrl.printHGV = function() {
    PrintUtil.printHGV(UtilService.calculateHGV(ctrl.rua));
  };

  ctrl.submitRuaAmendment = function() {
    ctrl.submittedAmendment = true;
    ConfirmModelService.confirm(ConfirmModelService.ConfirmType.CONFIRM, {
      header: "RUA Change Request Submit Confirmation",
      message: "Are you sure you want to submit RUA #" + ctrl.rua.number + " with <strong>Change Request #" + ctrl.rua.amendmentNumber + "</strong> for approval?"
    }, function() {
      UaService.updateUa({uaId: ctrl.rua.id}, Object.assign({}, ctrl.rua, {amendmentSubmitted: true})).$promise
        .then(function(res) {
          ctrl.rua = res;
          var amendmentMsg = 'Rua #' + ctrl.rua.number + ' with <strong>amendment #' + ctrl.rua.amendmentNumber + '</strong> has been submitted.';

          ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS,
            {message: amendmentMsg, buttons: undefined, close: false, autoClose: true, autoCloseTimeout: 3000});

          $window.setTimeout(function() {
            $location.search('activeRuaTab', undefined);
            $location.path('/rua');
          }, 3000);
        });
    });
  };

  ctrl.showAmendedSection = function(value) {
    if (!ctrl.rua.summaryOfChanges) {
      return false;
    }
    var regMatch = /\b([.\s.]+)\b/gmi, regexSub = '_';
    var regex = new RegExp('(\\b(' + value.replace(regMatch,regexSub) + ')\\b)', 'gmi');
    return UaService.isAmendment(ctrl.rua) && regex.test(ctrl.rua.summaryOfChanges.replace(regMatch,regexSub));
  };

  ctrl.openEmail = function() {
    var options = {
      addRecipients: true,
      allowEmail: false,
      addRecipientMessage: ''
    };
    UaService.getEmailTemplate({uaId: ctrl.rua.id}).$promise.then(function(notification) {
      EmailService.getMessage(ctrl.rua, buildNotification(notification), null, options, ctrl.sendNotification);
    });

  };

  ctrl.setPageDomainKey = function() {
    return ctrl.rua.statusType === 'PENDING' ? 'RUA_' + ctrl.rua.statusType : 'RUA_ACTIVE';
  };

  function buildNotification(notification) {
    return {
      toRecipients: [{
        userId: ctrl.rua.pi.userId,
        firstName: ctrl.rua.pi.firstName,
        lastName: ctrl.rua.pi.lastName
      }],
      ccRecipients: _.concat(BundleService.getLabContacts(ctrl.rua.uaBundle), ctrl.dscs),
      subject: notification.subject,
      bodyHtml: notification.body
    };
  }

  ctrl.sendNotification = function(ua, notification) {
    UaService.sendEmail({}, notification).$promise.then(function() {
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS, {message: 'Email has been sent.'});
    });
  };

  ctrl.startAmendment = function() {
    ctrl.amendmentStarted = false;
    ConfirmModelService.confirm(ConfirmModelService.ConfirmType.CONFIRM, {
      header: "Change Request Steps",
      message: "<p>If you would like to make a change to an RUA's:</p>" +
        "<ul>" +
        "<li>Building/Room</li>" +
        "<li>Personnel</li>" +
        "<li>Documents (Procedures, Statements of Experience)</li>" +
        "<li>Radionuclide Limits</li>" +
        "<li>Special Request (Under General tab)</li>" +
        "</ul>" +
        "<p>then please select the appropriate tab(s), make changes and \"Save\".</p>" +
        "<p>When all updates are complete, select \"Submit Change Request\", " +
        "and someone from the Radiation Safety Team will contact you shortly.</p>"
    }, function() {
      var rua = ctrl.rua;
      ctrl.savingInProgress = true;
      UaService.createAmendment({uaId: rua.id, uaNumber: rua.number}, [])
        .$promise.then(function(response) {
        ctrl.rua = response;
        ctrl.savingInProgress = false;
        PermissionService.setData(response);
        $location.path('/rua/' + response.id);
      });
    });
  };

  ctrl.submitRua = function() {
    UaService.getUa({uaId: ctrl.rua.id}, {}).$promise.then(function(response) {
      if (response) {
        ConfirmModelService.confirm(ConfirmModelService.ConfirmType.CONFIRM, {
          header: "RUA Submit Confirmation",
          message: "Are you sure you want to submit this RUA for approval?"
        }, function() {
          UaService.updateUa({uaId: ctrl.rua.id}, Object.assign({}, response, {uaSubmitted: true})).$promise
            .then(function(res) {
              ctrl.rua = res;
              var amendmentMsg = 'You have successfully submitted your RUA.';

              ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS,
                {message: amendmentMsg, buttons: undefined, close: false, autoClose: true, autoCloseTimeout: 3000});

              $window.setTimeout(function() {
                $location.search('activeRuaTab', undefined);
                $location.path('/rua');
              }, 3000);
            });
        });
      }
    });
  };

});
