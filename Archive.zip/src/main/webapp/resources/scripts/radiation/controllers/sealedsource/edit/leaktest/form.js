'use strict';

angular.module('app').controller('LeakTestFormCtrl', function($uibModalInstance, inspectors, testRecord, material, InventoryService, SealedSourceService, UtilService) {
  var formCtrl = this;

  formCtrl.inspectors = inspectors;
  formCtrl.material = material;
  formCtrl.nextDue = angular.copy(formCtrl.material.nextDue);
  formCtrl.leakTest = testRecord ? testRecord : {
      material: {
        id: formCtrl.material.id
      },
      testType: {
        id: 2 //Defaulted to Leak Test
      }
    };
  formCtrl.mode = testRecord ? 'EDIT' : 'NEW';

  formCtrl.cancel = function() {
    $uibModalInstance.close();
  };

  formCtrl.toggleTestDate = function($event) {
    $event.stopPropagation();
    $event.preventDefault();
    this.isTestDateOpen = !this.isTestDateOpen;
  };

  formCtrl.calculateDueDate = function(testDate) {
    formCtrl.nextDue = UtilService.calculateNextDue(formCtrl.material.testFrequency.frequency, testDate);
  };

  formCtrl.validatePerson = function() {
    if (!formCtrl.leakTest.testedBy) {
      formCtrl.showPersonError = true;
      return false;
    } else {
      formCtrl.showPersonError = false;
      return true;
    }
  };

  formCtrl.save = function() {
    if (formCtrl.validatePerson()) {
      if (formCtrl.mode === 'NEW') {
        formCtrl.leakTest.dueDate = formCtrl.material.nextDue;
      }
      SealedSourceService.saveTest(formCtrl.leakTest)
        .$promise
        .then(function(response) {
          formCtrl.material.nextDue = formCtrl.nextDue;
          InventoryService.updateMaterial({materialId: formCtrl.material.id}, formCtrl.material)
            .$promise
            .then(function(res) {
              $uibModalInstance.close();
            });
        });
    }
  };
});
