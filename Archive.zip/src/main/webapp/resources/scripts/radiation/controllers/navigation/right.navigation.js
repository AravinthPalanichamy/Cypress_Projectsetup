'use strict';

angular.module('app').controller('RightNavigationCtrl', function(ENV, TileService, PersonService, CLIENT_KEY, $http, $window) {
  var ctrl = this;
  this.ENV = ENV;
  ctrl.currentUser = {};
  ctrl.clientKey = CLIENT_KEY;
  ctrl.helpKey = 'radiation';
  ctrl.showNotifications = false;

  PersonService.getCurrentUserProfile().$promise.then(function(response) {
    ctrl.currentUser = response;
  });

  TileService.initialize(function() {
    ctrl.apps = TileService.apps;
    ctrl.serviceMap = TileService.serviceMap;
    ctrl.brand = TileService.brand;
  });

  this.getNotificationCount = function() {
    var countRequest = {
      method: 'GET',
      url: ctrl.serviceMap.notification.contextUrl + "api/header/count"
    };
    $http(countRequest).then(function(response) {
      ctrl.showNotifications = true;
      ctrl.notificationsCount = response.data.count;
    });
  };

  this.openNotificationInbox = function() {
    $window.location.href = ctrl.serviceMap.notification.contextUrl;
  };

});
