'use strict';

angular.module('app').component('ruaGeneralTab', {
  transclude: true,
  templateUrl: 'resources/scripts/radiation/controllers/rua/general/rua-general.html',
  controllerAs: 'ctrl',
  controller: function($q, $location, $window, $uibModal,
                        UaService, BundleService, PersonService, TypesService,
                        LocationService, LocationSearchService, StaticCollections, ConfirmModelService, CollectionService, PrintUtil, UtilService, PermissionService) {
    var ctrl = this;
    ctrl.init = function() {
      if (ctrl.rua && !ctrl.rua.id) {
        $location.path('/error');
      }
      ctrl.isAdmin = PersonService.isAdmin;
      ctrl.sortUseLocations(ctrl.rua);
      ctrl.initDefaults();
      ctrl.lookupServices();
      ctrl.hasAmendmentNumber = !!ctrl.rua.amendmentNumber;
      ctrl.isAmendment = UaService.isAmendment(ctrl.rua);
      ctrl.getActiveRuaIfAmendExists(ctrl.rua)(UaService.isAmendment);
    };

    ctrl.initDefaults = function() {
      ctrl.expiryDateRequiredError = false;
      ctrl.savingInProgress = false;
      ctrl.requiredFieldsError = false;
      ctrl.useLocationsError = false;
      ctrl.piChanged = false;
      ctrl.rua.orgDept = ctrl.rua.orgDept || ctrl.rua.pi.department;
      ctrl.rua.contactInfo = _.map(
                              _.filter(ctrl.rua.uaBundle.uaBundlePersons, function(uaBundlePerson) {
                                return uaBundlePerson.delegate && uaBundlePerson.active;
                              }),
                            'person.displayName')
                            .join(', ');
      ctrl.rua.assessmentFactor = ctrl.rua.assessmentFactor || ctrl.getDefaultAssessmentFactor(StaticCollections.assessmentFactorHash);
      BundleService.findGroupsByUserId({userId: ctrl.rua.pi.userId})
        .$promise
        .then(ctrl.findAllGroupsByUserId)
        .then(function(response) {
          ctrl.piChanged = !(response);
        });
    };

    ctrl.lookupServices = function() {
      var frequencies = TypesService.getFrequencyList({}, {}).$promise;
      var dosimetries = TypesService.getMonitorTypes({}, {}).$promise;
      var detectorTypes = TypesService.getDetectorTypes({}, {}).$promise;
      var collections = CollectionService.getCollectionByCampus({}, {}).$promise;
      var qAll = $q.all([frequencies, dosimetries, detectorTypes, collections])
        .then(function(values) {
          ctrl.surveyFrequencyType = values[0];
          ctrl.dosimetryType = _.reject(values[1], {'name': "other"});
          ctrl.instrumentationType = _.filter(values[2], {'active': true});
          ctrl.ruaTypes = StaticCollections.UATypesHash;
          ctrl.ruaSignature = StaticCollections.ruaSignatureTypes;
          ctrl.yesNoOptions = StaticCollections.yesNoOptions;
          ctrl.hazardClass = StaticCollections.classHash;
          ctrl.assessmentFactorHash = StaticCollections.assessmentFactorHash;
          ctrl.collection = values[3];
          ctrl.locationSearch = LocationSearchService;
          ctrl.status = StaticCollections.uaStatus;
        });
    };

    ctrl.validateStatus = function() {
      ctrl.statusRequiredError = !ctrl.rua.statusType;
      ctrl.requiredFieldsError = ctrl.requiredFieldsError || ctrl.statusRequiredError;
      if (ctrl.rua.statusType && ctrl.isAdmin
          && ctrl.rua.statusType === UtilService.findAndGet(StaticCollections.uaStatus, 'value', 'ACTIVE')()
        ) {
          if (ctrl.rua.amendmentNumber > 0) {
            ctrl.rua.amendmentSubmitted = true;
          } else {
            /**
             * Toggle this boolean only when Admin turns the RUA to active.
             * This boolean is primarily used for calculating the permission for the PI/delegate
             * when the ua is active / pending.
             */
            ctrl.rua.uaSubmitted = false;
          }
      }
    };

    ctrl.validateLocation = function() {
      ctrl.locationRequiredError = ctrl.rua.uaBundle.uaBundleLocations.length === 0;
    };

    ctrl.validateSurveyFrequency = function() {
      ctrl.frequencyRequireError = !ctrl.rua.frequency;
      ctrl.requiredFieldsError = ctrl.requiredFieldsError || ctrl.frequencyRequireError;
    };

    ctrl.validateUseLocations = function() {
      if (ctrl.rua.statusType === "PENDING") {
        ctrl.useLocationsError = false;
      } else {
        ctrl.useLocationsError = !ctrl.rua.uaBundle
        || (ctrl.rua.uaBundle && !ctrl.rua.uaBundle.uaBundleLocations)
        || (ctrl.rua.uaBundle && ctrl.rua.uaBundle.uaBundleLocations && ctrl.rua.uaBundle.uaBundleLocations.length === 0);
      }
      ctrl.requiredFieldsError = ctrl.requiredFieldsError || ctrl.useLocationsError;
    };

    ctrl.onDosimetryClick = function(dosimetry) {
      if (!ctrl.checkDosimetry(dosimetry)) {
        ctrl.rua.uaDosimteries.push({'ua': ctrl.rua.id, 'monitorType': dosimetry});
      } else {
        var toBeDeletedDosimetry = _.find(ctrl.rua.uaDosimteries, {'monitorType': {'name': dosimetry.name}});
        if (toBeDeletedDosimetry && toBeDeletedDosimetry.id) {
          toBeDeletedDosimetry.monitorType = null;
        }
      }
    };

    ctrl.buildLocationTemplate = function(activeRua) {
      ctrl.locationTemplate = '';
      if (!activeRua.uaBundle) {
        return "";
      }
      activeRua.uaBundle.uaBundleLocations = _.sortBy(activeRua.uaBundle.uaBundleLocations, ['location.buildingDisplayName', 'location.roomNumber']);
      _.each(activeRua.uaBundle.uaBundleLocations, function(building, i) {
        if (ctrl.checkBuildingName(i, activeRua.uaBundle.uaBundleLocations)) {
          ctrl.locationTemplate += "<div>" + building.location.buildingDisplayName + "</div>";
        }
        ctrl.locationTemplate += "<div>&nbsp; &nbsp; Room #: " + building.location.roomNumber + "</div>";
      });
      return ctrl.locationTemplate;
    };

    ctrl.addedLocationDiffTemplate = function(uaBundleLocations) {
      var str = '';
      _.each(uaBundleLocations, function(building, i) {
          str += "<div>" + building.location.buildingDisplayName + "</div>";
          str += "<div>&nbsp; &nbsp; Room #: " + building.location.roomNumber + "</div>";
      });
      return '<strong>' + str + '</strong>';
    };

    ctrl.isLocationModified = function(arr1, arr2) {
      var locArr1 = _.map(arr1, function(obj) {
        return obj.location.id;
      });
      var locArr2 = _.map(arr2, function(obj) {
        return obj.location.id;
      });
      return !_.isEmpty(_.xor(locArr1, locArr2));
    };

    ctrl.onDetectorClick = function(detector) {
      if (!ctrl.checkDetector(detector)) {
        ctrl.rua.uaDetectors.push({'ua': ctrl.rua.id, 'detectorType': detector});
      } else {
        var toBeDeletedDetector = _.find(ctrl.rua.uaDetectors, {'detectorType': {'name': detector.name}});
        if (toBeDeletedDetector && toBeDeletedDetector.id) {
          toBeDeletedDetector.detectorType = null;
        }
      }
    };

    // DatePicker ReceivedDate methods START
    ctrl.toggleExpiryDate = function($event) {
      $event.stopPropagation();
      $event.preventDefault();
      this.isExpiryDateOpened = !this.isExpiryDateOpened;
      ctrl.expiryDateRequiredError = false;
      ctrl.requiredFieldsError = ctrl.expiryDateRequiredError;
    };

    ctrl.toggleTerminatedDate = function($event) {
      $event.stopPropagation();
      $event.preventDefault();
      this.isTerminatedOpened = !this.isTerminatedOpened;
    };

    ctrl.toggleLastUpdatedDate = function($event) {
      $event.stopPropagation();
      $event.preventDefault();
      this.isLastUpdatedDateOpen = !this.isLastUpdatedDateOpen;
    };

    ctrl.toggleEnteredDate = function($event) {
      $event.stopPropagation();
      $event.preventDefault();
      this.isEnteredDateOpened = !this.isEnteredDateOpened;
    };

    ctrl.onAnimalChange = function() {
      if (ctrl.rua && ctrl.rua.isAnimalsUsed === false) {
        ctrl.rua.animalProtocolNumber = undefined;
      }
    };

    function updateDosimetryandDetector() {
      _.each(ctrl.rua.uaDosimteries, function(dosimetry) {
        dosimetry.ua = {'id': ctrl.rua.id};
        return dosimetry;
      });

      _.each(ctrl.rua.uaDetectors, function(detector) {
        detector.ua = {'id': ctrl.rua.id};
        return detector;
      });
    }


    ctrl.saveGeneralRua = function(ruaGeneralForm) {
      updateDosimetryandDetector();
      if (ctrl.rua.statusType === UtilService.findAndGet(StaticCollections.uaStatus, 'value', 'ACTIVE')() && ctrl.rua.amendmentNumber > 0 && ctrl.rua.amendmentSubmitted && !ctrl.isFormInValid(ruaGeneralForm)) {
        ctrl.approveRuaAmendment();
      } else if (!ctrl.isFormInValid(ruaGeneralForm)) {
        ctrl.savingInProgress = true;
        if (ctrl.rua.uaBundle) {
          return ctrl.saveIfBundleExists();
        } else {
          // find and create/update bundle
          return BundleService.findGroupsByUserId({userId: ctrl.rua.pi.userId}).$promise
            .then(ctrl.findAllGroupsByUserId)
            .then(ctrl.addBundleToUA)
            .then(ctrl.updateUA);
        }
      } else {
        ctrl.requiredFieldsError = true;
      }
      ctrl.rua.assessmentFactor = ctrl.rua.assessmentFactor || ctrl.getDefaultAssessmentFactor(StaticCollections.assessmentFactorHash);
    };

    ctrl.saveIfBundleExists = function() {
      updateDosimetryandDetector();
      var locations = _.chain(ctrl.rua)
        .get('uaBundle')
        .get('uaBundleLocations')
        .map(function(l) {
          return l.location;
        })
        .value();

      if (locations && locations.length > 0) {
        return BundleService.addLocationToGroup({groupId: ctrl.rua.uaBundle.csId}, locations).$promise
          .then(ctrl.mapBundleLocations)
          .then(ctrl.updateUA)
          .then(function(resp) {
            return resp;
          });
      } else {
        return ctrl.updateUA();
      }
    };

    ctrl.approveRuaAmendment = function() {
      UaService.approveAmendment({uaId: ctrl.rua.id}, ctrl.rua)
        .$promise
        .then(function(response) {
          $location.path('/rua');
        }, function(err) {
          console.log(err);
        });
    };

    ctrl.findAllGroupsByUserId = function(response) {
      var groupName = 'RUA' + '-' + ctrl.rua.number + '-' + ctrl.rua.pi.lastName.toUpperCase();
      return _.chain(response).filter({'name': groupName}).head().value();
    };

    ctrl.addBundleToUA = function(bundle) {
      if (!_.isEmpty(bundle)) {
        BundleService.addUaBundle({
          uaId: ctrl.rua.id,
          csId: bundle.csId,
          name: bundle.name
        }, {}).$promise
          .then(function(response) {
            ctrl.rua.uaBundle = response;
          });
      } else {
        BundleService.createBundle({
          groupName: 'RUA' + '-' + ctrl.rua.number + '-' + ctrl.rua.pi.lastName.toUpperCase(),
          userId: ctrl.pi.userId
        }).$promise
          .then(ctrl.addBundleToUA);
      }
    };

    ctrl.updateUA = function() {
      return UaService.updateUa({uaId: ctrl.rua.id}, ctrl.rua).$promise
        .then(function(res) {
          var desc = _.get(_.find(ctrl.ruaTypes, {'value': ctrl.rua.type}), 'description');
          ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS, {message: desc + ' #' + ctrl.rua.number + ' is saved!!!'});
          ctrl.savingInProgress = false;
          ctrl.rua = res;
          ctrl.sortUseLocations(ctrl.rua);
          ctrl.resetDefaults();
          PermissionService.setData(ctrl.rua);
          if (UaService.isAmendment(ctrl.rua)) {
            return UaService.updateSummaryOfChanges({uaId: ctrl.rua.id}, {"summaryOfChanges": "General"}).$promise
              .then(function(res) {
                ctrl.rua = res;
                ctrl.init();
                return Promise.resolve(res);
              });
          } else {
            return Promise.resolve(res);
          }
        });
    };

    ctrl.onChangePI = function(rua) {
      $uibModal.open({
        templateUrl: 'resources/scripts/radiation/controllers/rua/general/_change-pi.html',
        controller: 'ChangePICtrl',
        controllerAs: '$ctrl',
        size: 'md',
        backdrop: 'static',
        resolve: {
          rua: rua
        }
      }).result.then(function(response) {
        Object.assign(ctrl.rua.pi, response.$value);
      });
    };

    ctrl.mapBundleLocations = function(response) {
      if (response && response.placeMembers) {
        _.map(ctrl.rua.uaBundle.uaBundleLocations, function(ubl) {
          var loc = _.find(response.placeMembers, {'roomId': ubl.location.roomId});
          if (loc) {
            ubl.location = loc;
            ubl.location.buildingPrimaryName = _.first(_.filter(loc.buildingNames, {'type': 'Primary'})).name;
            ubl.location.buildingDisplayName = _.first(_.reject(loc.buildingNames, {'type': 'Primary'})).name;
            delete ubl.location.buildingNames;
          }
          return ubl;
        });
      }
      ctrl.showDone = false;
    };

    ctrl.isFormInValid = function(ruaGeneralForm) {
      ctrl.requiredFieldsError = false;
      if (!ctrl.rua.expiryDate) {
        ctrl.expiryDateRequiredError = true;
      } else {
        ctrl.expiryDateRequiredError = false;
      }
      ctrl.requiredFieldsError = ctrl.requiredFieldsError || ctrl.expiryDateRequiredError;
      ctrl.validateStatus();
      ctrl.validateSurveyFrequency();
      ctrl.validateUseLocations();
      ruaGeneralForm.$invalid = ruaGeneralForm.$invalid || ctrl.requiredFieldsError;
      ruaGeneralForm.$valid = !ruaGeneralForm.$invalid;
      return ctrl.requiredFieldsError;
    };

    ctrl.resetDefaults = function() {
      ctrl.expiryDateRequiredError = false;
      ctrl.savingInProgress = false;
      ctrl.requiredFieldsError = false;
      ctrl.statusRequiredError = false;
      ctrl.frequencyRequireError = false;
      ctrl.useLocationsError = false;
      ctrl.locationSearch.buildings.selected = undefined;
      ctrl.locationSearch.rooms.selected = undefined;
    };

    ctrl.removeRoom = function(location) {
      _.remove(ctrl.rua.uaBundle.uaBundleLocations, function(ubl) {
        return (location.buildingKey === ubl.location.buildingKey && location.roomId === ubl.location.roomId);
      });
    };

    ctrl.checkDosimetry = function(dosimetry) {
      return _.some(ctrl.rua.uaDosimteries, ['monitorType', {'name': dosimetry.name}]);
    };

    ctrl.checkDetector = function(detector) {
      return _.some(ctrl.rua.uaDetectors, ['detectorType', {'name': detector.name}]);
    };

    ctrl.checkBuildingName = function(index, bundleLocations) {
      if (index === 0) {
        return true;
      }
      var currentBuilding = !bundleLocations ? ctrl.rua.uaBundle.uaBundleLocations[index] : bundleLocations[index];
      var previousBuilding = !bundleLocations ? ctrl.rua.uaBundle.uaBundleLocations[index - 1] : bundleLocations[index - 1];
      return currentBuilding.location.buildingDisplayName !== previousBuilding.location.buildingDisplayName;
    };

    ctrl.sortUseLocations = function(res) {
      if (!res.uaBundle) {
        return res;
      }
      ctrl.rua.uaBundle.uaBundleLocations = _.sortBy(res.uaBundle.uaBundleLocations, ['location.buildingDisplayName', 'location.roomNumber']);
    };

    ctrl.onCancel = function() {
      if (!ctrl.isAdmin) {
        $location.url("/rua");
      } else {
        $window.history.back();
      }
    };

    ctrl.showHGV = function(ruaType) {
      return ruaType !== StaticCollections.UATypes.RPM.value;
    };

    ctrl.getDefaultAssessmentFactor = function(assessmentFactorHash) {
      return _.find(assessmentFactorHash, function(factor) {
        return factor.id === 3;
      });
    };

    ctrl.printHGV = function() {
      PrintUtil.printHGV(UtilService.calculateHGV(ctrl.rua));
    };

    ctrl.openHGV = function() {
      var modalOpts = {
        header: 'HGV Calculation',
        autoClose: false,
        buttons: {
          print: {
            label: 'Print HGV'
          },
          ok: {
          label: "Ok"
          }
        },
        data: UtilService.calculateHGV(ctrl.rua),
        template: 'resources/scripts/radiation/components/confirm-model/_hgv-calculation.model.html'
      };
      ConfirmModelService.confirm(ConfirmModelService.ConfirmType.EQUATION, modalOpts);
    };

    ctrl.getActiveRuaIfAmendExists = function(rua) {
      return function(isAmendment) {
        if (isAmendment(rua)) {
          return UaService.getUAByNumberAndTypeAndStatusType({
            uaNumber: rua.number,
            uaType: rua.type,
            uaStatus: UtilService.findAndGet(StaticCollections.uaStatus, 'displayName', 'Active')()
          }, {}).$promise.then(function(ua) {
            ctrl.activeRua = ua;
            ctrl.buildLocationTemplate(ua);
            ctrl.isLocModified = ctrl.isLocationModified(angular.copy(rua.uaBundle.uaBundleLocations), angular.copy(ua.uaBundle.uaBundleLocations));
            return ua;
          });
        }
      };
    };

    ctrl.displayChangedPIInfo = function() {
      if (ctrl.piChanged) {
        BundleService.findGroupByCsId({'csId': ctrl.rua.uaBundle.csId}, {})
          .$promise
          .then(function(response) {
            var result;
            if (response) {
              result = {header: response.name, message: 'The PI for this group is <strong>' + response.pi.firstName + ', ' + response.pi.lastName + '</strong>'};
            } else {
              result = {message: 'The PI for this group is <strong>NOT KNOWN</strong>. Contact your RSO'};
            }
            ConfirmModelService.confirm(ConfirmModelService.ConfirmType.INFO, result);
          });
      }
    };
  },

  bindings: {
    rua: '='
  }
});
