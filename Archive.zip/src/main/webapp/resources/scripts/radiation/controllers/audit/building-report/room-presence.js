'use strict';
angular.module('app').controller('RoomPresenceTab', function($q, AuditService, UtilService) {


  var roomPresenceCtrl = this;
  roomPresenceCtrl.roomPresenceData;


  roomPresenceCtrl.init = function() {
    var postParam = UtilService.searchDefaults;
    AuditService.roomPresenceReport({}, postParam)
    .$promise
    .then(function(res) {
      roomPresenceCtrl.roomPresenceData = _.filter(res, function(row) {
        if (!(_.isEmpty(row))) {
           return true;
        }
      });
      roomPresenceCtrl.totalItems = res.length;
    });
    roomPresenceCtrl.getTableHeader();
  };

  roomPresenceCtrl.getState = function(state) {
    return $q(function(resolve, reject) {
        return AuditService.roomPresenceReport({}, state)
        .$promise
        .then(function(res) {
          return resolve(res);
        });
    });
  };


  roomPresenceCtrl.getTableHeader = function() {
      roomPresenceCtrl.tableHeaders = {
      BUILDING: {
        field: 'building',
        displayName: 'Building'
      },
      ROOM: {
        field: 'room',
        displayName: 'Room'
      },
      RUA: {
        field: 'ruaNumber',
        displayName: 'RUA #s'
      },
      RADIONUCLIDE_NAME: {
        field: 'radionuclide',
        displayName: 'Radionuclides'
      }};
      roomPresenceCtrl.columns = Object.values(roomPresenceCtrl.tableHeaders);
  };

});
