'use strict';

angular.module('app').controller('RuaSurveyTab', function($location, $scope, $templateCache, $uibModal, StaticCollections, TableHeaderCollections, UaService, TypesService, SurveyService, UtilService, ConfirmModelService, PersonService) {
  var surveyTabCtrl = this;
  // surveyTabCtrl.currentUser = profile;
  var tableHeaderCollections = {};
  surveyTabCtrl.isAdmin = PersonService.isAdmin;

  surveyTabCtrl.init = function(ruaId) {
    surveyTabCtrl.surveyTypes = [];
    surveyTabCtrl.editData = [];
    surveyTabCtrl.getData(ruaId);
  };

  surveyTabCtrl.getTableHeader = function() {
    var dueDate = angular.copy(tableHeaderCollections.DATE_RANGE_SHORT);
    dueDate.field = 'dueDate';
    dueDate.displayName = 'Due Date (mm/dd/yyyy)';
    dueDate.enableFiltering = true;
    dueDate.width = '150';
    tableHeaderCollections['DUE_DATE'] = dueDate;

    tableHeaderCollections.SURVEY_TYPE.field = 'surveyType';
    tableHeaderCollections.SURVEY_TYPE.width = '100';
    tableHeaderCollections.SURVEY_TYPE.enableCellEditOnFocus = false;
    tableHeaderCollections.SURVEY_TYPE.enableCellEdit = false;

    tableHeaderCollections.EDIT.width = '70';
    tableHeaderCollections.EDIT.cellTemplate = $templateCache.get('rua-survey-edit.html'),

    tableHeaderCollections.DELETE.enableFiltering = false;
    tableHeaderCollections.DELETE.width = '70';
    tableHeaderCollections.DELETE.cellTemplate = $templateCache.get('rua-survey-delete.html'),

    tableHeaderCollections.PERFORMED_BY.width = '200';

    var performedDate = angular.copy(tableHeaderCollections.DATE_RANGE_SHORT);
    performedDate.field = tableHeaderCollections.PERFORMED_DATE.field;
    performedDate.displayName = tableHeaderCollections.PERFORMED_DATE.displayName;
    performedDate.enableFiltering = true;
    performedDate.width = '150';
    tableHeaderCollections.PERFORMED_DATE = performedDate;

    tableHeaderCollections.COMMENTS.enableFiltering = true;
    surveyTabCtrl.columns = surveyTabCtrl.colDefs();
    surveyTabCtrl.getTableFilters();
  };

  surveyTabCtrl.href = function(path) {
    $location.path(path);
  };

  surveyTabCtrl.getData = function(ruaId) {
    var defaultDates = SurveyService.getDefaultSurveyDueDates();
    SurveyService.getRuaSurveys({ruaId: ruaId})
      .$promise
      .then(function(response) {
        surveyTabCtrl.data = _.map(response, function(item) {
          if (item.performedBy) {
            item.performedBy.displayName = item.performedBy.firstName + ' ' + item.performedBy.lastName;
          }
          return item;
        });
        surveyTabCtrl.totalItems = surveyTabCtrl.data.length;
      }).then(function() {
        tableHeaderCollections = angular.copy(TableHeaderCollections);
        surveyTabCtrl.getTableHeader();
      });
  };

  surveyTabCtrl.getTableFilters = function() {
    SurveyService.getSurveyInspectors().$promise.then(function(response) {
      return _.map(response, function(item) {
        item.ref = _.cloneDeep(item);
        return item;
      });
    }).then(function(surveyInspectors) {
      surveyTabCtrl.surveyInspectorsList = surveyInspectors;
      var allRsoRst = _.map(surveyTabCtrl.surveyInspectorsList, function(person) {
        return {label: person.firstName + ' ' + person.lastName, value: person.id};
      });
      for (var key in StaticCollections.surveyTypes) {
        surveyTabCtrl.surveyTypes.push({label: StaticCollections.surveyTypes[key], value: key});
      }
      return surveyTabCtrl.surveyTypes;
    }).then(function(surveyTypes) {
      tableHeaderCollections.SURVEY_TYPE.filter.selectOptions = UtilService.sortUniqUnion(TableHeaderCollections.SURVEY_TYPE.filter.selectOptions, surveyTypes, 'label');
    });
  };

  surveyTabCtrl.deleteSurvey = function(survey) {
    ConfirmModelService.confirm(ConfirmModelService.ConfirmType.DELETE, {message: "Are you sure you want to delete this survey?"}, function() {
      SurveyService.deleteSurvey({ruaId: survey.ua.id, surveyId: survey.id})
        .$promise
        .then(function(response) {
          surveyTabCtrl.data = surveyTabCtrl.getData(survey.ua.id);
        });
    });
  };

  surveyTabCtrl.colDefs = function() {
    var list = [
      tableHeaderCollections.EDIT,
      tableHeaderCollections.PERFORMED_BY,
      tableHeaderCollections.PERFORMED_DATE,
      tableHeaderCollections.SURVEY_TYPE,
      tableHeaderCollections.DUE_DATE,
      tableHeaderCollections.COMMENTS,
      tableHeaderCollections.DELETE
    ];

    if (!surveyTabCtrl.isAdmin) {
      list = list.filter(function(item) {
        // return item.field !== tableHeaderCollections.EDIT.field &&
        return item.field !== tableHeaderCollections.DELETE.field;
      });
    }

    return list;
  };
})
  .run(function($templateCache) {
    $templateCache.put('rua-survey-table.html',
      '<div id="ruaSurveyTab" ui-grid="ctrl.gridOptions" class="data-grid" ng-if="ctrl.gridOptions.data"ui-grid-pagination ui-grid-edit></div>');
    $templateCache.put('rua-survey-delete.html',
      '<div class="delete-link">' +
      '<span><a href class="glyphicon glyphicon-trash text-danger" ng-click="grid.appScope.onDelete({ data: row.entity })" title="Delete Survey"></a></span>' +
      '</div>');
    $templateCache.put('rua-survey-edit.html',
      '<div class="edit-link">' +
      '<span ng-if="row.entity.id"><a href="#/survey/edit/{{row.entity.id}}" class="glyphicon {{ !grid.appScope.parentScope.isAdmin ? \'glyphicon-eye-open\' : \'glyphicon-edit\'}}" title="{{ !grid.appScope.parentScope.isAdmin ? \'View RUA \' : \'Edit RUA\'}}"></a></span>' +
      '</div>');
  });
