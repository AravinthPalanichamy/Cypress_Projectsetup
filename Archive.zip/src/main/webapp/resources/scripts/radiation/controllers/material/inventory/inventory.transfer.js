'use strict';

angular.module('app').controller('InventoryTransferCtrl', function(ExcelService, InventoryService, LabelService, TableHeaderCollections, MaterialUseService, EhsPickupService, WasteFormService) {
  var ctrl = this;

  ctrl.data = [];
  ctrl.tableHeaderCollections = _.cloneDeep(TableHeaderCollections);
  ctrl.useOption = {
    ACCEPTED: {id: 'ACCEPTED', label: 'Accept Transfer', template: 'choose-limit-form.html'},
    REJECTED: {id: 'REJECTED', label: 'Reject Transfer', template: ''}
  };

  ctrl.init = function(parent) {
    ctrl.currentRua = parent;
    ctrl.ua = parent.rua;
    ctrl.ruaNumber = parent.rua.number;
    ctrl.getTableData(parent.rua.id);
    ctrl.columns = ctrl.defineTable();
  };

  ctrl.getTableData = function(uaId) {
    InventoryService.getMaterialTransfersByUaAndStatus({ uaId: uaId, status: 'PENDING' }, function(response) {
      ctrl.data = response;
    });
  };

  ctrl.defineTable = function() {
    var referenceDate = _.cloneDeep(ctrl.tableHeaderCollections.DATE_RANGE_SHORT);
    referenceDate.field = 'material.initialDate';
    referenceDate.width = 150;
    referenceDate.displayName = 'Reference Date (mm/dd/yyyy)';
    referenceDate.enableFiltering = false;

    return [
      {displayName: 'Use', field: 'edit', width: 50, cellTemplate: "material-use.html", enableSorting: false, enableFiltering: false},
      {displayName: 'Material #', field: 'material.id', width: 100},
      {displayName: 'Radionuclide', field: 'material.radionuclideNameString'},
      {displayName: 'Initial Amount (mCi)', field: 'material.requestedAmount'},
      {displayName: 'Current Activity (mCi)', field: 'material.currentAmount'},
      {displayName: 'Initial Volume', headerCellTemplate: '<div class="ui-grid-cell-contents ui-grid-header-cell-label">Initial Volume(&micro;l)</div>', field: 'material.requestedVolume'},
      {displayName: 'Current Volume', headerCellTemplate: '<div class="ui-grid-cell-contents ui-grid-header-cell-label">Current Volume(&micro;l)</div>', field: 'material.currentVolume'},
      {displayName: 'Initial Mass (grams)', field: 'material.requestedElementalMass'},
      {displayName: 'Current Mass (grams)', field: 'material.currentElementalMass'},
      referenceDate,
      { displayName: 'From RUA', field: 'fromUa.number' },
      { displayName: 'To RUA', field: 'toUa.number' },
      { displayName: 'Institution Name', field: 'institutionName' }
    ];
  };

  ctrl.isTransferByRua = function(ruaNumber, row) {
    return ruaNumber === row.fromUa.number;
  };

  ctrl.onUseMaterial = function(option, material) {
    ctrl.transferMaterial = angular.copy(material);
    if (option.id === 'ACCEPTED') {
      MaterialUseService.openModal(option, ctrl.transferMaterial, ctrl.updateMaterial);
    } else if (option.id === 'REJECTED') {
      InventoryService.completeTransfer({materialTransferId: ctrl.transferMaterial.id, status: option.id}, {}).$promise
        .then(function(response) {
         ctrl.init(ctrl.currentRua);
      });
    }
  };

  ctrl.updateMaterial = function() {
    ctrl.init(ctrl.currentRua);
  };
})
  .run(function($templateCache) {

    var inventoryTransferTemplate = '<span ng-if="!row.entity.institutionName && !grid.appScope.parentScope.isTransferByRua(grid.appScope.parentScope.ruaNumber, row.entity)" uib-dropdown dropdown-append-to-body class="edit-link">' +
      '<a href uib-dropdown-toggle class="glyphicon glyphicon-edit"><span class="hideEditText">Use</span></a>' +
      '<ul class="dropdown-menu" uib-dropdown-menu>' +
      ' <li ng-click="grid.appScope.parentScope.onUseMaterial(grid.appScope.parentScope.useOption.ACCEPTED, row.entity)"><a href>{{grid.appScope.parentScope.useOption.ACCEPTED.label}}</a></li>' +
      ' <li ng-click="grid.appScope.parentScope.onUseMaterial(grid.appScope.parentScope.useOption.REJECTED, row.entity)"><a href>{{grid.appScope.parentScope.useOption.REJECTED.label}}</a></li>' +
      '</ul>' +
      '</span>';


    var printLabelTemplate = '<div ng-click="grid.appScope.parentScope.printLabel(row.entity)" class="edit-link">' +
      '<span><a class="glyphicon glyphicon-print"><span class="hideEditText">Print</span></a></span></div>';

    $templateCache.put('material-use.html', inventoryTransferTemplate);
    $templateCache.put('print-label.html', printLabelTemplate);
  });
