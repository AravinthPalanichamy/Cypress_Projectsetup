'use strict';

angular.module('app').controller('PendingMaterialRequestCtrl', function($location, TableHeaderCollections, pendingRequests) {
  var ctrl = this;

  ctrl.init = function() {
    ctrl.data = pendingRequests;
    ctrl.tableHeaderCollections = _.cloneDeep(TableHeaderCollections);
    ctrl.columns = ctrl.defineTable();
    ctrl.buttonList = [{label: "New Material Request", action: ctrl.newMaterialRequest}];
  };

  ctrl.defineTable = function() {
    ctrl.tableHeaderCollections.EDIT.cellTemplate = '<div class="edit-link"><span><a href="#/materials/request-edit/{{ row.entity.id }}?cancel=PENDING" class="glyphicon glyphicon-edit"><span class="hideEditText">Edit</span></a></span></div>';
    ctrl.tableHeaderCollections.RUA.field = 'ua.number';
    ctrl.tableHeaderCollections.RUA.width = 50;
    ctrl.tableHeaderCollections.PI_FIRST_NAME.field = 'ua.pi.firstName';
    ctrl.tableHeaderCollections.PI_LAST_NAME.field = 'ua.pi.lastName';

    var requestDate = _.cloneDeep(ctrl.tableHeaderCollections.DATE_RANGE_SHORT);
    requestDate.field = 'createdDate';
    requestDate.displayName = 'Requested Date (mm/dd/yyyy)';

    var referenceDate = _.cloneDeep(ctrl.tableHeaderCollections.DATE_RANGE_SHORT);
    referenceDate.field = 'initialDate';
    referenceDate.displayName = 'Reference Date (mm/dd/yyyy)';

    return [
      ctrl.tableHeaderCollections.EDIT,
      {field: 'id', displayName: 'RAM', width: 50},
      ctrl.tableHeaderCollections.RUA,
      ctrl.tableHeaderCollections.PI_FIRST_NAME,
      ctrl.tableHeaderCollections.PI_LAST_NAME,
      {field: 'id2', displayName: 'Leak Test', width: 50},
      requestDate,
      {displayName: 'Radionuclide', field: 'radionuclideNameString'},
      {displayName: 'Chemical Form', field: 'chemicalForm'},
      {displayName: 'Physical Form', field: 'physicalForm'},
      {displayName: 'Requested Amount (mCi)', field: 'requestedAmount', cellFilter: 'scientific'},
      {
        displayName: 'Requested Volume (microliter)', field: 'requestedVolume', cellFilter: 'scientific',
        headerCellTemplate: '<div class="ui-grid-cell-contents ui-grid-header-cell-label">Requested Volume(&micro;l)</div>'
      },
      {displayName: 'Requested Elemental Mass (grams)', field: 'requestedElementalMass', cellFilter: 'scientific'},
      {displayName: 'Requested Net Mass (grams)', field: 'requestedNetMass', cellFilter: 'scientific'},
      referenceDate
    ];
  };

  ctrl.newMaterialRequest = function() {
    $location.path("materials/request-create");
  };

  ctrl.init();
});
