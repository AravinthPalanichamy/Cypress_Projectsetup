'use strict';

angular.module('app').controller('PeoplePanelCtrl', function($location, person) {
  var ctrl = this;

  ctrl.panels = {
    GENERAL: 'General',
    DOCUMENTS: 'Documents',
    CHANGELOG: 'Changelog'
  };

  ctrl.init = function() {
    ctrl.person = person;
    ctrl.setPanel(ctrl.panels[$location.search().activePeopleTab] || ctrl.panels.GENERAL.toUpperCase());
  };

  ctrl.setPanel = function(panel) {
    ctrl.panel = panel.replace(/\s/g, '_').toUpperCase();
    $location.search("activePeopleTab", ctrl.panel).replace();
  };

  ctrl.getPanelValue = function(panel) {
    return panel ? panel.replace(/\s/g, '_').toUpperCase() : ctrl.panels.GENERAL.toUpperCase();
  };
});
