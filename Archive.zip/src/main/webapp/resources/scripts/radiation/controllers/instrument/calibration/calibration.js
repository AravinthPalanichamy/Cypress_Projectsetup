'use strict';
angular.module('app').controller('CalibrationCtrl', function($route, $uibModal, $scope, $filter, $timeout, UaService, PersonService, UtilService, StaticCollections, TableHeaderCollections, SurveyService, InstrumentService, ConfirmModelService) {
  var calibrationCtrl = this;
  calibrationCtrl.yesNoNaType = Object.keys(StaticCollections.yesNoNaType);
  calibrationCtrl.calibrationSourceType = StaticCollections.calibrationSourceType;
  calibrationCtrl.isAdmin = PersonService.isAdmin;
  calibrationCtrl.validationEnabled = true;

  calibrationCtrl.init = function() {
    calibrationCtrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
    calibrationCtrl.getTableHeader();
    calibrationCtrl.editData = [];
    InstrumentService.getInstrumentCalibrations({instrumentId: $route.current.params.instrumentId}).$promise.then(function(response) {
      calibrationCtrl.data = _.map(response, function(r) {
        if (r.vendorName) {
          r.calibratedBy = {displayName: 'Other Vendor'};
        }
        r.calibrationDateFormatted = $filter('date')(r.calibrationDate, 'shortDate');
        return r;
      });
      calibrationCtrl.chartData = calibrationCtrl.removeOtherVendor(calibrationCtrl.data);
      calibrationCtrl.calibrationLastPerformedDate = calibrationCtrl.data.length ? calibrationCtrl.data[calibrationCtrl.data.length - 1].calibrationDate : null;
      calibrationCtrl.showCalibrationGraph = calibrationCtrl.data.length ? true : false;
    });
    SurveyService.getSurveyInspectors().$promise.then(function(response) {
      calibrationCtrl.surveyInspectors = response;
      calibrationCtrl.surveyInspectors.push({displayName: 'Other Vendor'});
    });
    InstrumentService.get({instrumentId: $route.current.params.instrumentId}).$promise.then(function(response) {
      calibrationCtrl.instrument = response;
    });
    InstrumentService.getAllProbes().$promise.then(function(response) {
      calibrationCtrl.probes = response;
    });
    InstrumentService.getAllCalibrationSources().$promise.then(function(response) {
      calibrationCtrl.calibrationSources = response;
    });
    InstrumentService.getAllProbeResponseCheckSources().$promise.then(function(response) {
      calibrationCtrl.probeResponseCheckSources = response;
    });
    InstrumentService.getMeterRange().$promise.then(function(response) {
      calibrationCtrl.meterRangeList = response;
    });

    if (calibrationCtrl.isAdmin) {
      calibrationCtrl.buttonList = [
        {
          label: "New Calibration",
          action: calibrationCtrl.onAddNewCalibration
        }
      ];
    }

  };
  calibrationCtrl.removeOtherVendor = function(data) {
    return _.filter(data, function(d) {
      return (d.calibratedBy['displayName'] != "Other Vendor");
    });
  };
  calibrationCtrl.onAddNewCalibration = function() {
    calibrationCtrl.showCalibrationForm = true;
    calibrationCtrl.showCalibrationGraph = false;
    calibrationCtrl.validationEnabled = true;

    calibrationCtrl.filteredCalibrationSources = [];
    calibrationCtrl.calibration = {instrument: calibrationCtrl.instrument, entryDate: new Date()};
    calibrationCtrl.calibration.calibrationMatrix = [];
    calibrationCtrl.initProbeResponseCheckSources();
    calibrationCtrl.meterRangeList.forEach(function(meterRange) {
      calibrationCtrl.calibration.calibrationMatrix.push({meterRange: meterRange});
    });
    if (calibrationCtrl.data.length) {
      var lastCalibration = calibrationCtrl.data[calibrationCtrl.data.length - 1];
      lastCalibration.calibrationMatrix.forEach(function(cm) {
        var match = _.find(calibrationCtrl.calibration.calibrationMatrix, function(calMatrix) {
          return calMatrix.meterRange.id === cm.meterRange.id;
        });
        if (match) {
          match.pulseOrExposureRate = cm.pulseOrExposureRate;
        }
      });
    }
    calibrationCtrl.calibrationNextDue = UtilService.calculateNextDue(calibrationCtrl.instrument.calibrationFrequency.frequency, calibrationCtrl.calibrationLastPerformedDate);
  };

  calibrationCtrl.initProbeResponseCheckSources = function() {
    calibrationCtrl.calibration.probeResponseChecks = [];
    calibrationCtrl.probeResponseCheckSources.forEach(function(probeResponseCheckSource) {
      calibrationCtrl.calibration.probeResponseChecks.push({probeResponseCheckSource: probeResponseCheckSource});
    });
  };

  calibrationCtrl.onEditCalibration = function(calibration) {
    calibrationCtrl.showCalibrationForm = true;
    calibrationCtrl.assignCalibration(calibration, 'EDIT');
    calibrationCtrl.calibrationNextDue = UtilService.calculateNextDue(calibrationCtrl.instrument.calibrationFrequency.frequency, calibrationCtrl.calibrationLastPerformedDate);
    calibrationCtrl.validationEnabled = (calibrationCtrl.calibration.calibratedBy.displayName === 'Other Vendor') ? false : true;

  };

  calibrationCtrl.onSave = function(form) {
    if (form.$valid) {
      var clonedCalibration = _.cloneDeep(calibrationCtrl.calibration);
      if (clonedCalibration.vendorName) {
        delete clonedCalibration.calibratedBy;
      }
      InstrumentService.upsertCalibration({}, clonedCalibration).$promise.then(function(response) {
        calibrationCtrl.calibration.id = response.id;
        if (response.calibrationDate) {
          calibrationCtrl.instrument.calibrationNextDue = UtilService.calculateNextDue(calibrationCtrl.instrument.calibrationFrequency.frequency, response.calibrationDate);
          InstrumentService.upsert({}, calibrationCtrl.instrument).$promise.then(function(instrument) {
            calibrationCtrl.instrument = instrument;
          });
        }
        ConfirmModelService.confirm(ConfirmModelService.ConfirmType.SUCCESS, {message: 'Calibration has been saved.'}, function() {
          calibrationCtrl.assignCalibration(response, 'SAVE');
        });
      });
    }
  };

  calibrationCtrl.assignCalibration = function(calibration, action) {
    calibrationCtrl.calibration = calibration;
    calibrationCtrl.onCalibrationTypeClicked(action);

    if (calibrationCtrl.calibration.calibrationSource != null) {
        calibrationCtrl.calibration.calibrationSource = _.find(calibrationCtrl.filteredCalibrationSources, {id: calibrationCtrl.calibration.calibrationSource.id});
    }

    if (calibrationCtrl.calibration.vendorName) {
      calibrationCtrl.calibration.calibratedBy = _.find(calibrationCtrl.surveyInspectors, {displayName: 'Other Vendor'});
    } else {
      calibrationCtrl.calibration.calibratedBy = _.find(calibrationCtrl.surveyInspectors, {id: calibrationCtrl.calibration.calibratedBy.id});
    }
  };

  calibrationCtrl.getTableHeader = function() {
    calibrationCtrl.tableHeaders = {
      EDIT: Object.assign({}, calibrationCtrl.tableHeaderCollections.EDIT, {cellTemplate: 'calibration-table-edit.html'}),
      CALIBRATION_DATE: Object.assign({}, angular.copy(calibrationCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'calibrationDate',
        displayName: 'Calibration Date',
        width: 125,
        enableFiltering: false
      }),
      PROBE_TYPE: {
        field: 'probe.model',
        displayName: 'Probe Type',
        enableFiltering: false
      },
      PROBE_SERIAL: {
        field: 'probe.serial',
        displayName: 'Probe Serial',
        enableFiltering: false
      },
      BACKGROUND: {
        field: 'background',
        displayName: 'Background',
        enableFiltering: false
      },
      VOLTAGE: {
        field: 'voltage',
        displayName: 'Voltage',
        enableFiltering: false,
        width: 80
      },
      CALIBRATION_TYPE: {
        field: 'calibrationType',
        displayName: 'Calibration Type',
        enableFiltering: false,
        cellTemplate: "format-to-camelcase.html"
      },
      CALIBRATION_SOURCE: {
        field: 'calibrationSource.name',
        displayName: 'Calibration Source',
        enableFiltering: false
      },
      CALIBRATED_BY: {
        field: 'calibratedBy.displayName',
        displayName: 'Calibrated By',
        enableFiltering: false
      }
    };
    calibrationCtrl.columns = Object.values(calibrationCtrl.tableHeaders);
  };

  calibrationCtrl.openDatePicker = function(type) {
    calibrationCtrl.isOpen = {};
    calibrationCtrl.isOpen[type] = true;
  };

  calibrationCtrl.onCalibrationTypeClicked = function(action) {
    if (calibrationCtrl.calibration.calibrationType === 'PULSE_GENERATOR_CALIBRATION') {
      calibrationCtrl.rateAppliedType = 'Pulse';
      calibrationCtrl.filteredCalibrationSources = calibrationCtrl.filterCalibrationSources('PULSE_GENERATOR_CALIBRATION');
    } else if (calibrationCtrl.calibration.calibrationType === 'RANGE_CALIBRATION') {
      calibrationCtrl.calibration.meterScale = 'mR/hr';
      calibrationCtrl.rateAppliedType = 'Exposure';
      calibrationCtrl.filteredCalibrationSources = calibrationCtrl.filterCalibrationSources('RANGE_CALIBRATION');
    } else {
      calibrationCtrl.calibration.meterScale = '';
      calibrationCtrl.rateAppliedType = '';
    }
    calibrationCtrl.addNewProbeResponseCheckSources();
  };

  calibrationCtrl.filterCalibrationSources = function(type) {
    return _.filter(calibrationCtrl.calibrationSources, function(calibrationSource) {
      return calibrationSource.calibrationType === type;
    });
  };

  calibrationCtrl.onCancel = function() {
    calibrationCtrl.init();
    calibrationCtrl.showCalibrationForm = false;
  };

  calibrationCtrl.calculatePercentageEfficiency = function(probeResponseCheck) {
    if (probeResponseCheck.cpmReading && probeResponseCheck.dpmOfSource) {
      probeResponseCheck.percentageEfficiency = parseFloat(((probeResponseCheck.cpmReading / probeResponseCheck.dpmOfSource) * 100).toFixed(2));
    } else {
      probeResponseCheck.percentageEfficiency = null;
    }
  };

  calibrationCtrl.calculatePercentageError = function(cm) {
    if (cm.readingFound && cm.pulseOrExposureRate) {
      cm.percentageError = parseFloat((Math.abs(100.00 - ((cm.readingFound / cm.pulseOrExposureRate) * 100)).toFixed(2)));
    } else {
      cm.percentageError = null;
    }
  };

  calibrationCtrl.upsertProbe = function(probe) {
    probe.campus = calibrationCtrl.instrument.createdBy.campus;
    InstrumentService.upsertProbe({}, probe).$promise.then(function(response) {
      calibrationCtrl.probes.push(response);
      calibrationCtrl.calibration.probe = response;
      calibrationCtrl.probeAdded = true;
      calibrationCtrl.setTimeout('PROBE');
    });
  };

  calibrationCtrl.upsertCalibrationSource = function(calibrationSource) {
    calibrationSource.campus = calibrationCtrl.instrument.createdBy.campus;
    InstrumentService.upsertCalibrationSource({}, calibrationSource).$promise.then(function(response) {
      calibrationCtrl.calibrationSources.push(response);
      if (calibrationCtrl.calibration.calibrationType) {
        calibrationCtrl.filteredCalibrationSources = calibrationCtrl.filterCalibrationSources(calibrationCtrl.calibration.calibrationType);
        if (calibrationCtrl.calibration.calibrationType === calibrationSource.calibrationType && calibrationCtrl.filteredCalibrationSources.length) {
          calibrationCtrl.calibration.calibrationSource = calibrationCtrl.filteredCalibrationSources[calibrationCtrl.filteredCalibrationSources.length - 1];
        }
      }
      calibrationCtrl.calibrationSourceAdded = true;
      calibrationCtrl.setTimeout('CALIBRATION_SOURCE');
    });
  };

  calibrationCtrl.upsertProbeResponseCheckSource = function(probeResponseCheckSource) {
    probeResponseCheckSource.campus = calibrationCtrl.instrument.createdBy.campus;
    InstrumentService.upsertProbeResponseCheckSource({}, probeResponseCheckSource).$promise.then(function(response) {
      calibrationCtrl.probeResponseCheckSources.push(response);
      calibrationCtrl.addNewProbeResponseCheckSources();
      calibrationCtrl.probeResponseCheckSourceAdded = true;
      calibrationCtrl.setTimeout('PROBE_RESPONSE_CHECK_SOURCE');
    });
  };

  calibrationCtrl.addNewProbeResponseCheckSources = function() {
    calibrationCtrl.probeResponseCheckSources.forEach(function(probeResponseCheckSource) {
      var match = _.find(calibrationCtrl.calibration.probeResponseChecks, function(calibrationProbeResponseChecks) {
        return calibrationProbeResponseChecks.probeResponseCheckSource.id === probeResponseCheckSource.id;
      });
      if (!match) {
        calibrationCtrl.calibration.probeResponseChecks.push({probeResponseCheckSource: probeResponseCheckSource});
      }
    });
  };

  calibrationCtrl.setTimeout = function(type) {
    $timeout(function() {
      if (type === calibrationCtrl.calibrationSourceType.PROBE) {
        calibrationCtrl.probeAdded = false;
      } else if (type === calibrationCtrl.calibrationSourceType.CALIBRATION_SOURCE) {
        calibrationCtrl.calibrationSourceAdded = false;
      } else if (type === calibrationCtrl.calibrationSourceType.PROBE_RESPONSE_CHECK_SOURCE) {
        calibrationCtrl.probeResponseCheckSourceAdded = false;
      }
    }, 3000);
  };

  calibrationCtrl.onChangeCalibratedBy = function() {

    if (typeof calibrationCtrl.calibration.calibratedBy != 'undefined') {
      calibrationCtrl.validationEnabled = (calibrationCtrl.calibration.calibratedBy.displayName === 'Other Vendor') ? false : true;
    }

    if (calibrationCtrl.calibration.calibratedBy && calibrationCtrl.calibration.calibratedBy.displayName !== 'Other Vendor') {
      calibrationCtrl.calibration.vendorName = undefined;
    }

  };

  calibrationCtrl.openFormModal = function(type, callback) {
    var templateUrl;
    if (type === calibrationCtrl.calibrationSourceType.PROBE) {
      templateUrl = 'resources/scripts/radiation/controllers/instrument/calibration/probe/probe.html';
    } else if (type === calibrationCtrl.calibrationSourceType.CALIBRATION_SOURCE) {
      templateUrl = 'resources/scripts/radiation/controllers/instrument/calibration/calibration-source/calibration-source.html';
    } else if (type === calibrationCtrl.calibrationSourceType.PROBE_RESPONSE_CHECK_SOURCE) {
      templateUrl = 'resources/scripts/radiation/controllers/instrument/calibration/probe-source/probe-source.html';
    }
    $uibModal.open({
      templateUrl: templateUrl,
      backdrop: 'static',
      size: 'md',
      keyboard: false,
      controllerAs: '$ctrl',
      controller: function($uibModalInstance) {

        var $ctrl = this;

        $ctrl.cancel = function() {
          $uibModalInstance.close();
        };

        $ctrl.submit = function(form) {
          if (form.$valid) {
            var formObj;
            if (type === calibrationCtrl.calibrationSourceType.PROBE) {
              formObj = $ctrl.probe;
            } else if (type === calibrationCtrl.calibrationSourceType.CALIBRATION_SOURCE) {
              formObj = $ctrl.calibrationSource;
            } else if (type === calibrationCtrl.calibrationSourceType.PROBE_RESPONSE_CHECK_SOURCE) {
              formObj = $ctrl.probeResponseCheckSource;
            }
            callback(formObj);
            $ctrl.cancel();
          }
        };
      }
    });
  };
})
  .run(function($templateCache) {
    var calibrationEditTemplate = '<div class="edit-link"><span ng-if="row.entity.id"><a ng-href="" ng-click="grid.appScope.parentScope.onEditCalibration(row.entity)" class="glyphicon {{ !grid.appScope.parentScope.isAdmin ? \'glyphicon-eye-open\' : \'glyphicon-edit\'}}" title="Edit Calibration"></a></span></div>';
    $templateCache.put('calibration-table-edit.html', calibrationEditTemplate);
  });

