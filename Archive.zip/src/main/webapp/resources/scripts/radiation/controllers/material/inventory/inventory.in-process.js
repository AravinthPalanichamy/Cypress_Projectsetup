'use strict';

angular.module('app').controller('InventoryInProcessCtrl', function($uibModal, ExcelService, InventoryService, MaterialUseService, TableHeaderCollections, WasteService, PersonService) {
  var ctrl = this;

  ctrl.data = [];
  ctrl.tableHeaderCollections = _.cloneDeep(TableHeaderCollections);
  ctrl.useOptions = [
    {id: 'IN_DISPOSAL', label: 'Dispose in Local Waste Container', template: 'in-waste-container-form.html', status: 'IN_LOCAL_WASTE'}
  ];

  ctrl.init = function(parent) {
    ctrl.ruaNumber = parent.rua.number;
    ctrl.ruaId = parent.rua.id;
    ctrl.buttonList = [{label: 'Export', action: ctrl.exportExcel}];
    if (ctrl.hasInventoryAccess()) {
      ctrl.useOptions.push({ id: 'TRANSFER', label: 'Transfer Material', template: 'transfer-form.html' });
    }
    ctrl.columns = ctrl.defineTable();
    ctrl.getTableData(ctrl.ruaId);
  };

  ctrl.hasInventoryAccess = function() {
    return PersonService.isAdmin || PersonService.isRP_OR_DEL;
  };

  ctrl.getTableData = function(uaId, containerId) {
    InventoryService.getMaterialsByUaAndInventoryStatusType({
      uaId: uaId,
      inventoryStatusType: 'IN_PROCESS'
    }, function(response) {
      ctrl.data = response;
      if (containerId) {
        WasteService.updateWasteTagForContainer({ruaId: ctrl.ruaId, containerId: containerId}, {});
      }
    });
  };

  ctrl.defineTable = function() {
    var use = _.cloneDeep(ctrl.tableHeaderCollections.EDIT);
    use.displayName = 'Use';
    use.field = 'useMaterial';
    use.enableFiltering = false;
    use.cellTemplate = '' +
      '<span uib-dropdown dropdown-append-to-body class="edit-link">' +
      '<a href uib-dropdown-toggle class="glyphicon glyphicon-edit"><span class="hideEditText">Print</span></a>' +
      '<ul class="dropdown-menu" uib-dropdown-menu>' +
      '<li ng-repeat="option in grid.appScope.parentScope.useOptions" ng-click="grid.appScope.parentScope.useMaterial(option, row.entity)"><a href>{{ option.label }}</a></li>' +
      '</ul>' +
      '</span>';

    return [
      use,
      {displayName: 'Material #', field: 'id' },
      {displayName: 'Process Name', field: 'processName'},
      {displayName: 'Radionuclide', field: 'radionuclideNameString'},
      {displayName: 'Chemical Form', field: 'chemicalForm'},
      {displayName: 'Current Activity (mCi)', field: 'currentAmount'},
      {
        displayName: 'Current Volume (microliter)', field: 'currentVolume',
        headerCellTemplate: '<div class="ui-grid-cell-contents ui-grid-header-cell-label">Current Volume(&micro;l)</div>'
      },
      {displayName: 'Elemental Mass (grams)', field: 'currentElementalMass'},
      {displayName: 'Net Mass (grams)', field: 'currentNetMass'}
    ];
  };

  ctrl.save = function(material, options) {
      InventoryService.useMaterial(options, material).$promise.then(function(response) {
        ctrl.getTableData(ctrl.ruaId, material.getContainerId);
      });
  };

  ctrl.exportExcel = function() {
    var excelData = ctrl.filteredRows.map(function(row) {
      return {
        'Process Name': row.processName,
        'Material Number': row.id,
        'Radionuclide': row.radionuclideNameString,
        'Chemical Form': row.chemicalForm,
        'Current Activity (mCi)': row.currentAmount,
        'Current Volume (µl)': row.currentVolume,
        'Elemental Mass (grams)': row.currentElementalMass,
        'Net Mass (grams)': row.currentNetMass
      };
    });

    var name = ctrl.ruaNumber + ' RAM In Process';
    ExcelService.export(excelData, name, {withTimeStamp: true});
  };

  ctrl.useMaterial = function(option, material) {
    var callback = ctrl.save;
    if (option.id === 'TRANSFER') {
      callback = function() { ctrl.getTableData(ctrl.ruaId); };
    }
    MaterialUseService.openModal(option, _.cloneDeep(material), callback);
  };

});
