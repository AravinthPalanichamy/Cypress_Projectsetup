'use strict';

angular.module('app').controller('SurveyAssignmentListCtrl', function($location, $scope, $templateCache, PersonService, StaticCollections, TemplateUtils, TableHeaderCollections, UaService, TypesService, surveyInspectors, SurveyService, UtilService, data) {
  var ctrl = this;
  var tableHeaderCollections = {};
  ctrl.isAdmin = PersonService.isAdmin;
  var defaultDates = SurveyService.getDefaultSurveyDueDates();
  ctrl.startDate = defaultDates.startDate;
  ctrl.endDate = defaultDates.endDate;
  ctrl.isOpen = {startDate: false, endDate: false};
  ctrl.addRecordUrl = !ctrl.isAdmin ? '' : '/survey/create';

  ctrl.init = function() {
    ctrl.buttonList = [];
    ctrl.surveyInspectorsList = surveyInspectors;
    ctrl.surveyTypes = [];
    ctrl.data = data;
    ctrl.editData = [];
    tableHeaderCollections = angular.copy(TableHeaderCollections);
    if (ctrl.isAdmin) {
      ctrl.buttonList = [
        {
          label: "Assign Work",
          action: ctrl.assignWork
        }
      ];
    }

    for (var key in StaticCollections.surveyTypes) {
      ctrl.surveyTypes.push({label: StaticCollections.surveyTypes[key], value: key});
    }
    ctrl.getTableHeader();
  };

  ctrl.getTableHeader = function() {
    tableHeaderCollections.RUA.field = 'ua.number';
    tableHeaderCollections.PI_FIRST_NAME.field = 'ua.pi.firstName';
    tableHeaderCollections.PI_LAST_NAME.field = 'ua.pi.lastName';

    tableHeaderCollections.RUA_TYPE.field = 'ua.type';
    tableHeaderCollections.RUA_TYPE.displayName = 'RUA Type';

    tableHeaderCollections.SURVEY_FREQ.field = 'ua.frequency.frequency';

    tableHeaderCollections.DATE_RANGE_SHORT.field = 'ua.expiryDate';
    tableHeaderCollections.DATE_RANGE_SHORT.displayName = 'Expiration Date (mm/dd/yyyy)';
    tableHeaderCollections.DATE_RANGE_SHORT.width = 125;
    tableHeaderCollections.DATE_RANGE_SHORT.enableFiltering = false;

    tableHeaderCollections.STATUS.field = 'ua.status';
    tableHeaderCollections.STATUS.displayName = 'RUA Status';
    tableHeaderCollections.STATUS.width = '80';

    var dueDate = angular.copy(tableHeaderCollections.DATE_RANGE_SHORT);
    dueDate.field = 'dueDate';
    dueDate.displayName = 'Due Date (mm/dd/yyyy)';
    dueDate.enableFiltering = false;
    tableHeaderCollections['DUE_DATE'] = dueDate;

    tableHeaderCollections.SURVEY_TYPE.field = 'surveyType';
    tableHeaderCollections.SURVEY_TYPE.width = '100';
    if (ctrl.isAdmin) {
      tableHeaderCollections.SURVEY_TYPE.cellTemplate = TemplateUtils.getDropdownTemplate(ctrl.surveyTypes, "-- status --", tableHeaderCollections.SURVEY_TYPE);
    }
    tableHeaderCollections.INTERVAL.displayName = 'RUA Usage Interval';
    tableHeaderCollections.INTERVAL.field = 'usageInterval';
    tableHeaderCollections.INTERVAL.width = '70';

    tableHeaderCollections.ASSIGNED_TO.field = "assignedTo.displayName";
    if (ctrl.isAdmin) {
      tableHeaderCollections.ASSIGNED_TO.cellTemplate = TemplateUtils.getPersonDropdownTemplate(ctrl.surveyInspectorsList, "-- assigned to --", tableHeaderCollections.ASSIGNED_TO);
    }
    tableHeaderCollections.EDIT.cellTemplate = $templateCache.get('predictive-survey-edit.html');
    tableHeaderCollections.EDIT.width = '70';

    ctrl.columns = ctrl.colDefs();

    ctrl.getTableFilters();
  };

  ctrl.href = function(path) {
    $location.path(path);
  };

  ctrl.getData = function() {
    SurveyService.getSurveysDue({
      startDate: ctrl.startDate,
      endDate: ctrl.endDate
    }).$promise.then(function(response) {
      ctrl.data = _.map(response, function(item) {
        if (item.assignedTo) {
          item.assignedTo.displayName = item.assignedTo.firstName + ' ' + item.assignedTo.lastName;
        }
        return item;
      });
    });
  };

  ctrl.getTableFilters = function() {
    TypesService.getFrequencyList({}, {})
      .$promise
      .then(function(data) {
        var surveyFreq = _.map(data, function(value, key) {
          return {label: value.frequency, value: value.frequency};
        });

        var allRsoRst = _.map(ctrl.surveyInspectorsList, function(person) {
          return {label: person.firstName + ' ' + person.lastName, value: person.id};
        });

        var statusType = _.map(StaticCollections.uaStatusHash, function(value, key) {
          return {label: value, value: key};
        });

        ctrl.getSortedFilters(surveyFreq, statusType, allRsoRst, ctrl.surveyTypes);
      });
  };

  ctrl.getSortedFilters = function(surveyFreq, statusType, allRsoRst, surveyTypes) {
    tableHeaderCollections.SURVEY_FREQ.filter.selectOptions = UtilService.sortUniqUnion(TableHeaderCollections.SURVEY_FREQ.filter.selectOptions, surveyFreq, 'label');
    tableHeaderCollections.RUA_TYPE.filter.selectOptions = UtilService.sortUniqUnion(TableHeaderCollections.RUA_TYPE.filter.selectOptions, StaticCollections.UATypesHash, 'label');
    tableHeaderCollections.STATUS.filter.options = UtilService.sortUniqUnion(TableHeaderCollections.STATUS.filter.options, statusType, 'label');
    tableHeaderCollections.ASSIGNED_TO.filter.selectOptions = UtilService.sortUniqUnion(TableHeaderCollections.ASSIGNED_TO.filter.selectOptions, allRsoRst, 'label');
    tableHeaderCollections.SURVEY_TYPE.filter.selectOptions = UtilService.sortUniqUnion(TableHeaderCollections.SURVEY_TYPE.filter.selectOptions, surveyTypes, 'label');
    tableHeaderCollections.INTERVAL.filter.selectOptions = UtilService.sortUniqUnion(TableHeaderCollections.INTERVAL.filter.selectOptions, StaticCollections.uaUsageIntervalHash, 'label');
  };

  ctrl.colDefs = function() {
    return [
      tableHeaderCollections.EDIT,
      tableHeaderCollections.RUA,
      tableHeaderCollections.PI_FIRST_NAME,
      tableHeaderCollections.PI_LAST_NAME,
      tableHeaderCollections.RUA_TYPE,
      tableHeaderCollections.SURVEY_FREQ,
      tableHeaderCollections.DATE_RANGE_SHORT,
      tableHeaderCollections.STATUS,
      tableHeaderCollections.DUE_DATE,
      tableHeaderCollections.SURVEY_TYPE,
      tableHeaderCollections.ASSIGNED_TO,
      tableHeaderCollections.LATEST_SURVEY_DONE_BY,
      tableHeaderCollections.INTERVAL,
      tableHeaderCollections.LEAK_TEST_REQUIRED
    ];
  };

  ctrl.openDatePicker = function($event, open) {
    $event.preventDefault();
    $event.stopPropagation();
    ctrl.isOpen[open] = true;
  };

  ctrl.onStartDateChange = function() {
    if (moment(ctrl.startDate).isValid()) {
      ctrl.endDate = moment(ctrl.startDate).endOf('month').toDate();
    }
  };

  ctrl.assignWork = function() {
    var assignedWork = ctrl.editData;
    if (assignedWork.length > 0) {
      SurveyService.saveSurveys({}, assignedWork).$promise.then(function() {
        ctrl.getData();
      });
    }
  };

  // the data that is changed in the row is marked dirty in the directive
  // it's watched here and filtered out (as a new object) into an array
  // that holds the edited data which should be persisted
  $scope.$watch('ctrl.data', function(newVal) {
    ctrl.editData = _.chain(newVal)
      .filter(function(item) {
        return item.dirty;
      })
      .map(function(item) {
        return _.cloneDeep(item);
      })
      .value();
  }, true);
})

  .run(function($templateCache) {
    var predictiveSurveyEditTemplate = '<div class="edit-link"><span ng-if="row.entity.id"><a href="#/survey/edit/{{row.entity.id}}" class="glyphicon {{ !grid.appScope.parentScope.isAdmin ? \'glyphicon-eye-open\' : \'glyphicon-edit\'}}" title="{{ !grid.appScope.parentScope.isAdmin ? \'View Survey \' : \'Edit Survey\'}}"></a></span></div>';
    $templateCache.put('predictive-survey-edit.html', predictiveSurveyEditTemplate);
  });
