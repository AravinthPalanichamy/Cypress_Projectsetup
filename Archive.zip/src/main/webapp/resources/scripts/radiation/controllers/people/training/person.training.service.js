'use strict';

angular.module('app').factory('PersonTrainingService', function($resource, $http, $uibModal) {

  var service = {
    isOpen: false,
    /*
     - user: Person Object
     [userId, firtsName, lastName] - required fields
     */
    checkLMS: function(user) {
      if (service.isOpen) return true;

      var uibModal = $uibModal.open({
        templateUrl: 'resources/scripts/radiation/controllers/people/training/person-lms.html',
        controllerAs: '$ctrl',
        size: 'md',
        keyboard: false,
        windowTopClass: 'lms-model',
        backdrop: 'static',
        resolve: {
          lmsCheck: function(PersonService) {
              return PersonService.getAllPersonTrainings({userId: user.userId}).$promise
                .then(function(response) {
                  return response.length > 0 ? 'Person Record Found!' : 'No Person Record';
                });
            }
        },
        controller: function($uibModalInstance, lmsCheck, $templateCache) {

          var $ctrl = this;
          service.isOpen = true;
          $ctrl.lmsCheck = angular.copy(lmsCheck || null);
          $ctrl.init = function() {
            $ctrl.user = user;
          };

          $ctrl.cancel = function() {
            service.isOpen = false;
            $uibModalInstance.dismiss('cancel');
          };

          $ctrl.init();
        }

      });
      return uibModal;
    },
    showTrainings: function(user) {
      if (service.isOpen) return true;

      var uibModal = $uibModal.open({
        templateUrl: 'resources/scripts/radiation/controllers/people/training/person-training.html',
        controllerAs: '$ctrl',
        size: 'lg',
        keyboard: false,
        windowTopClass: 'training-model',
        backdrop: 'static',
        resolve: {
          trainings: function(PersonService) {
            return PersonService.getTrainings({userId: user.userId}).$promise
                  .then(markExpiredTraining);
          }
        },
        controller: function($uibModalInstance, TableHeaderCollections, trainings, $templateCache) {

          var $ctrl = this;
          service.isOpen = true;
          $ctrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
          $ctrl.tableHeaders = {};
          $ctrl.trainings = angular.copy(trainings || []);

          $ctrl.init = function() {
            $ctrl.user = user;
            $ctrl.getTableHeader();
          };

          $ctrl.getTableHeader = function() {
            $ctrl.tableHeaders = {
              STATUS: {
                field: 'Edit',
                width: 55,
                cellTemplate: $templateCache.get('training-status-icon.html')
              },
              COURSE: {
                field: 'activityName',
                displayName: 'Course'
              },
              COURSE_STATUS: {
                field: 'trxStatusDesc',
                displayName: 'Status',
                cellFilter: 'trainingStatus : row.entity',
                width: 125
              },
              COMPLETED_ON: {
                field: 'trxEndDate',
                displayName: 'Completed On',
                width: 125,
                cellTemplate: "format-to-date.html"
              },
              EXPIRY_DATE: {
                field: 'trxExpiryDate',
                displayName: 'Expires On',
                width: 125,
                cellTemplate: "format-to-date-with-na.html",
                cellClass: function(grid, row, col, rowRenderIndex, colRenderIndex) {
                  return (row.entity.trainingExpired) ? 'text-danger' : '';
                }
              }
            };

            $ctrl.trainingColumns = Object.values($ctrl.tableHeaders);
          };

          $ctrl.cancel = function() {
            service.isOpen = false;
            $uibModalInstance.dismiss('cancel');
          };

          $ctrl.init();
        }
      });

      return uibModal;
    }
  };

  var markExpiredTraining = function(response) {
    return _.map(response,function(training) {
      var currDate = moment(new Date()).format('YYYY-MM-DD');
      training.trainingExpired = (moment(training.trxExpiryDate).isBefore(currDate));
      return training;
    });
  };

  return service;
})
.run(function($templateCache) {
  $templateCache.put('training-status-icon.html',
    '<div class="text-center"> ' +
    '<i class="glyphicon" ng-class="{\'glyphicon-alert text-danger\': row.entity.trainingExpired, \'glyphicon-ok text-success\': !row.entity.trainingExpired }" title="{{row.entity.trainingExpired ? \'Expired\' : \'Current\'}}"></i>' +
    '</div>');
});
