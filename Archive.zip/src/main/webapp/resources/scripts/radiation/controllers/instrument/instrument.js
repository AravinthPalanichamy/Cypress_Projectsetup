'use strict';
angular.module('app').controller('InstrumentCtrl', function($location, UaService, profile, PersonService, TypesService, StaticCollections, InstrumentService, instrument) {
  var ctrl = this;
  ctrl.currentUser = profile;
  ctrl.isAdmin = PersonService.isAdmin;
  ctrl.ruaTypes = StaticCollections.uaTypeHash;
  ctrl.instrument = instrument;
  ctrl.successMessage = null;

  ctrl.init = function() {
    ctrl.initPanels();
    ctrl.setPanel(ctrl.panels[$location.search().activeInstrumentTab] || ctrl.panels.GENERAL);
    ctrl.calibrationDueStatusTypes = Object.keys(StaticCollections.calibrationDueStatusTypes);

    UaService.getUaListByStatusAndCampusCode({
      uaStatus: StaticCollections.getKeyByValue(StaticCollections.uaStatusHash, "Active"),
      campusCode: ctrl.currentUser.campus.code
    }, {}).$promise.then(function(response) {
      ctrl.useAuthorizations = response;
    });

    TypesService.getFrequencyList({}, {}).$promise
      .then(function(response) {
        ctrl.calibrationFrequencyType = angular.copy(response);
      });
  };

  ctrl.initPanels = function() {
    ctrl.panels = {GENERAL: 'General'};
    if (ctrl.instrument.id) {
      ctrl.panels.CALIBRATIONS = 'Calibrations';
      ctrl.panels.DOCUMENTS = 'Documents';
      ctrl.panels.CHANGELOG = 'Changelog';
    }
  };

  ctrl.setPanel = function(panel) {
    ctrl.panel = panel;
    $location.search("activeInstrumentTab", panel.toUpperCase());
  };

  ctrl.typeaheadLabel = function(ua, value) {
    if (ua && typeof ua !== 'string') {
      var radionuclides = value ? radionuclidesFilter(ua, value) : [];
      var label = 'RUA # ' + ua.number + ' ( ' + ua.pi.lastName + ', ' + ua.pi.firstName + ' )';
      label = radionuclides.length > 0 ? label.concat(' ( ' + radionuclides.join(' / ') + ' )') : label;
      return label;
    }
    return ua;
  };

  function radionuclidesFilter(ua, value) {
    return ua.radionuclides.filter(function(isotope) {
      return value.split(' ').some(function(input) {
        return isotope.toLowerCase().indexOf(input.toLowerCase()) !== -1;
      });
    });
  }

  ctrl.selectUa = function(ua) {
    ctrl.instrument.ua = ua;
  };

  ctrl.onSave = function(form) {
    if (form.$valid) {
      InstrumentService.upsert({}, ctrl.instrument).$promise.then(function(response) {
        ctrl.instrument = response;
        ctrl.successMessage = 'Your instrument has been saved.';
        $location.path('/instrument/edit/' + ctrl.instrument.id);
      });
    }
  };

  ctrl.hideSuccessMsg = function() {
    ctrl.successMessage = null;
  };
});
