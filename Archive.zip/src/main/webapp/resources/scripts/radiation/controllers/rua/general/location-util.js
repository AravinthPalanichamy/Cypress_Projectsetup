'use strict';

angular.module('app').factory('LocationSearchService', function(LocationService) {
  var service = {
    buildings: {
      selected: undefined,
      search: function(query) {
        return LocationService.findBuildings({
          search: query
        }).$promise.then(function(response) {
          return response.splice(0, 20);
        });
      },
      select: function($item, uaBundle) {
        if ($item && $item.buildingDisplayName) {
          service.buildings.selected = $item;
        }
      }
    },
    rooms: {
      selected: undefined,
      roomAlreadyAdded: false,
      search: function(query) {
        service.rooms.roomAlreadyAdded = false;
        return LocationService.findRooms({
          buildingId: service.buildings.selected.buildingKey,
          search: query
        }).$promise.then(function(response) {
          return response.splice(0, 20);
        });
      },
      select: function($item, uaBundle) {
        if ($item && $item.roomId) {
          service.rooms.roomAlreadyAdded = false;
          this.selected = $item;
          var useLocationsExists = _.find(uaBundle.uaBundleLocations, function(ubl) {
            return ubl.location.roomId === $item.roomId;
          });
          if (!useLocationsExists) {
            var labRoom = _.clone(service.buildings.selected, true);
            labRoom.roomId = $item.roomId;
            labRoom.roomKey = $item.roomKey;
            labRoom.roomNumber = $item.roomNumber;
            var lastIndex = _.findLastIndex(uaBundle.uaBundleLocations, ['location', {'buildingDisplayName': labRoom.buildingDisplayName}]);
            uaBundle.uaBundleLocations.splice(++lastIndex, 0, {'location': labRoom});
            service.rooms.selected = undefined;
          } else if (useLocationsExists) {
            service.rooms.roomAlreadyAdded = true;
          }
        }
      }
    }
  };
  return service;
});
