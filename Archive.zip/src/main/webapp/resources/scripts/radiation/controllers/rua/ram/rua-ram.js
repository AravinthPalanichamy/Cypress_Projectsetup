'use strict';

angular.module('app').controller('RuaRamTab', function($location, $scope, $templateCache, $uibModal, StaticCollections, TableHeaderCollections, UaService, TypesService, SurveyService, UtilService, ConfirmModelService, InventoryService) {
  var ramTabCtrl = this;

  ramTabCtrl.init = function(ruaId) {
    ramTabCtrl.surveyTypes = [];
    ramTabCtrl.editData = [];
    ramTabCtrl.tableHeaderCollections = angular.copy(TableHeaderCollections);
    ramTabCtrl.getTableHeader();
    ramTabCtrl.getData(ruaId);
  };

  ramTabCtrl.getTableHeader = function() {
    ramTabCtrl.tableHeaders = {
      MATERIAL: {
        field: 'id',
        displayName: 'Material #'
      },
      RADIONUCLIDE: {
        field: 'radionuclideNameString',
        displayName: 'Radionuclide'
      },
      CHEMICAL_FORM: {
        field: 'chemicalForm',
        displayName: 'Chemical Form'
      },
      PHYSICAL_FORM: {
        field: 'physicalForm',
        displayName: 'Physical Form'
      },
      ENRICHMENT: {
        field: 'uaLimit.enrichmentPercent',
        displayName: 'Enrichment'
      },
      RECEIVED_ACTIVITY: {
        field: 'requestedAmount',
        displayName: 'Received Activity',
        width: 150
      },
      REMAINING_ACTIVITY: {
        field: 'remainingActivity',
        displayName: 'Remaining Activity',
        width: 150
      },
      RECEIPT_DATE: Object.assign({}, angular.copy(ramTabCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'materialPackage.dateReceived',
        displayName: 'Receipt Date (mm/dd/yyyy)',
        width: 200
      }),
      INITIAL_DATE: Object.assign({}, angular.copy(ramTabCtrl.tableHeaderCollections.DATE_RANGE_SHORT), {
        field: 'initialDate',
        displayName: 'Initial Date (mm/dd/yyyy)',
        width: 200
      })
    };
    ramTabCtrl.columns = Object.values(ramTabCtrl.tableHeaders);
  };

  ramTabCtrl.getData = function(ruaId) {
    InventoryService.getMaterialsByUaAndInventoryStatusType({
      uaId: ruaId,
      inventoryStatusType: 'IN_INVENTORY',
      isSealedSource: false
    }, {}).$promise.then(function(response) {
      ramTabCtrl.data = response;
    });
  };
});
