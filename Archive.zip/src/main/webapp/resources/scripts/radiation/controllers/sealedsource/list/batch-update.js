'use strict';

angular.module('app').controller('BatchUpdateLeakTestCtrl', function($uibModalInstance, inspectors, materials, InventoryService, SealedSourceService, UtilService) {
  var ctrl = this;

  ctrl.inspectors = inspectors;
  ctrl.ruaMaterialMap = _.groupBy(materials, 'ua.number');
  ctrl.leakTest = {};

  ctrl.toggleTestDate = function($event) {
    $event.stopPropagation();
    $event.preventDefault();
    this.isTestDateOpen = !this.isTestDateOpen;
  };

  ctrl.save = function(form) {
    if (form.$valid) {
      var leakTests = [];
      _.forEach(materials, function(material) {
        var leakTest = angular.copy(ctrl.leakTest);
        leakTest.material = {
          id: material.id
        };
        leakTest.dueDate = angular.copy(material.nextDue);
        leakTests.push(leakTest);
        material.nextDue = UtilService.calculateNextDue(material.testFrequency.frequency, ctrl.leakTest.testDate);
      });

      SealedSourceService.batchSaveTest(leakTests)
        .$promise
        .then(function() {
          InventoryService.batchUpdateMaterial({}, materials)
            .$promise
            .then(function(response) {
              $uibModalInstance.close();
            });
        });
    }
  };

  ctrl.cancel = function() {
    $uibModalInstance.close();
  };
});
