'use strict';

angular.module('app').controller('NavigationCtrl', function(TileService, TITLE, ENV, CURRENT_USER, PersonService, CONTEXT_PATH, VERSION, SPOOF_URL, StaticCollections) {
  var ctrl = this;
  this.title = TITLE;
  this.environment = ENV;
  this.currentUser = CURRENT_USER;
  this.isAdmin = PersonService.isAdmin;
  this.version = VERSION;
  this.devTool = SPOOF_URL;

  TileService.initialize(function() {
    ctrl.brand = TileService.brand;
  });

  this.reload = function() {
    window.location.href = CONTEXT_PATH;
  };

  this.viewPIHomePage = function() {
    window.location.href = CONTEXT_PATH + '#/home?piViewForRSO=true';
  };
});

