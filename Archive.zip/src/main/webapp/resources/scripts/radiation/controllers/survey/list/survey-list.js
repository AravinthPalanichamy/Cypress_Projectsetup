'use strict';

angular.module('app').controller('surveyListCtrl', function($q, $templateCache, StaticCollections, PersonService, TableHeaderCollections, UaService, ExcelService, SurveyService, TypesService, UtilService, data) {
  var ctrl = this;
  var tableHeaderCollections = {};
  ctrl.download = ExcelService.surveyListExcel;
  ctrl.report = "Survey-List";
  ctrl.isAdmin = PersonService.isAdmin;
  ctrl.addRecordUrl = !ctrl.isAdmin ? '' : '/survey/create';

  ctrl.init = function() {
    ctrl.totalItems = data.totalCount;
    ctrl.surveyTypes = [];
    ctrl.surveyStatuses = [];
    ctrl.data = _.filter(data.data, function(row) {
      if (!(_.isEmpty(row))) {
        return row;
      }
    });
    tableHeaderCollections = angular.copy(TableHeaderCollections);
    ctrl.getTableHeader();
    ctrl.dateRangeLabel = {fromDate: 'Generate Survey Assignments for RUAs that have Surveys due from: '};
  };

  ctrl.getTableHeader = function() {
    tableHeaderCollections.RUA.field = 'ua.number';
    tableHeaderCollections.PI_FIRST_NAME.field = 'ua.pi.firstName';
    tableHeaderCollections.PI_LAST_NAME.field = 'ua.pi.lastName';

    tableHeaderCollections.RUA_TYPE.field = 'ua.type';
    tableHeaderCollections.RUA_TYPE.displayName = 'RUA Type';

    tableHeaderCollections.SURVEY_FREQ.field = 'ua.frequency.frequency';

    tableHeaderCollections.DATE_RANGE_SHORT.field = 'ua.expiryDate';
    tableHeaderCollections.DATE_RANGE_SHORT.displayName = 'Expiration Date';
    tableHeaderCollections.DATE_RANGE_SHORT.enableFiltering = true;

    /*STATUS TYPES*/
    tableHeaderCollections.SURVEY_STATUS.field = 'statusType';
    tableHeaderCollections.SURVEY_STATUS.displayName = 'Survey Status';
    tableHeaderCollections.SURVEY_STATUS.editDropdownOptionsArray = ctrl.surveyStatuses;

    var dueDate = angular.copy(tableHeaderCollections.DATE_RANGE_SHORT);
    dueDate.field = 'dueDate';
    dueDate.displayName = 'Due Date';
    dueDate.enableFiltering = true;
    tableHeaderCollections['DUE_DATE'] = dueDate;

    tableHeaderCollections.SURVEY_TYPE.field = 'surveyType';
    tableHeaderCollections.SURVEY_TYPE.editDropdownOptionsArray = ctrl.surveyTypes;

    tableHeaderCollections.LATEST_SURVEY_DONE_BY.field = 'assignedTo.displayName';
    tableHeaderCollections.LATEST_SURVEY_DONE_BY.displayName = 'Assigned To';

    var emailDate = angular.copy(tableHeaderCollections.DATE_RANGE_SHORT);
    emailDate.field = 'dateEmailed';
    emailDate.displayName = 'Date Emailed';
    emailDate.enableFiltering = true;
    tableHeaderCollections['EMAIL_DATE'] = emailDate;

    var performedDate = angular.copy(tableHeaderCollections.DATE_RANGE_SHORT);
    performedDate.field = 'performedDate';
    performedDate.displayName = 'Date Performed';
    performedDate.enableFiltering = true;
    tableHeaderCollections['PERFORMED_DATE'] = performedDate;

    tableHeaderCollections.EDIT.cellTemplate = $templateCache.get('survey-list-edit.html');

    ctrl.columns = ctrl.colDefs();

    ctrl.getTableFilters();
  };

  ctrl.getState = function(state) {

    var filter = _.find(state.filter, {'filterColumn': 'assignedTo.displayName'});
    if (filter) {
      filter['filterColumn'] = ['assignedTo.firstName', 'assignedTo.lastName'];
      filter.multipleTerms = true;
    }
    var sort = _.find(state.sort, {'sortColumn': 'assignedTo.displayName'});
    if (sort) {
      sort['sortColumn'] = 'assignedTo.firstName';
    }

    var leakTestFilter = _.remove(state.filter, {'filterColumn': 'leakTestDue'});
    var leakTestSort = _.remove(state.sort, {'sortColumn': 'leakTestDue'});

    return SurveyService.searchSurvey({}, state).$promise.then(function(data) {
      if (leakTestFilter.length) {
        data.data = _.filter(data.data, function(i) {
          return i.leakTestDue === leakTestFilter[0].filterTerm;
        });
      }

      if (leakTestSort.length) {
        data.data = _.orderBy(data.data, [leakTestSort[0].sortColumn], [leakTestSort[0].sortDirection]);
      }

      return data;
    });
  };

  ctrl.colDefs = function() {
    var list = [
      tableHeaderCollections.EDIT,
      tableHeaderCollections.RUA,
      tableHeaderCollections.PI_FIRST_NAME,
      tableHeaderCollections.PI_LAST_NAME,
      tableHeaderCollections.RUA_TYPE,
      tableHeaderCollections.SURVEY_FREQ,
      tableHeaderCollections.DATE_RANGE_SHORT,
      tableHeaderCollections.SURVEY_STATUS,
      tableHeaderCollections.DUE_DATE,
      tableHeaderCollections.SURVEY_TYPE,
      tableHeaderCollections.EMAIL_DATE,
      tableHeaderCollections.PERFORMED_DATE,
      tableHeaderCollections.LATEST_SURVEY_DONE_BY,
      tableHeaderCollections.LEAK_TEST_REQUIRED
    ];

    if (!ctrl.isAdmin || _.isEmpty(ctrl.data)) {
      list = list.filter(function(item) {
        return item.field !== tableHeaderCollections.EDIT.field;
      });
    }
    return list;
  };

  ctrl.getTableFilters = function() {
    TypesService.getFrequencyList({}, {})
      .$promise
      .then(function(data) {
        var surveyFreq = _.map(data, function(value, key) {
          return {label: value.frequency, value: value.frequency};
        });

        for (var key in StaticCollections.surveyTypes) {
          ctrl.surveyTypes.push({label: StaticCollections.surveyTypes[key], value: key});
        }

        for (var k in StaticCollections.surveyStatuses) {
          ctrl.surveyStatuses.push({label: StaticCollections.surveyStatuses[k], value: k});
        }

        ctrl.getSortedFilters(surveyFreq, ctrl.surveyTypes, ctrl.surveyStatuses);
      });
  };

  ctrl.getSortedFilters = function(surveyFreq, surveyTypes, surveyStatuses) {
    tableHeaderCollections.SURVEY_FREQ.filter.selectOptions = UtilService.sortUniqUnion(TableHeaderCollections.SURVEY_FREQ.filter.selectOptions, surveyFreq, 'label');
    tableHeaderCollections.RUA_TYPE.filter.selectOptions = UtilService.sortUniqUnion(TableHeaderCollections.RUA_TYPE.filter.selectOptions, StaticCollections.UATypesHash, 'label');
    tableHeaderCollections.SURVEY_STATUS.filter.selectOptions = UtilService.sortUniqUnion(TableHeaderCollections.SURVEY_STATUS.filter.selectOptions, surveyStatuses, 'label');
    tableHeaderCollections.SURVEY_TYPE.filter.selectOptions = UtilService.sortUniqUnion(TableHeaderCollections.SURVEY_TYPE.filter.selectOptions, surveyTypes, 'label');
  };
})
  .run(function($templateCache, INSPECT_URL) {
    $templateCache.put('survey-list-edit.html',
      '<div class="edit-link" ng-if="row.entity.id">' +
      '<span ><a href="#/survey/edit/{{row.entity.id}}" class="glyphicon glyphicon-edit"></a></span>' +
      '<span ng-if="row.entity.id">' +
      '<a ng-href="' + INSPECT_URL + '/#!/report-create?appName=radiation&id={{row.entity.ua.csId}}" target="_blank" title="Start an Inspection" class="uc-r-inspection"></a>' +
      '</span></div>');
  });
