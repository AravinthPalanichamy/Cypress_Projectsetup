'use strict';

angular.module('app', ['ngRoute', 'ngCookies', 'ngResource', 'ui.bootstrap', 'ngFileUpload', 'ngFileSaver', 'angulartics', 'angulartics.google.analytics',
  'ui.grid', 'ui.grid.expandable', 'ui.grid.cellNav', 'ui.grid.edit', 'ui.grid.resizeColumns', 'ui.grid.pinning', 'ui.grid.selection', 'ui.grid.moveColumns',
  'ui.grid.exporter', 'ui.grid.importer', 'ui.grid.grouping', 'ui.grid.pagination', 'textAngular', 'ngTagsInput'])
  .config(function ($httpProvider) {
    $httpProvider.defaults.useXDomain = true;
    delete $httpProvider.defaults.headers.common['X-Requested-With'];
    $httpProvider.interceptors.push('AuthenticationInterceptor');
  })
  .config(function (tagsInputConfigProvider) {
    tagsInputConfigProvider.setDefaults('tagsInput', {minLength: 1});
  })
  .config(function ($provide) {
    $provide.decorator('taOptions', ['taRegisterTool', '$delegate', function (taRegisterTool, taOptions) {
      taRegisterTool('superscript', {
        iconclass: "fa fa-superscript",
        tooltiptext: "Superscript",
        action: function () {
          return this.$editor().wrapSelection("superscript", null);
        },
        activeState: function () {
          return this.$editor().queryCommandState('subscript');
        }
      });

      taRegisterTool('subscript', {
        iconclass: "fa fa-subscript",
        tooltiptext: "Subscript",
        action: function () {
          return this.$editor().wrapSelection("subscript", null);
        },
        activeState: function () {
          return this.$editor().queryCommandState('subscript');
        }
      });

      taOptions.forceTextAngularSanitize = false;
      taOptions.toolbar = [
        ['bold', 'italics', 'underline', 'strikeThrough', 'subscript', 'superscript'],
        ['ul', 'ol'],
        ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent'],
        ['p', 'pre', 'quote', 'insertLink'],
        ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'],
        ['redo', 'undo', 'clear']
      ];

      return taOptions;
    }]);

    $provide.decorator('taTools', ['$delegate', function (taTools) {
      taTools.clear.iconclass = 'fa fa-eraser';
      return taTools;
    }]);
  })
  .config(function($routeProvider) {
    $routeProvider
      .when('/', {
        resolve: {
          check: function ($location, PersonService) {
            if (PersonService.isAdmin) {
              $location.path('/rua');
            } else {
              $location.path('/home');
            }
          }
        }
      })
      .when('/home', {
        templateUrl: 'resources/scripts/radiation/controllers/main/main.html',
        controller: 'MainCtrl',
        controllerAs: 'ctrl'
      })
      .when('/rua', {
        redirectTo: '/rua/list',
        caseInsensitiveMatch: true
      })
      .when('/rua/list', {
        templateUrl: 'resources/scripts/radiation/controllers/rua/list/rua-list.html',
        controller: 'RuaListCtrl',
        controllerAs: 'ctrl',
        resolve: {
          profile: function (PersonService) {
            return PersonService.getCurrentUserProfile({}, {}).$promise;
          },
          data: function (UaService, UtilService, PermissionService) {
            var promise = UaService.search({}, UtilService.searchDefaults).$promise;
            PermissionService.setData(promise);
            return promise;
          }
        }
      })
      .when('/rua/pending/list', {
        templateUrl: 'resources/scripts/radiation/controllers/rua/list/rua-pending-list.html',
        controller: 'RuaPendingListCtrl',
        controllerAs: 'ctrl',
        resolve: {
          profile: function (PersonService) {
            return PersonService.getCurrentUserProfile({}, {}).$promise;
          },
          data: function (UaService, UtilService, PermissionService) {
            var postParam = _.assign({}, {'category': 'PENDING'}, UtilService.searchDefaults);
            var promise = UaService.search({}, postParam).$promise;
            PermissionService.setData(promise);
            return promise;
          }
        }
      })
      .when('/rua/create', {
        templateUrl: 'resources/scripts/radiation/controllers/rua/rua-base.html',
        controller: 'UaBaseCtrl',
        controllerAs: 'ctrl',
        resolve: {
          ua: function (PermissionService) {
            PermissionService.setData({});
            return undefined;
          }
        }
      })
      .when('/rua/:uaId', {
        templateUrl: 'resources/scripts/radiation/controllers/rua/rua-main.html',
        controller: 'UaMainCtrl',
        controllerAs: 'ctrl',
        resolve: {
          uaId: function ($route) {
            return $route.current.params.uaId;
          },
          ua: function ($route, UaService, PermissionService) {
            var promise = UaService.getUa({uaId: $route.current.params.uaId}, {}).$promise;
            PermissionService.setData(promise);
            return promise;
          }
        },
        reloadOnSearch: false
      })
      .when('/rua/email/download', {
        templateUrl: 'resources/scripts/radiation/controllers/rua/list/email-list.html',
        controller: 'RuaEmailListCtrl',
        controllerAs: 'ctrl',
        resolve: {}
      })
      .when('/rua/pending/email/download', {
        templateUrl: 'resources/scripts/radiation/controllers/rua/list/email-list.html',
        controller: 'RuaEmailListCtrl',
        controllerAs: 'ctrl',
        resolve: {}
      })
      .when('/survey', {
        redirectTo: '/survey/assignment',
        caseInsensitiveMatch: true
      })
      .when('/survey/assignment', {
        templateUrl: 'resources/scripts/radiation/controllers/survey/list/survey-assignment-list.html',
        controller: 'SurveyAssignmentListCtrl',
        controllerAs: 'ctrl',
        resolve: {
          data: function (SurveyService) {
            var defaultDates = SurveyService.getDefaultSurveyDueDates();
            return SurveyService.getSurveysDue({
              startDate: defaultDates.startDate,
              endDate: defaultDates.endDate
            }).$promise.then(function (response) {
              return _.map(response, function (item) {
                if (item.assignedTo) {
                  item.assignedTo.displayName = item.assignedTo.firstName + ' ' + item.assignedTo.lastName;
                }
                return item;
              });
            });
          },
          surveyInspectors: function (SurveyService) {
            return SurveyService.getSurveyInspectors().$promise.then(function (response) {
              return _.map(response, function (item) {
                item.ref = _.cloneDeep(item);
                return item;
              });
            });
          }
        }
      })
      .when('/survey/surveylist', {
        templateUrl: 'resources/scripts/radiation/controllers/survey/list/survey-list.html',
        controller: 'surveyListCtrl',
        controllerAs: 'ctrl',
        resolve: {
          data: function (SurveyService) {
            var postParam = {filter: [], sort: [], pagination: {pageNumber: 1, itemPerPage: 10}};
            return SurveyService.searchSurvey({}, postParam).$promise;
          }
        }
      })
      .when('/survey/create', {
        templateUrl: 'resources/scripts/radiation/controllers/survey/survey.html',
        controller: 'SurveyCtrl',
        controllerAs: 'ctrl',
        resolve: {
          profile: function (PersonService) {
            return PersonService.getCurrentUserProfile({}, {}).$promise;
          },
          surveyInspectors: function (SurveyService) {
            return SurveyService.getSurveyInspectors().$promise;
          },
          survey: function () {
            return {};
          }
        }
      })
      .when('/survey/edit/:surveyId', {
        templateUrl: 'resources/scripts/radiation/controllers/survey/survey.html',
        controller: 'SurveyCtrl',
        controllerAs: 'ctrl',
        resolve: {
          profile: function (PersonService) {
            return PersonService.getCurrentUserProfile({}, {}).$promise;
          },
          surveyInspectors: function (SurveyService) {
            return SurveyService.getSurveyInspectors().$promise;
          },
          survey: function (SurveyService, $route) {
            return SurveyService.get({surveyId: $route.current.params.surveyId}).$promise;
          }
        }
      })
      .when('/instrument', {
        redirectTo: '/instrument/list',
        caseInsensitiveMatch: true
      })
      .when('/instrument/list', {
        templateUrl: 'resources/scripts/radiation/controllers/instrument/list/instrument-list.html',
        controller: 'InstrumentListCtrl',
        controllerAs: 'ctrl',
        resolve: {
          data: function (InstrumentService) {
            return InstrumentService.getAllInstruments({}).$promise;
          }
        }
      })
      .when('/instrument/new', {
        templateUrl: 'resources/scripts/radiation/controllers/instrument/instrument.html',
        controller: 'InstrumentCtrl',
        controllerAs: 'ctrl',
        resolve: {
          profile: function (PersonService) {
            return PersonService.getCurrentUserProfile({}, {}).$promise;
          },
          instrument: function () {
            return {};
          }
        }
      })
      .when('/instrument/edit/:instrumentId', {
        templateUrl: 'resources/scripts/radiation/controllers/instrument/instrument.html',
        controller: 'InstrumentCtrl',
        controllerAs: 'ctrl',
        resolve: {
          profile: function (PersonService) {
            return PersonService.getCurrentUserProfile({}, {}).$promise;
          },
          instrument: function (InstrumentService, $route) {
            return InstrumentService.get({instrumentId: $route.current.params.instrumentId}).$promise;
          }
        }
      })
      .when('/materials', {
        redirectTo: '/materials/inventory',
        caseInsensitiveMatch: true
      })
      .when('/materials/inventory', {
        templateUrl: 'resources/scripts/radiation/controllers/material/inventory/inventory.html',
        controller: 'InventoryCtrl',
        controllerAs: 'ctrl',
        resolve: {
          profile: function (PersonService) {
            return PersonService.getCurrentUserProfile().$promise;
          }
        }
      })
      .when('/materials/pending', {
        templateUrl: 'resources/scripts/radiation/controllers/material/request/pending-request.html',
        controller: 'PendingMaterialRequestCtrl',
        controllerAs: 'ctrl',
        resolve: {
          pendingRequests: function (InventoryService) {
            return InventoryService.getMaterialsByInventoryStatusType({inventoryStatusType: 'REQUESTED'}).$promise;
          }
        }
      })
      .when('/materials/request-create', {
        templateUrl: 'resources/scripts/radiation/controllers/material/request/request-material.html',
        controller: 'MaterialRequestCtrl',
        controllerAs: 'ctrl',
        resolve: {
          profile: function (PersonService) {
            return PersonService.getCurrentUserProfile().$promise;
          },
          material: function () {
            return {};
          },
          settings: function (SettingsService) {
            return SettingsService.getSettings().$promise;
          }
        }
      })
      .when('/materials/request-edit/:id', {
        templateUrl: 'resources/scripts/radiation/controllers/material/request/request-material.html',
        controller: 'MaterialRequestCtrl',
        controllerAs: 'ctrl',
        resolve: {
          profile: function (PersonService) {
            return PersonService.getCurrentUserProfile().$promise;
          },
          material: function (InventoryService, $route) {
            var materialId = $route.current.params.id;
            return InventoryService.getMaterial({materialId: materialId}).$promise;
          },
          settings: function (SettingsService) {
            return SettingsService.getSettings().$promise;
          }
        }
      })
      .when('/materials/package', {
        templateUrl: 'resources/scripts/radiation/controllers/material/packaging/list/package-list.html',
        controller: 'PackageListCtrl',
        controllerAs: 'ctrl',
        resolve: {
          page: function (InventoryService) {
            return InventoryService.searchPackages().$promise;
          }
        }
      })
      .when('/materials/package-create', {
        templateUrl: 'resources/scripts/radiation/controllers/material/packaging/package.html',
        controller: 'PackageCtrl',
        controllerAs: 'ctrl',
        resolve: {
          profile: function (PersonService) {
            return PersonService.getCurrentUserProfile().$promise;
          },
          inspectors: function (SurveyService) {
            return SurveyService.getSurveyInspectors().$promise;
          },
          packageVendors: function (InventoryService) {
            return InventoryService.getPackageVendors().$promise;
          },
          packageTypes: function (InventoryService) {
            return InventoryService.getPackageTypes().$promise;
          },
          materialPackage: function () {
            return {};
          }
        }
      })
      .when('/materials/package-edit/:id', {
        templateUrl: 'resources/scripts/radiation/controllers/material/packaging/package.html',
        controller: 'PackageCtrl',
        controllerAs: 'ctrl',
        resolve: {
          profile: function (PersonService) {
            return PersonService.getCurrentUserProfile().$promise;
          },
          inspectors: function (SurveyService) {
            return SurveyService.getSurveyInspectors().$promise;
          },
          packageVendors: function (InventoryService) {
            return InventoryService.getPackageVendors().$promise;
          },
          packageTypes: function (InventoryService) {
            return InventoryService.getPackageTypes().$promise;
          },
          materialPackage: function ($route, InventoryService) {
            var packageId = $route.current.params.id;
            return InventoryService.getPackage({id: packageId}).$promise;
          }
        }
      })
      .when('/materials/pending-transfers', {
        templateUrl: 'resources/scripts/radiation/controllers/material/pending-transfer/pending-transfer.html',
        controller: 'InventoryInstitutionTransferCtrl',
        controllerAs: 'ctrl',
        resolve: {
          materialTransfers: function (InventoryService) {
            return InventoryService.getMaterialTransfersToInstitutionByStatus({ status: 'PENDING' }).$promise;
          }
        }
      })
      .when('/materials/search', {
        templateUrl: 'resources/scripts/radiation/controllers/material/inventory-search/inventory-search.html',
        controller: 'InventorySearchCtrl',
        controllerAs: 'ctrl',
        resolve: {
          page: function (InventoryService) {
            var postParam = {filter: [], sort: [], pagination: {pageNumber: 1, itemPerPage: 10}};
            return InventoryService.searchMaterials({}, postParam).$promise;
          }
        }
      })
      .when('/materials/search/edit/:id', {
        templateUrl: 'resources/scripts/radiation/controllers/sealedsource/edit/panel.html',
        controller: 'PanelCtrl',
        controllerAs: 'ctrl',
        resolve: {
          material: function(InventoryService, $route) {
            return InventoryService.getMaterial({materialId: $route.current.params.id}).$promise;
          }
        },
        reloadOnSearch: false
      })
      .when('/rpm', {
        redirectTo: '/rpm/list',
        caseInsensitiveMatch: true
      })
      .when('/rpm/list', {
        templateUrl: 'resources/scripts/radiation/controllers/rpm/rpm-list.html',
        controller: 'RpmListCtrl',
        controllerAs: 'ctrl',
        resolve: {
          data: function (RpmService) {
            return RpmService.getAllByCampus().$promise;
          }
        }
      })
      .when('/people', {
        redirectTo: '/people/list',
        caseInsensitiveMatch: true
      })
      .when('/people/list', {
        templateUrl: 'resources/scripts/radiation/controllers/people/list/person-list.html',
        controller: 'PersonListCtrl',
        controllerAs: 'ctrl',
        resolve: {
          data: function (PersonService, $q) {
            var postParam = {filter: [], sort: [], pagination: {pageNumber: 1, itemPerPage: 10}};
            return PersonService.searchPeople({}, postParam)
              .$promise;
          }
        }
      })
      .when('/people/new', {
        templateUrl: 'resources/scripts/radiation/controllers/people/panel.html',
        controller: 'PeoplePanelCtrl',
        controllerAs: 'ctrl',
        resolve: {
          person: function () {
            return null;
          }
        }
      })
      .when('/people/:id', {
        templateUrl: 'resources/scripts/radiation/controllers/people/panel.html',
        controller: 'PeoplePanelCtrl',
        controllerAs: 'ctrl',
        resolve: {
          person: function (PersonService, $route) {
            var userId = $route.current.params.id;
            return PersonService.getLocalPersonByUserId({userId: userId}, {}).$promise;
          }
        }
      })
      .when('/dosimetry-issuance', {
        redirectTo: '/dosimetry-issuance/list',
        caseInsensitiveMatch: true
      })
      .when('/dosimetry-issuance/list', {
        templateUrl: 'resources/scripts/radiation/controllers/dosimetry-issuance/list/dosimetry-issuance-list.html',
        controller: 'DosimetryIssuanceListCtrl',
        controllerAs: 'ctrl',
        resolve: {
          page: function(DosimetryIssuanceService) {
            var postParam = {filter: [], sort: [], pagination: {pageNumber: 1, itemPerPage: 10}};
            return DosimetryIssuanceService.search({}, postParam).$promise;
          }
        }
      })
      .when('/dosimetry-issuance/new', {
        templateUrl: 'resources/scripts/radiation/controllers/dosimetry-issuance/form/dosimetry-issuance-form.html',
        controller: 'DosimetryIssuanceFormCtrl',
        controllerAs: 'ctrl',
        resolve: {
          dosimetryIssuance: function() {
            return {};
          },
          frequencyList: function(TypesService) {
            return TypesService.getFrequencyList().$promise;
          }
        }
      })
      .when('/dosimetry-issuance/edit/:id', {
        templateUrl: 'resources/scripts/radiation/controllers/dosimetry-issuance/form/dosimetry-issuance-form.html',
        controller: 'DosimetryIssuanceFormCtrl',
        controllerAs: 'ctrl',
        resolve: {
          dosimetryIssuance: function($route, DosimetryIssuanceService) {
            return DosimetryIssuanceService.get({ id: $route.current.params.id }).$promise;
          },
          frequencyList: function(TypesService) {
            return TypesService.getFrequencyList().$promise;
          }
        }
      })
      .when('/audit', {
        redirectTo: '/audit/license',
        caseInsensitiveMatch: true
      })
      .when('/audit/license', {
        templateUrl: 'resources/scripts/radiation/controllers/audit/license/license.html',
        controller: 'LicenseCtrl',
        controllerAs: 'ctrl',
        resolve: {
          profile: function (PersonService) {
            return PersonService.getCurrentUserProfile().$promise;
          }
        }
      })
      .when('/audit/inventory', {
        templateUrl: 'resources/scripts/radiation/controllers/audit/inventory/inventory.html',
        controller: 'InventoryAuditCtrl',
        controllerAs: 'ctrl',
        resolve: {
          data: function (AuditService) {
            return AuditService.getInventory({}).$promise;
          }
        }
      })
      .when('/audit/buildingreport', {
        templateUrl: 'resources/scripts/radiation/controllers/audit/building-report/building-report.html',
        controller: 'BuildingReportCtrl',
        controllerAs: 'ctrl',
        reloadOnSearch: false
      })
      .when('/admin', {
        redirectTo: '/admin/radionuclides',
        caseInsensitiveMatch: true
      })
      .when('/admin/radionuclides', {
        templateUrl: 'resources/scripts/radiation/controllers/admin/radionuclides/radionuclides-list.html',
        controller: 'radionuclideListCtrl',
        controllerAs: 'ctrl',
        resolve: {
          data: function (AdminService) {
            return AdminService.getAllRadionuclides().$promise;
          }
        }
      })
      .when('/admin/person-roles', {
        templateUrl: 'resources/scripts/radiation/controllers/admin/role-management/list/person-roles.html',
        controller: 'PersonRoleListCtrl',
        controllerAs: 'ctrl'
      })
      .when('/admin/hgv-range', {
        templateUrl: 'resources/scripts/radiation/controllers/admin/hgv/hgv-range.html',
        controller: 'HgvRangeCtrl',
        controllerAs: 'ctrl'
      })
      .when('/admin/settings', {
        templateUrl: 'resources/scripts/radiation/controllers/admin/settings/settings.html',
        controller: 'SettingsCtrl',
        controllerAs: 'ctrl',
        resolve: {
          settings: function (SettingsService) {
            return SettingsService.getSettings().$promise;
          }
        }
      })
      .when('/sealedsources', {
        redirectTo: '/sealedsources/list',
        caseInsensitiveMatch: true
      })
      .when('/sealedsources/list', {
        templateUrl: 'resources/scripts/radiation/controllers/sealedsource/list/leaktest-materials.html',
        controller: 'LeakTestMaterialsCtrl',
        controllerAs: 'ctrl',
        resolve: {
          page: function (SealedSourceService, UtilService) {
            var postParam = _.assign({}, UtilService.searchDefaults, {'sort': [{sortColumn: 'storageLocation.buildingPrimaryName', sortDirection: 'asc'}]});
            return SealedSourceService.getAllLeakTestMaterialsByCampus({}, postParam).$promise;
          }
        }
      })
      .when('/sealedsources/edit/:id', {
        templateUrl: 'resources/scripts/radiation/controllers/sealedsource/edit/panel.html',
        controller: 'PanelCtrl',
        controllerAs: 'ctrl',
        resolve: {
          material: function (InventoryService, $route) {
            return InventoryService.getMaterial({materialId: $route.current.params.id}).$promise;
          }
        },
        reloadOnSearch: false
      })
      .when('/waste-facility', {
        redirectTo: '/waste-facility/totals',
        caseInsensitiveMatch: true
      })
      .when('/waste-facility/totals', {
        templateUrl: 'resources/scripts/radiation/controllers/waste-facility/waste-facility.inventory.html',
        controller: 'WasteFacilityInventoryCtrl',
        controllerAs: 'ctrl',
        resolve: {
          data: function (InventoryService) {
            return InventoryService.getMaterialsByInventoryStatusType({ inventoryStatusType: 'PICKED_UP' }).$promise;
          }
        }
      })
      .when('/error', {
        templateUrl: 'resources/scripts/radiation/controllers/error/error.html',
        caseInsensitiveMatch: true
      })
      .when('/deny', {
        templateUrl: 'resources/scripts/radiation/controllers/deny/deny.html',
        caseInsensitiveMatch: true
      })
      .otherwise({
        redirectTo: '/'
      });
  })
  .run(function ($window, $location) {
  if ($window.sessionStorage.getItem('originalUrl')) {
    $location.url($window.sessionStorage.getItem('originalUrl'));
    delete $window.sessionStorage.originalUrl;
  }
});
