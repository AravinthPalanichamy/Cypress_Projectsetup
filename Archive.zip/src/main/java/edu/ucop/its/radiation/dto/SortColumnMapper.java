package edu.ucop.its.radiation.dto;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface SortColumnMapper {

  String column();

  String value() default "";

  String name();

  String dbPrefix();

}
