package edu.ucop.its.radiation.dto;


public class EntityInfo {

  private String entityName;
  private Integer entityId;

  public EntityInfo(String entityName, Integer entityId) {
    this.entityName = entityName;
    this.entityId = entityId;
  }

  public String getEntityName() {
    return entityName;
  }

  public void setEntityName(String entityName) {
    this.entityName = entityName;
  }

  public Integer getEntityId() {
    return entityId;
  }

  public void setEntityId(Integer entityId) {
    this.entityId = entityId;
  }
}
