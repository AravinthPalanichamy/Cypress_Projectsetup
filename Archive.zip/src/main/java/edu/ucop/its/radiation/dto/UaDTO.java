package edu.ucop.its.radiation.dto;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.persistence.Transient;

@JsonSerialize
@JsonInclude(Include.NON_NULL)
//{ 'id', 'ruaNumber', 'ruaType', 'piLastName', 'piFirstName', 'organization', 'useLocations', 'surveyFrequency', 'status', 'class', 'dosimentry', 'lbl', 'expirationDate' }
public class UaDTO {

  // id will hold the rua id # (PK col)
  private Integer id;

  @FilterColumnMapper(column = "number", dbPrefix = "u", name = "ruaNumber")
  @SortColumnMapper(column = "number", dbPrefix = "u", name = "ruaNumber")
  private Integer ruaNumber;

  @FilterColumnMapper(column = "type", dbPrefix = "u", name = "ruaType")
  @SortColumnMapper(column = "type", dbPrefix = "u", name = "ruaType")
  private String ruaType;

  @FilterColumnMapper(column = "last_name", dbPrefix = "prsn", name = "piLastName")
  @SortColumnMapper(column = "last_name", dbPrefix = "prsn", name = "piLastName")
  private String piLastName;

  @FilterColumnMapper(column = "first_name", dbPrefix = "prsn", name = "piFirstName")
  @SortColumnMapper(column = "first_name", dbPrefix = "prsn", name = "piFirstName")
  private String piFirstName;

  @FilterColumnMapper(column = "building_primary_name", dbPrefix = "loc", name = "useLocations")
  @FilterColumnMapper(column = "room_number", dbPrefix = "loc", name = "useLocations")
  @SortColumnMapper(column = "building_primary_name", dbPrefix = "loc", name = "useLocations")
  private String useLocations;

  @FilterColumnMapper(column = "frequency_name", dbPrefix = "f", name = "surveyFrequency")
  @SortColumnMapper(column = "frequency_name", dbPrefix = "f", name = "surveyFrequency")
  private String surveyFrequency;

  @FilterColumnMapper(column = "collection_name", dbPrefix = "cc", name = "coreCollection")
  @SortColumnMapper(column = "collection_name", dbPrefix = "cc", name = "coreCollection")
  private String coreCollection;

  @FilterColumnMapper(column = "status_type", dbPrefix = "u", name = "status")
  @SortColumnMapper(column = "status_type", dbPrefix = "u", name = "status")
  private String status;

  @FilterColumnMapper(column = "hazard_rating", dbPrefix = "u", name = "class")
  @SortColumnMapper(column = "hazard_rating", dbPrefix = "u", name = "class")
  @JsonProperty(value = "class")
  private String classs;

  @FilterColumnMapper(column = "name", dbPrefix = "mntrtyp", name = "dosimetry")
  @SortColumnMapper(column = "name", dbPrefix = "mntrtyp", name = "dosimetry")
  private String dosimetry;

  @FilterColumnMapper(column = "no_charge", dbPrefix = "u", name = "noCharge")
  @SortColumnMapper(column = "no_charge", dbPrefix = "u", name = "noCharge")
  private boolean noCharge;

  @FilterColumnMapper(column = "other", dbPrefix = "u", name = "other")
  @SortColumnMapper(column = "other", dbPrefix = "u", name = "other")
  private boolean other;

  @FilterColumnMapper(column = "expiry_date", dbPrefix = "u", name = "expirationDate")
  @SortColumnMapper(column = "expiry_date", dbPrefix = "u", name = "expirationDate")
  private Timestamp expirationDate;

  @Transient
  @JsonIgnore
  private String displayExpirationDate;


  public UaDTO(Integer id, Integer ruaNumber, String ruaType, String piLastName, String piFirstName,
               String useLocations, String surveyFrequency, String coreCollection, String status, String classs,
               String dosimetry, boolean noCharge, boolean other, Timestamp expirationDate) {
    this.id = id;
    this.ruaNumber = ruaNumber;
    this.ruaType = ruaType;
    this.piLastName = piLastName;
    this.piFirstName = piFirstName;
    this.useLocations = useLocations;
    this.surveyFrequency = surveyFrequency;
    this.coreCollection = coreCollection;
    this.status = status;
    this.classs = classs;
    this.dosimetry = dosimetry;
    this.noCharge = noCharge;
    this.other =  other;
    this.expirationDate = expirationDate;
  }

  public UaDTO(Integer id, Integer ruaNumber, String ruaType, String status) {
    this.id = id;
    this.ruaNumber = ruaNumber;
    this.ruaType = ruaType;
    this.status = status;
  }

  public UaDTO() {
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Integer getRuaNumber() {
    return ruaNumber;
  }

  public void setRuaNumber(Integer ruaNumber) {
    this.ruaNumber = ruaNumber;
  }

  public String getRuaType() {
    return ruaType;
  }

  public void setRuaType(String ruaType) {
    this.ruaType = ruaType;
  }

  public String getPiLastName() {
    return piLastName;
  }

  public void setPiLastName(String piLastName) {
    this.piLastName = piLastName;
  }

  public String getPiFirstName() {
    return piFirstName;
  }

  public void setPiFirstName(String piFirstName) {
    this.piFirstName = piFirstName;
  }

  public String getUseLocations() {
    return useLocations;
  }

  public void setUseLocations(String useLocations) {
    this.useLocations = useLocations;
  }

  public String getSurveyFrequency() {
    return surveyFrequency;
  }

  public void setSurveyFrequency(String surveyFrequency) {
    this.surveyFrequency = surveyFrequency;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getClasss() {
    return classs;
  }

  public void setClasss(String classs) {
    this.classs = classs;
  }

  public String getDosimetry() {
    return dosimetry;
  }

  public void setDosimetry(String dosimetry) {
    this.dosimetry = dosimetry;
  }

  public Timestamp getExpirationDate() {
    return expirationDate;
  }

  public void setExpirationDate(Timestamp expirationDate) {
    this.expirationDate = expirationDate;
  }

  public String getDisplayExpirationDate() {
    return displayExpirationDate;
  }

  public void setDisplayExpirationDate(String displayExpirationDate) {
    this.displayExpirationDate = displayExpirationDate;
  }

  public String getCoreCollection() {
    return coreCollection;
  }

  public void setCoreCollection(String coreCollection) {
    this.coreCollection = coreCollection;
  }

  public boolean isOther() {
    return other;
  }

  public void setOther(boolean other) {
    this.other = other;
  }

  public boolean isNoCharge() { return noCharge; }

  public void setNoCharge(boolean noCharge) { this.noCharge = noCharge; }
}
