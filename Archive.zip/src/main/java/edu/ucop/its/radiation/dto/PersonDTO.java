package edu.ucop.its.radiation.dto;

import org.joda.time.DateTime;

public class PersonDTO {

  private DateTime dob;

  private Boolean hasStatementOfExperience;

  private String comment;

  public DateTime getDob() {
    return dob;
  }

  public void setDob(DateTime dob) {
    this.dob = dob;
  }

  public Boolean getHasStatementOfExperience() {
    return hasStatementOfExperience;
  }

  public void setHasStatementOfExperience(Boolean hasStatementOfExperience) {
    this.hasStatementOfExperience = hasStatementOfExperience;
  }

  public String getComment() {
    return comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }
}
