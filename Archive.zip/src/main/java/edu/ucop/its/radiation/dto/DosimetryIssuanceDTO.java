package edu.ucop.its.radiation.dto;

import edu.ucop.its.radiation.domain.DosimetryIssuance;
import edu.ucop.its.radiation.domain.Ua;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DosimetryIssuanceDTO {

  private DosimetryIssuance dosimetryIssuance;

  private Ua ua;

  private List<Map<String, Object>> typeIssuance = new ArrayList<>();

  public DosimetryIssuanceDTO(DosimetryIssuance dosimetryIssuance) {
    this.dosimetryIssuance = dosimetryIssuance;
  }

  public DosimetryIssuanceDTO(Ua ua) {
    this.ua = ua;
  }

  public DosimetryIssuance getDosimetryIssuance() {
    return dosimetryIssuance;
  }

  public void setDosimetryIssuance(DosimetryIssuance dosimetryIssuance) {
    this.dosimetryIssuance = dosimetryIssuance;
  }

  public Ua getUa() {
    return ua;
  }

  public void setUa(Ua ua) {
    this.ua = ua;
  }

  public List<Map<String, Object>> getTypeIssuance() {
    return typeIssuance;
  }

  public void setTypeIssuance(List<Map<String, Object>> typeIssuance) {
    this.typeIssuance = typeIssuance;
  }
}
