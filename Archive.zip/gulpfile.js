'use strict';

var gulp = require('gulp');
const jscs = require('gulp-jscs');
var gutil = require('gulp-util');
var concat = require('gulp-concat');
var rimraf = require('gulp-rimraf');
var inject = require("gulp-inject");
var jshint = require('gulp-jshint');
var stylish = require('gulp-jscs-stylish');
var sass = require('gulp-sass');
var manifest = require('gulp-manifest');
var protractor = require("gulp-protractor").protractor;
var rename = require("gulp-rename");
var templateCache = require('gulp-angular-templatecache');
var karma = require('karma').server;
var fs = require('fs');
var changelog = require('conventional-changelog');

var karmaConfig = {
  browsers: ['PhantomJS'],
  frameworks: ['jasmine', 'sinon'],
  files: [
    'src/main/webapp/resources/lib/angular.js',
    'src/main/webapp/resources/lib/angular-*.js',
    'src/main/webapp/resources/lib/angulartics.min.js',
    'src/main/webapp/resources/lib/angulartics-ga.min.js',
    'src/main/webapp/resources/lib/ui-bootstrap-tpls.js',
    'src/main/webapp/resources/lib/lodash.js',
    'src/main/webapp/resources/lib/moment.js',
    'src/main/webapp/resources/scripts/app.js',
    'src/main/webapp/resources/scripts/utils/*.js',
    'src/main/webapp/resources/scripts/components/*.js',
    'src/main/webapp/resources/scripts/controllers/**/*.js',
    'src/main/webapp/resources/scripts/directives/*.js',
    'src/main/webapp/resources/scripts/services/*.js',
    'src/main/webapp/resources/scripts/filters/*.js',
    'src/main/webapp/resources/scripts/interceptors/*.js',
    'src/test/webapp/spec/helpers.spec.js',
    'src/test/webapp/spec/**/*.spec.js'
  ],
  exclude: [
    'src/main/webapp/resources/lib/vendor.js',
    'src/main/webapp/resources/scripts/build.js',
    'src/main/webapp/resources/scripts/templates.js',
    'src/main/webapp/resources/scripts/services/exception.service.js'
  ]
};

// e2e tests have to be execute in following order
var e2eSourceFiles = [
  'src/test/webapp/e2e/helper.js',
  'src/test/webapp/e2e/pageobject/**/*.js',
  'src/test/webapp/e2e/authentication.e2e.js',
  'src/test/webapp/e2e/ua/unity-monitoring.e2e.js',
  'src/test/webapp/e2e/ua/ehs.settings.e2e.js',
  'src/test/webapp/e2e/ua/ua.modify.e2e.js',
  'src/test/webapp/e2e/ua/license-radionuclide.e2e.js',
  'src/test/webapp/e2e/ua/ua-overview.e2e.js',
  'src/test/webapp/e2e/ua/ehs-rss.e2e.js',
  'src/test/webapp/e2e/ua/ehs-rso.e2e.js',
  'src/test/webapp/e2e/ua/ua-amendment-overview.e2e.js',
  'src/test/webapp/e2e/ua/ehs-approve-amendment.e2e.js',
  'src/test/webapp/e2e/ua/lab-member-ua.e2e.js',
  'src/test/webapp/e2e/ua/ua-memberships.e2e.js',
  'src/test/webapp/e2e/ua/landing.e2e.js',
  'src/test/webapp/e2e/ua/server-side-permissions.e2e.js',
  'src/test/webapp/e2e/ua/ehs.reports.e2e.js',
  'src/test/webapp/e2e/ua/ua-back-fill.e2e.js',
  'src/test/webapp/e2e/ua/ua-soe-check.e2e.js',
  'src/test/webapp/e2e/ua/instrument.e2e.js',
  'src/test/webapp/e2e/ua/instrument-calibration.e2e.js',
  'src/test/webapp/e2e/ua/sealed-sources.e2e.js',
  'src/test/webapp/e2e/ua/delegate-apply-rua.e2e.js'
];

var e2eInventoryFiles = [
  'src/test/webapp/e2e/pageobject/**/*.js',
  'src/test/webapp/e2e/inventory/inventory.navigation.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.request.RP.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.request.AU.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.request.RSO.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.receive.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.package.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.lab.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.stock.vial.nonsnm.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.stock.vial.snmorsource.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.stock.vial.exceptions.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.lab.RSO.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.material.history.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.detail.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.amendment.exceptions.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.exceptions.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.settings.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.waste.disposal.e2e.js',
  'src/test/webapp/e2e/inventory/waste-settings.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.back-fill.e2e.js',
  'src/test/webapp/e2e/inventory/inventory.lab.receive.e2e.js'/*,
   'src/test/webapp/e2e/inventory/inventory.use-log.e2e.js',
   'src/test/webapp/e2e/inventory/waste.detail.e2e.js'*/
];

var e2eBillingFiles = [
  'src/test/webapp/e2e/pageobject/**/*.js',
  'src/test/webapp/e2e/billing/billing.e2e.js',
  'src/test/webapp/e2e/billing/dosimetry-billing.e2e.js'
];

var e2eMachineFiles = [
  'src/test/webapp/e2e/helper.js',
  'src/test/webapp/e2e/pageobject/**/*.js',
  'src/test/webapp/e2e/machine/mua-create.e2e.js',
  'src/test/webapp/e2e/machine/mua-create-lab.e2e.js',
  'src/test/webapp/e2e/machine/mua-delegate-navigation.e2e.js',
  'src/test/webapp/e2e/machine/mua-create-pi.e2e.js',
  'src/test/webapp/e2e/machine/mua-create-pw.e2e.js',
  'src/test/webapp/e2e/machine/mua-create-soe.e2e.js',
  'src/test/webapp/e2e/machine/mua-create-finish.e2e.js',
  'src/test/webapp/e2e/machine/mua-summary-rso.e2e.js',
  'src/test/webapp/e2e/machine/mua-approval-rso.e2e.js',
  'src/test/webapp/e2e/machine/mua-summary-pi.e2e.js',
  'src/test/webapp/e2e/machine/machine-billing.e2e.js',
  'src/test/webapp/e2e/machine/mua-list.e2e.js',
  'src/test/webapp/e2e/machine/mua-amend.e2e.js',
  'src/test/webapp/e2e/machine/approve-mua-amendment.e2e.js',
  'src/test/webapp/e2e/machine/delegate-mua-amend.e2e.js',
  'src/test/webapp/e2e/machine/rso-mua-amend.e2e.js',
  'src/test/webapp/e2e/machine/delegate-ua-list.e2e.js'
];

gulp.task('default', function () {
  return gulp.src(['src/main/webapp/resources/scripts/radiation/**/*.js',
    'src/test/webapp/spec/**/*.js',
    'src/test/webapp/e2e/**/*.js',
    '!src/main/webapp/resources/scripts/main.js',
    '!src/main/webapp/resources/scripts/templates.js',
    '!src/main/webapp/resources/scripts/build.js'
  ])
    .pipe(jshint('.jshintrc'))
    .pipe(jscs())
    .pipe(stylish.combineWithHintResults())
    .pipe(jshint.reporter('jshint-stylish'));
});

gulp.task('e2e', ['lint'], function (done) {
  return gulp.src(e2eSourceFiles)
    .pipe(protractor({
      configFile: "protractor.conf.js",
      args: []
    }));
});

gulp.task('e2e-inventory', ['lint'], function (done) {
  return gulp.src(e2eInventoryFiles)
    .pipe(protractor({
      configFile: "protractor.conf.js",
      args: []
    }));
});

gulp.task('e2e-billing', ['lint'], function (done) {
  return gulp.src(e2eBillingFiles)
    .pipe(protractor({
      configFile: "protractor.conf.js",
      args: []
    }));
});

gulp.task('e2e-machine', ['lint'], function (done) {
  return gulp.src(e2eMachineFiles)
    .pipe(protractor({
      configFile: "protractor.conf.js",
      args: []
    }));
});

gulp.task('spec', ['lint'], function (done) {
  karmaConfig.singleRun = true;
  karma.start(karmaConfig, done);
});

gulp.task('spec:watch', ['lint'], function (done) {
  karma.start(karmaConfig, done);
});

gulp.task('e2e:debug', ['lint'], function (done) {
  return gulp.src(e2eSourceFiles)
    .pipe(protractor({
      configFile: "protractor.conf.js",
      args: ['debug']
    }));
});

gulp.task('clean', function () {
  return gulp.src([
    'src/main/webapp/resources/lib/vendor.js',
    'src/main/webapp/resources/scripts/build.js',
    'src/main/webapp/resources/scripts/templates.js'
  ], {read: false})
    .pipe(rimraf());
});

gulp.task('copy', ['clean'], function () {

  // copy third party lib
  gulp.src([
    'bower_components/angular/angular.*',
    'bower_components/angular-route/angular-route.*',
    'bower_components/angular-resource/angular-resource.*',
    'bower_components/angular-animate/angular-animate.*',
    'bower_components/angular-cookies/angular-cookies.*',
    'bower_components/angular-touch/angular-touch.*',
    'bower_components/angular-aria/angular-aria.*',
    'bower_components/ng-file-upload/ng-file-upload.*',
    'bower_components/angular-file-saver/dist/angular-file-saver.bundle.*',
    'bower_components/angular-sanitize/angular-sanitize.*',
    'bower_components/angulartics/dist/angulartics.min.js',
    'bower_components/angulartics/dist/angulartics-ga.min.js',
    'node_modules/lodash/lodash.*',
    'node_modules/xlsx/xlsx.full.min.js',
    'bower_components/moment/min/moment.min.*',
    'bower_components/moment/src/moment.*',
    'bower_components/angular-ui-bootstrap-bower/ui-bootstrap-tpls.*',
    'bower_components/crossfilter2/crossfilter.js',
    'bower_components/d3/d3.js',
    'bower_components/dcjs/dc.js',
    'bower_components/crossfilter2/crossfilter.min.js',
    'bower_components/d3/d3.min.js',
    'bower_components/dcjs/dc.min.js',
    'bower_components/angular-ui-grid/ui-grid.min.js',
    'bower_components/textAngular/dist/**.js',
    'bower_components/ng-tags-input/ng-tags-input.js'
  ])
    .pipe(gulp.dest('src/main/webapp/resources/lib'));

  gulp.src('bower_components/ng-tags-input/**.min.css')
    .pipe(gulp.dest('src/main/webapp/resources/css/'));

  gulp.src('bower_components/textAngular/dist/textAngular.css')
    .pipe(rename(function (path) {
      path.basename = '_' + path.basename;
      path.extname = '.scss';
    }))
    .pipe(gulp.dest('src/main/webapp/resources/css/'));

  // copy font-awesome
  gulp.src('bower_components/font-awesome/fonts/**')
    .pipe(gulp.dest('src/main/webapp/resources/fonts/'));
  gulp.src('bower_components/font-awesome/css/**')
    .pipe(gulp.dest('src/main/webapp/resources/css/'));

  gulp.src('bower_components/sass-flex-mixin/_flex.scss')
    .pipe(gulp.dest('src/main/webapp/resources/css/flex-grid/'));

  gulp.src('bower_components/dcjs/dc.css')
    .pipe(gulp.dest('src/main/webapp/resources/css/'));

  gulp.src('bower_components/angular-ui-grid/ui-grid.css')
    .pipe(gulp.dest('src/main/webapp/resources/css/ui-grid/'));

  //copy ui-grid fonts
  /*gulp.src(['bower_components/angular-ui-grid/ui-grid.eot',
   'bower_components/angular-ui-grid/ui-grid.svg',
   'bower_components/angular-ui-grid/ui-grid.ttf',
   'bower_components/angular-ui-grid/ui-grid.woff'])
   .pipe(gulp.dest('src/main/webapp/resources/css/'));

   gulp.src('bower_components/angular-ui-grid/fonts/bootstrap/!*.*')
   .pipe(gulp.dest('src/main/webapp/resources/fonts/bootstrap/'));*/

  /*// copy bootstrap
   gulp.src('bower_components/bootstrap-sass/assets/stylesheets/bootstrap/!**')
   .pipe(gulp.dest('src/main/webapp/resources/css/bootstrap/'));

   // copy style-guide
   gulp.src(['bower_components/style-guide-bower/css/!*.scss',
   '!bower_components/style-guide-bower/css/project.scss'])
   .pipe(gulp.dest('src/main/webapp/resources/css/'));

   //copy style-guide fonts
   gulp.src('bower_components/style-guide-bower/fonts/!*.*')
   .pipe(gulp.dest('src/main/webapp/resources/fonts/'));
   gulp.src('bower_components/style-guide-bower/fonts/bootstrap/!*.*')
   .pipe(gulp.dest('src/main/webapp/resources/fonts/bootstrap/'));

   //copy side-menu directive from style-guide
   gulp.src('bower_components/style-guide-bower/scripts/directives/uc-sidemenu.js')
   .pipe(gulp.dest('src/main/webapp/resources/lib/'));*/
});

gulp.task('sass', [], function () {
  gulp.src([
    './src/main/webapp/resources/css/*.scss',
    '!./src/main/webapp/resources/css/*-old.scss',
    './src/main/webapp/resources/css/dc.css',
    './src/main/webapp/resources/css/ui-grid/ui-grid.css'
  ])
    .pipe(sass())
    .pipe(concat('project.css'))
    .pipe(gulp.dest('./src/main/webapp/resources/css/'));
});

// Watch Files For Changes
gulp.task('watch', function () {
  gulp.watch(['./src/main/webapp/resources/css/**/*.scss'], ['sass']);
});

gulp.task('js:lib', function (done) {
  return gulp.src([
    'src/main/webapp/resources/lib/angular.min.js',
    'src/main/webapp/resources/lib/angular-animate.min.js',
    'src/main/webapp/resources/lib/angular-cookies.min.js',
    'src/main/webapp/resources/lib/angular-resource.min.js',
    'src/main/webapp/resources/lib/angular-route.min.js',
    'src/main/webapp/resources/lib/angular-touch.min.js',
    'src/main/webapp/resources/lib/angular-aria.min.js',
    'src/main/webapp/resources/lib/angular-sanitize.min.js',
    'src/main/webapp/resources/lib/angular-recaptcha.min.js',
    'src/main/webapp/resources/lib/angulartics.min.js',
    'src/main/webapp/resources/lib/angulartics-ga.min.js',
    'src/main/webapp/resources/lib/angular-touch.min.js',
    'src/main/webapp/resources/lib/lodash.min.js',
    'src/main/webapp/resources/lib/moment.min.js',
    'src/main/webapp/resources/lib/ng-file-upload.min.js',
    'src/main/webapp/resources/lib/ui-bootstrap-tpls.min.js',
    'src/main/webapp/resources/lib/jspdf.min.js',
    'src/main/webapp/resources/lib/jspdf.plugin.autotable.js',
    'src/main/webapp/resources/lib/angular-file-saver.bundle.min.js',
    'src/main/webapp/resources/lib/textAngular-rangy.min.js',
    'src/main/webapp/resources/lib/textAngular.min.js',
    'src/main/webapp/resources/lib/ng-tags-input.js'
  ])
    .pipe(concat('vendor.js'))
    .pipe(gulp.dest('src/main/webapp/resources/lib/'));
});

gulp.task('js:scripts', function (done) {
  return gulp.src([
    'src/main/webapp/resources/scripts/app.js',
    'src/main/webapp/resources/lib/uc-sidemenu.js',
    'src/main/webapp/resources/lib/uc-profile-modal.js',
    'src/main/webapp/resources/scripts/services/*.js',
    'src/main/webapp/resources/scripts/interceptors/*.js',
    'src/main/webapp/resources/scripts/directives/*.js',
    'src/main/webapp/resources/scripts/directives/**/*.js',
    'src/main/webapp/resources/scripts/filters/*.js',
    'src/main/webapp/resources/scripts/utils/*.js',
    'src/main/webapp/resources/scripts/components/**/*.js',
    'src/main/webapp/resources/scripts/controllers/**/*.js'
  ])
    .pipe(concat('build.js'))
    .pipe(gulp.dest('src/main/webapp/resources/scripts/'));
});

gulp.task('templates', function (done) {
  return gulp.src('src/main/webapp/resources/scripts/controllers/**/*.html')
    .pipe(templateCache({module: 'app', root: '${pageContext.request.contextPath}/resources/scripts/controllers/'}))
    .pipe(gulp.dest('src/main/webapp/resources/scripts/'));
});

gulp.task('build', ['clean', 'sass', 'js:lib', 'js:scripts', 'templates'], function (done) {

  return gulp.src(['src/main/webapp/WEB-INF/views/home.jsp'])
    .pipe(inject(gulp.src('src/main/webapp/resources/lib/vendor.js', {read: false}),
      {
        ignorePath: '/src/main/webapp/',
        addPrefix: '${pageContext.request.contextPath}',
        addRootSlash: false,
        starttag: '<!-- inject:vendor:{{ext}} -->'
      }))
    .pipe(inject(gulp.src(['src/main/webapp/resources/scripts/build.js', 'src/main/webapp/resources/scripts/templates.js'], {read: false}),
      {ignorePath: '/src/main/webapp/', addPrefix: '${pageContext.request.contextPath}', addRootSlash: false}))
    .pipe(gulp.dest('src/main/webapp/WEB-INF/views/'));
});

gulp.task('changelog', function () {
  var options = {
    repository: 'https://ysdamani@bitbucket.org/ucd-itservices/rad-safety.git',
    version: require('./package.json').version
  };
  changelog(options, function (error, log) {
    fs.writeFile("./CHANGELOG.md", log, function (error) {
      if (error) {
        gutil.log(gutil.colors.red('fail' + ': ' + error));
      } else {
        gutil.log(gutil.colors.green('Success'));
        return '';
      }
    });
  });
});
