# README #

NEEDS DESC

## How to run/test this project ##

### Requirement(s) ###

* Java 8
* IntelliJ / Eclipse
* MySQL
* MySQL Workbench (optional)

### How do I get set up? ###

* Check out this project using following command
```sh
git clone git@bitbucket.org:ucd-itservices/rad-safety.git
```
* Open it in Intelli J / Eclipse
* Check the project configuration to make sure it is using Java 8
* Run the project using : mvn tomcat7:run


### Automated Java Tests ###
* Run following command inside your project home.
```sh
mvn clean test
mvn clean integration-test
```

### Packaging And Uploading ###

* clean up the project using the following command :
```sh
mvn clean release:clean
```
* prepare : runs all the tests; tags the project and creates a package :
```sh
mvn release:prepare -Prelease -Darguments="-Dspring.profiles.active=local"
```
* perform : uploads the package to artifactory
```sh
mvn release:perform -Prelease -Darguments="-Dspring.profiles.active=local -Dmaven.javadoc.skip=true -DskipTests=true"
```
* Exceptions : To skip Java Tests OR JavaDoc creation - use this command :
```sh
mvn release:perform -Prelease -Darguments="-Dspring.profiles.active=local -Dmaven.javadoc.skip=true -DskipTests=true -Dmaven.exec.skip=true"
```

### Deploying on Dev Docker ###

* Login to dev6 and prepare for build
```sh
ssh {userName}@dev6.uctechnology.ucdavis.edu
cd /srv/docker-kaizen/rad
sudo vi DockerFile
```
* Update ENV version with the latest deployed war file version and save it : 
ENV version x.x.x // version

```sh
sudo vi radiation-dev.xml
```

* Update radsafety war file version with the latest deployed war file version and save it : 
```sh
<Context path="/radiation-dev" docBase="/srv/wars/radsafety-x.x.x.war" reloadable="true"> // version
```

* stop the old docker image (if any running) and remove it
```sh
sudo docker-compose stop rad     //stop the image
sudo docker-compose rm rad     //remove old image
```
* build a new image and run it
```sh
sudo docker-compose build --no-cache rad    //build a new image without using cache
sudo docker-compose up -d rad      // run the image in background (deamon)
```
* Verify its working on docker
```sh
sudo docker-compose ps      //will show the running images
```
* Verify it on browser at :
```sh
https://internal.itsvc.ucdavis.edu/radiation-dev/#/
```