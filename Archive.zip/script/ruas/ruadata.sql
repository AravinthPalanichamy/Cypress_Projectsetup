alter table ua add column rua varchar(25);



CREATE TABLE temp_rrua  ( 
	rua       	varchar(25) NULL;
	lastname  	varchar(50) NULL;
	firstname 	varchar(50) NULL;
	pi_email  	varchar(50) NULL;
	staffmail 	varchar(50) NULL;
	department	varchar(25) NULL;
	dept_code 	varchar(25) NULL;
	hrc       	varchar(25) NULL;
	billed    	varchar(25) NULL;
	rechargeno	varchar(25) NULL;
	scheddate 	varchar(25) NULL;
	renewalmo 	varchar(25) NULL;
	lstrendate	varchar(25) NULL;
	term      	varchar(25) NULL;
	termdate  	varchar(25) NULL;
	invqtr    	varchar(25) NULL;
	invdate   	varchar(25) NULL;
	letsentq  	varchar(25) NULL;
	rptflag   	varchar(25) NULL;
	hgv       	varchar(25) NULL;
	afactor   	varchar(25) NULL;
	nusers    	varchar(25) NULL;
	pitp      	varchar(25) NULL;
	paudits   	varchar(25) NULL;
	netid     	varchar(25) NULL;
	eppn      	varchar(50) NULL;
	bundleid  	varchar(100) NULL;
	bundlename	varchar(100) NULL ;
	chart varchar(25) null;
	account varchar(25) null;
	subaccount varchar(25) null;
	billingid varchar(25) null
	);



CREATE TABLE temp_bundle_location  ( 
	bundleid     	varchar(100) NULL;
	buildingkey  	varchar(50) NULL;
	floorkey     	varchar(50) NULL;
	roomkey      	varchar(50) NULL;
	building_name	varchar(100) NULL;
	floor_name   	varchar(100) NULL;
	room_number    	varchar(100) NULL
	);



CREATE TABLE temp_bundle_person  ( 
	bundleid  	varchar(100) NULL;
	eppn      	varchar(50) NULL;
	first_name	varchar(50) NULL;
	last_name 	varchar(50) NULL;
	email     	varchar(50) NULL 
	);



CREATE TABLE temp_rruaisos  ( 
	rua        	varchar(25) NULL;
	isotope    	varchar(25) NULL;
	posslimmci 	float NULL;
	explimmci  	float NULL;
	chemform   	varchar(8000) NULL;
	protocol   	varchar(25) NULL;
	speccond   	varchar(25) NULL;
	ufactor    	varchar(25) NULL;
	isotope_map	varchar(25) NULL 
	);


CREATE TABLE temp_rruassrc  ( 
	rua        	varchar(25) NULL;
	hrc        	varchar(11) NULL;
	id         	varchar(25) NULL;
	isotope    	varchar(25) NULL;
	mci        	float NULL;
	building   	varchar(25) NULL;
	room       	varchar(25) NULL;
	notes      	varchar(1000) NULL;
	scheddate  	varchar(25) NULL;
	lastdate   	varchar(25) NULL;
	ufactor    	varchar(25) NULL;
	isotope_map	varchar(25) NULL 
	);


CREATE TABLE temp_ractdos  ( 
	lastname  	varchar(50) NULL;
	firstname 	varchar(50) NULL;
	rua       	varchar(25) NULL;
	department	varchar(25) NULL;
	socsecno  	varchar(25) NULL;
	group1    	varchar(25) NULL;
	startdate 	varchar(25) NULL;
	enddate   	varchar(25) NULL;
	dob       	varchar(25) NULL;
	letsent   	varchar(25) NULL;
	termdate  	varchar(25) NULL;
	classreq  	varchar(25) NULL;
	userstat  	varchar(25) NULL;
	hletsent  	varchar(25) NULL;
	htermdate 	varchar(25) NULL;
	huserstat 	varchar(25) NULL;
	bua       	varchar(25) NULL;
	eidsid    	varchar(25) NULL 
	);


	CREATE TABLE temp_badges  (
	lastname 	varchar(25) NULL;
	firstname	varchar(25) NULL;
	recharge 	varchar(25) NULL;
	building 	varchar(25) NULL;
	group1   	varchar(25) NULL;
	bodyloc  	varchar(25) NULL;
	frequency	varchar(25) NULL;
	trainsucp	varchar(25) NULL;
	chart       varchar(25) null;
	account     varchar(25) null;
	subaccount  varchar(25) null;
	billingid   varchar(25) null
	);

load data local infile 'temp_rrua.csv' into table temp_rrua
 fields terminated by '^'
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines
(rua; lastname; firstname; pi_email; staffmail; department; dept_code; hrc; billed; rechargeno; scheddate; renewalmo; lstrendate; term; termdate; invqtr; invdate; letsentq; rptflag; hgv; afactor; nusers; pitp; paudits; netid;eppn; bundleid; bundlename; chart; account; subaccount; billingid);


load data local infile 'rua_bundle_location.csv' into table temp_bundle_location
 fields terminated by '^'
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines
(bundleid;buildingkey;floorkey;roomkey;building_name;floor_name;room_number);


load data local infile 'rua_bundle_people.csv' into table temp_bundle_person
 fields terminated by '^'
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines
(bundleid;eppn;first_name;last_name;email);


load data local infile 'temp_rua_isos.csv' into table temp_rruaisos  
 fields terminated by '^'
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines
(rua;isotope;posslimmci;explimmci;chemform; protocol; speccond; ufactor; isotope_map);


load data local infile 'temp_rua_ssrc.csv' into table temp_rruassrc  
 fields terminated by '^'
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines
(rua;hrc;id;isotope;mci; building; room; notes; scheddate; lastdate; ufactor; isotope_map);



load data local infile 'temp_ractdos.csv' into table temp_ractdos  
 fields terminated by '^'
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines
(lastname;firstname;rua;department;socsecno; group1; startdate; enddate; dob; letsent; termdate; classreq;userstat;hletsent; htermdate;huserstat;bua;eidsid);


load data local infile 'tempbadges.csv' into table temp_badges
 fields terminated by '^'
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines
(lastname;firstname; recharge; building;group1;bodyloc;frequency;trainsucp; chart; account; subaccount;billingid);


insert into person (eppn; first_name; last_name; campus_code; email; dob)
select distinct trim(LOWER(eppn)); trim(LOWER(x.firstname)); trim(LOWER(x.lastname)); '03'; LOWER(pi_email);
case when dob ='-   -' then null 
     else  str_to_date (concat(SUBSTRING(dob ;1;7);'19';SUBSTRING(dob;8;2));'%d-%b-%Y') end dob
from temp_rrua x
left join temp_ractdos r on trim(x.firstname) = trim(r.firstname) and trim(x.lastname) = trim(r.lastname)
where not exists (select * from person p where trim(x.eppn) = trim(p.eppn))
and x.eppn is not null and x.eppn > '' and x.bundleid is not null and x.bundleid > '';


insert into person (eppn; first_name; last_name; campus_code; email; dob)
select distinct trim(LOWER(eppn)); trim(LOWER(x.first_name)); trim(LOWER(x.last_name)); '03'; LOWER(email);
case when dob ='-   -' then null 
     else  str_to_date (concat(SUBSTRING(dob ;1;7);'19';SUBSTRING(dob;8;2));'%d-%b-%Y') end dob
from temp_bundle_person x
left join temp_ractdos r on trim(x.first_name) = trim(r.firstname) and trim(x.last_name) = trim(r.lastname)
where not exists (select * from person p where trim(x.eppn) = trim(p.eppn))
and x.eppn is not null and x.eppn > '';

insert into location(building_display_name; building_key; building_primary_name; campus_code; floor_key; floor_name; room_key; room_number)
select distinct building_name; trim(buildingkey); building_name; '03'; trim(floorkey); floor_name; trim(roomkey); room_number from temp_bundle_location tl
where not exists (select * from location l where trim(tl.buildingkey) = trim(l.building_key) and trim(tl.floorkey) =trim( l.floor_key) and trim(tl.roomkey) = trim(l.room_key) and l.campus_code = '03');

insert into core_bundle (cs_id; name; pi_person_id)
select trim(r.bundleid); r.bundlename; p.id from temp_rrua r
join person p on trim(r.eppn) = trim(p.eppn)
where r.bundleid is not null and r.bundleid > '' and not exists (select * from core_bundle c where trim(c.cs_id) = trim(r.bundleid));

insert into core_bundle_location (core_bundle_id; location_id)
select cb.id; l.id from core_bundle cb
join person p on cb.pi_person_id = p.id
join temp_rrua r on trim(p.eppn) = trim(r.eppn)  and trim(r.bundleid) = trim(cb.cs_id)
join temp_bundle_location tl on trim(r.bundleid) = trim(tl.bundleid)
join location l on trim( l.building_key) = trim(tl.buildingkey) and trim(l.floor_key) = trim(tl.floorkey) and trim(l.room_key) = trim(tl.roomkey)
where l.campus_code = '03' and not exists (select * from core_bundle_location cbl where cbl.core_bundle_id = cb.id and cbl.location_id = l.id);

insert into core_bundle_person (core_bundle_id; person_id)
select b.id; p.id from temp_bundle_person tp
join person p on trim(tp.eppn) = trim(p.eppn)
join core_bundle b on trim(b.cs_id)  = trim(tp.bundleid)
where not exists (select * from  core_bundle_person cbp where cbp.core_bundle_id = b.id and cbp.person_id = p.id);

insert into account(account_number; sub_account_number; chart_number; billing_id; is_active)
select distinct trim(account); trim(subaccount); trim(chart); trim(billingid); 1 from temp_rrua where bundleid is not null and bundleid > ''and account is not null and account > ''
and not exists( select * from account a where trim(a.account_number) = trim(account) and trim(a.sub_account_number) = trim(subaccount) and trim(a.chart_number) = trim(chart));

insert into ua( created_date; last_modified_date; status_type; type; expiry_date; created_by; last_modified_by; pi_person_id; is_active; is_monitoring_required;  number; hazard_rating;rua; account_id)
select curdate(); curdate(); 'DRAFT'; 'RUA'; str_to_date(scheddate; '%d-%b-%y') + INTERVAL 1 year; 1;1; p.id; 1;
 case when s1.monitoring > 0 then 1 else 0 end monitoring_required;
 r.rua;
case when r.hrc = '0' then '1a'
     when r.hrc = '1' then '1b'
     when r.hrc = '2' then '2'
     when r.hrc = '3' then '3'
     when r.hrc = '4' then '4' end hazard_rating;
 r.rua; a.account_id
from temp_rrua r join person p on trim(r.eppn) = trim(p.eppn)
left join account a on trim(a.account_number) = trim(r.account) and trim(a.chart_number) = trim(r.chart) and trim(a.sub_account_number) = trim(r.subaccount)
join (select r.rua; count(tb.lastname) + count(tb2.lastname) monitoring
from temp_rrua r
join temp_ractdos rd on r.rua = rd.rua
left join temp_badges tb on tb.lastname = r.lastname and tb.firstname = r.firstname
left join temp_badges tb2 on tb2.lastname = rd.lastname and tb2.firstname = rd.firstname
where bundleid is not null and bundleid > ''
group by r.rua ) as S1 on s1.rua = r.rua
where bundleid is not null and bundleid > '' and not exists (select * from ua u where u.number = r.rua);

insert into ua_bundle(cs_id; name; ua_id; pi_dosimetry_account_id)
select r.bundleid; r.bundlename; ua.id; a.account_id
from temp_rrua r
join ua on trim(ua.rua) = trim(r.rua)
join person p on trim(r.eppn) = trim(p.eppn)
left join account a on trim(a.account_number) = trim(r.account) and trim(a.chart_number) = trim(r.chart) and trim(a.sub_account_number) = trim(r.subaccount)
where bundleid is not null and bundleid > '' and not exists (select * from ua_bundle uab where uab.cs_id = r.bundleid and uab.ua_id = ua.id);

insert into ua_bundle_location(location_id; ua_bundle_id)
select l.id; uab.id
from temp_rrua r
join ua on ua.rua = r.rua
join ua_bundle uab on ua.id = uab.ua_id
join temp_bundle_location tbl on trim(r.bundleid) =trim(tbl.bundleid)
join  location l on trim(tbl.buildingkey) = trim(l.building_key) and trim(tbl.roomkey) = trim(l.room_key) and trim(tbl.floorkey) = trim(l.floor_key)
where l.campus_code = '03' and not exists (select * from ua_bundle_location ubl where ubl.location_id = l.id and ubl.ua_bundle_id = uab.id);

insert into ua_bundle_person(person_id; ua_bundle_id; is_authorized_to_work; dosimetry_account_id)
select p.id; uab.id; '1'; a.account_id
from temp_rrua r
join ua on trim(ua.rua) = trim(r.rua)
join ua_bundle uab on ua.id = uab.ua_id
join temp_bundle_person bp on trim(bp.bundleid) = trim(r.bundleid)
join person p on trim(bp.eppn) = trim(p.eppn)
left join account a on trim(a.account_number) = trim(r.account) and trim(a.chart_number) = trim(r.chart) and trim(a.sub_account_number) = trim(r.subaccount)
where not exists (select * from ua_bundle_person ubp where ubp.person_id = p.id and ubp.Ua_bundle_id = uab.id);

insert into ua_planned_work (chemical_form; experiment_possession_limit; is_sealed_source; purpose_type; requested_possession_limit; research_type; radionuclide_id; ua_id; physical_form_id; unit; vial_possession_limit)
select
substring(chemform; 1; 50);
explimmci;
0;
'RESEARCH';
posslimmci;
'NON_HUMAN';
r.radionuclide_id;
ua.id;
case when chemform like '%POWDER%' then 1
     when chemform like '%SOLID%' then 2
     when chemform like '%LIQUID%' then 3
     when chemform like '%GAS%' then 4
     else 5 end physical_form_id;
1;
posslimmci
from temp_rruaisos i
join radionuclide r on trim(i.isotope_map) = trim(r.name)
join ua on trim(ua.rua) = trim(i.rua)
where ua.rua is not null and ua.rua > '';


insert into ua_planned_work (chemical_form;single_source_limit; experiment_possession_limit; is_sealed_source; purpose_type; requested_possession_limit; research_type; radionuclide_id; ua_id; physical_form_id; unit)
select 'SEALED SOURCE'; mci; mci; 1; 'RESEARCH'; mci; 'NON_HUMAN'; r.radionuclide_id; ua.id; 2;1
from temp_rruassrc ss
join radionuclide r on trim(ss.isotope_map) = trim(r.name)
join ua on trim(ua.rua) = trim(ss.rua)
where ua.rua is not null and ua.rua > '';


insert into monitor_person(person_id; ua_id; monitor_type_id; effective_from_date; effective_to_date; effective_from_assigned_by; effective_to_assigned_by)
select distinct p.id; b.ua_id;
case when bodyloc = 'WB' then 3
     when bodyloc = 'FR' then 2
     when bodyloc = 'FL' then 1
     when bodyloc = 'WR' then 4
     when bodyloc = 'FT' then 10 end monitor;
 curdate(); str_to_date('12/31/2099'; '%m/%d/%Y') ;1;1  from temp_badges tm
join person p on trim(tm.firstname) = trim(p.first_name) and trim(tm.lastname) = trim(p.last_name)
join ua_bundle_person bp on p.id = bp.person_id
join ua_bundle b on bp.ua_bundle_id = b.id
where bodyloc in ('FL'; 'FR'; 'WB'; 'WR'; 'FT')
and not exists (select * from monitor_person mp where mp.person_id = p.id and mp.ua_id = b.ua_id and mp.monitor_type_id in (3; 2; 1; 4; 10));


insert into monitor_person(person_id; ua_id; monitor_type_id; effective_from_date; effective_to_date; effective_from_assigned_by; effective_to_assigned_by)
select distinct p.id;ua.id;
case when bodyloc = 'WB' then 3
     when bodyloc = 'FR' then 2
     when bodyloc = 'FL' then 1
     when bodyloc = 'WR' then 4
     when bodyloc = 'FT' then 10 end monitor;
 curdate(); str_to_date('12/31/2099'; '%m/%d/%Y') ;1;1
from temp_badges tm
join person p on trim(tm.firstname) = trim(p.first_name) and trim(tm.lastname) = trim(p.last_name)
join temp_rrua rr on trim(rr.firstname) = trim(tm.firstname) and trim(rr.lastname) = trim(tm.lastname)
join ua on trim(ua.rua) = (rr.rua)
where bodyloc in ('FL'; 'FR'; 'WB'; 'WR'; 'FT')
and not exists (select * from monitor_person mp where mp.person_id = p.id and mp.ua_id = ua.id and mp.monitor_type_id in (3; 2; 1; 4; 10));

-- Resetting schema tables to original state by removing temp tables and columns.

alter table ua drop column rua;

drop table temp_rrua;

drop table temp_bundle_location;

drop table temp_bundle_person;

drop table temp_rruaisos;

drop table temp_rruassrc;

drop table temp_ractdos;

drop table temp_badges;      