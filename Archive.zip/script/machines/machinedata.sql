alter table machine add column mua varchar(25);
alter table ua add column mua varchar(25);

CREATE TABLE temp_xrray  ( 
	rua       	varchar(25) NULL;
	lastname  	varchar(50) NULL;
	firstname 	varchar(50) NULL;
	department	varchar(50) NULL;
	dept_code 	varchar(25) NULL;
	co_pi1    	varchar(25) NULL;
	rechargeno	varchar(25) NULL;
	building  	varchar(50) NULL;
	room      	varchar(25) NULL;
	typemachin	varchar(25) NULL;
	machcode  	varchar(25) NULL;
	billed    	int(11) NULL;
	purpose   	varchar(25) NULL;
	manufact  	varchar(25) NULL;
	tmanufact 	varchar(25) NULL;
	model     	varchar(25) NULL;
	tmodel    	varchar(25) NULL;
	ucdno     	varchar(25) NULL;
	serialno  	varchar(25) NULL;
	tserialno 	varchar(25) NULL;
	maxma     	int(11) NULL;
	maxkvp    	int(11) NULL;
	normkvp   	int(11) NULL;
	normma    	varchar(25) NULL;
	scheddate 	varchar(25) NULL;
	lastdate  	varchar(25) NULL;
	term      	varchar(25) NULL;
	termdate  	varchar(25) NULL;
	comments  	varchar(8000) NULL;
	collimator	varchar(25) NULL;
	cntlmanu  	varchar(25) NULL;
	tubeyear  	varchar(25) NULL;
	cntlmodel 	varchar(25) NULL;
	cntrserl  	varchar(25) NULL;
	eppn      	varchar(50) NULL 
	);

load data local infile 'xxraywitheppn.csv' into table temp_xrray
 fields terminated by '^'
 enclosed by '"'
 lines terminated by '\n'
 ignore 1 lines
(rua; lastname; firstname; department; dept_code; co_pi1; rechargeno; building; room; typemachin; machcode; billed; purpose ; manufact; tmanufact; model; tmodel; ucdno; serialno; tserialno ;maxma; maxkvp;normkvp;normma;scheddate;lastdate;term;termdate;comments;collimator;cntlmanu;tubeyear;cntlmodel;cntrserl;eppn);


insert into person (eppn; first_name; last_name; campus_code)
select distinct eppn; firstname; lastname; '03' from temp_xrray x
where not exists (select * from person p where x.eppn = p.eppn)
and x.eppn is not null and x.eppn > '';


insert into machine (type; model; manufacturer; serial_number; max_ma; max_kvp; norm_ma; norm_kvp; mua)
select typemachin; model; manufact;serialno; maxma; maxkvp; normma; normkvp; rua from temp_xrray;


insert into ua( created_date; last_modified_date; status_type; type; expiry_date; created_by; last_modified_by; pi_person_id; is_active; is_monitoring_required; mua)
select curdate(); curdate(); 'DRAFT'; 'MUA'; str_to_date(scheddate; '%d-%b-%y') ; 1;1; p.id; 1; 0 ; rua from temp_xrray x join person p on x.eppn = p.eppn;

insert into machine_planned_work (machine_id; ua_id)
select m.machine_id; u.id from machine m join ua u on m.mua = u.mua ;


alter table machine drop column mua;
alter table ua drop column mua;

drop table temp_xrray;